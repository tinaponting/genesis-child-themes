<?php
remove_action( 'genesis_loop', 'genesis_do_loop' );
add_action( 'genesis_loop', 'tech_magazine_home_loop' );

function tech_magazine_home_loop() {

	if ( is_active_sidebar( 'home-page-top' ) || is_active_sidebar( 'home-page-left' ) || is_active_sidebar( 'home-page-right' ) || is_active_sidebar( 'home-page-bottom' ) ) {

		if ( is_active_sidebar( 'home-page-top' ) ) {
			echo '<div class="home-page-top">';
			dynamic_sidebar( 'home-page-top' );
			echo '</div><!-- end .home-page-top -->';
		}

		if ( is_active_sidebar( 'home-page-left' ) || is_active_sidebar( 'home-page-right' ) ) {

			echo '<div class="home-page-mid">';

			if ( is_active_sidebar( 'home-page-left' ) ) {
				echo '<div class="home-page-left">';
				dynamic_sidebar( 'home-page-left' );
				echo '</div><!-- end .home-page-left -->';
			}

			if ( is_active_sidebar( 'home-page-right' ) ) {
				echo '<div class="home-page-right">';
				dynamic_sidebar( 'home-page-right' );
				echo '</div><!-- end .home-page-right -->';
			}
		
			echo '</div><!-- end .home-page-mid -->';
		
		}
		
		if ( is_active_sidebar( 'home-page-bottom' ) ) {
			echo '<div class="home-page-bottom">';
			dynamic_sidebar( 'home-page-bottom' );
			echo '</div><!-- end .home-page-bottom -->';
		}
		
	}
	
	else {
		genesis_standard_loop();
	}
	
}

genesis();