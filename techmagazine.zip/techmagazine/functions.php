<?php
//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );

//* Child theme (do not remove)
define( 'CHILD_THEME_NAME', 'TechMagazine 2 Child Theme' );

//* Add HTML5 markup structure
add_theme_support( 'html5' );

//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Add support for custom background
add_theme_support( 'custom-background' );

//* Add support for 3-column footer widgets
add_theme_support( 'genesis-footer-widgets', 3 );

//* Reposition the primary navigation menu
remove_action( 'genesis_after_header', 'genesis_do_nav' );
add_action( 'genesis_before_header', 'genesis_do_nav' );

//* Add post navigation (requires HTML5 theme support)
add_action( 'genesis_entry_footer', 'genesis_prev_next_post_nav', 15 );

/** Support for different color style options */
add_theme_support( 'genesis-style-selector', array(
	'magazine-blue'		=> 'Blue',
	'magazine-green'	=> 'Green',
	'magazine-red'		=> 'Red',
	'magazine-black'		=> 'Black'
) );

/** Support for various Image sizes */
add_image_size('home', 300, 280, TRUE);
add_image_size('post-image', 600, 300, TRUE );
add_image_size('home-page-bottom', 220, 180, TRUE);
add_image_size('sidebar-featured', 300, 140, TRUE);

/** Reposition the secondary navigation menu */
remove_action( 'genesis_after_header', 'genesis_do_subnav' );
add_action( 'genesis_before', 'genesis_do_subnav' );

//* Enqueue Lato Google font
add_action( 'wp_enqueue_scripts', 'genesis_sample_google_fonts' );
function genesis_sample_google_fonts() {
	wp_enqueue_style( 'google-font-lato', '//fonts.googleapis.com/css?family=Lora:400,700,400italic|PT+Sans:400,700', array(), CHILD_THEME_VERSION );
}

/** Support of Fixed Menu at tht Top */
add_action( 'wp_enqueue_scripts', 'custom_enqueue_script' );
function custom_enqueue_script() {
	wp_enqueue_script( 'sticky-menu', get_stylesheet_directory_uri() . '/js/sticky-menu.js', array( 'jquery' ), '', true );
}

/* Code to Display Featured Image on top of the post */
add_action( 'genesis_before_entry', 'ibfy_post_image', 8 );
function ibfy_post_image() {
  if ( ! is_singular( 'post' ) )  return;
	the_post_thumbnail('post-image');
}

/** Footer Copyright notice */
add_filter('genesis_footer_output', 'footer_output_filter', 10, 3);
function footer_output_filter( $output, $backtotop_text, $creds_text ) {
    $creds_text = '<p>Copyright [footer_copyright] - <a href="'. trailingslashit( get_bloginfo('url') ) .'" title="'. esc_attr( get_bloginfo('name') ) .'" rel="dofollow">'.get_bloginfo('name').'</a>';
	  $output = '<div class="gototop"> [footer_backtotop text="Return to Top" href="#"] </div>' . '<div class="creds">' . $creds_text . ' | design by <a href="http://exempel.se">MY OWN DESIGN</a></p></div>' ;
      return $output;
}

/** Customize breadcrumbs display */
add_filter( 'genesis_breadcrumb_args', 'balance_breadcrumb_args' );
function balance_breadcrumb_args( $args ) {
	$args['home'] = 'Home';
	$args['sep'] = ' ';
	$args['list_sep'] = ', '; // Genesis 1.5 and later
	$args['prefix'] = '<div class="breadcrumb"><div class="wrap">';
	$args['suffix'] = '</div></div>';
	$args['labels']['prefix'] = '<span class="home">You are here :</span>';
	return $args;
}

/**
 * Register and Enqueue Primary Navigation Menu Script
 */
function gst_primarymenu_script() { 	
	wp_register_script( 'primary-menu', get_stylesheet_directory_uri() . '/js/primarymenu.js', array('jquery'), '1.0.0', false );
	wp_enqueue_script( 'primary-menu' );
 }
add_action('wp_enqueue_scripts', 'gst_primarymenu_script');

// Register Genesis Menus
add_theme_support ( 'genesis-menus' , array ( 'primary' => 'Primary Navigation Menu' , 'secondary' => 'Secondary Navigation Menu' ,'mobile' => 'Main Navigation Menu' ) );

// Add Support for Structural Wraps
add_theme_support( 'genesis-structural-wraps', array( 'header', 'menu-mobile', 'menu-primary', 'menu-secondary', 'footer-widgets', 'footer' ) );

add_action( 'genesis_after_header', 'gst_do_mobilenav' );

function gst_do_mobilenav() {

	//* Do nothing if menu not supported
	if ( ! genesis_nav_menu_supported( 'mobile' ) )
		return;

	//* If menu is assigned to theme location, output
	if ( has_nav_menu( 'mobile' ) ) {

		$class = 'menu genesis-nav-menu menu-mobile';
		if ( genesis_superfish_enabled() )
			$class .= ' js-superfish';

		$args = array(
			'theme_location' => 'mobile',
			'container'      => '',
			'menu_class'     => $class,
			'echo'           => 0,
		);

		$mobilenav = wp_nav_menu( $args );

		//* Do nothing if there is nothing to show
		if ( ! $mobilenav )
			return;

		$mobilenav_markup_open = genesis_markup( array(
			'html5'   => '<nav %s>',
			'xhtml'   => '<div id="mobilenav">',
			'context' => 'nav-mobile',
			'echo'    => false,
		) );
		
		$mobilenav_markup_open .= genesis_structural_wrap( 'menu-mobile', 'open', 0 );

		$mobilenav_markup_close  = genesis_structural_wrap( 'menu-mobile', 'close', 0 );
		$mobilenav_markup_close .= genesis_html5() ? '</nav>' : '</div>';

		$mobilenav_output = $mobilenav_markup_open . $mobilenav . $mobilenav_markup_close;

		echo apply_filters( 'gst_do_mobilenav', $mobilenav_output, $mobilenav, $args );

	}
}

add_filter( 'genesis_attr_nav-mobile', 'gst_attributes_nav_mobile' );
function gst_attributes_nav_mobile( $attributes ) {

	$attributes['role']      = 'navigation';
	$attributes['itemscope'] = 'itemscope';
	$attributes['itemtype']  = 'http://schema.org/SiteNavigationElement';

	return $attributes;
}


/** Register widget areas */
genesis_register_sidebar( array(
	'id'				=> 'home-page-top',
	'name'			=> __( 'Home Page Top', 'techmagazine' ),
	'description'	=> __( 'Place widgets to display in Home Page Top Section.', 'techmagazine' ),
) );
genesis_register_sidebar( array(
	'id'				=> 'home-page-left',
	'name'			=> __( 'Home Page Left', 'techmagazine' ),
	'description'	=> __( 'Place widgets to display in Home Page Middle Left Section.', 'techmagazine' ),
) );
genesis_register_sidebar( array(
	'id'				=> 'home-page-right',
	'name'			=> __( 'Home Page Right', 'techmagazine' ),
	'description'	=> __( 'Place widgets to display in Home Page Middle Right Section', 'techmagazine' ),
) );
genesis_register_sidebar( array(
	'id'				=> 'home-page-bottom',
	'name'			=> __( 'Home Page Bottom', 'techmagazine' ),
	'description'	=> __( 'Place widgets to display in Home Page Bottom Section', 'techmagazine' ),
) );