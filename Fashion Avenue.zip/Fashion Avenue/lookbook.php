<?php
/**
 * This file adds the lookbook to the Theme.
 * @author Brad Dalton
 * @subpackage Customizations
 */
/*
Template Name: Lookbook Page
*/
add_action( 'genesis_meta', 'mpp_lookbook_page' );
/**
 * Add widget support for homepage. If no widgets active, display the default loop.
 *
 */
function mpp_lookbook_page() {
	if ( is_active_sidebar( 'page-lookbook' ) ) {
		// Force content-sidebar layout setting
		add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );
		// Add mpp-home body class
		add_filter( 'body_class', 'mpp_body_class' );
		// Remove the default Genesis loop
		remove_action( 'genesis_loop', 'genesis_do_loop' );
		// Add homepage widgets
		add_action( 'genesis_loop', 'mpp_lookbook_page_widget' );
	}
}
function mpp_body_class( $classes ) {
	$classes[] = 'mpp-home';
	return $classes;
	
}
function mpp_lookbook_page_widget() {
	genesis_widget_area( 'page-lookbook', array(
		'before' => '<div id="lookbook"><div class="wrap">',
		'after'  => '</div></div>',
	) );
}
genesis();