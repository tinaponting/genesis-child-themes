<?php
//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );

//* Child theme (do not remove)
define( 'CHILD_THEME_NAME', 'Genesis Sample Theme' );
define( 'CHILD_THEME_URL', 'http://www.studiopress.com/' );
define( 'CHILD_THEME_VERSION', '2.1.2' );

//* Enqueue Google Fonts
add_action( 'wp_enqueue_scripts', 'genesis_sample_google_fonts' );
function genesis_sample_google_fonts() {

	wp_enqueue_style( 'google-fonts', '//fonts.googleapis.com/css?family=Lato:300,400,700', array(), CHILD_THEME_VERSION );

}

//* Add HTML5 markup structure
add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list' ) );

//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Add support for custom background
add_theme_support( 'custom-background' );

//* Add support for 3-column footer widgets
add_theme_support( 'genesis-footer-widgets', 3 );

//Add in new Widget areas
function themeprefix_extra_widgets() {
	genesis_register_sidebar( array(
	'id'            => 'slider',
	'name'          => __( 'Slider', 'genesischild' ),
	'description'   => __( 'This is the Slider area', 'genesischild' ),
	'before_widget' => '<div class="wrap slider">',
	'after_widget'  => '</div>',
	) );
}
add_action( 'widgets_init', 'themeprefix_extra_widgets' );

//Position the slider Area
function themeprefix_slider_widget() {
	if( is_front_page() ) {
	genesis_widget_area ( 'slider', array(
	'before' => '<aside class="slider-container">',
	'after'  => '</aside>',));
	}
}

add_action( 'genesis_after_header','themeprefix_slider_widget' );

// Use shortcodes in text widgets.
add_filter( 'widget_text', 'do_shortcode' );

/**
 * Remove Image Alignment from Featured Image
 *
 */
function be_remove_image_alignment( $attributes ) {
  $attributes['class'] = str_replace( 'alignleft', 'alignnone', $attributes['class'] );
	return $attributes;
}
add_filter( 'genesis_attr_entry-image', 'be_remove_image_alignment' );

/* Let admin upload a logo */
add_action( 'customize_register', 'cyb_logo_customize_register' );
function cyb_logo_customize_register( $wp_customize ) {
    $wp_customize->add_setting( 'eg_logo' ); // Add setting for logo uploader
         
    // Add control for logo uploader (actual uploader)
    $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'eg_logo', array(
        'label'    => __( 'Ajouter un logo (remplace le titre)', 'eg' ),
        'section'  => 'title_tagline',
        'settings' => 'eg_logo',
    ) ) );
}

remove_action( 'genesis_site_description', 'genesis_seo_site_description' );
add_action( 'genesis_site_description', 'cyb_seo_site_description' );
/**
 * Echo the site description into the header.
 *
 * Depending on the SEO option set by the user, this will either be wrapped
 * in an `h1` or `p` element.
 *
 * Applies the `genesis_seo_description` filter before echoing.
 *
 * @since 1.1.0
 *
 * @uses genesis_get_seo_option() Get SEO setting value.
 * uses genesis_html5()           Check for HTML5 support.
 */
function cyb_seo_site_description() {

	//* Set what goes inside the wrapping tags
	$inside = esc_html( get_bloginfo( 'description' ) );

	//* Wrap homepage site description in p tags if static front page
	$wrap = is_front_page() && ! is_home() ? 'p' : $wrap;

	//* And finally, $wrap in h2 if HTML5 & semantic headings enabled
	$wrap = genesis_html5() && genesis_get_seo_option( 'semantic_headings' ) ? 'h2' : $wrap;

	/**
	 * Site description wrapping element
	 *
	 * The wrapping element for the site description.
	 *
	 * @since 2.2.3
	 *
	 * @param string $wrap The wrapping element (h1, h2, p, etc.).
	 */
	$wrap = apply_filters( 'genesis_site_description_wrap', $wrap );

	//* Output (filtered)
	$output = $inside ? apply_filters( 'genesis_seo_description', $description, $inside, $wrap ) : '';

  if ( get_theme_mod( 'eg_logo' ) ) {
    printf( '<span class="hidden">%s</span>', $output );
  } else {
  	echo $output;
  }

}
remove_action( 'genesis_site_title', 'genesis_seo_site_title' );
add_action( 'genesis_site_title', 'cyb_seo_site_title' );
/**
 * Echo the site title into the header.
 *
 * Depending on the SEO option set by the user, this will either
 * be wrapped in an `h1` or `p` element.
 *
 * Applies the `genesis_seo_title` filter before echoing.
 *
 * @since 1.1.0
 *
 * @uses genesis_get_seo_option() Get SEO setting value.
 * @uses genesis_html5()          Check or HTML5 support.
 */
function cyb_seo_site_title() {

	//* Set what goes inside the wrapping tags
	$inside = sprintf( '<a href="%s">%s</a>', trailingslashit( home_url() ), get_bloginfo( 'name' ) );

	//* Wrap homepage site title in p tags if static front page
	$wrap = is_front_page() && ! is_home() ? 'p' : $wrap;

	//* And finally, $wrap in h1 if HTML5 & semantic headings enabled
	$wrap = genesis_html5() && genesis_get_seo_option( 'semantic_headings' ) ? 'h1' : $wrap;

	/**
	 * Site title wrapping element
	 *
	 * The wrapping element for the site title.
	 *
	 * @since 2.2.3
	 *
	 * @param string $wrap The wrapping element (h1, h2, p, etc.).
	 */
	$wrap = apply_filters( 'genesis_site_title_wrap', $wrap );

	//* Echo (filtered)
	$filtered_title = apply_filters( 'genesis_seo_title', $title, $inside, $wrap );

  if ( get_theme_mod( 'eg_logo' ) ) {
    $output = sprintf( '<a href="%s" ID="site-logo" title="%s" rel="home">', get_home_url(),
        esc_attr( get_bloginfo( 'name', 'display' ) ) );
    $output .= sprintf( '<img src="%s" alt="%s"></a>', get_theme_mod( 'eg_logo' ),
        esc_attr( get_bloginfo( 'name', 'display' ) ) );
    echo $output;
    echo sprintf( '<span class="hidden">%s</span>', $filtered_title );
  } else {
    echo $filtered_title;
  }

}


//* Remove secondary navigation menu
add_theme_support( 'genesis-menus', array( 'primary' => __( 'Primary Navigation Menu', 'genesis' ) ) );

//* Add new featured image sizes
add_image_size( 'sidebar', 300, 200, TRUE );

//* Remove the site footer
remove_action( 'genesis_footer', 'genesis_footer_markup_open', 5 );
remove_action( 'genesis_footer', 'genesis_do_footer' );
remove_action( 'genesis_footer', 'genesis_footer_markup_close', 15 );

//* Customize the site footer
add_action( 'genesis_footer', 'bg_custom_footer' );
function bg_custom_footer() { ?>

<div class="site-footer"><div class="wrap"><p>Cr&eacute;&eacute; avec <span class="dashicons dashicons-heart"></span> by <a href="http://www.webngirls.fr">Web & Girls</a>. Propuls&eacute; par <a href="#">WordPress et Genesis Framework</a>.</p></div></div>

<?php
}

function themeprefix_scripts_styles() { 
 wp_enqueue_script ('slicknav', '//cdn.jsdelivr.net/jquery.slicknav/1.0.1/jquery.slicknav.min.js', array( 'jquery' ),'1',false); 
 wp_enqueue_style ('slicknavcss', '//cdn.jsdelivr.net/jquery.slicknav/1.0.1/slicknav.css','', '1', 'all'); 
} 
 add_action( 'wp_enqueue_scripts', 'themeprefix_scripts_styles');

//* Remove the header right widget area
unregister_sidebar( 'header-right' );

//Responsive Nav
function themeprefix_responsive_menujs() {
	echo 	"<script>
			jQuery(function($) {
			$('#menu-menu-1').slicknav();
			});
			</script>";
}
add_action ('genesis_after','themeprefix_responsive_menujs');

genesis_register_sidebar( array(
	'id'          => 'page-lookbook',
	'name'        => __( 'Page - Lookbook','mpp' ),
	'description' => __( 'Lookbook.','mpp' ),
) );

add_image_size( 'lookbook', 350, 481, TRUE );

genesis_register_sidebar( array(
    'id' => 'before-footer',
    'name' => __( 'Pied de page Instagram', 'child' ),
    'description' => __( 'Afficher Instagram en pleine largeur - bas de page.', 'child' ),
) );


add_action( 'genesis_before_footer', 'before_footer_widget', 4 );
function before_footer_widget() {
if ( is_home() && is_active_sidebar( 'before-footer' ) ) {
		echo '<div class="before-footer">';
		dynamic_sidebar( 'before-footer' );
		echo '</div><!-- end #before-footer -->';
	}
 
}

/* Exclude post category 'lookbook' from Home Page posts */
function main_page_exclude_category_lookbook( $query ) {
    if ( $query->is_home() && $query->is_main_query() ) {
	$cat_lookbook = get_term_by('slug','lookbook','category');
        $query->set( 'cat', '-'.$cat_lookbook->term_id );
    }
}
add_action('pre_get_posts','main_page_exclude_category_lookbook');

//* Modify Read More Link
add_filter( 'excerpt_more', 'child_read_more_link' );
add_filter( 'get_the_content_more_link', 'child_read_more_link' );
add_filter( 'the_content_more_link', 'child_read_more_link' );
/**
 * Custom Read More link.
 *
 * @author Greg Rickaby
 * @since 1.0.0
 */
function child_read_more_link() {
	return '<a class="more-link" href="' . get_permalink() . '" rel="nofollow">Lire la suite</a>';
}

//* Post cats over title
function ll_post_cats () {
	if ( is_home() || is_archive() || is_single() ) { ?>
		<div class="entry-meta custom-post-cats"><?php echo do_shortcode("[post_categories before=\"\" sep=\"\"]"); ?></div>
	<?php }

}
add_filter( 'genesis_entry_header', 'll_post_cats', 8 );


