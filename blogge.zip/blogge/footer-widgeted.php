<div class="footer-widgets" id="footer-left">
	<div class="wrap">
    	<div class="footer-widgets-1">
		<div class="footer_menu_sec">
	
			<?php 
			if (genesism_get_option('footer_menu')){
			?>
			<div class="ftr_menu">
				<span class="menu_control">≡ Menu</span>
				<?php wp_nav_menu( array( 'theme_location' => 'SecondMenu','container' => false,'menu_id' => 'menu_ftr_menu' ) );?>
			</div>
			
			<?php 
			}
			?>
			
			</div>
		 </div>

   		<!-- end .footer-left -->
		

    
 
    	</div><!-- end .wrap -->
</div><!-- end #footer-widgets -->