<?php

function blogge_customize_register( $wp_customize ) {
 /*******************************************
Color scheme
********************************************/
 
// add the section to contain the settings
$wp_customize->add_section( 'textcolors' , array(
    'title' =>  'Color Scheme',
) );

// 1.Background Color
$txtcolors[] = array(
    'slug'=>'body_bg_color', 
    'default' => '#F0F0F0',
    'label' => 'Background Color'
);

 
// 2.Body Text Color
$txtcolors[] = array(
    'slug'=>'body_txt_color', 
    'default' => '#333333',
    'label' => 'Body Text Color'
);


// 3.Header Text Color
$txtcolors[] = array(
    'slug'=>'header_txt_color', 
    'default' => '#212121',
    'label' => 'Header Text Color'
);

// 4.Top Header Background
$txtcolors[] = array(
    'slug'=>'top_header_bg', 
    'default' => '#F2635D',
    'label' => 'Top Header BG Color'
);

// 5.link color
$txtcolors[] = array(
    'slug'=>'link_color', 
    'default' => '#F96302',
    'label' => 'Link Color'
);

//6.Sidebar Optin Header
$txtcolors[] = array(
    'slug'=>'sb_optin_hdr_bg', 
    'default' => '#0178bc',
    'label' => 'Sidebar Optin Header BG Color '
);

//7.Color1
$txtcolors[] = array(
    'slug'=>'color1', 
    'default' => '#f5f5f5',
    'label' => 'Color1 '
);

//8.sidebar BG
$txtcolors[] = array(
    'slug'=>'sidebar_bg', 
    'default' => '#f9f9f9',
    'label' => 'sidebar BG Color '
);

 
//9. Border color 
$txtcolors[] = array(
    'slug'=>'border_color', 
    'default' => '#EEEEEE',
    'label' => 'Border Color '
);

//10.site Footer BG
$txtcolors[] = array(
    'slug'=>'site_footer_bg', 
    'default' => '#353535',
    'label' => 'Site Footer BG Color '
);

//11.Footer Text Color
$txtcolors[] = array(
    'slug'=>'footer_text_clr', 
    'default' => '#CCCCCC',
    'label' => 'Footer Text Color '
);

//12.Hover BG
$txtcolors[] = array(
    'slug'=>'hover_bg', 
    'default' => '#363636',
    'label' => 'Hover BG Color '
);

// add the settings and controls for each color
foreach( $txtcolors as $txtcolor ) {
 
    // SETTINGS
    $wp_customize->add_setting(
        $txtcolor['slug'], array(
            'default' => $txtcolor['default'],
            'type' => 'option', 
            'capability' => 
            'edit_theme_options'
        )
    );
    // CONTROLS
    $wp_customize->add_control(
        new WP_Customize_Color_Control(
            $wp_customize,
            $txtcolor['slug'], 
            array('label' => $txtcolor['label'], 
            'section' => 'textcolors',
            'settings' => $txtcolor['slug'])
        )
    );
}
}
add_action( 'customize_register', 'blogge_customize_register' );