<?php
require_once(TEMPLATEPATH.'/lib/init.php'); // Start Genesis Engine
require_once(STYLESHEETPATH.'/lib/init.php'); // Start blog Options
require_once(STYLESHEETPATH.'/lib/updates.php'); // updates

include_once( 'lib/customizer.php' );
//* Add HTML5 markup structure
add_theme_support( 'html5' );


/** Support for various Image sizes */
add_theme_support('post-thumbnails');
//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Add support for custom background
//add_theme_support( 'custom-background' );


/** Register widget areas */
genesis_register_sidebar( array(
	'id'			=> 'single_related_post_widget',
	'name'			=> __( 'Single Related Post Widget', 'Fragranz Genesis Theme' ),
	'description'	=> __( 'This is the single page Content widget if you are using a two or three column site layout option.', 'Fragranz Genesis Theme' ),
) );

 
//* Do NOT include the opening php tag shown above. Copy the code shown below.
//* Remove the post meta function
remove_action( 'genesis_entry_footer', 'genesis_post_meta' );

//remove archive description
remove_action( 'genesis_before_content', 'genesis_do_taxonomy_title_description', 15 );

// Add widgeted footer section
add_action('genesis_before_footer', 'footer_bottom_widgets'); 
function footer_bottom_widgets() {
require(CHILD_DIR.'/footer-widgeted.php');
}

//* Display author box on archive pages
add_filter( 'get_the_author_genesis_author_box_archive', '__return_true' );

//* Customize the author box title
add_filter( 'genesis_author_box_title', 'custom_author_box_title' );
function custom_author_box_title() {
return "<h3 itemscope=\"Name\"> " . get_the_author() . "</h3>";
}

function ea_default_term_title( $value, $term_id, $meta_key, $single ) {
	if( ( is_category() || is_tag() || is_tax() ) && 'headline' == $meta_key && ! is_admin() ) {
	
		// Grab the current value, be sure to remove and re-add the hook to avoid infinite loops
		remove_action( 'get_term_metadata', 'ea_default_term_title', 10 );
		$value = get_term_meta( $term_id, 'headline', true );
		add_action( 'get_term_metadata', 'ea_default_term_title', 10, 4 );
		// Use term name if empty
		if( empty( $value ) ) {
			$term = get_term_by( 'term_taxonomy_id', $term_id );
			$value = $term->name;
		}
	
	}
	return $value;		
}
add_filter( 'get_term_metadata', 'ea_default_term_title', 10, 4 );

//placeholder for comment box in single page
add_filter('comment_form_default_fields','comment_form_placeholder');
function comment_form_placeholder($fields){ 
	$fields['author'] = '<p class="comment-form-author">' . '<label for="author">' . __( '', 'genesis' ) . '</label> ' . 	
	( $req ? '<span class="required">*</span>' : '' ) .                   
	'<input id="author" name="author" type="text" placeholder="Name *" value="' . 				
	esc_attr( $commenter['comment_author'] ) . '" size="30"' . $aria_req . ' /></p>';				
    $fields['email'] = '<p class="comment-form-email"><label for="email">' . __( '', 'genesis' ) . '</label> ' .
	( $req ? '<span class="required">*</span>' : '' ) .
	'<input id="email" name="email" type="text" placeholder="Email *" value="' . 	
	esc_attr(  $commenter['comment_author_email'] ) . '" size="30"' . $aria_req . ' /></p>';	
	$fields['url'] = '<p class="comment-form-url"><label for="url">' . __( '', 'genesis' ) . '</label>' .    
	'<input id="url" name="url" type="text" placeholder="URL *" value="' . 	
	esc_attr( $commenter['comment_author_url'] ) . '" size="30" /></p>';	
    return $fields;
}

 
// Customizes Footer Text (set in options) 
if (genesism_get_option('footer1')) { 
	add_filter('genesis_footer_creds_text', 'custom_footer_creds_text');
	function custom_footer_creds_text($creds) {
    	$creds = genesism_get_option('footer_text');
    return $creds;
	}
}

add_filter( 'genesis_before_header', 'search_box',2 );
function search_box( $text ) {
	return esc_attr( 'Go' );
}
remove_action( 'genesis_site_title', 'genesis_seo_site_title' );
remove_action( 'genesis_site_description', 'genesis_seo_site_description' );
/* BEGIN Custom User Contact Info */
function extra_contact_info($contactmethods) {

$contactmethods['facebook'] = 'Facebook';
$contactmethods['twitter'] = 'Twitter';

return $contactmethods;
}
add_filter('user_contactmethods', 'extra_contact_info');
/* END Custom User Contact Info */

add_action( 'genesis_before_comments', 'themeprefix_alt_author_box',2 );
function themeprefix_alt_author_box() {
if( is_single() ) {
 echo"<div class='single_title'><h3>THIS ARTICLE WAS WRITTEN BY</h3></div>";
echo "<div class=\"about-author\"><div class=\"author-info\" itemscope=\"itemscope\" itemtype=\"http://schema.org/person\">" . get_avatar( get_the_author_meta( 'ID' ), '100' ) . "</div>
<div class='author_right_cnt'>"; ?>
<h3 class="author_name"><?php the_author_posts_link(); ?></h3> 
  <?php echo "<p itemprop=\"description\">" . get_the_author_meta( 'description' ) . 
 "</p>
 <div class=\"author_social\">"; 

 if ( get_the_author_meta( 'facebook' ) != '' ) {
 echo "<a class=\"afb  fa\" href=\"https://www.facebook.com/". get_the_author_meta( 'facebook' ) . "\"></a>";
 }
 if ( get_the_author_meta( 'twitter' ) != '' ) {
 echo "<a class=\"atw fa\" href=\"https://twitter.com/". get_the_author_meta( 'twitter' ) . "\"></a>";
 } 
echo "</div></div></div>";
 }
} 
//* Remove the entry meta in the entry header 
 add_filter( 'genesis_post_info', 'sp_post_info_filter' );
function sp_post_info_filter($post_info) {
if ( is_single() ) {
	$post_info = '[post_date] by [post_author_posts_link] [post_comments]';
	return $post_info;
}}
 
// Register Genesis Menus
add_action( 'init', 'register_additional_menu' );
function register_additional_menu() {
  
register_nav_menu( 'FirstMenu' ,__( 'Bottom Menu' ));
register_nav_menu( 'SecondMenu' ,__( 'Footer Menu' ));  
register_nav_menu( 'ThirdMenu' ,__( 'top Header Menu' ));   
}

/** Remove Header */
remove_action( 'genesis_header', 'genesis_header_markup_open', 5 );
remove_action( 'genesis_header', 'genesis_do_header' );
remove_action( 'genesis_header', 'genesis_header_markup_close', 15 );

/** Add custom header support */	  
add_action('genesis_header','injectHeader');	  
function injectHeader(){ 

?>
<div class="top_header_cont">
<div class="top_inner_header wrap">
<div class="logo_section">
				<?php
				if (genesism_get_option('top_header')){?>
					<a title="<?php bloginfo('name'); ?>" href="<?php bloginfo('wpurl'); ?>"><img src="<?php echo genesism_get_option('top_header_logo_img'); ?>" alt="<?php bloginfo('name'); ?>"/></a>
				<?php
				}
				else { ?>
					<h1 itemprop="headline"><a title="<?php bloginfo('name'); ?>" href="<?php bloginfo('wpurl'); ?>"><?php bloginfo('name');?> </a></h1>
					
				<?php } ?>
</div>
<div class="top_header_right">
<div class="top_menu_sec">
		<?php 
			if (genesism_get_option('top_menu')){
			?>
			<div class="top_menu">
				<span class="menu_control">≡ Menu</span>
				<?php wp_nav_menu( array( 'theme_location' => 'ThirdMenu','container' => false,'menu_id' => 'menu_top_menu' ) );?>
			</div>
			
			<?php 
			}
			?>
			</div>
</div>

</div>
</div>

<div class="btm_header_cont">
 <div class="btm_inner_header wrap ">
	<div class="btm_left_header">
		
		<div class="bottom_menu_sec">
	
			<?php 
			if (genesism_get_option('btm_menu')){
			?>
			<div class="btm_menu">
				<span class="menu_control">≡ Menu</span>
				<?php wp_nav_menu( array( 'theme_location' => 'FirstMenu','container' => false,'menu_id' => 'menu_btm_menu' ) );?>
			</div>
			
			<?php 
			}
			?>
			
			</div>	
	</div> 
	<div class="btm_right_header">
	
			<div class="header_search_box">
			<?php
			if (genesism_get_option('search_section')){
			?>
					
				<div class="hdr_search_box sidebar_wid">
				<div class="header_search_icon">
				<i class='fa icon-search'></i>
				</div>
					<div class="header_search text_box">
						<form  method='get' action='<?php echo get_bloginfo('home'); ?>'>
						<input  type='text' placeholder='<?php echo genesism_option('search_text1'); ?>' name='s' id='s' />
						<input name="submit" class="btn btn-success" type="submit" value="<?php echo stripslashes(genesism_get_option('hdr_submit_text')); ?>"/>						
						</form>
					</div>
		</div>
				
			<?php 
			}
			?>
			</div>	
		
	</div>	
 </div>
</div>
<?php 
}
add_action('genesis_before_header','before_header');	
function before_header() { ?>
<div class="header" itemscope="itemscope" itemtype="http://schema.org/WPHeader">
<?php
}
add_action('genesis_after_header','after_header');			
function after_header() { ?>
 </div>	
<?php
} 
 
// Add Post Feature image
add_action( 'genesis_entry_content', 'custom_post_featureimage');
function custom_post_featureimage() {
if(!is_page()&&!is_single()){  
?>
<div class="post_featured_img">
<?php
if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
 echo "<div class='featured_viedo_image'>";
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true);echo "</div>";	
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video
 // Defaults
         $f_img_width = genesism_get_option('f_img_width');
        $f_img_height = genesism_get_option('f_img_height');
        $default_img =  'Feature_image'; 
      
        // Auto feature image defaults
        $thumb = get_post_thumbnail_id(); 
        $img_url = wp_get_attachment_url( $thumb,'full' ); 
        $image = aq_resize( $img_url,$f_img_width,$f_img_height, true );
        // Catch the Image defaults
        $catch_img_url = catch_that_image( $thumb,'full' );
        $catch_image = aq_resize( $catch_img_url, $f_img_width, $f_img_height, true );
        // Default Image
        $default_image = aq_resize( $default_img, $f_img_width, $f_img_height, true );		
		
		if(has_post_thumbnail()) { ?>
		<div class="featured_image">
        <a href="<?php echo the_permalink();?>" title="<?php echo the_title();?>"><img src="<?php echo $image;?>" width="<?php echo $f_img_width;?>" height="<?php echo $f_img_height;?>"  alt="<?php the_title(); ?>"  itemprop="image"></a></div>
		<?php        
		}
		elseif (catch_that_image()){ 	?>
		<div class="featured_image">
		<a href="<?php echo the_permalink();?>" title="<?php echo the_title();?>"><img src="<?php echo $catch_image;?>" width="<?php echo $f_img_width;?>" height="<?php echo $f_img_height;?>"  alt="<?php the_title(); ?>"  itemprop="image"></a></div>
		<?php        
		} 
		 else if(!empty($default_img)){     ?> 
		 <div class="featured_image">
          <a href="<?php echo the_permalink();?>" title="<?php echo the_title();?>"><img class="featureimg" src="<?php echo $default_img;?>" width="<?php echo $f_img_width;?>" height="<?php echo $f_img_height;?>"  alt="<?php the_title(); ?>"  itemprop="image"></a></div>
<?php     
	 }
	 }
	}

		/*featured image ends here*/
?>
</div>
<?php	
}      
} 
add_action( 'genesis_post_info', 'post_info_filter');
function post_info_filter() {
if(!is_page()){ 
?>
<div class="byline">
<?php
		$category = get_the_category(); 
	?>
	<span class='author'><?php the_author() ?></span>
	<span class='date'><?php the_time('j M , Y') ?></span>
	<span class="cat"><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></span>
	<span class='info_comments'><a  href="<?php the_permalink(); ?>#comments" title="<?php comments_number(__('0 Comment','fb'),__('1 Comment','periodic'),__('% Comments','fb')); ?>"><?php comments_number(__('0 Comment','periodic'),__('1 Comment','periodic'),__('% Comments','fb')); ?> </a></span>
</div>								
<?php
}
}

add_action('genesis_entry_content','post_ad',2);
function post_ad(){
if(genesism_get_option('postadcheck')){
if ( is_single() ) {?>
		<div class="post-ad" style="float:<?php echo genesism_option('float');?>; padding-right:5px; padding-left:15px; padding-top: 10px;">
		<?php  echo stripslashes((genesism_get_option('postad')));?>
		</div>
        <?php
		}
	}
	}
	
add_action ('genesis_entry_content','post_read_more');
function post_read_more(){
if (genesism_get_option('read_more')){
if(!is_page()&&!is_single()){
?>
<div class="read_more">
	<a class="read_more_btn" href="<?php echo the_permalink(); ?>"><?php  echo (genesism_get_option('read_text'));?></a>
</div>
<?php 
}
}	
}	

add_action ('genesis_before_sidebar_widget_area','before_sidebar_widget_area');
function before_sidebar_widget_area(){

?>
<div class="sidebar_section">
<?php 
}

add_action ('genesis_before_sidebar_widget_area','sidebar_optin',3);
function sidebar_optin(){	
if (genesism_get_option('sidebar_optin_section')){
?>
<div class="sidebar_optin_cnt">

<div class='sb_optin_hdr'>
<h2><?php echo genesism_get_option('sb_optin_header1'); ?></h2>
<h3><?php echo genesism_get_option('sb_optin_header2'); ?></h3>
<p><?php echo genesism_option('sb_optin_para'); ?></p>
</div>
<div class='form_content'>
<form method="post" action="<?php echo stripslashes(genesism_get_option('optin_url')); ?>" target="_blank">	
<div class="names">
<label><?php echo genesism_get_option('email'); ?></label>
<div class="sb_input">
<input class="name" type="text" name="<?php echo stripslashes(genesism_get_option('optin_name1')); ?>" placeholder="<?php echo stripslashes(genesism_get_option('name_text')); ?>"><div class='admins'></div>
<input class="email" type="text" name="<?php echo stripslashes(genesism_get_option('optin_email')); ?>" placeholder="<?php echo stripslashes(genesism_get_option('email_text')); ?>"><div class='mails'></div>
<?php echo stripslashes(genesism_get_option('optin_hidden')); ?>
<input name="submit" class="submit" type="submit" value="<?php echo stripslashes(genesism_get_option('submit_text')); ?>"/>
</div>
</div>
</form>
</div>
</div>
<?php 
}
}
add_action ('genesis_before_sidebar_widget_area','sidebar_social',5);
function sidebar_social(){
if (genesism_get_option('sidebar_social_section')){	
?>
<div class="sb_social_cont sidebar_widget">
<div class="sidebar_heading">
		<h3><?php echo genesism_option('sb_social_title'); ?></h3>
	</div>
<div class="sb_social_icons">
				<div class="social_icons">
					<a class="facebook" title="Facebook" href="<?php echo genesism_get_option('facebook_text2'); ?>" target="_blank">
						<i class="fa icon-facebook"></i>
					</a>
				</div>
				<div class="social_icons">
					<a class="twitter" title="Twitter" href="<?php echo genesism_get_option('twitter_text2'); ?>" target="_blank">
						<i class="fa icon-twitter"></i>
					</a>
				</div>
				<div class="social_icons">
					<a class="googleplus" title="google plus" href="<?php echo genesism_get_option('googleplus_text2'); ?>" target="_blank">
						<i class="fa icon-google-plus"></i>
					</a>
				</div>
				<div class="social_icons">
					<a class="pinterest" title="pinterest" href="<?php echo genesism_get_option('pinterest_text2'); ?>" target="_blank">
						<i class="fa icon-pinterest"></i>
					</a>
				</div>
				<div class="social_icons">
					<a class="instagram" title="instagram" href="<?php echo genesism_get_option('instagram_text2'); ?>" target="_blank">
						<i class="fa icon-instagram"></i>
					</a>
				</div>
				<div class="social_icons">
					<a class="youtube" title="youtube" href="<?php echo genesism_get_option('youtube_text2'); ?>" target="_blank">
						<i class="fa icon-youtube"></i>
					</a>
				</div>
		</div>
			</div>	
<?php 
}
}
add_action ('genesis_after_sidebar_widget_area','after_sidebar_widget_area');
function after_sidebar_widget_area(){
?>
</div>
<?php 
}

// Customize the post meta function
add_filter('genesis_entry_footer', 'post_meta_filter',1);
function post_meta_filter() {
if ( is_single() ) {?>
<p class='post_tags'> 
	<?php // Tag
		$posttags = get_the_tags();
		if ($posttags) {
		foreach($posttags as $tag) {
		
		echo $tag->name .'  '; 
		}
		}
	?>
</p>
<?php
}
}
add_filter( 'genesis_term_meta_headline', 'be_default_category_title', 10, 2 );
function be_default_category_title( $headline, $term ) {
	if( ( is_category() || is_tag() || is_tax() ) && empty( $headline ) )
		$headline = $term->name;	
	return $headline;
}
	
/** Genesis Previous/Next Post Post Navigation */
add_action ('genesis_entry_footer','prev_next_post_nav',3);
function prev_next_post_nav(){
if ( is_single() ) {
echo '<div class="prev-next-navigation">';
previous_post_link( '<div class="previous"><span>Previous article:</span> %link</div>', '%title' );
next_post_link( '<div class="next"><span>Next article:</span> %link</div>', '%title' );
echo '</div><!-- .prev-next-navigation -->';
}
}	
add_action( 'genesis_entry_header', 'breadcrumbs',2);
function breadcrumbs(){
if ( is_single() ) {

}
}
add_action( 'genesis_before_comments', 'single_page_socialshare',2);
function single_page_socialshare(){
if (genesism_get_option('single_social_share')){
if ( is_single() ) {?>
<div class="sharing group sharing_social_count">
<div class="single_title">
	<h3><?php  echo (genesism_get_option('share_title'));?></h3>
	<span class="sep"></span>
</div>
<ul class="social_share_count">
		<li class="share_tweet">
		<a href="http://twitter.com/share?text=<?php echo htmlspecialchars(urlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8')), ENT_COMPAT, 'UTF-8'); ?>&amp;url=<?php the_permalink(); ?>" target="_blank">
		<i class="icon-twitter icon"></i>
		<span>
		 Twitter
		</span>
		</a>
		</li>
		<li class="share_fb">
		<a href="http://www.facebook.com/sharer.php?u=<?php the_permalink(); ?>&amp;t=<?php echo htmlspecialchars(urlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8')), ENT_COMPAT, 'UTF-8'); ?>" target="_blank">
		<i class="icon-facebook icon"></i>
		<span>
		 Facebook
		</span>
		</a>
		</li>
		<li class="share_linkedin">
		<a target="_blank" href="http://www.linkedin.com/shareArticle?mini=true&amp;url=<?php the_permalink(); ?>">
		<i class="icon-linkedin icon"></i>
		<span>
		 Linkedin
		</span>
		</a> 
		</li>
		<li class="share_reddit">
		<a target="_blank" href="http://www.reddit.com/submit?url=<?php the_permalink(); ?>&amp;title=<?php echo htmlspecialchars(urlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8')), ENT_COMPAT, 'UTF-8'); ?>">
		<i class="icon-reddit icon"></i>
		<span>
		 Reddit
		</span>
		</a>
		</li>
		<li class="share_pintrest">
		<a target="_blank" href="http://pinterest.com/pinthis?url=<?php the_permalink(); ?>&amp;title=<?php echo htmlspecialchars(urlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8')), ENT_COMPAT, 'UTF-8'); ?>">
		<i class="icon-pinterest icon"></i>
		<span>
		 Pintrest
		</span>
		</a>
		</li>		
	</ul>
</div>
<?php
}
}
}
	//Related Post Box
add_action( 'genesis_before_comments', 'related_posts',3);
function related_posts(){
?>
<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Single Related Post Widget') ) : ?>
<div class="widget">
<h4 itemprop="headline"><?php _e("Single Related Post #Widget", 'genesis'); ?></h4>
<p><?php _e("Displays Related posts with thumbnails.", 'genesis'); ?></p>
</div><!-- end .widget -->
<?php endif; ?> 
<?php

}
//Single Optin Box
add_action( 'genesis_before_comments', 'single_page_optin',3);
function single_page_optin(){
if (genesism_get_option('single_optin_section')){
?>
<div class="single_optin_cnt">
<div class='sp_optin_hdr'>
<h2><?php echo genesism_get_option('sp_optin_header1'); ?></h2>
<h3><?php echo genesism_get_option('sp_optin_header2'); ?></h3>
<p><?php echo genesism_option('sp_optin_para'); ?></p>
</div>
<div class='form_content'>
<form method="post" action="<?php echo stripslashes(genesism_get_option('optin_url2')); ?>" target="_blank">	
<div class="names">
<label><?php echo genesism_get_option('email2'); ?></label>
<div class="sp_input">
<input class="name" type="text" name="<?php echo stripslashes(genesism_get_option('optin_name2')); ?>" placeholder="<?php echo stripslashes(genesism_get_option('name_text2')); ?>"><div class='mails'></div>
<input class="email" type="text" name="<?php echo stripslashes(genesism_get_option('optin_email2')); ?>" placeholder="<?php echo stripslashes(genesism_get_option('email_text2')); ?>"><div class='mails'></div>
<?php echo stripslashes(genesism_get_option('optin_hidden2')); ?>
<input name="submit" class="submit" type="submit" value="<?php echo stripslashes(genesism_get_option('submit_text2')); ?>"/>
</div>
</div>
</form>
</div>
</div>
<?php
}
}
add_action('wp_head','color_box');
function color_box(){
$body_bg_color = get_option('body_bg_color');
$body_txt_color = get_option('body_txt_color');
$header_txt_color = get_option('header_txt_color');
$top_header_bg = get_option('top_header_bg');
$link_color =get_option('link_color');
$sb_optin_hdr_bg =get_option('sb_optin_hdr_bg');
$color1 =get_option('color1');
$sidebar_bg =get_option('sidebar_bg');
$border_color =get_option('border_color');
$site_footer_bg =get_option('site_footer_bg');
$footer_text_clr =get_option('footer_text_clr');
$hover_bg =get_option('hover_bg');
?>
<style type="text/css">
body, .single_optin_cnt {
background:<?php echo $body_bg_color; ?>;
}
body, .blog .entry-content p, .archive .entry-content p, .search .entry-content p{
color: <?php echo $body_txt_color; ?> ;
}
a, .entry-title a,
.sidebar .widget-title a {
color: <?php echo $header_txt_color; ?>;
}
.bottom_menu_sec .menu a {
    color: <?php echo $header_txt_color; ?>;
}
h1,h2,h3,h4,h5,h6, .widget_search button{
color: <?php echo $header_txt_color; ?>;
}
.top_header_cont{
background-color: <?php echo $top_header_bg; ?> ;
}
.menu .sub-menu li a:hover{
background-color: <?php echo $top_header_bg; ?>;
}
.header_search .btn-success, .sb_widget_search .btn-success{
background-color: <?php echo $top_header_bg; ?>;
}
.footer-widgets{
background-color: <?php echo $top_header_bg; ?>;
}
.landing_right_optin input[type="submit"]{
background-color: <?php echo $top_header_bg; ?>;
}
a:hover, .single .post .byline span, .single .post .byline span a, .single_category a, .blog .byline .cat a, .archive .byline .cat a, .search .byline .cat a,
 .permalink a:after, .permalink a, .popular_cnt .pop_byline span, .social_icons a:hover, .btm_menu .menu .current-menu-item > a, .menu li a:hover, 
 .archive-description .archive-title, .entry-title a:hover, .info_comments:before, .entry-header .byline, .info_comments a, 
 .cat:before, .read_more a, .read_more a:before, .landing_left_list  ul li:before{
color: <?php echo $link_color; ?> ;
}
.footer-widgets-1 .tagcloud a, .left_side_optin .form  input[type="submit"], .comment-reply a, .single .post_tags, .sidebar .tagcloud a, .sec_cat_left_btm,
 .sec_category_content .entry_cat_title  h4 a, .img_content_area .entry_cat_title h4 a, .edit_news_cont_left .permalink  a, .archive-pagination li a:hover, 
  .archive-pagination .active a, .form-submit input[type="submit"]:hover, .author_social a:hover, .single_optin_cnt input[type="submit"]:hover, 
 .sidebar_optin_cnt input[type="submit"]:hover, .landing_optin_header h3:before, .aboutus_cnt_main a{
background-color: <?php echo $link_color; ?>;
}
.aboutus_cnt_main a{
box-shadow: 0px 0px 0px 2px <?php echo $link_color; ?>;

}
.footer-widgets-1 .tagcloud a:hover{
border-color: <?php echo $link_color; ?>;
}
.menu li .sub-menu {
border-bottom-color: <?php echo $link_color; ?>;
}
.sb_optin_hdr, .sp_optin_hdr{
background-color: <?php echo $sb_optin_hdr_bg; ?> ;
}
.sidebar_optin_cnt .form_content:before, .single_optin_cnt .form_content:before {
border-top-color: <?php echo $sb_optin_hdr_bg; ?> ;
}
.feature_cont .about_read a{
background-color: <?php echo $sb_optin_hdr_bg; ?> ;
}
.sidebar_optin_cnt input[type="text"], .single_optin_cnt input[type="text"]{
background-color:<?php echo $color1; ?> ;
}
.sidebar_optin_cnt h3{
color: <?php echo $color1; ?> ;
}
.btm_header_cont, .btm_menu ul li{
border-color: <?php echo $color1; ?> ;
}
.landing_optin_title p, .edit_news_cont_left p, .widget_recent_entries ul li a, .textwidget{
color: <?php echo $color1; ?> ;
}
.sidebar_widget{
background-color: <?php echo $sidebar_bg; ?> ;
}
.header_search_icon, .sidebar_section .widget-wrap, .prev-next-navigation, .related_post_section{
background-color: <?php echo $sidebar_bg; ?> ;
}
.sidebar_optin_cnt  input[type="text"], .sidebar_section .widget-wrap, .single_optin_cnt .form_content, 
.single_optin_cnt  input[type="text"]{
border-color: <?php echo $border_color; ?> ;
}
.border_line, .bottom_menu_sec .menu li, .blog .content .post, .archive .content .post, .search .content .post, .single .post .byline, .related_post_section, .content .single_title h3, #reply-title{
border-bottom-color: <?php echo $border_color; ?> ;
}
.single .post .byline{
border-top-color: <?php echo $border_color; ?> ;
}
.byline span{
border-right-color: <?php echo $border_color; ?> ;
}
.sb_optin_hdr p, .sp_optin_hdr p{
color: <?php echo $border_color; ?> ;
}
.site-footer {
background-color: <?php echo $site_footer_bg; ?> ;
}
.widget_recent_entries ul li a, .textwidget{
color: <?php echo $footer_text_clr; ?> ;
}
.site-footer, .site-footer a {
color: <?php echo $footer_text_clr; ?> ;
}
.landing_left_list ul li{
color:<?php echo $footer_text_clr; ?> ;
}
.feature_cont .about_read a:hover, .sidebar_optin_cnt input[type="submit"], .landing_right_optin input[type="submit"]:hover,
.archive-pagination li a, .sidebar .tagcloud a:hover{
background-color:<?php echo $hover_bg; ?> ;
}
<?php echo genesism_option('custom_css'); ?>
</style>
<?php
}
add_action('wp_footer','script_box');
function script_box(){?>
<script type="text/javascript">
function loadScript(src) {
     var element = document.createElement("script");
     element.src = src;
     document.body.appendChild(element);
}
// Add a script element as a child of the body
function downloadJSAtOnload() {
	 loadScript("<?php bloginfo('stylesheet_directory'); ?>/scripts/menu.js");		

}
 // Check for browser support of event handling capability
 if (window.addEventListener)
     window.addEventListener("load", downloadJSAtOnload, false);
	 else if (window.attachEvent)
     window.attachEvent("onload", downloadJSAtOnload);
 else window.onload = downloadJSAtOnload; 
 (function() {
      function getScript(url,success){
        var script=document.createElement('script');
        script.src=url;
        var head=document.getElementsByTagName('head')[0],
            done=false;
        script.onload=script.onreadystatechange = function(){
          if ( !done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete') ) {
            done=true;
            success();
            script.onload = script.onreadystatechange = null;
            head.removeChild(script);
          }
        };
        head.appendChild(script);
      }
        getScript('http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js',function(){
        });
    })();
</script>
<?php
}
// Auto Resize Image
function aq_resize( $url, $width, $height = null, $crop = null, $single = true ) {

//validate inputs
if(!$url OR !$width ) return false;

//define upload path & dir
$upload_info = wp_upload_dir();
$upload_dir = $upload_info['basedir'];
$upload_url = $upload_info['baseurl'];

//check if $img_url is local
if(strpos( $url, $upload_url ) === false) return false;

//define path of image
$rel_path = str_replace( $upload_url, '', $url);
$img_path = $upload_dir . $rel_path;

//check if img path exists, and is an image indeed
if( !file_exists($img_path) OR !getimagesize($img_path) ) return false;

//get image info
$info = pathinfo($img_path);
$ext = $info['extension'];
list($orig_w,$orig_h) = getimagesize($img_path);

//get image size after cropping
$dims = image_resize_dimensions($orig_w, $orig_h, $width, $height, $crop);
$dst_w = $dims[4];
$dst_h = $dims[5];

//use this to check if cropped image already exists, so we can return that instead
$suffix = "{$dst_w}x{$dst_h}";
$dst_rel_path = str_replace( '.'.$ext, '', $rel_path);
$destfilename = "{$upload_dir}{$dst_rel_path}-{$suffix}.{$ext}";

if(!$dst_h) {
//can't resize, so return original url
$img_url = $url;
$dst_w = $orig_w;
$dst_h = $orig_h;
}
//else check if cache exists
elseif(file_exists($destfilename) && getimagesize($destfilename)) {
$img_url = "{$upload_url}{$dst_rel_path}-{$suffix}.{$ext}";
}
//else, we resize the image and return the new resized image url
else {

// Note: This pre-3.5 fallback check will edited out in subsequent version
if(function_exists('wp_get_image_editor')) {
$editor = wp_get_image_editor($img_path);
if ( is_wp_error( $editor ) || is_wp_error( $editor->resize( $width, $height, $crop ) ) )
return false;
$resized_file = $editor->save();
if(!is_wp_error($resized_file)) {
$resized_rel_path = str_replace( $upload_dir, '', $resized_file['path']);
$img_url = $upload_url . $resized_rel_path;
} else {
return false;
}
} else {
$resized_img_path = image_resize( $img_path, $width, $height, $crop ); // Fallback foo
if(!is_wp_error($resized_img_path)) {
$resized_rel_path = str_replace( $upload_dir, '', $resized_img_path);
$img_url = $upload_url . $resized_rel_path;
} else {
return false;
}
}
}
//return the output
if($single) {
//str return
$image = $img_url;
} else {
//array return
$image = array (
0 => $img_url,
1 => $dst_w,
2 => $dst_h
);
}
return $image;
}
function catch_that_image() {
        global $post, $posts;
        $first_img = '';
        ob_start();
        ob_end_clean();
        $output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
        if(count($matches [1]))$first_img = $matches [1] [0];
        return $first_img;
}
function new_excerpt_length($length) {
    return 40;
}
add_filter('excerpt_length', 'new_excerpt_length');
function string_limit_words($string, $word_limit)
{
  $words = explode(' ', $string, ($word_limit + 1));
  if(count($words) > $word_limit)
  array_pop($words);
  return implode(' ', $words);
}   
function custom_pagination($numpages = '', $pagerange = '', $paged='') {
  if (empty($pagerange)) {
    $pagerange = 2;
  }

  /**
   * This first part of our function is a fallback
   * for custom pagination inside a regular loop that
   * uses the global $paged and global $wp_query variables. 
   * It's good because we can now override default pagination
   * in our theme, and use this function in default quries
   * and custom queries.
   */
  global $paged;
  if (empty($paged)) {
    $paged = 1;
  }
  if ($numpages == '') {
    global $wp_query;
    $numpages = $wp_query->max_num_pages;
    if(!$numpages) {
        $numpages = 1;
    }
  }

  /** 
   * We construct the pagination arguments to enter into our paginate_links
   * function. 
   */
  $pagination_args = array(
    'base'            => get_pagenum_link(1) . '%_%',
    'format'          => 'page/%#%',
    'total'           => $numpages,
    'current'         => $paged,
    'show_all'        => False,
    'end_size'        => 1,
    'mid_size'        => $pagerange,
    'prev_next'       => True,
    'prev_text'       => __('&laquo;'),
    'next_text'       => __('&raquo;'),
    'type'            => 'plain',
    'add_args'        => false,
    'add_fragment'    => ''
  );
  $paginate_links = paginate_links($pagination_args);
  if ($paginate_links) {
    echo "<nav class='custom-pagination'>";
      echo "<span class='page-numbers page-num'>Page " . $paged . " of " . $numpages . "</span> ";
      echo $paginate_links;
    echo "</nav>";
  }
}

#-----------------------------------------------------------------
# Plugin Recommendations
#-----------------------------------------------------------------
require_once ('lib/class-tgm-plugin-activation.php');
add_action( 'tgmpa_register', 'pngs_register_required_plugins' );
function pngs_register_required_plugins() {
	$plugins = array(	
		array(
			'name'     				=> 'Replace Featured Image with Video',
			'slug'     				=> 'replacefeaturedimagewithvideo',
			'source'   				=> get_stylesheet_directory() . '/lib/plugins/replace-featured-image-with-video.zip',
			'required' 				=> true,
			'version' 				=> '2.4.10',
			'force_activation' 		=> false,
			'force_deactivation' 	=> false,
			'external_url' 			=> '',
		),
	);
	$config = array( 
		'domain'       		=> 'blogge',
		'default_path' 		=> '',
		'parent_menu_slug' 	=> 'themes.php',
		'parent_url_slug' 	=> 'themes.php',
		'menu'         		=> 'install-required-plugins',
		'has_notices'      	=> true,
		'is_automatic'    	=> false,
		'message' 			=> '',
		'strings'      		=> array(
			'page_title'                       			=> __( 'Install Required Plugins', 'blogge' ),
			'menu_title'                       			=> __( 'Install Plugins', 'blogge' ),
			'installing'                       			=> __( 'Installing Plugin: %s', 'blogge' ), // %1$s = plugin name
			'oops'                             			=> __( 'Something went wrong with the plugin API.', 'blogge' ),
			'notice_can_install_required'     			=> _n_noop( 'This theme requires the following plugin: %1$s.', 'This theme requires the following plugins: %1$s.', 'blogge' ), // %1$s = plugin name(s)
			'notice_can_install_recommended'			=> _n_noop( 'This theme recommends the following plugin: %1$s.', 'This theme recommends the following plugins: %1$s.', 'blogge' ), // %1$s = plugin name(s)
			'notice_cannot_install'  					=> _n_noop( 'Sorry, but you do not have the correct permissions to install the %s plugin. Contact the administrator of this site for help on getting the plugin installed.', 'Sorry, but you do not have the correct permissions to install the %s plugins. Contact the administrator of this site for help on getting the plugins installed.', 'blogge' ), // %1$s = plugin name(s)
			'notice_can_activate_required'    			=> _n_noop( 'The following required plugin is currently inactive: %1$s.', 'The following required plugins are currently inactive: %1$s.', 'blogge' ), // %1$s = plugin name(s)
			'notice_can_activate_recommended'			=> _n_noop( 'The following recommended plugin is currently inactive: %1$s.', 'The following recommended plugins are currently inactive: %1$s.', 'blogge' ), // %1$s = plugin name(s)
			'notice_cannot_activate' 					=> _n_noop( 'Sorry, but you do not have the correct permissions to activate the %s plugin. Contact the administrator of this site for help on getting the plugin activated.', 'Sorry, but you do not have the correct permissions to activate the %s plugins. Contact the administrator of this site for help on getting the plugins activated.', 'blogge' ), // %1$s = plugin name(s)
			'notice_ask_to_update' 						=> _n_noop( 'The following plugin needs to be updated to its latest version to ensure maximum compatibility with this theme: %1$s.', 'The following plugins need to be updated to their latest version to ensure maximum compatibility with this theme: %1$s.', 'blogge' ), // %1$s = plugin name(s)
			'notice_cannot_update' 						=> _n_noop( 'Sorry, but you do not have the correct permissions to update the %s plugin. Contact the administrator of this site for help on getting the plugin updated.', 'Sorry, but you do not have the correct permissions to update the %s plugins. Contact the administrator of this site for help on getting the plugins updated.', 'blogge' ), // %1$s = plugin name(s)
			'install_link' 					  			=> _n_noop( 'Begin installing plugin', 'Begin installing plugins', 'blogge'  ),
			'activate_link' 				  			=> _n_noop( 'Activate installed plugin', 'Activate installed plugins', 'blogge'  ),
			'return'                           			=> __( 'Return to Required Plugins Installer', 'blogge' ),
			'plugin_activated'                 			=> __( 'Plugin activated successfully.', 'blogge' ),
			'complete' 									=> __( 'All plugins installed and activated successfully. %s', 'blogge' ), // %1$s = dashboard link
			'nag_type'									=> 'updated'
		)
	);
	tgmpa( $plugins, $config );
}

// About Us Widget Starts Here
class gl_aboutus_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_aboutus_widget', 
__('Blogge - About Us ', 'gl_aboutus_widget_domain'), 
array( 'description' => __( 'Displays About Us Content', 'gl_aboutus_widget_domain' ), ) 
);
}
public function widget( $args, $instance ) {
$sb_aboutus_title = apply_filters( 'sb_aboutus_title', $instance['sb_aboutus_title'] );
$about_us_img = apply_filters( 'about_us_img', $instance['about_us_img'] );
$sb_aboutus_cnt = apply_filters( 'sb_aboutus_cnt', $instance['sb_aboutus_cnt'] );
$sb_aboutus_read = apply_filters( 'sb_aboutus_read', $instance['sb_aboutus_read'] );
$sb_aboutus_read_link = apply_filters( 'sb_aboutus_read_link', $instance['sb_aboutus_read_link'] );
echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];
?>
<div class="sidebar_aboutus sidebar_widget">
	<div class="aboutus_cnt">
			<img alt="<?php  echo $instance['sb_aboutus_title'];?>" src='<?php  echo $instance['about_us_img'];?>'/>
			<div class="aboutus_cnt_title_para">
			<h3><?php  echo $instance['sb_aboutus_title'];?></h3>
				<div class="aboutus_cnt_main">
			<p><?php  echo $instance['sb_aboutus_cnt'];?></p>
			<a class="custom" href="<?php  echo $instance['sb_aboutus_read_link'];?>"><?php  echo $instance['sb_aboutus_read'];?></a>
			</div>
			</div>
		</div>	
</div>
<?php
echo $args['after_widget'];
}		
public function form( $instance ) {
if ( isset( $instance[ 'sb_aboutus_title' ] ) ) {
$sb_aboutus_title = $instance[ 'sb_aboutus_title' ];
}
else {
$sb_aboutus_title = __( 'Emily smith', 'gl_aboutus_widget_domain' );
}
 if ( isset( $instance[ 'about_us_img' ] ) ) {
$about_us_img = $instance[ 'about_us_img' ];
}
else {
$about_us_img = __( ' ', 'gl_aboutus_widget_domain' );
}
 if ( isset( $instance[ 'sb_aboutus_cnt' ] ) ) {
$sb_aboutus_cnt = $instance[ 'sb_aboutus_cnt' ];
}
else {
$sb_aboutus_cnt = __( 'About Us Content', 'gl_aboutus_widget_domain' );
}
 if ( isset( $instance[ 'sb_aboutus_read' ] ) ) {
$sb_aboutus_read = $instance[ 'sb_aboutus_read' ];
}
else {
$sb_aboutus_read = __( 'Read More', 'gl_aboutus_widget_domain' );
}
 if ( isset( $instance[ 'sb_aboutus_read_link' ] ) ) {
$sb_aboutus_read_link = $instance[ 'sb_aboutus_read_link' ];
}
else {
$sb_aboutus_read_link = __( '', 'gl_aboutus_widget_domain' );
}
?>
<p>
<label for="<?php echo $this->get_field_id( 'sb_aboutus_title' ); ?>"><?php _e( 'About Us Name:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'sb_aboutus_title' ); ?>" name="<?php echo $this->get_field_name( 'sb_aboutus_title' ); ?>" type="text" value="<?php echo esc_attr( $sb_aboutus_title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'about_us_img' ); ?>"><?php _e( 'About Us Image URL Link:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'about_us_img' ); ?>" name="<?php echo $this->get_field_name( 'about_us_img' ); ?>" type="text" value="<?php echo esc_attr( $about_us_img ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'sb_aboutus_cnt' ); ?>"><?php _e( 'About Us Content:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'sb_aboutus_cnt' ); ?>" name="<?php echo $this->get_field_name( 'sb_aboutus_cnt' ); ?>" type="text" value="<?php echo esc_attr( $sb_aboutus_cnt ); ?>"/>
</p>
<p>
<label for="<?php echo $this->get_field_id( 'sb_aboutus_read' ); ?>"><?php _e( 'About Us Readmore Text:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'sb_aboutus_read' ); ?>" name="<?php echo $this->get_field_name( 'sb_aboutus_read' ); ?>" type="text" value="<?php echo esc_attr( $sb_aboutus_read ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'sb_aboutus_read_link' ); ?>"><?php _e( 'About Us Readmore Text URL Link:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'sb_aboutus_read_link' ); ?>" name="<?php echo $this->get_field_name( 'sb_aboutus_read_link' ); ?>" type="text" value="<?php echo esc_attr( $sb_aboutus_read_link ); ?>" />
</p>
<?php 
}
public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['sb_aboutus_title'] = ( ! empty( $new_instance['sb_aboutus_title'] ) ) ? strip_tags( $new_instance['sb_aboutus_title'] ) : '';
$instance['about_us_img'] = ( ! empty( $new_instance['about_us_img'] ) ) ? strip_tags( $new_instance['about_us_img'] ) : '';
$instance['sb_aboutus_cnt'] = ( ! empty( $new_instance['sb_aboutus_cnt'] ) ) ? strip_tags( $new_instance['sb_aboutus_cnt'] ) : '';
$instance['sb_aboutus_read'] = ( ! empty( $new_instance['sb_aboutus_read'] ) ) ? strip_tags( $new_instance['sb_aboutus_read'] ) : '';
$instance['sb_aboutus_read_link'] = ( ! empty( $new_instance['sb_aboutus_read_link'] ) ) ? strip_tags( $new_instance['sb_aboutus_read_link'] ) : '';
return $instance;
}
}
// About us post widget ends here
// Sidebar Search Widget Starts Here
class gl_search_widget extends WP_Widget {
function __construct() {
parent::__construct(
'gl_search_widget', 

__('Blogge - Sidebar Search Box ', 'gl_search_widget_domain'), 
array( 'description' => __( 'Displays Sidebar Search Content', 'gl_search_widget_domain' ), ) 
);
}
public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$sb_search_text = apply_filters( 'sb_search_text', $instance['sb_search_text'] );
echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];
?>
<div class="sb_widget_search_box sidebar_widget">
					<div class="sb_widget_search">
						<form method='get' action='<?php echo get_bloginfo('home'); ?>'>
							<input type='text' placeholder='<?php echo $instance['sb_search_text']; ?>' name='s' />
							<button type='submit' class='btn btn-success'>
								<i class='fa icon-search'></i>
							</button>			
						</form>
					</div>
		</div>
<?php
echo $args['after_widget'];
}		
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( '', 'gl_random_widget_domain' );
}
if ( isset( $instance[ 'sb_search_text' ] ) ) {
$sb_search_text = $instance[ 'sb_search_text' ];
}
else {
$sb_search_text = __( 'Search here...', 'gl_search_widget_domain' );
}
?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'sb_search_text' ); ?>"><?php _e( 'Search Placeholder text:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'sb_search_text' ); ?>" name="<?php echo $this->get_field_name( 'sb_search_text' ); ?>" type="text" value="<?php echo esc_attr( $sb_search_text ); ?>" />
</p>
<?php 
}
public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['sb_search_text'] = ( ! empty( $new_instance['sb_search_text'] ) ) ? strip_tags( $new_instance['sb_search_text'] ) : '';
return $instance;
}
}
// Sidebar Search widget ends here
// Popular Widget Starts Here
class gl_popular_widget extends WP_Widget {
function __construct() {
parent::__construct(
'gl_popular_widget', 
__('Blogge - Popular Post', 'gl_popular_widget_domain'), 
array( 'description' => __( 'Displays Popular Post', 'gl_popular_widget_domain' ), ) 
);
}
public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );
echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];
?>
<div class="popular_post sidebar_widget">	
	<div class='popular_post_cnt sidebar_content'>
		<?php
			query_posts('post_type=post&posts_per_page='. $post_count .' &orderby=comment_count&order=DESC');
			while (have_posts()): the_post(); 
		?>
			<div class='popular_post_section border_line entry_cnt'>
				<div class='popular_img'>
					<?php
					if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
 echo "<div class='featured_viedo_image'>";
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true); echo "</div>";	
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video
						  $f_img_width2 = $instance['width_size'];
							$f_img_height2 =$instance['height_size'];
							$default_img =  'Feature_image'; 
						// Auto feature image defaults
						$thumb = get_post_thumbnail_id(); 
						$img_url = wp_get_attachment_url( $thumb,'full' ); 
						$image = aq_resize( $img_url, $f_img_width2, $f_img_height2, true );
						// Catch the Image defaults
						$catch_img_url = catch_that_image( $thumb,'full' );
						$catch_image = aq_resize( $catch_img_url, $f_img_width2, $f_img_height2, true );
						if(has_post_thumbnail())
						echo
						"<div class=\"featured_image\">\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width2 . "\" height=\"" . $f_img_height2 . "\" alt=\"" . get_the_title() . "\"></a><div class='thumb_hover'><a class=\"link\" href=\"" . get_permalink() . "\"></a></div>\n".
						"</div>\n";
						elseif (catch_that_image()){ 
						echo
						"<div class=\"featured_image\">\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width2 . "\" height=\"" . $f_img_height2 . "\" alt=\"" . get_the_title() . "\"></a><div class='thumb_hover'><a class=\"link\" href=\"" . get_permalink() . "\"></a></div>\n".
						"</div>\n";  
						} 
						}
						}
					?>
				</div>
				<div class="popular_cnt">
					<h3><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a></h3>
				
				<div class='pop_byline'>
				<span><?php the_time('M jS, Y'); ?></span>
				</div>
				</div>
			</div>
		<?php
			endwhile;
		?>
	</div>
</div>
<?php
echo $args['after_widget'];
}		
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Popular Posts', 'gl_popular_widget_domain' );
}
 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '4', 'gl_popular_widget_domain' );
}
 if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '98', 'gl_popular_widget_domain' );
}
 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '98', 'gl_popular_widget_domain' );
}
?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>
<?php 
}
public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';
return $instance;
}
}
//Popular Post Widget Ends Here//
// Random Post Widget Starts Here
class gl_random_widget extends WP_Widget {
function __construct() {
parent::__construct(
'gl_random_widget', 
__('Blogge - Random Post', 'gl_random_widget_domain'), 
array( 'description' => __( 'Displays Random Post', 'gl_random_widget_domain' ), ) 
);
}
public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );
echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];
?>
<div class="random_post sidebar_widget_bg sidebar_widget">	
	<div class='random_post_cnt sidebar_content'>
		<?php
			query_posts('post_type=post&posts_per_page='. $post_count .' &orderby=rand&order=DESC');
			while (have_posts()): the_post(); 
		?>
			<div class='random'>
				<div class='random_img'>
					<?php
					if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
 echo "<div class='featured_viedo_image featured_image'>";
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true);echo "</div>";	
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video
			
					// Defaults
						$f_img_width4 = $instance['width_size'];
						$f_img_height4 = $instance['height_size'];
						// Auto feature image defaults
						$thumb = get_post_thumbnail_id(); 
						$img_url = wp_get_attachment_url( $thumb,'full' ); 
						$image = aq_resize( $img_url, $f_img_width4, $f_img_height4, true );
						// Catch the Image defaults
						$catch_img_url = catch_that_image( $thumb,'full' );
						$catch_image = aq_resize( $catch_img_url, $f_img_width4, $f_img_height4, true );
						if(has_post_thumbnail())
						echo
						"<div class=\"featured_image\">\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width4 . "\" height=\"" . $f_img_height4 . "\" alt=\"" . get_the_title() . "\"></a><div class='thumb_hover'><a class=\"link\" href=\"" . get_permalink() . "\"></a></div>\n".
						"</div>\n";
						elseif (catch_that_image()){ 
						echo
						"<div class=\"featured_image\">\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width4 . "\" height=\"" . $f_img_height4 . "\" alt=\"" . get_the_title() . "\"></a><div class='thumb_hover'><a class=\"link\" href=\"" . get_permalink() . "\"></a></div>\n".
						"</div>\n";  
						} 
						}
						}
					?>
				</div>
				<div class="random_cnt">
					<h3><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a></h3>
				</div>
			</div>
		<?php
			endwhile;
		?>
	</div>
</div>
<?php
echo $args['after_widget'];
}		
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Random Posts', 'gl_random_widget_domain' );
}
 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '4', 'gl_random_widget_domain' );
}
 if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '112', 'gl_random_widget_domain' );
}
 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '100', 'gl_random_widget_domain' );
}
?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>
<?php 
}
public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';
return $instance;
}
}
//Random Post Widget Ends Here//
//Trending Post Widget Starts Here
class gl_trending_widget extends WP_Widget {
function __construct() {
parent::__construct(
'gl_trending_widget', 
__('Blogge - Trending Post', 'gl_trending_widget_domain'), 
array( 'description' => __( 'Displays Trending Post', 'gl_trending_widget_domain' ), ) 
);
}
public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );
echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];
?>
<div class="trending_post sidebar_widget">	
	<div class="trending_post_section sidebar_content">
		<ul>
			<?php
				global $query_string;
				query_posts( array( 'posts_per_page'=> $instance['post_count'] , 'post_type' => 'post', 'orderby' => 'comment_count','order' => 'desc', 'paged' => get_query_var('paged')) );
				if(have_posts()) : 
				while(have_posts()) : the_post();
			?>
				<li class="trend_cont">
				<?php 

echo"<div class='trend_img'>";
if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
 echo "<div class='featured_viedo_image featured_image'>";
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true);echo "</div>";		
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video		
 // Defaults
        $f_img_width5 = $instance['width_size'];
        $f_img_height5 = $instance['height_size'];
		// Auto feature image defaults
		$thumb = get_post_thumbnail_id(); 
		$img_url = wp_get_attachment_url( $thumb,'full' ); 
		$image = aq_resize( $img_url,$f_img_width5,$f_img_height5, true );
		// Catch the Image defaults
        $catch_img_url = catch_that_image( $thumb,'full' );
        $catch_image = aq_resize( $catch_img_url, $f_img_width5, $f_img_height5, true );
        // Default Image
		if(has_post_thumbnail())
		echo
		"<div class=\"featured_image\">\n".
		"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width5 . "\" height=\"" . $f_img_height5 . "\" alt=\"" . get_the_title() . "\"><div class='thumb_hover'></div></a>\n".
		"</div>\n";
		elseif (catch_that_image()){ 
		echo
		"<div class=\"featured_image\">\n".
		"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width5 . "\" height=\"" . $f_img_height5 . "\" alt=\"" . get_the_title() . "\"></a>\n".
		"</div>\n"; 
		}
}
}		
		/*featured image ends here*/
echo "</div>";
echo "<h3><a href='". get_permalink() ."'>".
get_the_title() ."".
"</a></h3>";
?>
				</li>
			<?php 
				endwhile;
				endif;
			?>
		</ul>
	</div>
</div>
<?php
echo $args['after_widget'];
}		
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Trending Posts', 'gl_trending_widget_domain' );
}
 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '4', 'gl_trending_widget_domain' );
}
 if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '149', 'gl_popular_widget_domain' );
}
 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '95', 'gl_popular_widget_domain' );
}
?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>
<?php 
}
public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';
return $instance;
}
}
//trending post ends here
//Last Updated Post Widget Starts Here
class gl_last_update_widget extends WP_Widget {
function __construct() {
parent::__construct(
'gl_last_update_widget', 
__('Blogge - Last Updated Post', 'gl_last_update_widget_domain'), 
array( 'description' => __( 'Displays Last Updated Post', 'gl_last_update_widget_domain' ), ) 
);
}
public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];
?>
<div class="last_updated_pst sidebar_widget_bg ">	
	<div class="last_updated sidebar_content">
		<?php		
			// Query Arguments
			$lastupdated_args = array(
			'orderby' => 'modified',
			);
			//Loop to display 5 recently updated posts
			$lastupdated_loop = new WP_Query( $lastupdated_args );
			$counter = 1;
			echo '<ul>';
			while( $lastupdated_loop->have_posts() && $counter <= $instance[ 'post_count' ] ) : $lastupdated_loop->the_post();
			echo '<li>';		
echo"<div class='trend_img'>";
if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
 echo "<div class='featured_viedo_image featured_image'>";
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true);echo "</div>";	
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video
		
 // Defaults
        $f_img_width6 = 98;
        $f_img_height6 = 98;

		// Auto feature image defaults
		$thumb = get_post_thumbnail_id(); 
		$img_url = wp_get_attachment_url( $thumb,'full' ); 
		$image = aq_resize( $img_url,$f_img_width6,$f_img_height6, true );
		// Catch the Image defaults
        $catch_img_url = catch_that_image( $thumb,'full' );
        $catch_image = aq_resize( $catch_img_url, $f_img_width6, $f_img_height6, true );
        // Default Image
		if(has_post_thumbnail())
		echo
		"<div class=\"featured_image\">\n".
		"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width6 . "\" height=\"" . $f_img_height6 . "\" alt=\"" . get_the_title() . "\"><div class='thumb_hover'></div></a>\n".
		"</div>\n";
		elseif (catch_that_image()){ 
		echo
		"<div class=\"featured_image\">\n".
		"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width6 . "\" height=\"" . $f_img_height6 . "\" alt=\"" . get_the_title() . "\"></a>\n".
		"</div>\n"; 
		}
}
}		
		/*featured image ends here*/
echo "</div>".
'<h3><a href="' . get_permalink( $lastupdated_loop->post->ID ) . '"> ' .get_the_title( $lastupdated_loop->post->ID ) . '</a> ( '. get_the_modified_date() .')</h3> '.
'</li>';
			$counter++;
			endwhile; 
			echo '</ul>';
			wp_reset_postdata(); 
		
		?>
	</div>
</div>
<?php
echo $args['after_widget'];
}		
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Last Updated Posts', 'gl_last_update_widget_domain' );
}
 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '4', 'gl_last_update_widget_domain' );
}
?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>
<?php 
}
public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
return $instance;
}
} 
//Last Updated Post Widget Ends Here//
//Single Page Related Post Widget starts Here
class gl_related_post_widget extends WP_Widget {
function __construct() {
parent::__construct(
'gl_related_post_widget', 
__('Blogge - Single Related Post', 'gl_related_post_widget_domain'), 
array( 'description' => __( 'Displays Single Related Post', 'gl_related_post_widget_domain' ), ) 
);
}
public function widget( $args, $instance ) {
$related_title = apply_filters( 'related_title', $instance['related_title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );
echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];
?>
<div class="thesis_related single_page_cnt">
<?php
global $post;

	if ( is_single() ) {
		$tags = get_the_tags($post->ID);
			if ($tags) {
			$tag_ids = array();
			foreach($tags as $individual_tag) $tag_ids[] = $individual_tag->term_id;
			$args=array(
			'tag__in' => $tag_ids,
			'post__not_in' => array($post->ID),
			'showposts'=>$instance[ 'post_count' ],  // Number of related posts that will be shown.
			'caller_get_posts'=>1
			);
	$my_query = new wp_query($args);
			if( $my_query->have_posts() ) {
	echo	'<div id="relatedposts">'.
				'<div class="single_title">'.
					'<h3>'. $related_title .'</h3>'.
				'</div>'.
			'<div class="related_section">';
		while ($my_query->have_posts()) {
			$my_query->the_post();
			$i++;
			$class = ( $i % 3) ? 'related_post_section' : 'related_post_section last';
	 ?>
			<div class="<?php echo $class; ?>">
							<div class="related_img">
								<?php
if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
 echo "<div class='featured_viedo_image featured_image'>";
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true); "</div>";	
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video
						  $f_img_width8 = $instance['width_size'];
							$f_img_height8 =$instance['height_size'];
							$default_img =  'Feature_image'; 
						// Auto feature image defaults
						$thumb = get_post_thumbnail_id(); 
						$img_url = wp_get_attachment_url( $thumb,'full' ); 
						$image = aq_resize( $img_url, $f_img_width8, $f_img_height8, true );
						// Catch the Image defaults
						$catch_img_url = catch_that_image( $thumb,'full' );
						$catch_image = aq_resize( $catch_img_url, $f_img_width8, $f_img_height8, true );
						if(has_post_thumbnail())
						echo
						"<div class=\"featured_image\">\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width8 . "\" height=\"" . $f_img_height8 . "\" alt=\"" . get_the_title() . "\"></a><div class='img_hover'><a class=\"link\" href=\"" . get_permalink() . "\"></a></div>\n".
						"</div>\n";
						elseif (catch_that_image()){ 
						echo
						"<div class=\"featured_image\">\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width8 . "\" height=\"" . $f_img_height8 . "\" alt=\"" . get_the_title() . "\"></a><div class='img_hover'><a class=\"link\" href=\"" . get_permalink() . "\"></a></div>\n".
						"</div>\n";  
						}
						}
						}						
					?>
							</div>
							<div class="related_post_cnt">
									<?php echo "<h3><a href='". get_permalink() ."'>".get_the_title()."";
									echo "</a></h3>";?>
									<span class='date'><?php the_time('M jS, Y') ?></span>		
							</div>
					</div>
	<?php
			}
			echo '</div>';
			echo '</div>';
			}
		}
	$post = $backup;
			wp_reset_query();
			?>
			<div class="clear"></div>
			<?php
			 }		
?>
</div>
<?php
echo $args['after_widget'];
}		
public function form( $instance ) {
if ( isset( $instance[ 'related_title' ] ) ) {
$related_title = $instance[ 'related_title' ];
}
else {
$related_title = __( 'Related Post', 'gl_related_post_widget_domain' );
}
 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '3', 'gl_related_post_widget_domain' );
}
if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '228', 'gl_related_post_widget_domain' );
}
 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '223', 'gl_related_post_widget_domain' );
}
?>
<p>
<label for="<?php echo $this->get_field_id( 'related_title' ); ?>"><?php _e( 'Post Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'related_title' ); ?>" name="<?php echo $this->get_field_name( 'related_title' ); ?>" type="text" value="<?php echo esc_attr( $related_title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Left Latest News Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Left Latest News  Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>
<?php 
}
public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['related_title'] = ( ! empty( $new_instance['related_title'] ) ) ? strip_tags( $new_instance['related_title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';
return $instance;
}
}
//Single Page Related Post Widget Ends Here
// Register and load the widget
function gl_load_widget() {
	register_widget( 'gl_aboutus_widget' );
	register_widget( 'gl_search_widget' );
	register_widget( 'gl_popular_widget' );
	register_widget( 'gl_random_widget' );
	register_widget( 'gl_trending_widget' );
	register_widget( 'gl_last_update_widget' );
	register_widget( 'gl_related_post_widget' );
	
}
add_action( 'widgets_init', 'gl_load_widget' );