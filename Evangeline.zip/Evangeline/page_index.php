<?php
/**
 * This file adds the Grid Category Page to the Evangeline Theme.
 * @package Evangeline
 * @subpackage Customizations
 */
/*
Template Name: Grid Category 
*/
add_action('genesis_meta','evangeline_category_genesis_meta');
/**
 * Add widget support for Grid Category. If no widgets active, display the default loop.
 *
 */
function evangeline_category_genesis_meta() {
	if ( is_active_sidebar( 'grid-category' )) {
		remove_action('genesis_loop','genesis_do_loop');
		add_action('genesis_loop','evangeline_category_sections');
		add_filter('genesis_pre_get_option_site_layout','__genesis_return_content_sidebar');
	}}
function evangeline_category_sections() {
	genesis_widget_area( 'grid-category', array(
		'before'=>'<div class="grid-category widget-area">',
		'after'=>'</div>',
	));}
genesis();