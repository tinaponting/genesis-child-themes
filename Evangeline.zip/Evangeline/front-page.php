<?php
/**
 * This file adds the Home Page to the Evangeline Child Theme.
 * @package Evangeline
 * @subpackage Customizations
 */
add_action( 'genesis_meta', 'evangeline_home_genesis_meta' );
/**
 * Add widget support for homepage. If no widgets active, display the default loop.
 */
function evangeline_home_genesis_meta(){
	if ( is_active_sidebar('home-top') || is_active_sidebar('home-middle') || is_active_sidebar('home-bottom')){

		// Force content-sidebar layout setting
		add_filter('genesis_site_layout','__genesis_return_content_sidebar');

		// Add evangeline-home body class
		add_filter('body_class','evangeline_body_class');

		// Remove the default Genesis loop
		remove_action('genesis_loop','genesis_do_loop');

		// Add homepage widgets
		add_action('genesis_loop','evangeline_homepage_widgets');

	}}
function evangeline_body_class( $classes ) {
	$classes[] ='evangeline-home';return $classes;	
}
function evangeline_homepage_widgets(){
	genesis_widget_area('home-top',array(
		'before'=> '<div class="home-top widget-area">',
		'after'=>'</div>',
	));
	genesis_widget_area( 'home-middle', array(
		'before'=>'<div class="home-middle widget-area">',
		'after'=>'</div>',
	));
	genesis_widget_area( 'home-bottom', array(
		'before'=>'<div class="home-bottom widget-area">',
		'after'=>'</div>',
	));}
genesis();