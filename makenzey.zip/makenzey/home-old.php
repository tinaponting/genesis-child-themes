<?php
//* Add Genesis grid loop
remove_action( 'genesis_loop', 'genesis_do_loop' );
add_action( 'genesis_loop', 'makenzey_grid_loop_helper' );
function makenzey_grid_loop_helper() {
	if ( function_exists( 'genesis_grid_loop' ) ) {
		genesis_grid_loop( array(
			'features'=> 0,
			'feature_image_size'=> 1,
			'feature_image_class'=> 'alignleft post-image',
			'feature_content_limit'=> 0,
			'grid_image_size'=> 'new-grid',
			'grid_image_class'=> 'alignleft post-image',
			'grid_content_limit'=> 900,
			'more'=> __( '[Continue reading]', 'makenzey' ),
		));
	} else {genesis_standard_loop();
	}}
genesis();