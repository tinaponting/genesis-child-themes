<?php
//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );

//* Set Localization (do not remove)
load_child_theme_textdomain( 'makenzey', apply_filters( 'child_theme_textdomain', get_stylesheet_directory() . '/languages', 'makenzey' ) );

//* Child theme (do not remove)
define( 'CHILD_THEME_NAME', __( 'makenzey' ) );
define( 'CHILD_THEME_VERSION', '2.0' );

//* Customize the post info function
add_filter( 'genesis_post_info', 'sp_post_info_filter' );
function sp_post_info_filter($post_info) {
if ( !is_page() ) {$post_info = '[post_date]';return $post_info;
}}

//* Customize the entry meta in the entry footer (requires HTML5 theme support)
add_filter( 'genesis_post_meta', 'sp_post_meta_filter' );
function sp_post_meta_filter($post_meta) {
    $post_meta = '[post_categories] [post_tags] Posted by [post_author_posts_link] [post_comments] [post_edit] ';return $post_meta;
}

//* Position post info above post title
remove_action( 'genesis_entry_header', 'genesis_post_info', 12);
add_action( 'genesis_entry_header', 'genesis_post_info', 9 );

//* Add HTML5 markup structure
add_theme_support( 'html5' );

//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Load Google fonts
add_action( 'wp_enqueue_scripts', 'makenzey_google_fonts' );
function makenzey_google_fonts() {wp_enqueue_style( 'google-font', '//fonts.googleapis.com/css?family=Homemade+Apple:400|Josefin+Sans:400', array(), PARENT_THEME_VERSION );
}

//* Add new featured image size
add_image_size( 'grid-featured', 740, 400, TRUE );
add_image_size( 'grid', 740, 200, TRUE );
add_image_size( 'new-grid', 740, 250, array( 'left', 'top' ) );

//* Add support for custom header
add_theme_support( 'custom-header', array(
	'width'=> 600,
	'height'=> 140,
	'header-selector'=> '.site-header .title-area',
	'header-text'=> false
));

//* Add support for structural wraps
add_theme_support( 'genesis-structural-wraps', array(
	'header',
	'nav',
	'subnav',
	'site-inner',
	'footer-widgets',
	'footer'
));

//* Hook after post widget after the entry content
add_action( 'genesis_after_entry', 'makenzey_after_entry', 5 );
function makenzey_after_entry() {

	if ( is_singular( 'post' ) )
		genesis_widget_area( 'after-entry', array(
			'before'=> '<div class="after-entry widget-area">',
			'after'=> '</div>',
	));}

//* Reposition the primary navigation menu
remove_action( 'genesis_after_header', 'genesis_do_nav' );
add_action( 'genesis_before_header', 'genesis_do_nav' );

//* Reposition the secondary navigation menu
remove_action( 'genesis_after_header', 'genesis_do_subnav' );
add_action( 'genesis_before_content_sidebar_wrap', 'genesis_do_subnav' );

//* Add support for 3-column footer widgets
add_theme_support( 'genesis-footer-widgets', 3 );

//* Customize the credits
add_filter( 'genesis_footer_creds_text', 'custom_footer_creds_text' );
function custom_footer_creds_text() {
echo '<div class="creds"><p>';
echo 'Copyright &copy; ';
echo date('Y');
echo ' &middot; Theme Design by<a href="http://exempel.se"> Exempel</a>';
echo '</p></div>';
}
add_action( 'wp_enqueue_scripts', 'amethyst_load_mobile_nav_script' );
function amethyst_load_mobile_nav_script() {

    //Add mobile button script to secondary navigation menu
    wp_enqueue_script( 'nav_for_mobile', get_bloginfo( 'stylesheet_directory' ) . '/scripts/drop-down-nav.js', array('jquery'), '0.5' );
}
add_action( 'wp_enqueue_scripts', 'amethyst_load_mobile_script' );
function amethyst_load_mobile_script() {wp_enqueue_script( 'nav_mobile', get_bloginfo( 'stylesheet_directory' ) . '/scripts/primary-drop-down.js', array('jquery'), '0.5' );
}
//* Register widget areas
genesis_register_sidebar( array(
	'id'=> 'after-entry',
	'name'=> __( 'After Entry', 'makenzey' ),
	'description'=> __( 'This is the after entry widget area.', 'makenzey' ),
));
add_filter( 'genesis_gravatar_sizes', 'ck_user_profile' );
function ck_user_profile( $sizes ) {$sizes['Extra Large Image'] = 220;return $sizes;
}