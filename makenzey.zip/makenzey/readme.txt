Mackensey: bg-kenzey.gif, if you want someone else: Just change it to: bg-kenzey.gif, I uplades som alternative in images folder.

ROW: 89 change of footer text.