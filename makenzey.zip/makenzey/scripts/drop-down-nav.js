jQuery( function($) { 'use strict';
$( '<div id="menu-mobile">&#8801; Menu</div>' ).insertBefore( 'ul.menu-secondary' );
$( 'ul.menu-secondary' ).addClass( 'displaynone' );
$('#menu-mobile').click (function(){
$('.menu-secondary').slideToggle();
$(this).toggleClass('active');
});});