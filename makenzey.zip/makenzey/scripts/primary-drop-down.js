jQuery( function($) { 'use strict';
$( '<div id="menu-mobile-primary">&#8801; Menu</div>' ).insertBefore( 'ul.menu-primary' );
$( 'ul.menu-primary' ).addClass( 'displaynone' );
$('#menu-mobile-primary').click (function(){
$('.menu-primary').slideToggle();
$(this).toggleClass('active');
});});