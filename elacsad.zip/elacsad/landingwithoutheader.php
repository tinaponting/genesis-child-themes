<?php
/*
Template Name: Landing Page with out header
*/


// Add custom body class to the head
add_filter( 'body_class', 'metro_add_body_class' );
function metro_add_body_class( $classes ) {
   $classes[] = 'lwithheader';
   return $classes;
}

remove_action( 'genesis_sidebar_alt', 'genesis_do_sidebar_alt' );
remove_action( 'genesis_sidebar', 'genesis_do_sidebar' );
add_filter ( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );

add_action('genesis_before_content_sidebar_wrap','landingpage_video_section',2);
function landingpage_video_section(){
if(genesism_get_option('landing_page_cnt')){
?>
<div class="landingpage_video_section">
	<div class="inner_landingpage wrap">
		<div class="landingpage_leftcnt">
			<h3><?php echo genesism_option('landing_title');?></h3>
			<p><?php echo genesism_option('landing_cnt');?></p>
			<a href="<?php echo genesism_option('landing_read_link');?>"><?php echo genesism_option('landing_read');?></a>
		</div>
		<div class="landingpage_rightcnt">
			<?php echo genesism_option('landing_video_link');?>			
		</div>
	</div>
</div>
<?php 
}
}


genesis();