<?php

function elacsad_customize_register( $wp_customize ) {
 /*******************************************
Color scheme
********************************************/
 
// add the section to contain the settings
$wp_customize->add_section( 'textcolors' , array(
    'title' =>  'Color Scheme',
) );

// Background Color
$txtcolors[] = array(
    'slug'=>'body_bg_color', 
    'default' => '#f5f5f5',
    'label' => 'Background Color'
);

// Header Text Color
$txtcolors[] = array(
    'slug'=>'title_txt_color', 
    'default' => '#111',
    'label' => 'Header Text Color'
);

// Body Text Color
$txtcolors[] = array(
    'slug'=>'body_txt_color', 
    'default' => '#666666',
    'label' => 'Body Text Color'
);


// Title Hover Color
$txtcolors[] = array(
    'slug'=>'title_hover_color', 
    'default' => '#ed485c',
    'label' => 'Title Hover Color'
);

 
// Cat BG Color
$txtcolors[] = array(
    'slug'=>'cat_bg_color', 
    'default' => '#6033cc',
    'label' => ' Cat BG Color'
);


// Bottom Header BG Color
$txtcolors[] = array(
    'slug'=>'btm_bg', 
    'default' => '#2f3c4e',
    'label' => 'Bottom Header BG Color'
);

// Hover color
$txtcolors[] = array(
    'slug'=>'hover_color', 
    'default' => '#2f3c4e',
    'label' => 'Hover Color'
);

// Border color1 
$txtcolors[] = array(
    'slug'=>'border_color1', 
    'default' => '#e3e3e3',
    'label' => 'Border Color1 '
);

// Border color2 
$txtcolors[] = array(
    'slug'=>'border_color2', 
    'default' => '#ecedee',
    'label' => 'Border Color2 '
);

// Border color3 
$txtcolors[] = array(
    'slug'=>'border_color3', 
    'default' => '#5a5a5a',
    'label' => 'Border Color3 '
);


//Tag BG Color
$txtcolors[] = array(
    'slug'=>'tag_bg_color', 
    'default' => '#f6f6f6',
    'label' => 'Tag BG Color '
);

//Top Footer BG
$txtcolors[] = array(
    'slug'=>'top_footer_bg', 
    'default' => '#232930',
    'label' => 'Top Footer BG Color '
);

//Bottom Footer BG
$txtcolors[] = array(
    'slug'=>'bottom_footer_bg', 
    'default' => '#ed485c',
    'label' => 'Bottom Footer BG Color '
);

//Footer Border Color
$txtcolors[] = array(
    'slug'=>'footer_border_color', 
    'default' => '#363e44',
    'label' => 'Footer Border Color '
);




// add the settings and controls for each color
foreach( $txtcolors as $txtcolor ) {
 
    // SETTINGS
    $wp_customize->add_setting(
        $txtcolor['slug'], array(
            'default' => $txtcolor['default'],
            'type' => 'option', 
            'capability' => 
            'edit_theme_options'
        )
    );
    // CONTROLS
    $wp_customize->add_control(
        new WP_Customize_Color_Control(
            $wp_customize,
            $txtcolor['slug'], 
            array('label' => $txtcolor['label'], 
            'section' => 'textcolors',
            'settings' => $txtcolor['slug'])
        )
    );
}
}
add_action( 'customize_register', 'elacsad_customize_register' );