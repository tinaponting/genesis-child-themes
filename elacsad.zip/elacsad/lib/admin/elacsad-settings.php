<?php

/**
 * This function registers the default values for genesis theme settings
 */
 
function genesism_theme_settings_defaults() {
$defaults = array( // define our defaults
'style' => 'default',
'custom' => 0,
'shortcodes-css' => 1,

'f_img_width'=>'760',
'f_img_height'=>'428',

'header' => 1,
'top_ad' => 1,
'bottom_menu' => 1,
'search_box' => 1,
'header_social' => 1,
'optin_section' => 1,
'read_more' => 1,
'home_social' => 1,
'sidebar_ad' => 1,
'sidebar_optin' => 1,
'postadcheck' => 1,
'social_post_button' => 1,
'landing_page_cnt' => 1,
'landing_feature' => 1,
'footer_about' => 1,
'footer_recent' => 1,
'footer_menu' => 1,
'footer1' => 1,

'header_text' => 'http://elacsad.genesislovers.com/wp-content/uploads/2016/03/logo.png',
'top_ad_img' => '<img alt="Header Ad" src="http://elacsad.genesislovers.com/wp-content/uploads/2016/03/topad.png"/>',
'search_title' => 'Search',
'search_text' => 'Search here...',
'header_socail_title' => 'Follow Me',

'optin_bg' => 'http://elacsad.genesislovers.com/wp-content/uploads/2016/03/optin.jpg',
'optin_header1' => 'Lorem ipsum is simply dummy text',
'optin_cnt' => 'There are many variations of passages of Lorem Ipsum available.',
'name_text' => 'Enter your name',
'email_text' => 'Enter your email',
'submit_text1' => 'Subscribe me',
'read_text' => 'View More',
'sidebar_ad_title' => 'Advertisement ',
'sidebar_ad_img' => '<img alt="Sidebar Ad" src="http://elacsad.genesislovers.com/wp-content/uploads/2016/03/sidebarad.jpg"/>',
'sidebar_optin_header' => 'Newsletter',
'name_text2' => 'Enter your name',
'email_text2' => 'Enter your email',
'submit_text2' => 'Subscribe me',
'float' => 'right',
'postad' => '<img alt="Single Page Ad" src="http://elacsad.genesislovers.com/wp-content/uploads/2016/03/300x250.jpg"/>',
'sharehead' => 'Social Share',

'landing_title' => 'Lorem ipsum dolor sit amet',
'landing_cnt' => 'Lorem ipsum dolor sit amet, mauris suspendisse viverra eleifend tortor tellus suscipit, tortor aliquet at nulla mus, dignissim neque, nulla neque. Ultrices proin mi urna nibh ut, aenean sollicitudin etiam libero nisl, ultrices ridiculus in magna purus consequuntur, ipsum donec orci ad vitae pede, id odio.',
'landing_read' => 'Read More',
'landing_video_link' => '<iframe width="560" height="315" src="https://www.youtube.com/embed/AbeIhvxOVp8" allowfullscreen></iframe>',

'landing_feature_title' => 'Landing Page Feature',
'landing_feature_img1' => 'http://elacsad.genesislovers.com/wp-content/uploads/2016/03/feature1.png',
'landing_feature_subtitle1' => 'Lorem Ipsum is simply dummy text',
'landing_feature_cnt1' => 'All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words.',
'landing_feature_read_txt1' => 'Read More',
'landing_feature_img2' => 'http://elacsad.genesislovers.com/wp-content/uploads/2016/03/feature2.png',
'landing_feature_subtitle2' => 'Lorem Ipsum is simply dummy text',
'landing_feature_cnt2' => 'All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words.',
'landing_feature_read_txt2' => 'Read More',
'landing_feature_img3' => 'http://elacsad.genesislovers.com/wp-content/uploads/2016/03/feature3.png',
'landing_feature_subtitle3' => 'Lorem Ipsum is simply dummy text',
'landing_feature_cnt3' => 'All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words.',
'landing_feature_read_txt3' => 'Read More',
'landing_feature_img4' => 'http://elacsad.genesislovers.com/wp-content/uploads/2016/03/feature4.png',
'landing_feature_subtitle4' => 'Lorem Ipsum is simply dummy text',
'landing_feature_cnt4' => 'All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words.',
'landing_feature_read_txt4' => 'Read More',

'footer_abt_tle' => 'About Me',
'footer_abt_cnt' => 'All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet.',
'footer_social_tle' => 'Social',
'recent_comments_title' => 'Recent Comments',


'footer_text' => 'Copyright &copy;'.date('Y') .  ' <a href="'. get_bloginfo('url') .'">' . get_bloginfo('name') . '</a>'
	
	);
	
	return apply_filters('genesism_theme_settings_defaults', $defaults);

}



function genesism_theme_settings_boxes() {
	global $_genesism_theme_settings_pagehook;
	
	if (function_exists('add_screen_option')) { add_screen_option('layout_columns', array('max' => 2, 'default' => 2) ); }

add_meta_box('genesism-theme-settings-version', __('Theme Information', 'genesism'), 'genesism_theme_settings_info_box', $_genesism_theme_settings_pagehook, 'normal');	
 }
  
 function genesism_theme_settings_info_box() { 
?>

<p class="bolder"><strong><?php echo CHILD_THEME_NAME; ?></strong> by <a href="http://genesislovers.com">genesislovers.com</a></p>
<p><strong>
  <?php _e('Version:', 'genesism'); ?>
  </strong> <?php echo CHILD_THEME_VERSION; ?> <strong>
   </p>
<p><span class="description">
  <?php _e('For support, please visit <a href="http://genesislovers.com/contact-us/">http://genesislovers.com/contact-us/</a>', 'genesism'); ?>
  </span></p>

<div id="tabs">
	<ul>
		<li><a href="#tabs-1"><?php _e("Header Logo", 'genesism'); ?></a></li>
		<li><a href="#tabs-2"><?php _e("Header Advertisement", 'genesism'); ?></a></li>
		<li><a href="#tabs-3"><?php _e("Bottom Menu", 'genesism'); ?></a></li>
		<li><a href="#tabs-4"><?php _e("Search Box", 'genesism'); ?></a></li>
		<li><a href="#tabs-5"><?php _e("Header Social follow", 'genesism'); ?></a></li>
		<li><a href="#tabs-6"><?php _e("Optin Section Box", 'genesism'); ?></a></li>		
		<li><a href="#tabs-7"><?php _e("Feature image on Blog Post", 'genesism'); ?></a></li>
		<li><a href="#tabs-8"><?php _e("Read More Box", 'genesism'); ?></a></li>
		<li><a href="#tabs-9"><?php _e("Home Page Social Share", 'genesism'); ?></a></li>
		
		<li><a href="#tabs-10"><?php _e("Sidebar Advertisement Box ", 'genesism'); ?></a></li>
		<li><a href="#tabs-11"><?php _e("Sidebar Optin Box ", 'genesism'); ?></a></li>
		<li><a href="#tabs-12"><?php _e("Single Page Advertisement Box ", 'genesism'); ?></a></li>
		<li><a href="#tabs-13"><?php _e("Single Page Social Sharing Box ", 'genesism'); ?></a></li>
		
		<li><a href="#tabs-14"><?php _e("Landing Page Video Section ", 'genesism'); ?></a></li>
		<li><a href="#tabs-15"><?php _e("Landing Page Feature section", 'genesism'); ?></a></li>
		<li><a href="#tabs-16"><?php _e("Footer Aboutus & Social Follow", 'genesism'); ?></a></li>
		<li><a href="#tabs-17"><?php _e("Footer Recent Comments", 'genesism'); ?></a></li>
		<li><a href="#tabs-18"><?php _e("Footer Menu Section", 'genesism'); ?></a></li>
		
		<li><a href="#tabs-19"><?php _e("Footer Text section", 'genesism'); ?></a></li>
		<li><a href="#tabs-20"><?php _e("Custom CSS", 'genesism'); ?></a></li>
	</ul>
	<div id="tabs-1">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[header]" id="<?php echo ELACSAD_SETTINGS_FIELD; ?>[header]" value="1" <?php checked(1, genesism_get_option('header')); ?> />
				<label for="<?php echo ELACSAD_SETTINGS_FIELD; ?>[header]">
				<?php _e("Enable Header Logo", 'genesism'); ?>
				</label>
			</li>
				<li class="second_list">
				<label>Enter the Logo image url here</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[header_text]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('header_text') ); ?></textarea>
			</li>
		</ul>
	</div>
	
	<div id="tabs-2">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[top_ad]" id="<?php echo ELACSAD_SETTINGS_FIELD; ?>[top_ad]" value="1" <?php checked(1, genesism_get_option('top_ad')); ?> />
				<label for="<?php echo ELACSAD_SETTINGS_FIELD; ?>[top_ad]">
				<?php _e("Enable Header Advertisement", 'genesism'); ?>
				</label>
			</li>
				<li class="second_list">
				<label>Enter the Header Advertisement URL Link here</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[top_ad_img]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('top_ad_img') ); ?></textarea>
			</li>
		</ul>
	</div>
	<div id="tabs-3">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[bottom_menu]" id="<?php echo ELACSAD_SETTINGS_FIELD; ?>[bottom_menu]" value="1" <?php checked(1, genesism_get_option('bottom_menu')); ?> />
				<label for="<?php echo ELACSAD_SETTINGS_FIELD; ?>[bottom_menu]">
				<?php _e("Enable Bottom Menu Section", 'genesism'); ?>
				</label>
			</li>
		</ul>
	</div>
	
	
	<div id="tabs-4">
		 <ul>
			<li class="first_list chkbox">
			  <input type="checkbox" name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[search_box]" id="<?php echo ELACSAD_SETTINGS_FIELD; ?>[search_box]" value="1" <?php checked(1, genesism_get_option('search_box')); ?> />
			   <label for="<?php echo ELACSAD_SETTINGS_FIELD; ?>[search_box]">
			  <?php _e("Enable Search Box", 'genesism'); ?>
			 </label>
			</li>
			<li class="second_list">
			  <label>Enter the Search Box Title here</label>
			  <textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[search_title]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('search_title') ); ?></textarea>
			</li>
			<li class="second_list">
			  <label>Enter the Search Place holder Text here</label>
			  <textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[search_text]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('search_text') ); ?></textarea>
			</li>
		</ul>
	</div>
	
	<div id="tabs-5">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[header_social]" id="<?php echo ELACSAD_SETTINGS_FIELD; ?>[header_social]" value="1" <?php checked(1, genesism_get_option(header_social)); ?> />
				<label for="<?php echo ELACSAD_SETTINGS_FIELD; ?>[header_social]">
				<?php _e("Enable Social follow", 'genesism'); ?>
				</label>
			</li>
			<li class="second_list"><label>Header Social Follow Title Here</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[header_socail_title]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option(header_socail_title) ); ?></textarea> 
			</li>
			<li class="second_list"><label>Paste Your Facebook URL Link</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[facebook_text2]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option(facebook_text2) ); ?></textarea> 
			</li>
			<li class="second_list"><label>Paste Your Twitter URL Link</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[twitter_text2]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('twitter_text2') ); ?></textarea> 
			</li>
			<li class="second_list"><label>Paste Your Dribbble URL Link</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[dribbble_text2]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('dribbble_text2') ); ?></textarea>
			</li>
			<li class="second_list"><label>Paste Your Googleplus URL Link</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[googleplus_text2]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('googleplus_text2') ); ?></textarea> 
			</li>
			<li class="second_list"><label>Paste Your Vimeo URL Link</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[vimeo_text2]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('vimeo_text2') ); ?></textarea>
			</li>
			<li class="second_list"><label>Paste Your Youtube URL Link</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[youtube_text2]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('youtube_text2') ); ?></textarea>
			</li>	


			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[fb_check2]" id="<?php echo ELACSAD_SETTINGS_FIELD; ?>[fb_check2]" value="1" <?php checked(1, genesism_get_option('fb_check2')); ?> />
				<label for="<?php echo ELACSAD_SETTINGS_FIELD; ?>[fb_check2]">
				<?php _e("Disable Facebook icon", 'genesism'); ?>
				</label>
			</li>

				<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[twi_check2]" id="<?php echo ELACSAD_SETTINGS_FIELD; ?>[twi_check2]" value="1" <?php checked(1, genesism_get_option('twi_check2')); ?> />
				<label for="<?php echo ELACSAD_SETTINGS_FIELD; ?>[twi_check2]">
				<?php _e("Disable Twitter icon", 'genesism'); ?>
				</label>
			</li>
			
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[drbl_check2]" id="<?php echo ELACSAD_SETTINGS_FIELD; ?>[drbl_check2]" value="1" <?php checked(1, genesism_get_option('drbl_check2')); ?> />
				<label for="<?php echo ELACSAD_SETTINGS_FIELD; ?>[drbl_check2]">
				<?php _e("Disable Dribbble icon", 'genesism'); ?>
				</label>
			</li>
			
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[gp_check2]" id="<?php echo ELACSAD_SETTINGS_FIELD; ?>[gp_check2]" value="1" <?php checked(1, genesism_get_option('gp_check2')); ?> />
				<label for="<?php echo ELACSAD_SETTINGS_FIELD; ?>[gp_check2]">
				<?php _e("Disable Google Plus icon", 'genesism'); ?>
				</label>
			</li>
			
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[vimeo_check2]" id="<?php echo ELACSAD_SETTINGS_FIELD; ?>[vimeo_check2]" value="1" <?php checked(1, genesism_get_option('vimeo_check2')); ?> />
				<label for="<?php echo ELACSAD_SETTINGS_FIELD; ?>[vimeo_check2]">
				<?php _e("Disable Vimeo icon", 'genesism'); ?>
				</label>
			</li>
			
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[yt_check2]" id="<?php echo ELACSAD_SETTINGS_FIELD; ?>[yt_check2]" value="1" <?php checked(1, genesism_get_option('yt_check2')); ?> />
				<label for="<?php echo ELACSAD_SETTINGS_FIELD; ?>[yt_check2]">
				<?php _e("Disable Youtube icon", 'genesism'); ?>
				</label>
			</li>
			
		</ul>			
	</div>
	
	<div id="tabs-6">
		 <ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[optin_section]" id="<?php echo ELACSAD_SETTINGS_FIELD; ?>[optin_section]" value="1" <?php checked(1, genesism_get_option('optin_section')); ?> />
				<label for="<?php echo ELACSAD_SETTINGS_FIELD; ?>[optin_section]">
				<?php _e("Enable Optin Section Box", 'genesism'); ?>
				</label>
			</li>
			<li class="second_list">
				<label>Paste your optin code and Press Tab Button</label>
				<textarea id="optin_code" name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[optin_code]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_code') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form name</label>
				<textarea id="optin_name" name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[optin_name]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('optin_name') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form Email</label>
				<textarea id="optin_email" name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[optin_email]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('optin_email') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form action url</label>
				<textarea id="optin_url" name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[optin_url]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_url') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Hidden fields</label>
				<textarea id="optin_hidden" name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[optin_hidden]" rows="10" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_hidden') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Enter your Optin Background Image URL Link</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[optin_bg]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_bg') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Enter your Optin Header Text</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[optin_header1]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_header1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Enter your Optin Header Text</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[optin_cnt]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_cnt') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change your Enter your name text here</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[name_text]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('name_text') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Change your Enter your email text here</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[email_text]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('email_text') ); ?></textarea>
			</li>
			
						
			
			<li class="second_list">
				<label>Change your Subscribe me button text</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[submit_text1]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('submit_text1') ); ?></textarea>
			</li>
		  </ul>
<script type="text/javascript">
var j = jQuery.noConflict();
j(document).ready(function(){
j("#optin_code").blur(function(){
var txt=j(this).val();
if(txt=="")
{
j("#optin_url").val("");
j("#optin_hidden").val("");
j("#optin_name").val("");
j("#optin_email").val("");
return false;
}
var pos1=0;
var pos2=0;
var i=1;
var hidden="";
while(1)
{
pos1=txt.indexOf("<input",pos1);
if(pos1<0) break;
pos2=txt.indexOf(">",pos1+1);
var text=txt.substr(pos1,pos2-pos1);
pp=text.indexOf('type="hidden"');
pp1=text.indexOf('type="submit"');
if(pp>0)
{
hidden+=text+">";
}
if(pp<0 && pp1<0){
pp=text.indexOf('name="');
pp=pp+6;
pp1=text.indexOf('"',pp+1);
var tt=text.substr(pp,pp1-pp);
if(i==1) j("#optin_name").val(tt);
else j("#optin_email").val(tt);
i++;
}
pos1=pos2+1;
}
pos1=txt.indexOf("<form",0);
pos2=txt.indexOf(">",pos1+1);
text=txt.substr(pos1,pos2-pos1);
pp=text.indexOf('action="');
pp=pp+8;
pp1=text.indexOf('"',pp+1);
var tt=text.substr(pp,pp1-pp);
j("#optin_url").val(tt);
j("#optin_hidden").val(hidden);
});
});
</script>  
	</div>
	

		
	<div id="tabs-7">
		<ul>
			<li class="second_list">
				<label>Enter the Blog Post feature image Width Size here</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[f_img_width]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('f_img_width') ); ?></textarea> 
			</li>
			<li class="second_list">
				<label>Enter the Blog Post feature image Height Size here</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[f_img_height]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('f_img_height') ); ?></textarea> 
			</li>
		</ul>
	</div>
	
	<div id="tabs-8">
		<ul>
			<li class="first_list chkbox">
			  <input type="checkbox" name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[read_more]" id="<?php echo ELACSAD_SETTINGS_FIELD; ?>[read_more]" value="1" <?php checked(1, genesism_get_option('read_more')); ?> />
			   <label for="<?php echo ELACSAD_SETTINGS_FIELD; ?>[read_more]">
			  <?php _e("Enable Read More Box", 'genesism'); ?>
			 </label>
			</li>
			<li class="second_list">
			  <label>Change Your Read More Text here</label>
			  <textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[read_text]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('read_text') ); ?></textarea>
			</li>
		</ul>
	</div>
	
	<div id="tabs-9">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[home_social]" id="<?php echo ELACSAD_SETTINGS_FIELD; ?>[home_social]" value="1" <?php checked(1, genesism_get_option('home_social')); ?> />
				<label for="<?php echo ELACSAD_SETTINGS_FIELD; ?>[home_social]">
				<?php _e("Enable Home Page social share section", 'genesism'); ?>
				</label>
			</li>
			
		</ul>
	</div>
	
	<div id="tabs-10">
		<ul>
			<li class="first_list chkbox">
			  <input type="checkbox" name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[sidebar_ad]" id="<?php echo ELACSAD_SETTINGS_FIELD; ?>[sidebar_ad]" value="1" <?php checked(1, genesism_get_option('sidebar_ad')); ?> />
				<label for="<?php echo ELACSAD_SETTINGS_FIELD; ?>[sidebar_ad]">
				<?php _e("Enable Sidebar Advertisement Box", 'genesism'); ?>
			  </label>
			</li>
			
			<li class="second_list">
				<label>Enter the Sidebar Advertisement Title Here</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[sidebar_ad_title]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('sidebar_ad_title') ); ?></textarea> 
			 </li>
			 
			<li class="second_list">
				<label>Enter the Sidebar Advertisement Image URL Link Here</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[sidebar_ad_img]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('sidebar_ad_img') ); ?></textarea> 
			 </li>
		</ul>
	</div>
	
	<div id="tabs-11">
		<ul>
			<li class="first_list chkbox">
			  <input type="checkbox" name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[sidebar_optin]" id="<?php echo ELACSAD_SETTINGS_FIELD; ?>[sidebar_optin]" value="1" <?php checked(1, genesism_get_option('sidebar_optin')); ?> />
				<label for="<?php echo ELACSAD_SETTINGS_FIELD; ?>[sidebar_optin]">
				<?php _e("Enable Sidebar Optin Box", 'genesism'); ?>
			  </label>
			</li>
			<li class="second_list">
				<label>Paste your optin code and Press Tab Button</label>
				<textarea id="optin_code1" name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[optin_code1]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_code1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form name</label>
				<textarea id="optin_name1" name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[optin_name1]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('optin_name1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form Email</label>
				<textarea id="optin_email1" name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[optin_email1]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('optin_email1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form action url</label>
				<textarea id="optin_url1" name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[optin_url1]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_url1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Hidden fields</label>
				<textarea id="optin_hidden1" name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[optin_hidden1]" rows="10" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_hidden1') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Enter your Sidebar Optin Header Text</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[sidebar_optin_header]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('sidebar_optin_header') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Change your Enter your name text here</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[name_text2]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('name_text2') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Change your Enter your email text here</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[email_text2]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('email_text2') ); ?></textarea>
			</li>						
			
			<li class="second_list">
				<label>Change your Subscribe me button text</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[submit_text2]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('submit_text2') ); ?></textarea>
			</li>
		  </ul>
<script type="text/javascript">
var j = jQuery.noConflict();
j(document).ready(function(){
j("#optin_code1").blur(function(){
var txt=j(this).val();
if(txt=="")
{
j("#optin_url1").val("");
j("#optin_hidden1").val("");
j("#optin_name1").val("");
j("#optin_email1").val("");
return false;
}
var pos1=0;
var pos2=0;
var i=1;
var hidden="";
while(1)
{
pos1=txt.indexOf("<input",pos1);
if(pos1<0) break;
pos2=txt.indexOf(">",pos1+1);
var text=txt.substr(pos1,pos2-pos1);
pp=text.indexOf('type="hidden"');
pp1=text.indexOf('type="submit"');
if(pp>0)
{
hidden+=text+">";
}
if(pp<0 && pp1<0){
pp=text.indexOf('name="');
pp=pp+6;
pp1=text.indexOf('"',pp+1);
var tt=text.substr(pp,pp1-pp);
if(i==1) j("#optin_name1").val(tt);
else j("#optin_email1").val(tt);
i++;
}
pos1=pos2+1;
}
pos1=txt.indexOf("<form",0);
pos2=txt.indexOf(">",pos1+1);
text=txt.substr(pos1,pos2-pos1);
pp=text.indexOf('action="');
pp=pp+8;
pp1=text.indexOf('"',pp+1);
var tt=text.substr(pp,pp1-pp);
j("#optin_url1").val(tt);
j("#optin_hidden1").val(hidden);
});
});
</script> 
	</div>
	
	<div id="tabs-12">
		<ul>
			<li class="first_list chkbox">
			  <input type="checkbox" name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[postadcheck]" id="<?php echo ELACSAD_SETTINGS_FIELD; ?>[postadcheck]" value="1" <?php checked(1, genesism_get_option('postadcheck')); ?> />
				<label for="<?php echo ELACSAD_SETTINGS_FIELD; ?>[postadcheck]">
				<?php _e("Enable Single Page  Postad section", 'genesism'); ?>
			  </label>
			</li>
			<li class="second_list">
				<label>Enter the advertisement position ... left or right...</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[float]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('float') ); ?></textarea> 
			</li>
			<li class="second_list">
				<label>Enter the Post Advertisement Image url</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[postad]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('postad') ); ?></textarea> 
			 </li>
		</ul>
	</div>
	
	<div id="tabs-13">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[social_post_button]" id="<?php echo ELACSAD_SETTINGS_FIELD; ?>[social_post_button]" value="1" <?php checked(1, genesism_get_option('social_post_button')); ?> />
				<label for="<?php echo ELACSAD_SETTINGS_FIELD; ?>[social_post_button]">
				<?php _e("Enable Single Page Social Sharing Box", 'genesism'); ?>
				</label>
			</li>
			<li class="second_list">
				<label>Enter the Social Share Heading here</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[sharehead]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('sharehead') ); ?></textarea>
			</li>
		</ul>
	</div>
	
	<div id="tabs-14">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[landing_page_cnt]" id="<?php echo ELACSAD_SETTINGS_FIELD; ?>[landing_page_cnt]" value="1" <?php checked(1, genesism_get_option('landing_page_cnt')); ?> />
				<label for="<?php echo ELACSAD_SETTINGS_FIELD; ?>[landing_page_cnt]">
				<?php _e("Enable Landing Page Video Section", 'genesism'); ?>
				</label>
			</li>
			<li class="second_list">
				<label>Change Your Landing Page Title here</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[landing_title]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_title') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change Your Landing Page Content here</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[landing_cnt]" rows="4" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_cnt') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change Your Landing Page Read More Text here</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[landing_read]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('landing_read') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change Your Landing Page Read More Text URL Link here</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[landing_read_link]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_read_link') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change Your Landing Page Video Image URL Link here</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[landing_video_link]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_video_link') ); ?></textarea>
			</li>
			
		</ul>
	</div>
	
	<div id="tabs-15">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[landing_feature]" id="<?php echo ELACSAD_SETTINGS_FIELD; ?>[landing_feature]" value="1" <?php checked(1, genesism_get_option('landing_feature')); ?> />
				<label for="<?php echo ELACSAD_SETTINGS_FIELD; ?>[landing_feature]">
				<?php _e("Enable Landing Page Feature Section", 'genesism'); ?>
				</label>
			</li>
			
			<li class="second_list">
				<label>Change the Landing Page Feature Title text here</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[landing_feature_title]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('landing_feature_title') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Paste the Landing Page Feature Image1 URL Link here</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[landing_feature_img1]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_img1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Page Feature Subtitle Text1 here</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[landing_feature_subtitle1]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('landing_feature_subtitle1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Page Feature Content1 here</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[landing_feature_cnt1]" rows="4" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_cnt1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Page Feature Read More Text1 here</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[landing_feature_read_txt1]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('landing_feature_read_txt1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Paste the Landing Page Feature Read More Text1 URL Link here</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[landing_feature_readtxt_link1]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_readtxt_link1') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Paste the Landing Page Feature Image2 URL Link here</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[landing_feature_img2]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_img2') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Page Feature Subtitle Text2 here</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[landing_feature_subtitle2]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('landing_feature_subtitle2') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Page Feature Content2 here</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[landing_feature_cnt2]" rows="4" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_cnt2') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Page Feature Read More Text2 here</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[landing_feature_read_txt2]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('landing_feature_read_txt2') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Paste the Landing Page Feature Read More Text2 URL Link here</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[landing_feature_readtxt_link2]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_readtxt_link2') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Paste the Landing Page Feature Image3 URL Link here</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[landing_feature_img3]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_img3') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Page Feature Subtitle Text3 here</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[landing_feature_subtitle3]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('landing_feature_subtitle3') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Page Feature Content3 here</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[landing_feature_cnt3]" rows="4" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_cnt3') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Page Feature Read More Text3 here</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[landing_feature_read_txt3]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('landing_feature_read_txt3') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Paste the Landing Page Feature Read More Text3 URL Link here</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[landing_feature_readtxt_link3]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_readtxt_link3') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Paste the Landing Page Feature Image4 URL Link here</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[landing_feature_img4]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_img4') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Page Feature Subtitle Text4 here</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[landing_feature_subtitle4]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('landing_feature_subtitle4') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Page Feature Content4 here</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[landing_feature_cnt4]" rows="4" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_cnt4') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Page Feature Read More Text4 here</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[landing_feature_read_txt4]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('landing_feature_read_txt4') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Paste the Landing Page Feature Read More Text4 URL Link here</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[landing_feature_readtxt_link4]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_readtxt_link4') ); ?></textarea>
			</li>
			
			
		</ul>
	</div>
	
	<div id="tabs-16">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[footer_about]" id="<?php echo ELACSAD_SETTINGS_FIELD; ?>[footer_about]" value="1" <?php checked(1, genesism_get_option('footer_about')); ?> />
				<label for="<?php echo ELACSAD_SETTINGS_FIELD; ?>[footer_about]">
				<?php _e("Enable Footer About Us and Social Follow Section", 'genesism'); ?>
				</label>
			</li>
			
			<li class="second_list">
				<label>Change the Footer About Us Title text here</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[footer_abt_tle]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('footer_abt_tle') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Paste the Footer About Us Content here</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[footer_abt_cnt]" rows="4" cols="70"><?php echo htmlspecialchars( genesism_get_option('footer_abt_cnt') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Footer Social Follow Text here</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[footer_social_tle]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('footer_social_tle') ); ?></textarea>
			</li>
			
			<li class="second_list"><label>Paste Your Facebook URL Link</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[facebook_text3]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('facebook_text3') ); ?></textarea> 
			</li>
			<li class="second_list"><label>Paste Your Twitter URL Link</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[twitter_text3]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('twitter_text3') ); ?></textarea> 
			</li>
			<li class="second_list"><label>Paste Your Instagram URL Link</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[instagram_text3]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('instagram_text3') ); ?></textarea>
			</li>
			<li class="second_list"><label>Paste Your Youtube URL Link</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[youtube_text3]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('youtube_text3') ); ?></textarea>
			</li>
			<li class="second_list"><label>Paste Your Linkedin URL Link</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[linkedin_text3]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('linkedin_text3') ); ?></textarea> 
			</li>
			<li class="second_list"><label>Paste Your Pinterest URL Link</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[pinterest_text3]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('pinterest_text3') ); ?></textarea>
			</li>
					
			
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[fb_check3]" id="<?php echo ELACSAD_SETTINGS_FIELD; ?>[fb_check3]" value="1" <?php checked(1, genesism_get_option('fb_check3')); ?> />
				<label for="<?php echo ELACSAD_SETTINGS_FIELD; ?>[fb_check3]">
				<?php _e("Disable Facebook icon", 'genesism'); ?>
				</label>
			</li>

				<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[twi_check3]" id="<?php echo ELACSAD_SETTINGS_FIELD; ?>[twi_check3]" value="1" <?php checked(1, genesism_get_option('twi_check3')); ?> />
				<label for="<?php echo ELACSAD_SETTINGS_FIELD; ?>[twi_check3]">
				<?php _e("Disable Twitter icon", 'genesism'); ?>
				</label>
			</li>
			
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[inst_check3]" id="<?php echo ELACSAD_SETTINGS_FIELD; ?>[inst_check3]" value="1" <?php checked(1, genesism_get_option('inst_check3')); ?> />
				<label for="<?php echo ELACSAD_SETTINGS_FIELD; ?>[inst_check3]">
				<?php _e("Disable Instagram icon", 'genesism'); ?>
				</label>
			</li>
			
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[yt_check3]" id="<?php echo ELACSAD_SETTINGS_FIELD; ?>[yt_check3]" value="1" <?php checked(1, genesism_get_option('yt_check3')); ?> />
				<label for="<?php echo ELACSAD_SETTINGS_FIELD; ?>[yt_check3]">
				<?php _e("Disable Youtube icon", 'genesism'); ?>
				</label>
			</li>
			
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[lin_check3]" id="<?php echo ELACSAD_SETTINGS_FIELD; ?>[lin_check3]" value="1" <?php checked(1, genesism_get_option('lin_check3')); ?> />
				<label for="<?php echo ELACSAD_SETTINGS_FIELD; ?>[lin_check3]">
				<?php _e("Disable Linkedin icon", 'genesism'); ?>
				</label>
			</li>
			
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[pint_check3]" id="<?php echo ELACSAD_SETTINGS_FIELD; ?>[pint_check3]" value="1" <?php checked(1, genesism_get_option('pint_check3')); ?> />
				<label for="<?php echo ELACSAD_SETTINGS_FIELD; ?>[pint_check3]">
				<?php _e("Disable Pinterest icon", 'genesism'); ?>
				</label>
			</li>
			
			
			
		</ul>
	</div>
	
	<div id="tabs-17">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[footer_recent]" id="<?php echo ELACSAD_SETTINGS_FIELD; ?>[footer_recent]" value="1" <?php checked(1, genesism_get_option('footer_recent')); ?> />
				<label for="<?php echo ELACSAD_SETTINGS_FIELD; ?>[footer_recent]">
				<?php _e("Enable Footer Recent Comment Section", 'genesism'); ?>
				</label>
			</li>
			
			<li class="second_list">
				<label>Change the Footer Recent Comment Title text here</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[recent_comments_title]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('recent_comments_title') ); ?></textarea>
			</li>
			
		</ul>
	</div>
	<div id="tabs-18">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[footer_menu]" id="<?php echo ELACSAD_SETTINGS_FIELD; ?>[footer_menu]" value="1" <?php checked(1, genesism_get_option('footer_menu')); ?> />
				<label for="<?php echo ELACSAD_SETTINGS_FIELD; ?>[footer_menu]">
				<?php _e("Enable Footer Menu Section", 'genesism'); ?>
				</label>
			</li>
		</ul>
	</div>
	
	<div id="tabs-19">
		 <ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[footer1]" id="<?php echo ELACSAD_SETTINGS_FIELD; ?>[footer1]" value="1" <?php checked(1, genesism_get_option('footer1')); ?> />
				<label for="<?php echo ELACSAD_SETTINGS_FIELD; ?>[footer1]">
				<?php _e("Enable Footer text", 'genesism'); ?>
				</label>
			</li>
			<li class="second_list"><label>Use custom footer text?</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[footer_text]" rows="5" cols="50"><?php echo htmlspecialchars( genesism_get_option('footer_text') ); ?></textarea> 
			</li>
		</ul>
	</div>
	
	<div id="tabs-20">
		 <ul>
			
			<li class="second_list"><label>Enter the Custom CSS Code here</label>
				<textarea name="<?php echo ELACSAD_SETTINGS_FIELD; ?>[custom_css]" rows="20" cols="70"><?php echo htmlspecialchars( genesism_get_option('custom_css') ); ?></textarea> 
			</li>
		</ul>
	</div>
	
</div>    
  
 
 
<?php
}
 