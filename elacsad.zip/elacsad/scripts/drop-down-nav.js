var j=jQuery.noConflict();
( function( window, j, undefined ) {
	'use strict';

	j( 'nav' ).before( '<button type="button" class="menu-toggle" role="button" aria-pressed="false"></button>' ); // Add toggles to menus
	j( 'nav .sub-menu' ).before( '<button class="sub-menu-toggle" role="button" aria-pressed="false"></button>' ); // Add toggles to sub menus

	// Show/hide the navigation
	j( '.menu-toggle, .sub-menu-toggle' ).on( 'click', function() {
		var jthis = j( this );
		jthis.attr( 'aria-pressed', function( index, value ) {
			return 'false' === value ? 'true' : 'false';
		});

		jthis.toggleClass( 'activated' );
		jthis.next( 'nav, .sub-menu' ).slideToggle( 'fast' );

	});

})( this, jQuery );