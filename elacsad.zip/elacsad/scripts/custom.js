/* Search */
	
	jQuery(".header-search-a").click(function (){
		var header_search = jQuery(this).parent();
		if (header_search.hasClass("header-search-active")) {
			header_search.removeClass("header-search-active");
			header_search.find("i").addClass("icon-search").removeClass("icon-close");
			jQuery(".wrap-search").slideUp(300);
		}else {
			var header = jQuery("#header").height();
			header_search.addClass("header-search-active");
			header_search.find("i").addClass("icon-close").removeClass("icon-search");
			jQuery(".wrap-search").css({"padding-top":header+50});
			jQuery(".wrap-search").slideDown(300);
		}
	});
	
	/* Header follow */
	
	jQuery(".header-follow-a").click(function (){
		var header_follow = jQuery(this).parent();
		if (header_follow.hasClass("header-follow-active")) {
			header_follow.removeClass("header-follow-active");
		}else {
			header_follow.addClass("header-follow-active");
		}
	});
	
/* Share follow */
	
	jQuery(".post-meta-share > a").click(function (){
		var share_social = jQuery(this).parent();
		if (share_social.hasClass("share-active")) {
			share_social.removeClass("share-active");
		}else {
			share_social.addClass("share-active");
		}
		return false;
	});
	
/*sticky */


var j=jQuery.noConflict();
j(document).ready(function() {
var s = j('#sticky');
var pos = s.position();
var stickermax = j(document).outerHeight() - j('#footer').outerHeight() - s.outerHeight() - 120; //40 value is the total of the top and bottom margin
j(window).scroll(function() {
var windowpos = j(window).scrollTop();
if (windowpos >= pos.top && windowpos < stickermax) {
s.attr('style', '');
s.addClass('stick');
} else if (windowpos >= stickermax) {
s.removeClass();
s.css({position: 'absolute', top: stickermax + 'px'});
} else {
s.removeClass(); 
}
});
});


/* Menu */

var j=jQuery.noConflict();
(function(){
var classes = document.getElementsByClassName('menu_control');
for (i = 0; i < classes.length; i++) {
classes[i].onclick = function() {
var menu = this.nextElementSibling;
if (/show_menu/.test(menu.className))
menu.className = menu.className.replace('show_menu', '').trim();
else
menu.className += ' show_menu';
};
}
})();