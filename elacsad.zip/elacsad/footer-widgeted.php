<div class="footer-widgets" id="footer">
	<div class="wrap">
		<?php 
		if (genesism_get_option('footer_about')){
		?>
    	<div class="footer_widgets_1 footer_widget">
			<div class="footer_about_us">
				<h4 class="footer-widget-title"><?php echo genesism_option('footer_abt_tle'); ?></h4>
				<p><?php echo genesism_option('footer_abt_cnt'); ?></p>
			</div>
			<div class="footer_social_follow">
				<h4 class="footer-widget-title"><?php echo genesism_option('footer_social_tle'); ?></h4>
				<div class="social_widget">
					<?php
				    if (!genesism_get_option('fb_check3')){
				    ?>
					<a href="<?php echo genesism_option('facebook_text3'); ?>" target="_blank" title="Facebook"><i class="fa icon-facebook3"></i></a>
					<?php
						}
						if (!genesism_get_option('twi_check3')){
						?>
					<a href="<?php echo genesism_option('twitter_text3'); ?>" target="_blank" title="Twitter"><i class="fa icon-twitter"></i></a> 
						<?php
						}
						if (!genesism_get_option('inst_check3')){
						?>
					
					<a href="<?php echo genesism_option('instagram_text3'); ?>" target="_blank" title="Instagram"><i class="fa icon-instagram"></i></a> 
					<?php
					}
					if (!genesism_get_option('yt_check3')){
					?>
					
					<a href="<?php echo genesism_option('youtube_text3'); ?>" target="_blank" title="YouTube"><i class="fa icon-youtube"></i></a> 
					<?php
					}
					if (!genesism_get_option('lin_check3')){
					?>
					
					<a href="<?php echo genesism_option('linkedin_text3'); ?>" target="_blank" title="Linkedin"><i class="fa icon-linkedin2"></i></a> 
					<?php
					}
					if (!genesism_get_option('pint_check3')){
					?>
					
					<a href="<?php echo genesism_option('pinterest_text3'); ?>" target="_blank" title="Pinterest"><i class="fa icon-pinterest"></i></a> 
					<?php
				}
				?>
				</div>
			</div>
		</div>
		<?php 
		}
		?>
   		<!-- end .footer-left -->
    <?php 
		if (genesism_get_option('footer_about')){
		?>
		<div class="footer_widgets_2 footer_widget">
			<?php 
	global $wpdb;
	$query = "SELECT * from $wpdb->comments WHERE comment_approved= '1'
	ORDER BY comment_date DESC LIMIT 0 ,2";
	$comments = $wpdb->get_results($query);

	if ($comments) {
	echo '<div class="recent_comments"><h4 class="footer-widget-title">'. genesism_get_option('recent_comments_title') .'</h4>';
	foreach ($comments as $comment) {
	$url = '<a href="'. get_permalink($comment->comment_post_ID).'#comment-'.$comment->comment_ID .'" title="'.$comment->comment_author .' | '.get_the_title($comment->comment_post_ID).'">';
	$img_w='50';
	echo '<div class="avt_rec">';
	echo '<div class="avt_img">';
	echo $url;
	echo get_avatar( $comment->comment_author_email, $img_w);
	echo '</a></div>';

	echo '<div class="rec_aut">';
	echo $url;
	echo '<span>';
	echo $comment->comment_author;
	echo '</span>';
	echo '<br>';
	echo get_the_title($comment->comment_post_ID);
	echo '</a></div>';
	echo '</div>';
	}
	echo '</div>';
	}
	?>        
    	</div><!-- end .footer-right -->
	<?php 
		}
		?>
    	<!-- end .footer-middle -->
    	<div class="footer_widgets_3 footer_widget">
        	       <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer Widget1') ) : ?>
    			<div class="widget">
            		<h4 itemprop="headline"><?php _e("Footer #Widget1", 'genesis'); ?></h4>
			
            		<p><?php _e("This is an example of a widget area that you can place text to describe a product or service. You can also use other WordPress widgets such as recent posts, recent comments, a tag cloud or more.", 'genesis'); ?></p>
					
				</div><!-- end .widget -->
			<?php endif; ?> 
    	</div><!-- end .footer-right -->
    	</div><!-- end .wrap -->
</div><!-- end #footer-widgets -->