<?php
/*
Template Name: Landing Page with header
*/


// Add custom body class to the head
add_filter( 'body_class', 'metro_add_body_class' );
function metro_add_body_class( $classes ) {
   $classes[] = 'lwithheader';
   return $classes;
}

remove_action( 'genesis_sidebar_alt', 'genesis_do_sidebar_alt' );
remove_action( 'genesis_sidebar', 'genesis_do_sidebar' );
add_filter ( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );

add_action('genesis_before_content_sidebar_wrap','landingpage_video_section',2);
function landingpage_video_section(){
if(genesism_get_option('landing_page_cnt')){
?>
<div class="landingpage_video_section">
	<div class="inner_landingpage wrap">
		<div class="landingpage_leftcnt">
			<h3><?php echo genesism_option('landing_title');?></h3>
			<p><?php echo genesism_option('landing_cnt');?></p>
			<a href="<?php echo genesism_option('landing_read_link');?>"><?php echo genesism_option('landing_read');?></a>
		</div>
		<div class="landingpage_rightcnt">
			<?php echo genesism_option('landing_video_link');?>			
		</div>
	</div>
</div>
<?php 
}
}

add_action('genesis_before_content_sidebar_wrap','landing_page_feature',3);
function landing_page_feature(){
if(genesism_get_option('landing_feature')){
?>
<div class="landing_page_feature" >	
	<div class="landing_page_feature_section wrap">
		<div class="landing_page_feature_title">
			<h3><?php echo genesism_option('landing_feature_title'); ?></h3>
		</div>
		<div class="feature_inner_cnt">
			<div class="column1">
				<img alt="<?php echo genesism_option('landing_feature_subtitle1'); ?>" src="<?php echo genesism_option('landing_feature_img1'); ?>"/>
				<h3><a href="<?php echo genesism_option('landing_feature_readtxt_link1'); ?>"><?php echo genesism_option('landing_feature_subtitle1'); ?></a></h3>
				<p><?php echo genesism_option('landing_feature_cnt1'); ?></p>
				<a class="read_more_btn" href="<?php echo genesism_option('landing_feature_readtxt_link1');?>"><?php echo genesism_option('landing_feature_read_txt1'); ?></a>
			</div>

			<div class="column1 column2">
				<img alt="<?php echo genesism_option('landing_feature_subtitle2'); ?>" src="<?php echo genesism_option('landing_feature_img2'); ?>"/>
				<h3><a href="<?php echo genesism_option('landing_feature_readtxt_link2'); ?>"><?php echo genesism_option('landing_feature_subtitle2'); ?></a></h3>
				<p><?php echo genesism_option('landing_feature_cnt2'); ?></p>
				<a class="read_more_btn" href="<?php echo genesism_option('landing_feature_readtxt_link2'); ?>"><?php echo genesism_option('landing_feature_read_txt2'); ?></a>
			</div>

			<div class="column1 column3">
				<img alt="<?php echo genesism_option('landing_feature_subtitle3'); ?>" src="<?php echo genesism_option('landing_feature_img3'); ?>"/>
				<h3><a href="<?php echo genesism_option('landing_feature_readtxt_link3'); ?>"><?php echo genesism_option('landing_feature_subtitle3'); ?></a></h3>
				<p><?php echo genesism_option('landing_feature_cnt3'); ?></p>
				<a class="read_more_btn" href="<?php echo genesism_option('landing_feature_readtxt_link3'); ?>"><?php echo genesism_option('landing_feature_read_txt3'); ?></a>
			</div>

			<div class="column1 last">
				<img alt="<?php echo genesism_option('landing_feature_subtitle4'); ?>" src="<?php echo genesism_option('landing_feature_img4'); ?>"/>
				<h3><a href="<?php echo genesism_option('landing_feature_readtxt_link4'); ?>"><?php echo genesism_option('landing_feature_subtitle4'); ?></a></h3>
				<p><?php echo genesism_option('landing_feature_cnt4'); ?></p>
				<a class="read_more_btn" href="<?php echo genesism_option('landing_feature_readtxt_link4'); ?>"><?php echo genesism_option('landing_feature_read_txt4'); ?></a>
			</div>
		</div>
	</div>
</div>
<?php 
}
}

genesis();