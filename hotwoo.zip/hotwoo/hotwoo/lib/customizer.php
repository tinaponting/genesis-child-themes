<?php

function hotwoo_customize_register( $wp_customize ) {
 /*******************************************
Color scheme
********************************************/
 
// add the section to contain the settings
$wp_customize->add_section( 'textcolors' , array(
    'title' =>  'Color Scheme',
) );

// Background Color
$txtcolors[] = array(
    'slug'=>'body_bg_color', 
    'default' => '#f8f8f8',
    'label' => 'Background Color'
);

 
// Body Text Color
$txtcolors[] = array(
    'slug'=>'body_txt_color', 
    'default' => '#888',
    'label' => 'Body Text Color'
);

// Top Header Background

$txtcolors[] = array(
    'slug'=>'top_bg_clr', 
    'default' => '#f9f9f9',
    'label' => 'Top Header BG Color'
);

// center Header Background

$txtcolors[] = array(
    'slug'=>'center_bg_clr', 
    'default' => '#fff',
    'label' => 'center Header BG Color'
);

// Bottom Header Background

$txtcolors[] = array(
    'slug'=>'btm_bg_clr', 
    'default' => '#222222',
    'label' => 'Bottom Header BG Color'
);

// Header Text Color
$txtcolors[] = array(
    'slug'=>'header_txt_clr', 
    'default' => '#666',
    'label' => 'Header Text Color'
);


// Title Text color
$txtcolors[] = array(
    'slug'=>'title_txt_color', 
    'default' => '#313131',
    'label' => 'title Text Color'
);


// Title Hover color
$txtcolors[] = array(
    'slug'=>'title_hover_color', 
    'default' => '#e62263',
    'label' => 'title Hover Color'
);

// Hover color
$txtcolors[] = array(
    'slug'=>'hover_color1', 
    'default' => '#ffe7f0',
    'label' => 'Hover Color'
);
 
// Border color1 
$txtcolors[] = array(
    'slug'=>'border_color1', 
    'default' => '#d1d1d1',
    'label' => 'Border Color1 '
);

// Border color2 
$txtcolors[] = array(
    'slug'=>'border_color2', 
    'default' => '#e5e5e5',
    'label' => 'Border Color2 '
);

// Border color3 
$txtcolors[] = array(
    'slug'=>'border_color3', 
    'default' => '#e8e8e8',
    'label' => 'Border Color3 '
);

// Border color4 
$txtcolors[] = array(
    'slug'=>'border_color4', 
    'default' => '#e1e1e1',
    'label' => 'Border Color4 '
);

//Feature BG
$txtcolors[] = array(
    'slug'=>'feature_bg_color', 
    'default' => '#1bbc9b',
    'label' => 'Feature BG Color '
);

//Special BG
$txtcolors[] = array(
    'slug'=>'special_bg_color', 
    'default' => '#1f8ceb',
    'label' => 'Special BG Color '
);

//Footer BG
$txtcolors[] = array(
    'slug'=>'footer_bg', 
    'default' => '#111111',
    'label' => 'Footer BG Color '
);


// add the settings and controls for each color
foreach( $txtcolors as $txtcolor ) {
 
    // SETTINGS
    $wp_customize->add_setting(
        $txtcolor['slug'], array(
            'default' => $txtcolor['default'],
            'type' => 'option', 
            'capability' => 
            'edit_theme_options'
        )
    );
    // CONTROLS
    $wp_customize->add_control(
        new WP_Customize_Color_Control(
            $wp_customize,
            $txtcolor['slug'], 
            array('label' => $txtcolor['label'], 
            'section' => 'textcolors',
            'settings' => $txtcolor['slug'])
        )
    );
}
}
add_action( 'customize_register', 'hotwoo_customize_register' );