<?php

/**
 * This function registers the default values for genesis theme settings
 */
 
function genesism_theme_settings_defaults() {
$defaults = array( // define our defaults
'style' => 'default',
'custom' => 0,
'shortcodes-css' => 1,
'f_img_width'=>'366',
'f_img_height'=>'258',

'header' => 1,
'contact_box' => 1,
'header_social' => 1,
'search_box' => 1,
'header_menu1' => 1,
'header_menu2' => 1,
'header_cart' => 1,
'optin_section' => 1,
'read_more' => 1,
'sidebar_optin' => 1,
'social_post_button' => 1,
'postadcheck' => 1,
'footer_logo' => 1,
'footer_social' => 1,
'footer1' => 1,

'header_text' => 'http://hotwoo.genesislovers.com/wp-content/uploads/2016/06/logo.png',
'contact_address' => '123 Pall Mall, London England',
'contact_email' => 'admin@gmail.com',
'contact_number' => '+123 444 5656',
'search_text' => 'Product Search here...',
'optin_bg' => 'http://hotwoo.genesislovers.com/wp-content/uploads/2016/05/optinbg.jpg',
'optin_header1' => 'LOREM IPSUM IS TEXT',
'optin_header2' => 'LOREM IPSUM IS SIMPLY DUMMY',
'optin_cnt' => 'EIf you are going to use a passage of Lorem Ipsum, you need to be sure there isn"t anything embarrassing hidden in the middle of text. ',
'email_text' => 'Enter Your Email',
'submit_text' => 'Submit',
'read_text' => 'Continue Reading',
'sidebar_optin_header' => 'News Letter',
'name_text2' => 'Enter your name...',
'email_text2' => 'Enter your email...',
'submit_text2' => 'Subscribe me',

'sharehead' => 'Social Share',
'postad' => '<img alt="Single Page Ad" src="http://hotwoo.genesislovers.com/wp-content/uploads/2016/06/pagead.jpg"/>',
'footer_logo_text' => 'http://hotwoo.genesislovers.com/wp-content/uploads/2016/06/footerlogo.png',


		'footer_text' => 'Copyright &copy;'.date('Y') .  ' <a href="'. get_bloginfo('url') .'">' . get_bloginfo('name') . '</a>'
	
	);
	
	return apply_filters('genesism_theme_settings_defaults', $defaults);

}



function genesism_theme_settings_boxes() {
	global $_genesism_theme_settings_pagehook;
	
	if (function_exists('add_screen_option')) { add_screen_option('layout_columns', array('max' => 2, 'default' => 2) ); }

add_meta_box('genesism-theme-settings-version', __('Theme Information', 'genesism'), 'genesism_theme_settings_info_box', $_genesism_theme_settings_pagehook, 'normal');	
 }
  
 function genesism_theme_settings_info_box() { 
?>

<p class="bolder"><strong><?php echo CHILD_THEME_NAME; ?></strong> by <a href="http://genesislovers.com">genesislovers.com</a></p>
<p><strong>
  <?php _e('Version:', 'genesism'); ?>
  </strong> <?php echo CHILD_THEME_VERSION; ?> <strong>
   </p>
<p><span class="description">
  <?php _e('For support, please visit <a href="http://genesislovers.com/contactus/">http://genesislovers.com/contactus/</a>', 'genesism'); ?>
  </span></p>

<div id="tabs">
	<ul>
		<li><a href="#tabs-1"><?php _e("Header Logo", 'genesism'); ?></a></li>
		<li><a href="#tabs-2"><?php _e("Contact Box", 'genesism'); ?></a></li>
		<li><a href="#tabs-3"><?php _e("Header Social follow", 'genesism'); ?></a></li>
		<li><a href="#tabs-4"><?php _e("Header Product Search", 'genesism'); ?></a></li>
		<li><a href="#tabs-5"><?php _e("Header Menu One", 'genesism'); ?></a></li>
		<li><a href="#tabs-6"><?php _e("Header Menu Two", 'genesism'); ?></a></li>
		<li><a href="#tabs-7"><?php _e("Header Cart Item", 'genesism'); ?></a></li>		
		
		<li><a href="#tabs-8"><?php _e("Optin Section", 'genesism'); ?></a></li>		
		<li><a href="#tabs-9"><?php _e("Featured Image", 'genesism'); ?></a></li>
		<li><a href="#tabs-10"><?php _e("Read More Section", 'genesism'); ?></a></li>	
		
		<li><a href="#tabs-11"><?php _e("Sidebar Optin Section", 'genesism'); ?></a></li>
		<li><a href="#tabs-12"><?php _e("Single Page Social Share", 'genesism'); ?></a></li>
	
		<li><a href="#tabs-13"><?php _e("Single Page Advertisement", 'genesism'); ?></a></li>
		<li><a href="#tabs-14"><?php _e("Footer Logo Section", 'genesism'); ?></a></li>
		<li><a href="#tabs-15"><?php _e("Footer Social Follow", 'genesism'); ?></a></li>
		
		<li><a href="#tabs-16"><?php _e("Footer Text section", 'genesism'); ?></a></li>
		<li><a href="#tabs-17"><?php _e("Custom CSS section", 'genesism'); ?></a></li>
		
		
	</ul>
	<div id="tabs-1">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[header]" id="<?php echo HOTWOO_SETTINGS_FIELD; ?>[header]" value="1" <?php checked(1, genesism_get_option('header')); ?> />
				<label for="<?php echo HOTWOO_SETTINGS_FIELD; ?>[header]">
				<?php _e("Enable Header Logo", 'genesism'); ?>
				</label>
			</li>
				<li class="second_list">
				<label>Enter the Logo image url here</label>
				<textarea name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[header_text]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('header_text') ); ?></textarea>
			</li>
		</ul>
	</div>
	
	
	<div id="tabs-2">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[contact_box]" id="<?php echo HOTWOO_SETTINGS_FIELD; ?>[contact_box]" value="1" <?php checked(1, genesism_get_option('contact_box')); ?> />
				<label for="<?php echo HOTWOO_SETTINGS_FIELD; ?>[contact_box]">
				<?php _e("Enable Bottom Menu Section", 'genesism'); ?>
				</label>
			</li>
			
			<li class="second_list"><label>Enter Your Contact Address here</label>
				<textarea name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[contact_address]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option(contact_address) ); ?></textarea> 
			</li>
			
			<li class="second_list"><label>Enter Your Contact Email here</label>
				<textarea name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[contact_email]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option(contact_email) ); ?></textarea> 
			</li>
			
			<li class="second_list"><label>Enter Your Contact Phone Number here</label>
				<textarea name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[contact_number]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option(contact_number) ); ?></textarea> 
			</li>
		</ul>
	</div>
	
		
	<div id="tabs-3">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[header_social]" id="<?php echo HOTWOO_SETTINGS_FIELD; ?>[header_social]" value="1" <?php checked(1, genesism_get_option(header_social)); ?> />
				<label for="<?php echo HOTWOO_SETTINGS_FIELD; ?>[header_social]">
				<?php _e("Enable Social follow", 'genesism'); ?>
				</label>
			</li>
		
			<li class="second_list"><label>Paste Your Facebook URL Link</label>
				<textarea name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[facebook_text2]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option(facebook_text2) ); ?></textarea> 
			</li>
			<li class="second_list"><label>Paste Your Twitter URL Link</label>
				<textarea name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[twitter_text2]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('twitter_text2') ); ?></textarea> 
			</li>
			<li class="second_list"><label>Paste Your Linkedin URL Link</label>
				<textarea name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[linkedin_text2]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('linkedin_text2') ); ?></textarea>
			</li>
			<li class="second_list"><label>Paste Your Googleplus URL Link</label>
				<textarea name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[googleplus_text2]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('googleplus_text2') ); ?></textarea> 
			</li>
			<li class="second_list"><label>Paste Your Pinterest URL Link</label>
				<textarea name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[pinterest_text2]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('pinterest_text2') ); ?></textarea>
			</li>
			<li class="second_list"><label>Paste Your Instagram URL Link</label>
				<textarea name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[instagram_text2]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('instagram_text2') ); ?></textarea>
			</li>
			<li class="second_list"><label>Paste Your Youtube URL Link</label>
				<textarea name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[youtube_text2]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('youtube_text2') ); ?></textarea>
			</li>	
			
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[fbcheck2]" id="<?php echo HOTWOO_SETTINGS_FIELD; ?>[fbcheck2]" value="1" <?php checked(1, genesism_get_option('fbcheck2')); ?> />
				<label for="<?php echo HOTWOO_SETTINGS_FIELD; ?>[fbcheck2]">
				<?php _e("Disable Facebook icon", 'genesism'); ?>
				</label>
			</li>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[twtcheck2]" id="<?php echo HOTWOO_SETTINGS_FIELD; ?>[twtcheck2]" value="1" <?php checked(1, genesism_get_option('twtcheck2')); ?> />
				<label for="<?php echo HOTWOO_SETTINGS_FIELD; ?>[twtcheck2]">
				<?php _e("Disable Twitter icon", 'genesism'); ?>
				</label>
			</li>
			
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[linkcheck2]" id="<?php echo HOTWOO_SETTINGS_FIELD; ?>[linkcheck2]" value="1" <?php checked(1, genesism_get_option('linkcheck2')); ?> />
				<label for="<?php echo HOTWOO_SETTINGS_FIELD; ?>[linkcheck2]">
				<?php _e("Disable Linkedin icon", 'genesism'); ?>
				</label>
			</li>
			
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[gpcheck2]" id="<?php echo HOTWOO_SETTINGS_FIELD; ?>[gpcheck2]" value="1" <?php checked(1, genesism_get_option('gpcheck2')); ?> />
				<label for="<?php echo HOTWOO_SETTINGS_FIELD; ?>[gpcheck2]">
				<?php _e("Disable Googleplus icon", 'genesism'); ?>
				</label>
			</li>
			
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[pintcheck2]" id="<?php echo HOTWOO_SETTINGS_FIELD; ?>[pintcheck2]" value="1" <?php checked(1, genesism_get_option('pintcheck2')); ?> />
				<label for="<?php echo HOTWOO_SETTINGS_FIELD; ?>[pintcheck2]">
				<?php _e("Disable Pinterest icon", 'genesism'); ?>
				</label>
			</li>
			
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[intsagramcheck2]" id="<?php echo HOTWOO_SETTINGS_FIELD; ?>[intsagramcheck2]" value="1" <?php checked(1, genesism_get_option('intsagramcheck2')); ?> />
				<label for="<?php echo HOTWOO_SETTINGS_FIELD; ?>[intsagramcheck2]">
				<?php _e("Disable Instagram icon", 'genesism'); ?>
				</label>
			</li>
			
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[ytcheck2]" id="<?php echo HOTWOO_SETTINGS_FIELD; ?>[ytcheck2]" value="1" <?php checked(1, genesism_get_option('ytcheck2')); ?> />
				<label for="<?php echo HOTWOO_SETTINGS_FIELD; ?>[ytcheck2]">
				<?php _e("Disable Youtube icon", 'genesism'); ?>
				</label>
			</li>
			
			
		</ul>			
	</div>
	
	<div id="tabs-4">
		 <ul>
			<li class="first_list chkbox">
			  <input type="checkbox" name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[search_box]" id="<?php echo HOTWOO_SETTINGS_FIELD; ?>[search_box]" value="1" <?php checked(1, genesism_get_option('search_box')); ?> />
			   <label for="<?php echo HOTWOO_SETTINGS_FIELD; ?>[search_box]">
			  <?php _e("Enable Product Search Box", 'genesism'); ?>
			 </label>
			</li>
			
			<li class="second_list">
			  <label>Enter the Search Place holder Text here</label>
			  <textarea name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[search_text]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('search_text') ); ?></textarea>
			</li>
		</ul>
	</div>
	
	<div id="tabs-5">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[header_menu1]" id="<?php echo HOTWOO_SETTINGS_FIELD; ?>[header_menu1]" value="1" <?php checked(1, genesism_get_option('header_menu1')); ?> />
				<label for="<?php echo HOTWOO_SETTINGS_FIELD; ?>[header_menu1]">
				<?php _e("Enable Header Menu One Section", 'genesism'); ?>
				</label>
			</li>
		</ul>
	</div>
	
	<div id="tabs-6">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[header_menu2]" id="<?php echo HOTWOO_SETTINGS_FIELD; ?>[header_menu2]" value="1" <?php checked(1, genesism_get_option('header_menu2')); ?> />
				<label for="<?php echo HOTWOO_SETTINGS_FIELD; ?>[header_menu2]">
				<?php _e("Enable Header Menu Two Section", 'genesism'); ?>
				</label>
			</li>
		</ul>
	</div>
	
	<div id="tabs-7">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[header_cart]" id="<?php echo HOTWOO_SETTINGS_FIELD; ?>[header_cart]" value="1" <?php checked(1, genesism_get_option('header_cart')); ?> />
				<label for="<?php echo HOTWOO_SETTINGS_FIELD; ?>[header_cart]">
				<?php _e("Enable Header Cart Item Section", 'genesism'); ?>
				</label>
			</li>
		</ul>
	</div>
	
	
	<div id="tabs-8">
		 <ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[optin_section]" id="<?php echo HOTWOO_SETTINGS_FIELD; ?>[optin_section]" value="1" <?php checked(1, genesism_get_option('optin_section')); ?> />
				<label for="<?php echo HOTWOO_SETTINGS_FIELD; ?>[optin_section]">
				<?php _e("Enable Optin Section Box", 'genesism'); ?>
				</label>
			</li>
			<li class="second_list">
				<label>Paste your optin code and Press Tab Button</label>
				<textarea id="optin_code" name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[optin_code]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_code') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form name</label>
				<textarea id="optin_name" name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[optin_name]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('optin_name') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form Email</label>
				<textarea id="optin_email" name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[optin_email]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('optin_email') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form action url</label>
				<textarea id="optin_url" name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[optin_url]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_url') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Hidden fields</label>
				<textarea id="optin_hidden" name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[optin_hidden]" rows="10" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_hidden') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Enter your Optin Background Image URL Link</label>
				<textarea name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[optin_bg]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_bg') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Enter your Optin Header Title1 Text</label>
				<textarea name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[optin_header1]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_header1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Enter your Optin Header Title2 Text</label>
				<textarea name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[optin_header2]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_header2') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Enter your Optin Header Text</label>
				<textarea name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[optin_cnt]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_cnt') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Change your Enter your email text here</label>
				<textarea name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[email_text]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('email_text') ); ?></textarea>
			</li>					
			
			<li class="second_list">
				<label>Change your Subscribe me button text</label>
				<textarea name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[submit_text]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('submit_text') ); ?></textarea>
			</li>
		  </ul>
<script type="text/javascript">
var j = jQuery.noConflict();
j(document).ready(function(){
j("#optin_code").blur(function(){
var txt=j(this).val();
if(txt=="")
{
j("#optin_url").val("");
j("#optin_hidden").val("");
j("#optin_name").val("");
j("#optin_email").val("");
return false;
}
var pos1=0;
var pos2=0;
var i=1;
var hidden="";
while(1)
{
pos1=txt.indexOf("<input",pos1);
if(pos1<0) break;
pos2=txt.indexOf(">",pos1+1);
var text=txt.substr(pos1,pos2-pos1);
pp=text.indexOf('type="hidden"');
pp1=text.indexOf('type="submit"');
if(pp>0)
{
hidden+=text+">";
}
if(pp<0 && pp1<0){
pp=text.indexOf('name="');
pp=pp+6;
pp1=text.indexOf('"',pp+1);
var tt=text.substr(pp,pp1-pp);
if(i==1) j("#optin_name").val(tt);
else j("#optin_email").val(tt);
i++;
}
pos1=pos2+1;
}
pos1=txt.indexOf("<form",0);
pos2=txt.indexOf(">",pos1+1);
text=txt.substr(pos1,pos2-pos1);
pp=text.indexOf('action="');
pp=pp+8;
pp1=text.indexOf('"',pp+1);
var tt=text.substr(pp,pp1-pp);
j("#optin_url").val(tt);
j("#optin_hidden").val(hidden);
});
});
</script>  
	</div>
	
	
	<div id="tabs-9">
		<ul>
			<li class="second_list">
				<label>Enter the  Width Of Feature Image Size here</label>
				<textarea name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[f_img_width]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('f_img_width') ); ?></textarea> 
			</li>
			<li class="second_list">
				<label>Enter the Height Of Feature Image Size here</label>
				<textarea name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[f_img_height]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('f_img_height') ); ?></textarea> 
			</li>
		</ul>
	</div>
	
	<div id="tabs-10">
		<ul>
			<li class="first_list chkbox">
			  <input type="checkbox" name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[read_more]" id="<?php echo HOTWOO_SETTINGS_FIELD; ?>[read_more]" value="1" <?php checked(1, genesism_get_option('read_more')); ?> />
			   <label for="<?php echo HOTWOO_SETTINGS_FIELD; ?>[read_more]">
			  <?php _e("Enable Read More Box", 'genesism'); ?>
			 </label>
			</li>
			<li class="second_list">
			  <label>Change Your Read More Text here</label>
			  <textarea name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[read_text]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('read_text') ); ?></textarea>
			</li>
		</ul>
	</div>
	
	<div id="tabs-11">
		<ul>
			<li class="first_list chkbox">
			  <input type="checkbox" name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[sidebar_optin]" id="<?php echo HOTWOO_SETTINGS_FIELD; ?>[sidebar_optin]" value="1" <?php checked(1, genesism_get_option('sidebar_optin')); ?> />
				<label for="<?php echo HOTWOO_SETTINGS_FIELD; ?>[sidebar_optin]">
				<?php _e("Enable Sidebar Optin Box", 'genesism'); ?>
			  </label>
			</li>
			<li class="second_list">
				<label>Paste your optin code and Press Tab Button</label>
				<textarea id="optin_code1" name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[optin_code1]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_code1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form name</label>
				<textarea id="optin_name1" name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[optin_name1]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('optin_name1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form Email</label>
				<textarea id="optin_email1" name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[optin_email1]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('optin_email1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form action url</label>
				<textarea id="optin_url1" name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[optin_url1]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_url1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Hidden fields</label>
				<textarea id="optin_hidden1" name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[optin_hidden1]" rows="10" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_hidden1') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Enter your Sidebar Optin Header Text</label>
				<textarea name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[sidebar_optin_header]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('sidebar_optin_header') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Change your Enter your name text here</label>
				<textarea name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[name_text2]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('name_text2') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Change your Enter your email text here</label>
				<textarea name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[email_text2]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('email_text2') ); ?></textarea>
			</li>						
			
			<li class="second_list">
				<label>Change your Subscribe me button text</label>
				<textarea name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[submit_text2]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('submit_text2') ); ?></textarea>
			</li>
		  </ul>
<script type="text/javascript">
var j = jQuery.noConflict();
j(document).ready(function(){
j("#optin_code1").blur(function(){
var txt=j(this).val();
if(txt=="")
{
j("#optin_url1").val("");
j("#optin_hidden1").val("");
j("#optin_name1").val("");
j("#optin_email1").val("");
return false;
}
var pos1=0;
var pos2=0;
var i=1;
var hidden="";
while(1)
{
pos1=txt.indexOf("<input",pos1);
if(pos1<0) break;
pos2=txt.indexOf(">",pos1+1);
var text=txt.substr(pos1,pos2-pos1);
pp=text.indexOf('type="hidden"');
pp1=text.indexOf('type="submit"');
if(pp>0)
{
hidden+=text+">";
}
if(pp<0 && pp1<0){
pp=text.indexOf('name="');
pp=pp+6;
pp1=text.indexOf('"',pp+1);
var tt=text.substr(pp,pp1-pp);
if(i==1) j("#optin_name1").val(tt);
else j("#optin_email1").val(tt);
i++;
}
pos1=pos2+1;
}
pos1=txt.indexOf("<form",0);
pos2=txt.indexOf(">",pos1+1);
text=txt.substr(pos1,pos2-pos1);
pp=text.indexOf('action="');
pp=pp+8;
pp1=text.indexOf('"',pp+1);
var tt=text.substr(pp,pp1-pp);
j("#optin_url1").val(tt);
j("#optin_hidden1").val(hidden);
});
});
</script> 
	</div>
	
	<div id="tabs-12">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[social_post_button]" id="<?php echo HOTWOO_SETTINGS_FIELD; ?>[social_post_button]" value="1" <?php checked(1, genesism_get_option('social_post_button')); ?> />
				<label for="<?php echo HOTWOO_SETTINGS_FIELD; ?>[social_post_button]">
				<?php _e("Enable Single Page Social Sharing Box", 'genesism'); ?>
				</label>
			</li>
			<li class="second_list">
				<label>Enter the Social Share Heading here</label>
				<textarea name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[sharehead]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('sharehead') ); ?></textarea>
			</li>
		</ul>
	</div>
	
	
	
	<div id="tabs-13">
		<ul>
			<li class="first_list chkbox">
			  <input type="checkbox" name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[postadcheck]" id="<?php echo HOTWOO_SETTINGS_FIELD; ?>[postadcheck]" value="1" <?php checked(1, genesism_get_option('postadcheck')); ?> />
				<label for="<?php echo HOTWOO_SETTINGS_FIELD; ?>[postadcheck]">
				<?php _e("Enable Single Page  Postad section", 'genesism'); ?>
			  </label>
			</li>
			<li class="second_list">
				<label>Enter the Post ad image url</label>
				<textarea name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[postad]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('postad') ); ?></textarea> 
			 </li>
		</ul>
	</div>
	
	<div id="tabs-14">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[footer_logo]" id="<?php echo HOTWOO_SETTINGS_FIELD; ?>[footer_logo]" value="1" <?php checked(1, genesism_get_option('footer_logo')); ?> />
				<label for="<?php echo HOTWOO_SETTINGS_FIELD; ?>[footer_logo]">
				<?php _e("Enable Footer Logo", 'genesism'); ?>
				</label>
			</li>
				<li class="second_list">
				<label>Enter the Footer Logo Image URL here</label>
				<textarea name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[footer_logo_text]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('footer_logo_text') ); ?></textarea>
			</li>
		</ul>
	</div>
	
	<div id="tabs-15">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[footer_social]" id="<?php echo HOTWOO_SETTINGS_FIELD; ?>[footer_social]" value="1" <?php checked(1, genesism_get_option('footer_social')); ?> />
				<label for="<?php echo HOTWOO_SETTINGS_FIELD; ?>[footer_social]">
				<?php _e("Enable Footer Social follow", 'genesism'); ?>
				</label>
			</li>
		
			<li class="second_list"><label>Paste Your Facebook URL Link</label>
				<textarea name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[facebook_text]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('facebook_text') ); ?></textarea> 
			</li>
			<li class="second_list"><label>Paste Your Twitter URL Link</label>
				<textarea name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[twitter_text]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('twitter_text') ); ?></textarea> 
			</li>
			<li class="second_list"><label>Paste Your Linkedin URL Link</label>
				<textarea name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[linkedin_text]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('linkedin_text') ); ?></textarea>
			</li>
			<li class="second_list"><label>Paste Your Googleplus URL Link</label>
				<textarea name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[googleplus_text]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('googleplus_text') ); ?></textarea> 
			</li>
			<li class="second_list"><label>Paste Your Pinterest URL Link</label>
				<textarea name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[pinterest_text]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('pinterest_text') ); ?></textarea>
			</li>
			<li class="second_list"><label>Paste Your Instagram URL Link</label>
				<textarea name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[instagram_text]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('instagram_text') ); ?></textarea>
			</li>
			<li class="second_list"><label>Paste Your Youtube URL Link</label>
				<textarea name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[youtube_text]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('youtube_text') ); ?></textarea>
			</li>

				<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[fbcheck3]" id="<?php echo HOTWOO_SETTINGS_FIELD; ?>[fbcheck3]" value="1" <?php checked(1, genesism_get_option('fbcheck3')); ?> />
				<label for="<?php echo HOTWOO_SETTINGS_FIELD; ?>[fbcheck3]">
				<?php _e("Disable Facebook icon", 'genesism'); ?>
				</label>
			</li>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[twtcheck3]" id="<?php echo HOTWOO_SETTINGS_FIELD; ?>[twtcheck3]" value="1" <?php checked(1, genesism_get_option('twtcheck3')); ?> />
				<label for="<?php echo HOTWOO_SETTINGS_FIELD; ?>[twtcheck3]">
				<?php _e("Disable Twitter icon", 'genesism'); ?>
				</label>
			</li>
			
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[linkcheck3]" id="<?php echo HOTWOO_SETTINGS_FIELD; ?>[linkcheck3]" value="1" <?php checked(1, genesism_get_option('linkcheck3')); ?> />
				<label for="<?php echo HOTWOO_SETTINGS_FIELD; ?>[linkcheck3]">
				<?php _e("Disable Linkedin icon", 'genesism'); ?>
				</label>
			</li>
			
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[gpcheck3]" id="<?php echo HOTWOO_SETTINGS_FIELD; ?>[gpcheck3]" value="1" <?php checked(1, genesism_get_option('gpcheck3')); ?> />
				<label for="<?php echo HOTWOO_SETTINGS_FIELD; ?>[gpcheck3]">
				<?php _e("Disable Googleplus icon", 'genesism'); ?>
				</label>
			</li>
			
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[pintcheck3]" id="<?php echo HOTWOO_SETTINGS_FIELD; ?>[pintcheck3]" value="1" <?php checked(1, genesism_get_option('pintcheck3')); ?> />
				<label for="<?php echo HOTWOO_SETTINGS_FIELD; ?>[pintcheck3]">
				<?php _e("Disable Pinterest icon", 'genesism'); ?>
				</label>
			</li>
			
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[intsagramcheck3]" id="<?php echo HOTWOO_SETTINGS_FIELD; ?>[intsagramcheck3]" value="1" <?php checked(1, genesism_get_option('intsagramcheck3')); ?> />
				<label for="<?php echo HOTWOO_SETTINGS_FIELD; ?>[intsagramcheck3]">
				<?php _e("Disable Instagram icon", 'genesism'); ?>
				</label>
			</li>
			
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[ytcheck3]" id="<?php echo HOTWOO_SETTINGS_FIELD; ?>[ytcheck3]" value="1" <?php checked(1, genesism_get_option('ytcheck3')); ?> />
				<label for="<?php echo HOTWOO_SETTINGS_FIELD; ?>[ytcheck3]">
				<?php _e("Disable Youtube icon", 'genesism'); ?>
				</label>
			</li>
			
		</ul>			
	</div>
	
	
	<div id="tabs-16">
		 <ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[footer1]" id="<?php echo HOTWOO_SETTINGS_FIELD; ?>[footer1]" value="1" <?php checked(1, genesism_get_option('footer1')); ?> />
				<label for="<?php echo HOTWOO_SETTINGS_FIELD; ?>[footer1]">
				<?php _e("Enable Footer text", 'genesism'); ?>
				</label>
			</li>
			<li class="second_list"><label>Use custom footer text?</label>
				<textarea name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[footer_text]" rows="5" cols="50"><?php echo htmlspecialchars( genesism_get_option('footer_text') ); ?></textarea> 
			</li>
		</ul>
	</div>
	
	<div id="tabs-17">
		 <ul>
			
			<li class="second_list"><label>Use Custom CSS</label>
				<textarea name="<?php echo HOTWOO_SETTINGS_FIELD; ?>[custom_css]" rows="30" cols="70"><?php echo htmlspecialchars( genesism_get_option('custom_css') ); ?></textarea> 
			</li>
		</ul>
	</div>
	

	
</div>    
  
  
 
 
<?php
}
 