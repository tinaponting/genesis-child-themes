<?php
/*
Template Name: Front Page
*/

// Add custom body class to the head
add_filter( 'body_class', 'metro_add_body_class' );
function metro_add_body_class( $classes ) {
   $classes[] = 'frontpage woocommerce';
   return $classes;
}

// set full width layout
add_filter ( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );
remove_action( 'genesis_entry_content', 'genesis_do_post_content' );
remove_action('genesis_before_loop', 'genesis_do_breadcrumbs');
remove_action( 'genesis_loop', 'genesis_do_loop' );
remove_action( 'genesis_sidebar', 'genesis_do_sidebar' );



add_action('genesis_before_content_sidebar_wrap','slider_cont',1);
function slider_cont(){

?>
<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Front Page Top Slider Widget') ) : ?>
<div class="widget">
<h4 itemprop="headline"><?php _e("Front Page Top Slider #Widget", 'genesis'); ?></h4>
<p><?php _e("Displays Front Page Top Slider Widget.", 'genesis'); ?></p>
</div><!-- end .widget -->
<?php endif; ?> 
<?php

}


add_action('genesis_before_content_sidebar_wrap','front_page_cont',2);
function front_page_cont(){

?>
<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Front Page Content Widget') ) : ?>
<div class="widget">
<h4 itemprop="headline"><?php _e("Front Page Content #Widget", 'genesis'); ?></h4>
<p><?php _e("Displays Front Page Content Widget.", 'genesis'); ?></p>
</div><!-- end .widget -->
<?php endif; ?> 
<?php

}


add_action('genesis_before_content_sidebar_wrap','frontpage_optin',3);
function frontpage_optin(){
if (genesism_get_option('optin_section')){
?>
<div class="optin_section" style="background-image:url(<?php echo genesism_option('optin_bg'); ?>);">
	<div class="optin_color">
			<div class="optin_box_section wrap">
				<div class="optin_header">
					<h3 class="optin_title1"><?php echo genesism_option('optin_header1'); ?></h3>
					<h3 class="optin_title2"><?php echo genesism_option('optin_header2'); ?></h3>
					<p><?php echo genesism_option('optin_cnt'); ?></p>
					
				</div>
				<div class="optin_cnt">
					
					<form method="post" class="form" action="<?php echo stripslashes(genesism_option('optin_url')); ?>" target="_blank">	
						<div class="names">				
						<input class="email search_text" type="text" name="<?php echo stripslashes(genesism_option('optin_email')); ?>" placeholder="<?php echo stripslashes(genesism_option('email_text')); ?>"><div class='mails'></div></div>
						<?php echo stripslashes(genesism_option('optin_hidden')); ?>
						<input name="submit" class="submit" type="submit" value="<?php echo stripslashes(genesism_option('submit_text')); ?>"/>
					</form>
				</div>
		</div>
	</div>
</div>
<?php 
}
}

add_action('genesis_before_content_sidebar_wrap','front_page_bottom_latest',4);
function front_page_bottom_latest(){

?>
<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Bottom Latest News Widget') ) : ?>
<div class="widget">
<h4 itemprop="headline"><?php _e("Bottom Latest News #Widget", 'genesis'); ?></h4>
<p><?php _e("Displays Bottom Latest News Widget.", 'genesis'); ?></p>
</div><!-- end .widget -->
<?php endif; ?> 
<?php

}


genesis();