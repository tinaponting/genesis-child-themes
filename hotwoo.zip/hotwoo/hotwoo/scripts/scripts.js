var j=jQuery.noConflict();
jQuery(document).ready(function(j) {

 
	// Infinite Scroll
	j('.infinite-content').infinitescroll({
	  navSelector: ".nav-links",
	  nextSelector: ".nav-links a:first",
	  itemSelector: ".infinite-post",
	  loading: {
		msgText: "Loading more posts...",
		finishedMsg: "Sorry, no more posts"
	  },
	  errorCallback: function(){ j(".inf-more-but").css("display", "none") }
	});
	j(window).unbind('.infscr');
	j(".inf-more-but").click(function(){
   		j('.infinite-content').infinitescroll('retrieve');
        	return false;
	});
	j(window).load(function(){
		if (j('.nav-links a').length) {
			j('.inf-more-but').css('display','inline-block');
		} else {
			j('.inf-more-but').css('display','none');
		}
	});
	
	
	
	
});