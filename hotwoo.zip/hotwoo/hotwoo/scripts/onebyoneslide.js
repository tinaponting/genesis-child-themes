
var j=jQuery.noConflict();
    j(document).ready(function() {
        j('#myCarousel').oneCarousel({
            easeIn: 'rotateIn',
            interval: 5000,
            pause: 'hover'
        });
    });
   