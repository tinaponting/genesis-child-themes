var $j=jQuery.noConflict();
$j(".click_icon").click(function(e){
$j("body").toggleClass("active_search");
 $j(".site-header .widget-area").slideToggle(200); 
return false;
});


