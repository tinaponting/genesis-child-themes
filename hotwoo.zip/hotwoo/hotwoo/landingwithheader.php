<?php
/*
Template Name: Landing Page with header
*/


// Add custom body class to the head
add_filter( 'body_class', 'metro_add_body_class' );
function metro_add_body_class( $classes ) {
   $classes[] = 'lwithheader';
   return $classes;
}

remove_action( 'genesis_sidebar_alt', 'genesis_do_sidebar_alt' );
remove_action( 'genesis_sidebar', 'genesis_do_sidebar' );
add_filter ( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );

genesis();