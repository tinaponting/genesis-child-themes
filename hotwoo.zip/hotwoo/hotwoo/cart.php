<?php
/*
Template Name:Cart
*/


// Add custom body class to the head
add_filter( 'body_class', 'metro_add_body_class' );
function metro_add_body_class( $classes ) {
   $classes[] = 'cartpage';
   return $classes;
}

// set full width layout
add_filter ( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );
remove_action( 'genesis_sidebar', 'genesis_do_sidebar' ); 

remove_action ('genesis_before_content_sidebar_wrap','content_advertisement');


genesis();