<div class="footer_widgets">
	<div class="wrap">
		<div class="footer_top_cnt">
			<div class="footer_logo_section">
				<?php
				if (genesism_get_option('footer_logo')){?>
					<a itemprop="url" title="<?php bloginfo('name'); ?>" href="<?php bloginfo('wpurl'); ?>"><img src="<?php echo genesism_option('footer_logo_text'); ?>" alt="<?php bloginfo('name'); ?>"/></a>
				<?php
				}
				else { ?>
					<h1 itemprop="headline"><a title="<?php bloginfo('name'); ?>" href="<?php bloginfo('wpurl'); ?>"><?php bloginfo('name');?> </a></h1>
					<p><?php bloginfo('description'); ?></p>
				<?php } ?>
			</div>
			<?php
				if (genesism_get_option('footer_social')){
			?>
			
			<div class="footer_follow_social">
					<ul>
					<?php
						if (!genesism_get_option('fbcheck3')){
						?>
						<li class="social-facebook">
							<a class="facebook" title="Facebook" href="<?php echo genesism_option('facebook_text'); ?>" target="_blank"><i class="fa icon-facebook3"></i></a>
						</li>
						<?php
						}
						?>
						
						<?php
						if (!genesism_get_option('twtcheck3')){
						?>
						<li class="social-twitter">
							<a class="twitter" title="Twitter" href="<?php echo genesism_option('twitter_text'); ?>" target="_blank"><i class="fa icon-twitter"></i></a>
						</li>
						<?php
						}
						?>
						<?php
						if (!genesism_get_option('linkcheck3')){
						?>
						<li class="social-dribbble">
							<a class="linkedin" title="Linkedin" href="<?php echo genesism_option('linkedin_text'); ?>" target="_blank"><i class="fa icon-linkedin2"></i></a>
						</li>
						<?php
						}
						?>
						
						<?php
						if (!genesism_get_option('gpcheck3')){
						?>
						<li class="social-google">
							<a class="googleplus" title="google plus" href="<?php echo genesism_option('googleplus_text'); ?>" target="_blank"><i class="fa icon-google-plus"></i></a>
						</li>
						<?php
						}
						?>
						
						<?php
						if (!genesism_get_option('pintcheck3')){
						?>
						<li class="social-vimeo">
							<a class="pinterest" title="Pinterest" href="<?php echo genesism_option('pinterest_text'); ?>" target="_blank"><i class="fa icon-pinterest"></i></a>
						</li>
						<?php
						}
						?>
						
						<?php
						if (!genesism_get_option('intsagramcheck3')){
						?>
						<li class="social-vimeo">
							<a class="instagram" title="Instagram" href="<?php echo genesism_option('instagram_text'); ?>" target="_blank"><i class="fa icon-instagram"></i></a>
						</li>
						<?php
						}
						?>
						
						<?php
						if (!genesism_get_option('ytcheck3')){
						?>
						<li class="social-youtube">
							<a class="youtube" title="youtube" href="<?php echo genesism_option('youtube_text'); ?>" target="_blank"><i class="fa icon-youtube"></i></a>
						</li>
						<?php
						}
						?>
					</ul>
			</div>
			<?php 
			}
			?>
			
		</div>
		<div class="footer_btm_cnt">
    	<div class="footer_widgets_1 footer_widget">
		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer Widget1') ) : ?>
    			<div class="widget">
            		<h4 itemprop="headline"><?php _e("Footer #Widget2", 'genesis'); ?></h4>
            		<p><?php _e("This is an example of a widget area that you can place text to describe a product or service. You can also use other WordPress widgets such as recent posts, recent comments, a tag cloud or more.", 'genesis'); ?></p>
	    		</div><!-- end .widget -->
	    	<?php endif; ?> 
				       </div>

   		<!-- end .footer-left -->
    
		<div class="footer_widgets_2 footer_widget">
  
        	<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer Widget2') ) : ?>
    			<div class="widget">
            		<h4 itemprop="headline"><?php _e("Footer #Widget2", 'genesis'); ?></h4>
            		<p><?php _e("This is an example of a widget area that you can place text to describe a product or service. You can also use other WordPress widgets such as recent posts, recent comments, a tag cloud or more.", 'genesis'); ?></p>
	    		
				
				
				
				</div><!-- end .widget -->
	  
			
		<?php endif; ?> 

		
	
		
    	</div><!-- end .footer-right -->
		
		<div class="footer_widgets_3 footer_widget">
  
        	<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer Widget3') ) : ?>
    			<div class="widget">
            		<h4 itemprop="headline"><?php _e("Footer #Widget3", 'genesis'); ?></h4>
            		<p><?php _e("This is an example of a widget area that you can place text to describe a product or service. You can also use other WordPress widgets such as recent posts, recent comments, a tag cloud or more.", 'genesis'); ?></p>
	    		
				
				
				
				</div><!-- end .widget -->
	  
			
		<?php endif; ?> 

		
	
		
    	</div><!-- end .footer-right -->
	
		
	
    	
		</div>
    	</div><!-- end .wrap -->
</div><!-- end #footer-widgets -->