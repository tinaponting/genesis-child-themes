<?php
require_once(TEMPLATEPATH.'/lib/init.php'); // Start Genesis Engine
require_once(STYLESHEETPATH.'/lib/init.php'); // Start blog Options
require_once(STYLESHEETPATH.'/lib/updates.php'); // updates

include_once( 'lib/customizer.php' );

//* Remove for custom background
 remove_custom_background();

//* Add HTML5 markup structure
add_theme_support( 'html5' );


/** Support for various Image sizes */
add_theme_support('post-thumbnails');
//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Add support for custom background
add_theme_support( 'custom-background' );

 
add_filter( 'excerpt_length', 'sp_excerpt_length' );
function sp_excerpt_length( $length ) {
	return 25; // pull first 50 words
}

// Add widgeted footer section
add_action('genesis_before_footer', 'footer_bottom_widgets'); 
function footer_bottom_widgets() {
    require(CHILD_DIR.'/footer-widgeted.php');
}

/** Register widget areas */
genesis_register_sidebar( array(
	'id'			=> 'front_page_top_slider_widget',
	'name'			=> __( 'Front Page Top Slider Widget', 'Hotwoo Woocommerce Theme' ),
	'description'	=> __( 'This is the front page top slider widget if you are using a two or three column site layout option.', 'Hotwoo Woocommerce Theme' ),
	
) );

genesis_register_sidebar( array(
	'id'			=> 'front_page_content_widget',
	'name'			=> __( 'Front Page Content Widget', 'Hotwoo Woocommerce Theme' ),
	'description'	=> __( 'This is the Front Page Content Widget if you are using a two or three column site layout option.', 'Hotwoo Woocommerce Theme' ),
	
) );

genesis_register_sidebar( array(
	'id'			=> 'front_page_bottom_latest_widget',
	'name'			=> __( 'Bottom Latest News Widget', 'Hotwoo Woocommerce Theme' ),
	'description'	=> __( 'This is the Bottom Latest News Widget if you are using a two or three column site layout option.', 'Hotwoo Woocommerce Theme' ),
	
) );

register_sidebar( array(
        'name' => __( 'Single Related Post Widget ', 'Minsandgens Genesis Theme' ),
        'id' => 'single_related_post_widget',
        'description' => __( 'This is the single page related post widget.', 'Minsandgens Genesis Theme' ),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget'  => '</div>',
	
    ) );

genesis_register_sidebar( array(
	'id'			=> 'footer-widget1',
	'name'			=> __( 'Footer Widget1', 'Hotwoo Woocommerce Theme' ),
	'description'	=> __( 'This is the footer widget1 section.', 'Hotwoo Woocommerce Theme' ),
	
) );

genesis_register_sidebar( array(
	'id'			=> 'footer-widget2',
	'name'			=> __( 'Footer Widget2', 'Hotwoo Woocommerce Theme' ),
	'description'	=> __( 'This is the footer widget1 section.', 'Hotwoo Woocommerce Theme' ),
	
) );	

genesis_register_sidebar( array(
	'id'			=> 'footer-widget3',
	'name'			=> __( 'Footer Widget3', 'Hotwoo Woocommerce Theme' ),
	'description'	=> __( 'This is the footer widget1 section.', 'Hotwoo Woocommerce Theme' ),
	
) );	


add_filter( 'genesis_register_sidebar_defaults', 'custom_register_sidebar_defaults' );
function custom_register_sidebar_defaults( $defaults ) {
	$defaults['before_title'] = '<h4 class="widget-title widgettitle"><span>';
	$defaults['after_title'] = '</span></h4>';
	return $defaults;
}

add_action( 'after_setup_theme', 'woocommerce_support' );
function woocommerce_support() {
    add_theme_support( 'woocommerce' );
}


//remove archive description
remove_action( 'genesis_before_content', 'genesis_do_taxonomy_title_description', 15 );

//placeholder for comment box in single page
add_filter('comment_form_default_fields','comment_form_placeholder');
function comment_form_placeholder($fields){ 
	$fields['author'] = '<p class="comment-form-author">' . '<label for="author">' . __( '', 'genesis' ) . '</label> ' . 	
	( $req ? '<span class="required">*</span>' : '' ) .                   
	'<input id="author" name="author" type="text" placeholder="Name *" value="' . 				
	esc_attr( $commenter['comment_author'] ) . '" size="30"' . $aria_req . ' /></p>';				
    $fields['email'] = '<p class="comment-form-email"><label for="email">' . __( '', 'genesis' ) . '</label> ' .
	( $req ? '<span class="required">*</span>' : '' ) .
	'<input id="email" name="email" type="text" placeholder="Email *" value="' . 	
	esc_attr(  $commenter['comment_author_email'] ) . '" size="30"' . $aria_req . ' /></p>';	
	$fields['url'] = '<p class="comment-form-url"><label for="url">' . __( '', 'genesis' ) . '</label>' .    
	'<input id="url" name="url" type="text" placeholder="URL *" value="' . 	
	esc_attr( $commenter['comment_author_url'] ) . '" size="30" /></p>';	
    return $fields;
}

function string_limit_words($string, $word_limit)
{
  $words = explode(' ', $string, ($word_limit + 1));
  if(count($words) > $word_limit)
  array_pop($words);
  return implode(' ', $words);
}
 
// Customizes Footer Text (set in options) 
if (genesism_get_option('footer1')) { 
	add_filter('genesis_footer_creds_text', 'custom_footer_creds_text');
	function custom_footer_creds_text($creds) {
    	$creds = genesism_get_option('footer_text');
    return $creds;
	}
}




remove_action( 'genesis_site_title', 'genesis_seo_site_title' );
remove_action( 'genesis_site_description', 'genesis_seo_site_description' );
/* BEGIN Custom User Contact Info */
function extra_contact_info($contactmethods) {

$contactmethods['facebook'] = 'Facebook';
$contactmethods['twitter'] = 'Twitter';

return $contactmethods;
}
add_filter('user_contactmethods', 'extra_contact_info');
/* END Custom User Contact Info */


add_action( 'genesis_before_comments', 'themeprefix_alt_author_box',2 );
function themeprefix_alt_author_box() {
if( is_single() ) {
 
echo "<div class=\"about-author single_page_cnt\">";?>
	<div class='single_page_title'>
	<h3>About Author</h3>
	</div>
	<?php 
echo "<div class=\"author-info\" itemscope=\"itemscope\" itemtype=\"http://schema.org/person\" >" . get_avatar( get_the_author_meta( 'ID' ), '100' ) . "</div>
  <div class='author_right_cnt'>
  <h3 itemprop=\"author\"> " . get_the_author() . "</h3> 
  <p itemprop=\"description\">" . get_the_author_meta( 'description' ) . 
 "</p>
 <div class=\"author_social\">"; 

 if ( get_the_author_meta( 'facebook' ) != '' ) {
 echo "<a title='Facebook' class=\"afb fa\" href=\"". get_the_author_meta( 'facebook' ) . "\"><i class='fa icon-facebook'></i></a>";
 }
 if ( get_the_author_meta( 'googleplus' ) != '' ) {
 echo "<a title='Googleplus' class=\"agp fa\" href=\"". get_the_author_meta( 'googleplus' ) . "\"><i class='fa icon-google-plus'></i></a>";
 }
 if ( get_the_author_meta( 'twitter' ) != '' ) {
 echo "<a title='Twitter' class=\"atw fa\" href=\"https://twitter.com/". get_the_author_meta( 'twitter' ) . "\"><i class='fa icon-twitter'></i></a>";
 }
 
echo "</div></div></div>";
 }
} 

// Register Genesis Menus
add_action( 'init', 'register_additional_menu' );
function register_additional_menu() {
  
register_nav_menu( 'FirstMenu' ,__( 'Header Menu One' ));
register_nav_menu( 'SecondMenu' ,__( 'Header Menu Two' ));
register_nav_menu( 'ThirdMenu' ,__( 'Footer Menu' ));  
}  
 
/** Remove Header */
remove_action( 'genesis_header', 'genesis_header_markup_open', 5 );
remove_action( 'genesis_header', 'genesis_do_header' );
remove_action( 'genesis_header', 'genesis_header_markup_close', 15 );

add_action('genesis_before_header','before_header');	
function before_header() { ?>
<div class="headermain" id="header" itemscope="itemscope" itemtype="http://schema.org/WPHeader">
<?php
}

/** Add custom header support */
add_action('genesis_header','injectHeader');		  
function injectHeader(){ 
?>
<div class="top_header">
	<div class="top_inner_header wrap">
		<div class="top_left_header">
			<?php
			if (genesism_get_option('contact_box')){
			?>
				<div class="contact_box">
					<ul>
						<li class="address"><?php echo genesism_option('contact_address'); ?></li>
						<li class="email"><?php echo genesism_option('contact_email'); ?></li>
						<li class="phone"><?php echo genesism_option('contact_number'); ?></li>
					</ul>
				</div>	
			<?php 
			}
			?>
		</div>		
		<div class="top_right_header">
			<?php
			if (genesism_get_option('header_social')){
			?>
			<div class="header_follow">
				<div class="follow_social">
					<ul>
						<?php
						if (!genesism_get_option('fbcheck2')){
						?>
						<li class="social-facebook">
							<a class="facebook" title="Facebook" href="<?php echo genesism_option('facebook_text2'); ?>" target="_blank"><i class="fa icon-facebook3"></i></a>
						</li>
						<?php
						}
						?>
						<?php
						if (!genesism_get_option('twtcheck2')){
						?>						
						<li class="social-twitter">
							<a class="twitter" title="Twitter" href="<?php echo genesism_option('twitter_text2'); ?>" target="_blank"><i class="fa icon-twitter"></i></a>
						</li>
						<?php
						}
						?>
						
						<?php
						if (!genesism_get_option('linkcheck2')){
						?>	
						<li class="social-dribbble">
							<a class="linkedin" title="Linkedin" href="<?php echo genesism_option('linkedin_text2'); ?>" target="_blank"><i class="fa icon-linkedin2"></i></a>
						</li>
						<?php
						}
						?>
						<?php
						if (!genesism_get_option('gpcheck2')){
						?>
						<li class="social-google">
							<a class="googleplus" title="google plus" href="<?php echo genesism_option('googleplus_text2'); ?>" target="_blank"><i class="fa icon-google-plus"></i></a>
						</li>
						<?php
						}
						?>
						<?php
						if (!genesism_get_option('pintcheck2')){
						?>
						<li class="social-vimeo">
							<a class="pinterest" title="Pinterest" href="<?php echo genesism_option('pinterest_text2'); ?>" target="_blank"><i class="fa icon-pinterest"></i></a>
						</li>
						<?php
						}
						?>
						
						<?php
						if (!genesism_get_option('intsagramcheck2')){
						?>
						<li class="social-vimeo">
							<a class="instagram" title="Instagram" href="<?php echo genesism_option('instagram_text2'); ?>" target="_blank"><i class="fa icon-instagram"></i></a>
						</li>
						<?php
						}
						?>
						<?php
						if (!genesism_get_option('ytcheck2')){
						?>
						<li class="social-youtube">
							<a class="youtube" title="youtube" href="<?php echo genesism_option('youtube_text2'); ?>" target="_blank"><i class="fa icon-youtube"></i></a>
						</li>
						<?php
						}
						?>
					</ul>
				</div>
			</div>	
			<?php 
			}
			?>
		</div>
		
	</div>
</div>
<div class="center_header">
	<div class="center_inner_header wrap">
		<div class="center_left_header">
			<div class="global_table">
			<div class="global_row">
				<div class="logo_section">
					<?php
					if (genesism_get_option('header')){?>
						<a itemprop="url" title="<?php bloginfo('name'); ?>" href="<?php bloginfo('wpurl'); ?>"><img src="<?php echo genesism_option('header_text'); ?>" alt="<?php bloginfo('name'); ?>"/></a>
					<?php
					}
					else { ?>
						<h1 itemprop="headline"><a title="<?php bloginfo('name'); ?>" href="<?php bloginfo('wpurl'); ?>"><?php bloginfo('name');?> </a></h1>
						<p><?php bloginfo('description'); ?></p>
					<?php } ?>
				</div>	
			</div>
			</div>
		</div>
		
		<div class="center_right_header">
			<div class="global_table">
			<div class="global_row">
				<div class="center_left_header_cnt">
					<div class="center_menu">
						<?php
						if (genesism_get_option('header_menu1')){
						?>
						<?php wp_nav_menu( array( 'theme_location' => 'FirstMenu','container' => false,'menu_class' => 'menu2','menu_id' => 'menu_center_menu' ) );?>
						<?php 
						}
						?>
					</div>
					<div class="header_search_cart_cnt">
						<?php
						if (genesism_get_option('search_box')){
						?>
						<div class="header_search">
							<div class='widget_search'>
								<form method='get' action='<?php echo get_bloginfo('home'); ?>'>
								<input type='text' placeholder='<?php echo genesism_option('search_text'); ?>' name='s1' id='s1' />			
								<button type='submit' class='btn btn-success'>
								<input type="hidden" name="post_type" value="product" />
								<i class='fa fa-search'>Search</i>
								</button>
								</form>
							</div>
						</div>
						<?php 
						}
						?>
						<div class="widget_shopping_cart">
							<?php
							if (genesism_get_option('header_cart')){
							?>
								<div class="cart-wrap">
									<?php if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
										?>
										<?php echo cg_woocommerce_cart_dropdown(); ?>
									<?php }
									?>
								</div>
							<?php 
							}
							?>			
						</div>
					</div>
				</div>
			</div>
			</div>
		</div>
	</div>
</div>
<div class="bottom_header">
	<div class="bottom_inner_header wrap ">
			<?php
				if (genesism_get_option('header_menu2')){?>
			<div class="bottom_menu">
				<span class="menu_control">≡ Menu</span>
				<?php wp_nav_menu( array( 'theme_location' => 'SecondMenu','container' => false,'menu_id' => 'menu_bottom_menu' ) );?>
			</div>	
			<?php } ?>
	</div>
</div>

<?php 
}  
 
 
add_action('genesis_after_header','after_header');			
function after_header() { ?>
<div class="click_icon"></div>
</div>	

<?php
}

add_action('genesis_before_content_sidebar_wrap','before_content');
function before_content(){
?>
<div class="main_container wrap">
<?php 
}


add_action('genesis_after_content_sidebar_wrap','after_content');
function after_content(){
?>
</div>
<?php 
}

add_filter( 'genesis_entry_header', 'post_category',2);
function post_category() {
if ( !is_page() ) {
?>
<div class="catgory_section">	
<?php
$category = get_the_category(); 
?>
<span class="post_cat" itemprop="keywords"><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></span>	
</div>								
<?php
}
}


remove_action( 'genesis_entry_footer', 'genesis_post_meta' );

add_filter( 'genesis_post_info', 'sp_post_info_filter' );
function sp_post_info_filter($post_info) {
if ( !is_page() ) {
	$post_info = ' By [post_author_posts_link] [post_date] [post_comments zero="0" one="1 Comment" more="%"] [post_edit]';
	return $post_info;
}
}


add_action ('genesis_entry_footer','post_read_more');
function post_read_more(){
if(!is_page()&&!is_single()){
if (genesism_get_option('read_more')){
?>
<div class="post_read_more">
	<a class="pst_read_more_btn" href="<?php echo the_permalink(); ?>"><?php  echo (genesism_get_option('read_text'));?></a>
</div>
<?php 
}
}
}


add_action ('genesis_before_sidebar_widget_area','sidebar_optin',1);
function sidebar_optin(){
if (genesism_get_option('sidebar_optin')){
?>
<div class="sidebar_widget sidebar_optin">
	<div class="sidbar_optin_section">
	<div class="sidebar_title">
		<h3 class="widget-title widgettitle"><span class=""><?php echo genesism_option('sidebar_optin_header'); ?></span></h3>
		
	</div>
	<div class="sidebar_optin_cnt">
		<form method="post" class="form" action="<?php echo stripslashes(genesism_option('optin_url1')); ?>" target="_blank">
			<div class="names"><input class="name" type="text" name="<?php echo stripslashes(genesism_option('optin_name1')); ?>" placeholder="<?php echo stripslashes(genesism_option('name_text2')); ?>"><div class='admins'></div></div>
			<div class="names"><input class="email" type="text" name="<?php echo stripslashes(genesism_option('optin_email1')); ?>" placeholder="<?php echo stripslashes(genesism_option('email_text2')); ?>"><div class='mails'></div></div>
			<?php echo stripslashes(genesism_option('optin_hidden1')); ?>
			<input name="submit" class="submit" type="submit" value="<?php echo stripslashes(genesism_option('submit_text2')); ?>"/>
		</form>
	</div>
	</div>
</div>


<?php 
}
}

/** Genesis Previous/Next Post Post Navigation */
add_action ('genesis_before_comments','prev_next_post_nav',1);
function prev_next_post_nav(){
if ( is_single() ) {
echo '<div class="prev-next-navigation">';
previous_post_link( '<div class="previous">%link</div>', '%title' );
next_post_link( '<div class="next"> %link</div>', '%title' );
echo '</div><!-- .prev-next-navigation -->';
}
}	  	
add_action('genesis_entry_content','post_ad',2);
function post_ad(){
if(genesism_get_option('postadcheck')){
if ( is_single() ) {?>
		<div class="post-ad" style="text-align: center;padding: 10px">
		<?php  echo stripslashes((genesism_get_option('postad')));?>
		</div>
        <?php
		}
	}
	}

add_action( 'genesis_entry_footer', 'social_post');
function social_post(){
if ( is_single() ) {
if(genesism_get_option('social_post_button')){
?>
<div class="post-meta-share">
<div class="single_page_title">
	<h3><?php echo genesism_option('sharehead');?></h3>
	</div>	
	<div class="share-social">
		<ul class="social_share_count">
			<li class="share_tweet social-twitter">
			<a title="Twitter" href="http://twitter.com/share?text=<?php echo htmlspecialchars(urlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8')), ENT_COMPAT, 'UTF-8'); ?>&amp;url=<?php the_permalink(); ?>" target="_blank">
			<i class="icon-twitter2 icon"></i>Twitter
			</a>
			</li>
			<li class="share_fb social-facebook">
			<a title="Facebook" href="http://www.facebook.com/sharer.php?u=<?php the_permalink(); ?>&amp;t=<?php echo htmlspecialchars(urlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8')), ENT_COMPAT, 'UTF-8'); ?>" target="_blank">
			<i class="icon-facebook3 icon"></i>Facebook
			</a>
			</li>
			<li class="share_linkedin social-linkedin">
			<a title="Linkedin" target="_blank" href="http://www.linkedin.com/shareArticle?mini=true&amp;url=<?php the_permalink(); ?>">
			<i class="icon-linkedin2 icon"></i>Linkedin
			</a> 
			</li>
			<li class="share_reddit social-reddit">
			<a title="Reddit" target="_blank" href="http://www.reddit.com/submit?url=<?php the_permalink(); ?>&amp;title=<?php echo htmlspecialchars(urlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8')), ENT_COMPAT, 'UTF-8'); ?>">
			<i class="icon-reddit icon"></i>Reddit
			</a>
			</li>
			<li class="share_pintrest social-pinterest">
			<a title="Pinterest" target="_blank" href="http://pinterest.com/pinthis?url=<?php the_permalink(); ?>&amp;title=<?php echo htmlspecialchars(urlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8')), ENT_COMPAT, 'UTF-8'); ?>">
			<i class="icon-pinterest icon"></i>Pinterest
			</a>
			</li>	
		</ul>
		
	</div><!-- End follow-social -->
</div>

<?php

}
}
}


	//Related Post Box

add_action( 'genesis_before_comments', 'related_posts');
function related_posts(){
if ( is_single() ) {
?>

<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Single Related Post Widget') ) : ?>
<div class="widget">
<h4 itemprop="headline"><?php _e("Single Related Post Widget", 'genesis'); ?></h4>
<p><?php _e("Displays Related posts with thumbnails.", 'genesis'); ?></p>
</div><!-- end .widget -->
<?php endif; ?> 
</div>
<?php
}
}


add_action('wp_head','color_box');
function color_box(){

$body_bg_color = get_option('body_bg_color');
$body_txt_color = get_option('body_txt_color');
$top_bg_clr = get_option('top_bg_clr');
$center_bg_clr =get_option('center_bg_clr');
$btm_bg_clr =get_option('btm_bg_clr');
$header_txt_clr =get_option('header_txt_clr');
$title_txt_color =get_option('title_txt_color');
$title_hover_color =get_option('title_hover_color');
$hover_color1 = get_option('hover_color1');
$border_color1 = get_option('border_color1');
$border_color2 = get_option('border_color2');
$border_color3 =get_option('border_color3');
$border_color4 =get_option('border_color4');
$feature_bg_color =get_option('feature_bg_color');
$special_bg_color =get_option('special_bg_color');
$footer_bg =get_option('footer_bg');

?>
<style type="text/css">

body {
	background:<?php echo $body_bg_color; ?>;
	color:<?php echo $body_txt_color; ?>;
}
.woocommerce .woocommerce-error, .woocommerce .woocommerce-info, .woocommerce .woocommerce-message,
#add_payment_method #payment, .woocommerce-checkout #payment,
.author-info img{
	background:<?php echo $body_bg_color; ?>;
}
.woocommerce .quantity .qty,.right_popup_cnt .product_meta a,del,.hme_byline span a,
.hme_byline span,.entry-meta span,.entry-meta time ,.entry-meta a,.entry_right_cnt time,
.last_updated ul li:before,.comment-time a,.comment-author span,
.woocommerce div.product form.cart .variations label,.header_search input[type="text"]{
	color:<?php echo $body_txt_color; ?>;
}

.top_header{
    background: <?php echo $top_bg_clr; ?> ;
}

.center_header{
	background: <?php echo $center_bg_clr; ?>;
}

.bottom_header{
	background: <?php echo $btm_bg_clr; ?>;
}

.contact_box ul li,.follow_social ul li a,.menu .sub-menu a,.center_menu ul li a{
	color:<?php echo $header_txt_clr; ?>;
}

.btm_product h3 a,.entry-title a,h3.post_title_sec a,.post_contant_sec .post_date .post_date_day, 
.post_contant_sec .post_date .post_date_month,.sidebar a,.entry-title,.prev-next-navigation a,
.related_post_cnt h3 a,ins .amount,.woocommerce ul.products li.product h3,
.woocommerce div.product .woocommerce-tabs ul.tabs li a ,
.entry_right_cnt h3 a,.cart_item .product-name a,.product_title_sec h3,
.best_product_title_sec a,.optin_cnt input[type="submit"],.latest_new_title .title,
.comment-time a:hover,.archive-title{
	color:<?php echo $title_txt_color; ?>;
}


.title-separator:after,  .title-separator:before,
.title-separator span:after,  .title-separator span:before  {
	background:<?php echo $border_color1; ?> ;
}

.optin_cnt input[type="submit"]:hover{
	color:<?php echo $title_hover_color; ?> ;
	background:<?php echo $title_hover_color; ?>;	
}

.woocommerce div.product .woocommerce-tabs ul.tabs li > a:hover{
	color:<?php echo $title_txt_color; ?>;
	border-bottom-color:<?php echo $title_txt_color; ?>;	
}

.woocommerce div.product .woocommerce-tabs ul.tabs li.active a{
	color:<?php echo $title_hover_color; ?> ;
	border-bottom-color:<?php echo $title_hover_color; ?> ;
}


.single_page_title h3, h3.comment-reply-title, .entry-comments h3,.related.products h2{
	color:<?php echo $title_hover_color; ?>;
	border-bottom-color:<?php echo $title_hover_color; ?>;	
}

.related_post_section{
	background:<?php echo $body_bg_color; ?>;
	border-bottom-color:<?php echo $title_hover_color; ?>;	
}

.prev-next-navigation{
	border-color:<?php echo $title_hover_color; ?>;
}
.prev-next-navigation .previous{
	border-right-color:<?php echo $title_hover_color; ?> ;	
}
.woocommerce .woocommerce-message, .woocommerce .woocommerce-info {
    border-top-color: <?php echo $title_hover_color; ?>!important;
}


.btm_product h3 a:hover,.entry-title a:hover,.woocommerce .star-rating span:before,
.catgory_section a,.entry-meta a:hover,.archive-pagination li a,
.sidebar_widget .widgettitle, .sidebar .widget .widgettitle,.sidebar a:hover,
.prev-next-navigation a:hover,.related_post_cnt h3 a:hover,
.woocommerce ul.products li.product h3:hover,.entry_right_cnt h3 a:hover,
.woocommerce .woocommerce-message:before,.woocommerce .woocommerce-info:before,
.center_menu ul li a:before,.contact_box ul li:before,.follow_social ul li a:hover,
.product_meta a:hover,.product_title_sec h3 strong,.woocommerce nav.woocommerce-pagination ul li a, 
.woocommerce nav.woocommerce-pagination ul li span,.cart_item .product-name a:hover,
.woocommerce a.added_to_cart,.center_menu ul li a:hover  {
	color:<?php echo $title_hover_color; ?> ;
}

.woocommerce nav.woocommerce-pagination ul, .woocommerce nav.woocommerce-pagination ul li {
    border-color: <?php echo $title_hover_color; ?>;
}
p.price{
    border-bottom-color: <?php echo $title_hover_color; ?>;
}
@media only screen and (max-width: 768px) {

.prev-next-navigation .previous {
    border-bottom-color:<?php echo $title_hover_color; ?>;
}

}

.btm_product .button:hover,.post_read_more a:hover,.sidebar .tagcloud a:hover,
.woocommerce #respond input#submit:hover, .woocommerce a.button:hover, .woocommerce button.button:hover,
.woocommerce input.button:hover,ul.tiny-cart li ul.cart_list li.buttons .button:hover,
.right_popup_cnt .single_variation_wrap  button:hover,.best_product_title_sec a:hover {
    background: <?php echo $title_hover_color; ?>!important;
    border-color:<?php echo $title_hover_color; ?> !important;
}


.tiny-cart .cart_dropdown_link{
    background: <?php echo $title_hover_color; ?>!important;
    border-bottom-color:<?php echo $title_hover_color; ?>!important;
}

.best_title_sec,.box_hover .md-trigger:hover,.entry-meta:after,
.archive-pagination li a:hover, .archive-pagination li a:focus, .archive-pagination .active a,
.sidebar_optin_cnt input[type="submit"]:hover,.comment-reply a,
.form-submit input[type="submit"],.woocommerce span.onsale,
.woocommerce nav.woocommerce-pagination ul li a:focus, .woocommerce nav.woocommerce-pagination ul li a:hover, 
.woocommerce nav.woocommerce-pagination ul li span.current,.header_search .btn,
.menu a:hover,.menu .current-menu-item > a{
    background: <?php echo $title_hover_color; ?>;
}

.comment-reply a:hover,.form-submit input[type="submit"]:hover {
    box-shadow: 0 0 3px 2px <?php echo $title_hover_color; ?>;
}

.sidebar_widget .widgettitle span, .sidebar .widget .widgettitle span,
.single_page_title h3,h3.comment-reply-title,.entry-comments h3,
.related.products h2,.archive-pagination li a,.header_search .btn:hover{
    background: <?php echo $hover_color1; ?>;
}

ul.tiny-cart li ul.cart_list li.buttons .button,.right_popup_cnt .single_variation_wrap button,
.btm_product .button,.best_product_title_sec a,.post_read_more a,.sidebar .tagcloud a,
.woocommerce #respond input#submit, .woocommerce a.button, .woocommerce button.button, .woocommerce input.button,
a.inf-more-but,.single-product #container,li.comment {
	border-color:<?php echo $border_color1; ?>!important;
}

ul.tiny-cart li ul.cart_list li.buttons .button,.right_popup_cnt .single_variation_wrap button,
.btm_product .button,.best_product_title_sec a,.post_read_more a,.sidebar .tagcloud a,
.woocommerce #respond input#submit, .woocommerce a.button, .woocommerce button.button, .woocommerce input.button,
a.inf-more-but,.right_popup_cnt .sku_wrapper,.right_popup_cnt .posted_in,.right_popup_cnt .tagged_as,
.right_popup_cnt .product_title,.md-content .md-close,.btm_product .price{
	color: <?php echo $title_txt_color; ?>!important;
}

.woocommerce .star-rating:before{
	color: <?php echo $border_color1; ?>!important;
}

.entry,.product_section,.best_product_section_cnt .row_fluid,.sidebar_widget,.sidebar .widget,
.single_page_cnt,.comment-respond,.entry-comments,.archive .site-inner #container,
.woocommerce ul.products li.product, .woocommerce-page ul.products li.product ,
.woocommerce div.product div.images img ,.woocommerce div.product .woocommerce-tabs ul.tabs,
.woocommerce div.product .woocommerce-tabs .panel,.related.products ,.archive-description,.right_popup_cnt select{
	border-color: <?php echo $border_color2; ?>!important;
}

.product_title_sec,.best_title_sec {
	border-bottom-color: <?php echo $border_color2; ?>!important;
}

.feature_product_section_cnt .row_fluid{
	border-right-color: <?php echo $border_color2; ?>!important;
}

.widget_shopping_cart,.header_search,.header_search .btn,.menu .sub-menu{
	border-color: <?php echo $border_color3; ?>!important;
}

.top_header{
	border-bottom-color: <?php echo $border_color3; ?>!important;
}

.feature_product_title_sec .best_title_sec,.meta_post_categories{
    background: <?php echo $feature_bg_color; ?>!important;
}

h3.post_title_sec a:hover,.hme_byline span a:hover,.hme_byline span.author{
    color: <?php echo $feature_bg_color; ?>!important;
}

.menu .sub-menu li {
	border-bottom-color: <?php echo $border_color4; ?>!important;
}

.sidebar_optin_cnt input[type="text"],.woocommerce-cart table.cart td.actions .coupon .input-text,
.checkoutpage input[type="text"],.right_popup_cnt selec{
	border-color:<?php echo $border_color4; ?>!important;
}

.sku_wrapper, .posted_in, .tagged_as{
	border-top-color:<?php echo $border_color4; ?>!important;
}
.tagged_as,.cart_totals h2,ul.tiny-cart li ul.cart_list li.cart_list_product{
	border-bottom-color:<?php echo $border_color4; ?>!important;
}

.checkoutpage input[type="text"],.right_popup_cnt .single_variation_wrap .quantity .input-tex{
	color:<?php echo $body_txt_color; ?>!important;
}

ul.tiny-cart li ul.cart_list li.cart_list_product a.cg-cart-remove{
	background:<?php echo $body_txt_color; ?>!important;
}

.right_popup_cnt label{
	color:<?php echo $title_txt_color; ?>!important;
}

.footer_widgets,a.inf-more-but:hover,.post_contant_sec .post_img_section .featured_image,
.post_featured_img .featured_image,.site-footer,.sidebar_search_cnt .btn-success,
.sidebar_optin_cnt input[type="submit"]{
    background-color: <?php echo $footer_bg; ?> ;
}

.sidebar_search_cnt .btn-success:hover, .btn-warning {
    background-color: <?php echo $title_hover_color; ?> ;
}

.special_title_sec{
	background-color:<?php echo $special_bg_color; ?> ;
}

.header_search .btn:hover{
 background-color:<?php echo $title_txt_color; ?>;
}


</style>
<?php
}

add_action( 'wp_enqueue_scripts', 'enqueue_script' );
function enqueue_script() {
	

//wp_enqueue_script( 'main', get_stylesheet_directory_uri() . '/scripts/main.js', array( 'jquery' ), '', true );	
   // wp_enqueue_script( 'owl.carousel', get_stylesheet_directory_uri() . '/scripts/owl.carousel.js', array( 'jquery' ), '', true );	
  
	wp_enqueue_script( 'jquery.infinitescroll.min', get_stylesheet_directory_uri() . '/scripts/jquery.infinitescroll.min.js', array( 'jquery' ), '', true );	
	wp_enqueue_script( 'scripts', get_stylesheet_directory_uri() . '/scripts/scripts.js', array( 'jquery' ), '', true );
	wp_enqueue_script( 'autoloadpost', get_stylesheet_directory_uri() . '/scripts/autoloadpost.js', array( 'jquery' ), '', true );	
	wp_enqueue_script( 'classie', get_stylesheet_directory_uri() . '/scripts/classie.js', array( 'jquery' ), '', true );	
	wp_enqueue_script( 'modalEffects', get_stylesheet_directory_uri() . '/scripts/modalEffects.js', array( 'jquery' ), '', true );	
	wp_enqueue_script( 'custom', get_stylesheet_directory_uri() . '/scripts/custom.js', array( 'jquery' ), '', true );
		
	
wp_enqueue_script( 'modernizr.custom.49511', get_stylesheet_directory_uri() . '/scripts/modernizr.custom.49511.js', array( 'jquery' ), '', true );

wp_enqueue_script( 'jquery.onecarousel.min', get_stylesheet_directory_uri() . '/scripts/jquery.onecarousel.min.js', array( 'jquery' ), '', true );

wp_enqueue_script( 'bootstrap.min', get_stylesheet_directory_uri() . '/scripts/bootstrap.min.js', array( 'jquery' ), '', true );

wp_enqueue_script( 'onebyoneslide', get_stylesheet_directory_uri() . '/scripts/onebyoneslide.js', array( 'jquery' ), '', true );	
		
}


/////////////////////////////////////
// Pagination
/////////////////////////////////////

if ( !function_exists( 'pagination' ) ) {
function pagination($pages = '', $range = 4)
{
     $showitems = ($range * 2)+1;

     global $paged;
     if(empty($paged)) $paged = 1;

     if($pages == '')
     {
         global $wp_query;
         $pages = $wp_query->max_num_pages;
         if(!$pages)
         {
             $pages = 1;
         }
     }

     if(1 != $pages)
     {
         echo "<div class=\"pagination\"><span>".__( 'Page', 'mvp-text' )." ".$paged." ".__( 'of', 'mvp-text' )." ".$pages."</span>";
         if($paged > 2 && $paged > $range+1 && $showitems < $pages) echo "<a href='".get_pagenum_link(1)."'>&laquo; ".__( 'First', 'mvp-text' )."</a>";
         if($paged > 1 && $showitems < $pages) echo "<a href='".get_pagenum_link($paged - 1)."'>&lsaquo; ".__( 'Previous', 'mvp-text' )."</a>";

         for ($i=1; $i <= $pages; $i++)
         {
             if (1 != $pages &&( !($i >= $paged+$range+1 || $i <= $paged-$range-1) || $pages <= $showitems ))
             {
                 echo ($paged == $i)? "<span class=\"current\">".$i."</span>":"<a href='".get_pagenum_link($i)."' class=\"inactive\">".$i."</a>";
             }
         }

         if ($paged < $pages && $showitems < $pages) echo "<a href=\"".get_pagenum_link($paged + 1)."\">".__( 'Next', 'mvp-text' )." &rsaquo;</a>";
         if ($paged < $pages-1 &&  $paged+$range-1 < $pages && $showitems < $pages) echo "<a href='".get_pagenum_link($pages)."'>".__( 'Last', 'mvp-text' )." &raquo;</a>";
         echo "</div>\n";
     }
}
}

add_action('wp_footer','script_box');
function script_box(){?>
<script type="text/javascript">
function loadScript(src) {
     var element = document.createElement("script");
     element.src = src;
     document.body.appendChild(element);
}
// Add a script element as a child of the body
function downloadJSAtOnload() {

   	//loadScript("<?php bloginfo('stylesheet_directory'); ?>/scripts/scripts.js");	
	//loadScript("<?php bloginfo('stylesheet_directory'); ?>/scripts/jquery.infinitescroll.min.js");		
	//loadScript("<?php bloginfo('stylesheet_directory'); ?>/scripts/autoloadpost.js");		

}
 // Check for browser support of event handling capability
 if (window.addEventListener)
     window.addEventListener("load", downloadJSAtOnload, false);
	 else if (window.attachEvent)
     window.attachEvent("onload", downloadJSAtOnload);
 else window.onload = downloadJSAtOnload; 
 (function() {
      function getScript(url,success){
        var script=document.createElement('script');
        script.src=url;
        var head=document.getElementsByTagName('head')[0],
            done=false;
        script.onload=script.onreadystatechange = function(){
          if ( !done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete') ) {
            done=true;
            success();
            script.onload = script.onreadystatechange = null;
            head.removeChild(script);
          }
        };
        head.appendChild(script);
      }
        getScript('https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js',function(){
        });
    })();
</script>
<?php
}

// Auto Resize Image

function aq_resize( $url, $width, $height = null, $crop = null, $single = true ) {

//validate inputs
if(!$url OR !$width ) return false;

//define upload path & dir
$upload_info = wp_upload_dir();
$upload_dir = $upload_info['basedir'];
$upload_url = $upload_info['baseurl'];

//check if $img_url is local
if(strpos( $url, $upload_url ) === false) return false;

//define path of image
$rel_path = str_replace( $upload_url, '', $url);
$img_path = $upload_dir . $rel_path;

//check if img path exists, and is an image indeed
if( !file_exists($img_path) OR !getimagesize($img_path) ) return false;

//get image info
$info = pathinfo($img_path);
$ext = $info['extension'];
list($orig_w,$orig_h) = getimagesize($img_path);

//get image size after cropping
$dims = image_resize_dimensions($orig_w, $orig_h, $width, $height, $crop);
$dst_w = $dims[4];
$dst_h = $dims[5];

//use this to check if cropped image already exists, so we can return that instead
$suffix = "{$dst_w}x{$dst_h}";
$dst_rel_path = str_replace( '.'.$ext, '', $rel_path);
$destfilename = "{$upload_dir}{$dst_rel_path}-{$suffix}.{$ext}";

if(!$dst_h) {
//can't resize, so return original url
$img_url = $url;
$dst_w = $orig_w;
$dst_h = $orig_h;
}
//else check if cache exists
elseif(file_exists($destfilename) && getimagesize($destfilename)) {
$img_url = "{$upload_url}{$dst_rel_path}-{$suffix}.{$ext}";
}
//else, we resize the image and return the new resized image url
else {

// Note: This pre-3.5 fallback check will edited out in subsequent version
if(function_exists('wp_get_image_editor')) {

$editor = wp_get_image_editor($img_path);

if ( is_wp_error( $editor ) || is_wp_error( $editor->resize( $width, $height, $crop ) ) )
return false;

$resized_file = $editor->save();

if(!is_wp_error($resized_file)) {
$resized_rel_path = str_replace( $upload_dir, '', $resized_file['path']);
$img_url = $upload_url . $resized_rel_path;
} else {
return false;
}

} else {

$resized_img_path = image_resize( $img_path, $width, $height, $crop ); // Fallback foo
if(!is_wp_error($resized_img_path)) {
$resized_rel_path = str_replace( $upload_dir, '', $resized_img_path);
$img_url = $upload_url . $resized_rel_path;
} else {
return false;
}

}

}

//return the output
if($single) {
//str return
$image = $img_url;
} else {
//array return
$image = array (
0 => $img_url,
1 => $dst_w,
2 => $dst_h
);
}

return $image;
}

function catch_that_image() {
        global $post, $posts;
        $first_img = '';
        ob_start();
        ob_end_clean();
        $output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
        if(count($matches [1]))$first_img = $matches [1] [0];
        return $first_img;
}


 

// Add Post Feature image

add_action( 'genesis_entry_header', 'custom_post_featureimage',1 );
function custom_post_featureimage() {
if(!is_page()&&!is_single()){ 
?>
<div class="post_featured_img" itemprop="image">
<?php
 // Defaults
        $f_img_width = genesism_get_option('f_img_width');
        $f_img_height =genesism_get_option('f_img_height');
        $default_img =  'Feature_image'; 
      
        // Auto feature image defaults
        $thumb = get_post_thumbnail_id(); 
        $img_url = wp_get_attachment_url( $thumb,'full' ); 
        $image = aq_resize( $img_url,$f_img_width,$f_img_height, true );
        // Catch the Image defaults
        $catch_img_url = catch_that_image( $thumb,'full' );
        $catch_image = aq_resize( $catch_img_url, $f_img_width, $f_img_height, true );
        // Default Image
        $default_image = aq_resize( $default_img, $f_img_width, $f_img_height, true );		
		
			
		
		if(has_post_thumbnail()) { ?>
		<div class="featured_image">
        <a href="<?php echo the_permalink();?>" title="<?php echo the_title();?>"><img src="<?php echo $image;?>" width="<?php echo $f_img_width;?>" height="<?php echo $f_img_height;?>"  class="post-image entry-image" alt="<?php the_title(); ?>"  itemprop="image"><div class="img-overlay"></div></a></div>
		<?php        
		}
		elseif (catch_that_image()){ 	?>
		<div class="featured_image">
		<a href="<?php echo the_permalink();?>" title="<?php echo the_title();?>"><img src="<?php echo $catch_image;?>" width="<?php echo $f_img_width;?>" height="<?php echo $f_img_height;?>"  class="post-image entry-image" alt="<?php the_title(); ?>"  itemprop="image"><div class="img-overlay"></div></a></div>
		<?php        
		} 
		 else if(!empty($default_img)){     ?> 
		 <div class="featured_image">
          <a href="<?php echo the_permalink();?>" title="<?php echo the_title();?>"><img class="featureimg" src="<?php echo $default_img;?>" width="<?php echo $f_img_width;?>" height="<?php echo $f_img_height;?>"  class="post-image entry-image" alt="<?php the_title(); ?>"  itemprop="image"><div class="img-overlay"></div></a></div>
<?php     
	 }
	 
echo "</div>";	 
	 } 
      
}





// Crop the product image.


function etheme_get_image( $attachment_id = 0, $width = null, $height = null, $crop = true, $post_id = null ) {
	global $post;
	if (!$attachment_id) {
		if (!$post_id) {
			$post_id = $post->ID;
		}
		if ( has_post_thumbnail( $post_id ) ) {
			$attachment_id = get_post_thumbnail_id( $post_id );
		} 
		else {
			$attached_images = (array)get_posts( array(
				'post_type'   => 'attachment',
				'numberposts' => 1,
				'post_status' => null,
				'post_parent' => $post_id,
				'orderby'     => 'menu_order',
				'order'       => 'ASC'
			) );
			if ( !empty( $attached_images ) )
				$attachment_id = $attached_images[0]->ID;
		}
	}
	
	if (!$attachment_id)
		return;
		
	$image_url = etheme_get_resized_url($attachment_id,$width, $height, $crop);
	
	return apply_filters( 'blanco_product_image', $image_url );
}



function etheme_get_resized_url($id,$width, $height, $crop) {
	if ( function_exists("gd_info") && (($width >= 10) && ($height >= 10)) && (($width <= 1024) && ($height <= 1024)) ) {
		$vt_image = vt_resize( $id, '', $width, $height, $crop );
		if ($vt_image) 
			$image_url = $vt_image['url'];
		else
			$image_url = false;
	}
	else {
		$full_image = wp_get_attachment_image_src( $id, 'full');
		if (!empty($full_image[0]))
			$image_url = $full_image[0];
		else
			$image_url = false;
	}
	
    if( is_ssl() && !strstr(  $image_url, 'https' ) ) str_replace('http', 'https', $image_url);
    
    return $image_url;
}

if ( !function_exists('vt_resize') ) {
	function vt_resize( $attach_id = null, $img_url = null, $width, $height, $crop = false ) {
	
		// this is an attachment, so we have the ID
		if ( $attach_id ) {
		
			$image_src = wp_get_attachment_image_src( $attach_id, 'full' );
			$file_path = get_attached_file( $attach_id );
		
		// this is not an attachment, let's use the image url
		} else if ( $img_url ) {
			
			$file_path = parse_url( $img_url );
			$file_path = $_SERVER['DOCUMENT_ROOT'] . $file_path['path'];
			
			//$file_path = ltrim( $file_path['path'], '/' );
			//$file_path = rtrim( ABSPATH, '/' ).$file_path['path'];
			
			$orig_size = getimagesize( $file_path );
			
			$image_src[0] = $img_url;
			$image_src[1] = $orig_size[0];
			$image_src[2] = $orig_size[1];
		}
		
		$file_info = pathinfo( $file_path );
	
		// check if file exists
		$base_file = $file_info['dirname'].'/'.$file_info['filename'].'.'.$file_info['extension'];
		if ( !file_exists($base_file) )
			return;
		 
		$extension = '.'. $file_info['extension'];
	
		// the image path without the extension
		$no_ext_path = $file_info['dirname'].'/'.$file_info['filename'];
		
		// checking if the file size is larger than the target size
		// if it is smaller or the same size, stop right here and return
		if ( $image_src[1] > $width || $image_src[2] > $height ) {
	
			if ( $crop == true ) {
			
				$cropped_img_path = $no_ext_path.'-'.$width.'x'.$height.$extension;
				
				// the file is larger, check if the resized version already exists (for $crop = true but will also work for $crop = false if the sizes match)
				if ( file_exists( $cropped_img_path ) ) {
		
					$cropped_img_url = str_replace( basename( $image_src[0] ), basename( $cropped_img_path ), $image_src[0] );
					
					$vt_image = array (
						'url' => $cropped_img_url,
						'width' => $width,
						'height' => $height
					);
					
					return $vt_image;
				}
			}
			elseif ( $crop == false ) {
			
				// calculate the size proportionaly
				$proportional_size = wp_constrain_dimensions( $image_src[1], $image_src[2], $width, $height );
				$resized_img_path = $no_ext_path.'-'.$proportional_size[0].'x'.$proportional_size[1].$extension;			
	
				// checking if the file already exists
				if ( file_exists( $resized_img_path ) ) {
				
					$resized_img_url = str_replace( basename( $image_src[0] ), basename( $resized_img_path ), $image_src[0] );
	
					$vt_image = array (
						'url' => $resized_img_url,
						'width' => $proportional_size[0],
						'height' => $proportional_size[1]
					);
					
					return $vt_image;
				}
			}
	
			// check if image width is smaller than set width
			$img_size = getimagesize( $file_path );
			if ( $img_size[0] <= $width ) $width = $img_size[0];		
	
			// no cache files - let's finally resize it
			$new_img_path = image_resize( $file_path, $width, $height, $crop );
			$new_img_size = getimagesize( $new_img_path );
			$new_img = str_replace( basename( $image_src[0] ), basename( $new_img_path ), $image_src[0] );
	
			// resized output
			$vt_image = array (
				'url' => $new_img,
				'width' => $new_img_size[0],
				'height' => $new_img_size[1]
			);
			
			return $vt_image;
		}
	
		// default output - without resizing
		$vt_image = array (
			'url' => $image_src[0],
			'width' => $image_src[1],
			'height' => $image_src[2]
		);
		
		return $vt_image;
	}
}


 
 
function cg_woocommerce_cart_dropdown() {

    global $woo_options;
    global $woocommerce;
    global $cg_options;

    $cg_cart_icon_type = '';
    if ( isset( $cg_options['cg_cart_icon_type'] ) ) {
        $cg_cart_icon_type = $cg_options['cg_cart_icon_type'];
    }
    ?>

    <ul class="tiny-cart">
        <li>
            <a class="cart_dropdown_link cart-parent" href="<?php echo $woocommerce->cart->get_cart_url(); ?>" title="<?php _e( 'View your shopping cart', 'commercegurus' ); ?>">
                <div class="cg-header-cart-icon-wrap">
                    <?php if ( $cg_cart_icon_type == "bag" ) { ?>
                        <div class="icon cg-icon-bag-shopping-2"></div>
                    <?php } elseif ( $cg_cart_icon_type == "basket" ) { ?>
                        <div class="icon cg-icon-basket-1"></div>
    <?php } else { ?> 
                        <div class="icon cg-icon-shopping-1"></div>
            <?php } ?>
                    <span class="cg-cart-count">Shopping Cart <?php echo WC()->cart->cart_contents_count; ?></span>
                </div>
                <span class='cart_subtotal'><?php echo $woocommerce->cart->get_cart_subtotal(); ?></span>
            </a>
            <?php
            echo '<ul class="cart_list">';
            if ( sizeof( $woocommerce->cart->cart_contents ) > 0 ) : foreach ( $woocommerce->cart->cart_contents as $cart_item_key => $cart_item ) :
                    $_product = $cart_item['data'];
                    if ( $_product->exists() && $cart_item['quantity'] > 0 ) :
                        echo '<li class="cart_list_product">';
                        ?>
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-2">
                                    <?php echo apply_filters( 'woocommerce_cart_item_remove_link', sprintf( '<a href="%s" class="cg-cart-remove" title="%s">x</a>', esc_url( $woocommerce->cart->get_remove_url( $cart_item_key ) ), __( 'Remove this item', 'woocommerce' ) ), $cart_item_key ); ?>
                                </div>
                                <div class="col-lg-10">

                                    <?php
                                    echo '<a href="' . get_permalink( $cart_item['product_id'] ) . '">';

                                    echo $_product->get_image();

                                    echo apply_filters( 'woocommerce_cart_widget_product_title', $_product->get_title(), $_product ) . '</a>';

                                    if ( $_product instanceof woocommerce_product_variation && is_array( $cart_item['variation'] ) ) :
                                        echo woocommerce_get_formatted_variation( $cart_item['variation'] );
                                    endif;

                                    echo '<span class="quantities">' . $cart_item['quantity'] . ' &times; ' . woocommerce_price( $_product->get_price() ) . '</span>';
                                    ?>
                                </div>
                            </div>
                        </div>
                    </li>

                    <?php
                endif;
            endforeach;

        else: echo '<li class="empty">' . __( 'No products in the cart.', 'commercegurus' ) . '</li>';
        endif;
        if ( sizeof( $woocommerce->cart->cart_contents ) > 0 ) :
            echo '<li class="total"><strong>';

            if ( get_option( 'js_prices_include_tax' ) == 'yes' ) :
                _e( 'Total', 'commercegurus' );
            else :
                _e( 'Subtotal', 'commercegurus' );
            endif;

            echo ': </strong>' . $woocommerce->cart->get_cart_subtotal();
            '</li>';

            echo '<li class="buttons"><a href="' . $woocommerce->cart->get_cart_url() . '" class="button">' . __( 'View Cart', 'commercegurus' ) . '</a> <a href="' . $woocommerce->cart->get_checkout_url() . '" class="button checkout">' . __( 'Checkout', 'commercegurus' ) . '</a></li>';
        endif;

        echo '</ul>';
        ?>
    </li>
    </ul>
    <?php
}




#-----------------------------------------------------------------
# Plugin Recommendations
#-----------------------------------------------------------------

require_once ('lib/class-tgm-plugin-activation.php');
add_action( 'tgmpa_register', 'brand_shop_register_required_plugins' );

function brand_shop_register_required_plugins() {
	
	$plugins = array(
		
		array(
			'name'     				=> 'WooCommerce',
			'slug'     				=> 'woocommerce',
			'source'   				=> 'https://downloads.wordpress.org/plugin/woocommerce.2.5.5.zip',
			'required' 				=> true,
			'version' 				=> '2.5.5',
			'force_activation' 		=> false,
			'force_deactivation' 	=> false,
			'external_url' 			=> '',
		),
		
		

	);

	$config = array( 
		'domain'       		=> 'hotwoo',
		'default_path' 		=> '',
		'parent_menu_slug' 	=> 'themes.php',
		'parent_url_slug' 	=> 'themes.php',
		'menu'         		=> 'install-required-plugins',
		'has_notices'      	=> true,
		'is_automatic'    	=> false,
		'message' 			=> '',
		'strings'      		=> array(
			'page_title'                       			=> __( 'Install Required Plugins', 'hotwoo' ),
			'menu_title'                       			=> __( 'Install Plugins', 'hotwoo' ),
			'installing'                       			=> __( 'Installing Plugin: %s', 'hotwoo' ), // %1$s = plugin name
			'oops'                             			=> __( 'Something went wrong with the plugin API.', 'hotwoo' ),
			'notice_can_install_required'     			=> _n_noop( 'This theme requires the following plugin: %1$s.', 'This theme requires the following plugins: %1$s.', 'hotwoo' ), // %1$s = plugin name(s)
			'notice_can_install_recommended'			=> _n_noop( 'This theme recommends the following plugin: %1$s.', 'This theme recommends the following plugins: %1$s.', 'hotwoo' ), // %1$s = plugin name(s)
			'notice_cannot_install'  					=> _n_noop( 'Sorry, but you do not have the correct permissions to install the %s plugin. Contact the administrator of this site for help on getting the plugin installed.', 'Sorry, but you do not have the correct permissions to install the %s plugins. Contact the administrator of this site for help on getting the plugins installed.', 'hotwoo' ), // %1$s = plugin name(s)
			'notice_can_activate_required'    			=> _n_noop( 'The following required plugin is currently inactive: %1$s.', 'The following required plugins are currently inactive: %1$s.', 'hotwoo' ), // %1$s = plugin name(s)
			'notice_can_activate_recommended'			=> _n_noop( 'The following recommended plugin is currently inactive: %1$s.', 'The following recommended plugins are currently inactive: %1$s.', 'hotwoo' ), // %1$s = plugin name(s)
			'notice_cannot_activate' 					=> _n_noop( 'Sorry, but you do not have the correct permissions to activate the %s plugin. Contact the administrator of this site for help on getting the plugin activated.', 'Sorry, but you do not have the correct permissions to activate the %s plugins. Contact the administrator of this site for help on getting the plugins activated.', 'hotwoo' ), // %1$s = plugin name(s)
			'notice_ask_to_update' 						=> _n_noop( 'The following plugin needs to be updated to its latest version to ensure maximum compatibility with this theme: %1$s.', 'The following plugins need to be updated to their latest version to ensure maximum compatibility with this theme: %1$s.', 'hotwoo' ), // %1$s = plugin name(s)
			'notice_cannot_update' 						=> _n_noop( 'Sorry, but you do not have the correct permissions to update the %s plugin. Contact the administrator of this site for help on getting the plugin updated.', 'Sorry, but you do not have the correct permissions to update the %s plugins. Contact the administrator of this site for help on getting the plugins updated.', 'hotwoo' ), // %1$s = plugin name(s)
			'install_link' 					  			=> _n_noop( 'Begin installing plugin', 'Begin installing plugins', 'hotwoo'  ),
			'activate_link' 				  			=> _n_noop( 'Activate installed plugin', 'Activate installed plugins', 'hotwoo'  ),
			'return'                           			=> __( 'Return to Required Plugins Installer', 'hotwoo' ),
			'plugin_activated'                 			=> __( 'Plugin activated successfully.', 'hotwoo' ),
			'complete' 									=> __( 'All plugins installed and activated successfully. %s', 'hotwoo' ), // %1$s = dashboard link
			'nag_type'									=> 'updated'
		)
	);

	tgmpa( $plugins, $config );
}

//All Genesis Lovers Widget Starts Here


//top slider widget starts here


class gl_top_slider_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_top_slider_widget', 

__(' Hotwoo Front Top Slider Widget', 'gl_top_slider_widget_domain'), 

array( 'description' => __( 'Displays Hotwoo Front Top Slider', 'gl_top_slider_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {

$slider1_img = apply_filters( 'slider1_img', $instance['slider1_img'] );
$slider1_title = apply_filters( 'slider1_title', $instance['slider1_title'] );
$slider1_para = apply_filters( 'slider1_para', $instance['slider1_para'] );
$slider1_read_more = apply_filters( 'slider1_read_more', $instance['slider1_read_more'] );
$readmorelink1 = apply_filters( 'readmorelink1', $instance['readmorelink1'] );

$slider2_img = apply_filters( 'slider2_img', $instance['slider2_img'] );
$slider2_title = apply_filters( 'slider2_title', $instance['slider2_title'] );
$slider2_para = apply_filters( 'slider2_para', $instance['slider2_para'] );
$slider2_read_more = apply_filters( 'slider2_read_more', $instance['slider2_read_more'] );
$readmorelink2 = apply_filters( 'readmorelink2', $instance['readmorelink2'] );

$slider3_img = apply_filters( 'slider3_img', $instance['slider3_img'] );
$slider3_title = apply_filters( 'slider3_title', $instance['slider3_title'] );
$slider3_para = apply_filters( 'slider3_para', $instance['slider3_para'] );
$slider3_read_more = apply_filters( 'slider3_read_more', $instance['slider3_read_more'] );
$readmorelink3 = apply_filters( 'readmorelink3', $instance['readmorelink3'] );

$slider4_img = apply_filters( 'slider4_img', $instance['slider4_img'] );
$slider4_title = apply_filters( 'slider4_title', $instance['slider4_title'] );
$slider4_para = apply_filters( 'slider4_para', $instance['slider4_para'] );
$slider4_read_more = apply_filters( 'slider4_read_more', $instance['slider4_read_more'] );
$readmorelink4 = apply_filters( 'readmorelink4', $instance['readmorelink4'] );


echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];

?>
<div class="slider_container">

    <div class="slid_container">
    <div id="myCarousel" class="carousel slide">
      <div class="carousel-inner">
        <div class="item active">
		<img alt='<?php echo $instance['slider1_title']; ?>' src='<?php echo $instance['slider1_img']; ?>'/>
         
          <div class="slid_container">
            <div class="carousel-caption">
              <h2 data-animate="lightSpeedIn"><a href="<?php echo $instance['readmorelink1']; ?>">
			  <?php echo $instance['slider1_title']; ?></a></h2>
              <p class="lead" data-animate="fadeInDown"><?php echo $instance['slider1_para']; ?></p>
              <a class="btn btn-large btn-warning" href="<?php echo $instance['readmorelink1']; ?>">
			  <?php echo $instance['slider1_read_more']; ?></a>
            </div>
          </div>
        </div>
		
        <div class="item">
			<img alt='<?php echo $instance['slider2_title']; ?>' src='<?php echo $instance['slider2_img']; ?>'/>
          <div class="slid_container">
            <div class="carousel-caption">
              <h2 data-animate="lightSpeedIn"><a href="<?php echo $instance['readmorelink2']; ?>"> <?php echo $instance['slider2_title']; ?></a></h2>
              <p class="lead" data-animate="fadeInDown"><?php echo $instance['slider2_para']; ?>
			  </p>
              <a class="btn btn-large btn-warning" href="<?php echo $instance['readmorelink2']; ?>">
			  <?php echo $instance['slider2_read_more']; ?></a>
            </div>
          </div>
        </div>
		
        <div class="item">
          <img alt='<?php echo $instance['slider3_title']; ?>' src='<?php echo $instance['slider3_img']; ?>'/>
          <div class="slid_container">
            <div class="carousel-caption">
              <h2 data-animate="lightSpeedIn"><a href="<?php echo $instance['readmorelink3']; ?>"><?php echo $instance['slider3_title']; ?></a></h2>
              <p class="lead" data-animate="fadeInDown"><?php echo $instance['slider3_para']; ?>
			  </p>
              <a class="btn btn-large btn-warning" href="<?php echo $instance['readmorelink3']; ?>">
			  <?php echo $instance['slider3_read_more']; ?></a>
            </div>
          </div>
        </div>
		
		 <div class="item">
          <img alt='<?php echo $instance['slider4_title']; ?>' src='<?php echo $instance['slider4_img']; ?>'/>
          <div class="slid_container">
            <div class="carousel-caption">
              <h2 data-animate="lightSpeedIn"><a href="<?php echo $instance['readmorelink4']; ?>"><?php echo $instance['slider4_title']; ?></a></h2>
              <p class="lead" data-animate="fadeInDown"><?php echo $instance['slider4_para']; ?>
			  </p>
              <a class="btn btn-large btn-warning" href="<?php echo $instance['readmorelink4']; ?>">
			  <?php echo $instance['slider4_read_more']; ?></a>
            </div>
          </div>
        </div>		       

      </div>
      <a class="left carousel-control" href="#myCarousel" data-slide="prev">&lsaquo;</a>
      <a class="right carousel-control" href="#myCarousel" data-slide="next">&rsaquo;</a>
    </div><!-- /.carousel -->

    </div> <!-- end of container -->

</div>

<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {


 if ( isset( $instance[ 'slider1_img' ] ) ) {
$slider1_img = $instance[ 'slider1_img' ];
}
else {
$slider1_img = __( '', 'gl_top_slider_widget_domain' );
}

if ( isset( $instance[ 'slider1_title' ] ) ) {
$slider1_title = $instance[ 'slider1_title' ];
}
else {
$slider1_title = __( '', 'gl_top_slider_widget_domain' );
}

 if ( isset( $instance[ 'slider1_para' ] ) ) {
$slider1_para = $instance[ 'slider1_para' ];
}
else {
$slider1_para = __( '', 'gl_top_slider_widget_domain' );
}


if ( isset( $instance[ 'slider1_read_more' ] ) ) {
$slider1_read_more = $instance[ 'slider1_read_more' ];
}
else {
$slider1_read_more = __( '', 'gl_top_slider_widget_domain' );
}

if ( isset( $instance[ 'readmorelink1' ] ) ) {
$readmorelink1 = $instance[ 'readmorelink1' ];
}
else {
$readmorelink1 = __( '', 'gl_top_slider_widget_domain' );
}

/*slider2*/
if ( isset( $instance[ 'slider2_img' ] ) ) {
$slider2_img = $instance[ 'slider2_img' ];
}
else {
$slider2_img = __( '', 'gl_top_slider_widget_domain' );
}

if ( isset( $instance[ 'slider2_title' ] ) ) {
$slider2_title = $instance[ 'slider2_title' ];
}
else {
$slider2_title = __( '', 'gl_top_slider_widget_domain' );
}

 if ( isset( $instance[ 'slider2_para' ] ) ) {
$slider2_para = $instance[ 'slider2_para' ];
}
else {
$slider2_para = __( '', 'gl_top_slider_widget_domain' );
}


if ( isset( $instance[ 'slider2_read_more' ] ) ) {
$slider2_read_more = $instance[ 'slider2_read_more' ];
}
else {
$slider2_read_more = __( '', 'gl_top_slider_widget_domain' );
}

if ( isset( $instance[ 'readmorelink2' ] ) ) {
$readmorelink2 = $instance[ 'readmorelink2' ];
}
else {
$readmorelink2 = __( '', 'gl_top_slider_widget_domain' );
}

/*sliader3*/
if ( isset( $instance[ 'slider3_img' ] ) ) {
$slider3_img = $instance[ 'slider3_img' ];
}
else {
$slider3_img = __( '', 'gl_top_slider_widget_domain' );
}

if ( isset( $instance[ 'slider3_title' ] ) ) {
$slider3_title = $instance[ 'slider3_title' ];
}
else {
$slider3_title = __( '', 'gl_top_slider_widget_domain' );
}

 if ( isset( $instance[ 'slider3_para' ] ) ) {
$slider3_para = $instance[ 'slider3_para' ];
}
else {
$slider3_para = __( '', 'gl_top_slider_widget_domain' );
}


if ( isset( $instance[ 'slider3_read_more' ] ) ) {
$slider3_read_more = $instance[ 'slider3_read_more' ];
}
else {
$slider3_read_more = __( '', 'gl_top_slider_widget_domain' );
}

if ( isset( $instance[ 'readmorelink3' ] ) ) {
$readmorelink3 = $instance[ 'readmorelink3' ];
}
else {
$readmorelink3 = __( '', 'gl_top_slider_widget_domain' );
}

/*slider4*/
if ( isset( $instance[ 'slider4_img' ] ) ) {
$slider4_img = $instance[ 'slider4_img' ];
}
else {
$slider4_img = __( '', 'gl_top_slider_widget_domain' );
}

if ( isset( $instance[ 'slider4_title' ] ) ) {
$slider4_title = $instance[ 'slider4_title' ];
}
else {
$slider4_title = __( '', 'gl_top_slider_widget_domain' );
}

 if ( isset( $instance[ 'slider4_para' ] ) ) {
$slider4_para = $instance[ 'slider4_para' ];
}
else {
$slider4_para = __( '', 'gl_top_slider_widget_domain' );
}


if ( isset( $instance[ 'slider4_read_more' ] ) ) {
$slider4_read_more = $instance[ 'slider4_read_more' ];
}
else {
$slider4_read_more = __( '', 'gl_top_slider_widget_domain' );
}

if ( isset( $instance[ 'readmorelink4' ] ) ) {
$readmorelink4 = $instance[ 'readmorelink4' ];
}
else {
$readmorelink4 = __( '', 'gl_top_slider_widget_domain' );
}


?>
<p>
<label for="<?php echo $this->get_field_id( 'slider1_img' ); ?>"><?php _e( 'Slider1 Image Link here:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'slider1_img' ); ?>" name="<?php echo $this->get_field_name( 'slider1_img' ); ?>" type="text" value="<?php echo esc_attr( $slider1_img ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'slider1_title' ); ?>"><?php _e( 'Slider1 Title here:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'slider1_title' ); ?>" name="<?php echo $this->get_field_name( 'slider1_title' ); ?>" type="text" value="<?php echo esc_attr( $slider1_title ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'slider1_para' ); ?>"><?php _e( 'Slider1 Para here:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'slider1_para' ); ?>" name="<?php echo $this->get_field_name( 'slider1_para' ); ?>" type="text" value="<?php echo esc_attr( $slider1_para ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'slider1_read_more' ); ?>"><?php _e( 'Slider1 Read more Text here:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'slider1_read_more' ); ?>" name="<?php echo $this->get_field_name( 'slider1_read_more' ); ?>" type="text" value="<?php echo esc_attr( $slider1_read_more ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'readmorelink1' ); ?>"><?php _e( 'Slider1 Read more Link here:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'readmorelink1' ); ?>" name="<?php echo $this->get_field_name( 'readmorelink1' ); ?>" type="text" value="<?php echo esc_attr( $readmorelink1 ); ?>" />
</p>



<p>
<label for="<?php echo $this->get_field_id( 'slider2_img' ); ?>"><?php _e( 'Slider2 Image Link here:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'slider2_img' ); ?>" name="<?php echo $this->get_field_name( 'slider2_img' ); ?>" type="text" value="<?php echo esc_attr( $slider2_img ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'slider2_title' ); ?>"><?php _e( 'Slider2 Title here:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'slider2_title' ); ?>" name="<?php echo $this->get_field_name( 'slider2_title' ); ?>" type="text" value="<?php echo esc_attr( $slider2_title ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'slider2_para' ); ?>"><?php _e( 'Slider2 Para here:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'slider2_para' ); ?>" name="<?php echo $this->get_field_name( 'slider2_para' ); ?>" type="text" value="<?php echo esc_attr( $slider2_para ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'slider2_read_more' ); ?>"><?php _e( 'Slider2 Read more Text here:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'slider2_read_more' ); ?>" name="<?php echo $this->get_field_name( 'slider2_read_more' ); ?>" type="text" value="<?php echo esc_attr( $slider2_read_more ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'readmorelink2' ); ?>"><?php _e( 'Slider2 Read more Link here:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'readmorelink2' ); ?>" name="<?php echo $this->get_field_name( 'readmorelink2' ); ?>" type="text" value="<?php echo esc_attr( $readmorelink2 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'slider3_img' ); ?>"><?php _e( 'Slider3 Image Link here:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'slider3_img' ); ?>" name="<?php echo $this->get_field_name( 'slider3_img' ); ?>" type="text" value="<?php echo esc_attr( $slider3_img ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'slider3_title' ); ?>"><?php _e( 'Slider3 Title here:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'slider3_title' ); ?>" name="<?php echo $this->get_field_name( 'slider3_title' ); ?>" type="text" value="<?php echo esc_attr( $slider3_title ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'slider3_para' ); ?>"><?php _e( 'Slider3 Para here:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'slider3_para' ); ?>" name="<?php echo $this->get_field_name( 'slider3_para' ); ?>" type="text" value="<?php echo esc_attr( $slider3_para ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'slider3_read_more' ); ?>"><?php _e( 'Slider3 Read more Text here:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'slider3_read_more' ); ?>" name="<?php echo $this->get_field_name( 'slider3_read_more' ); ?>" type="text" value="<?php echo esc_attr( $slider3_read_more ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'readmorelink3' ); ?>"><?php _e( 'Slider3 Read more Link here:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'readmorelink3' ); ?>" name="<?php echo $this->get_field_name( 'readmorelink3' ); ?>" type="text" value="<?php echo esc_attr( $readmorelink3 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'slider4_img' ); ?>"><?php _e( 'Slider4 Image Link here:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'slider4_img' ); ?>" name="<?php echo $this->get_field_name( 'slider4_img' ); ?>" type="text" value="<?php echo esc_attr( $slider4_img ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'slider4_title' ); ?>"><?php _e( 'Slider4 Title here:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'slider4_title' ); ?>" name="<?php echo $this->get_field_name( 'slider4_title' ); ?>" type="text" value="<?php echo esc_attr( $slider4_title ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'slider4_para' ); ?>"><?php _e( 'Slider4 Para here:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'slider4_para' ); ?>" name="<?php echo $this->get_field_name( 'slider4_para' ); ?>" type="text" value="<?php echo esc_attr( $slider4_para ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'slider4_read_more' ); ?>"><?php _e( 'Slider4 Read more Text here:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'slider4_read_more' ); ?>" name="<?php echo $this->get_field_name( 'slider4_read_more' ); ?>" type="text" value="<?php echo esc_attr( $slider4_read_more ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'readmorelink4' ); ?>"><?php _e( 'Slider4 Read more Link here:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'readmorelink4' ); ?>" name="<?php echo $this->get_field_name( 'readmorelink4' ); ?>" type="text" value="<?php echo esc_attr( $readmorelink4 ); ?>" />
</p>
<?php 
}


public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['slider1_img'] = ( ! empty( $new_instance['slider1_img'] ) ) ? strip_tags( $new_instance['slider1_img'] ) : '';
$instance['slider1_title'] = ( ! empty( $new_instance['slider1_title'] ) ) ? strip_tags( $new_instance['slider1_title'] ) : '';
$instance['slider1_para'] = ( ! empty( $new_instance['slider1_para'] ) ) ? strip_tags( $new_instance['slider1_para'] ) : '';
$instance['slider1_read_more'] = ( ! empty( $new_instance['slider1_read_more'] ) ) ? strip_tags( $new_instance['slider1_read_more'] ) : '';
$instance['readmorelink1'] = ( ! empty( $new_instance['readmorelink1'] ) ) ? strip_tags( $new_instance['readmorelink1'] ) : '';

$instance['slider2_img'] = ( ! empty( $new_instance['slider2_img'] ) ) ? strip_tags( $new_instance['slider2_img'] ) : '';
$instance['slider2_title'] = ( ! empty( $new_instance['slider2_title'] ) ) ? strip_tags( $new_instance['slider2_title'] ) : '';
$instance['slider2_para'] = ( ! empty( $new_instance['slider2_para'] ) ) ? strip_tags( $new_instance['slider2_para'] ) : '';
$instance['slider2_read_more'] = ( ! empty( $new_instance['slider2_read_more'] ) ) ? strip_tags( $new_instance['slider2_read_more'] ) : '';
$instance['readmorelink2'] = ( ! empty( $new_instance['readmorelink2'] ) ) ? strip_tags( $new_instance['readmorelink2'] ) : '';

$instance['slider3_img'] = ( ! empty( $new_instance['slider3_img'] ) ) ? strip_tags( $new_instance['slider3_img'] ) : '';
$instance['slider3_title'] = ( ! empty( $new_instance['slider3_title'] ) ) ? strip_tags( $new_instance['slider3_title'] ) : '';
$instance['slider3_para'] = ( ! empty( $new_instance['slider3_para'] ) ) ? strip_tags( $new_instance['slider3_para'] ) : '';
$instance['slider3_read_more'] = ( ! empty( $new_instance['slider3_read_more'] ) ) ? strip_tags( $new_instance['slider3_read_more'] ) : '';
$instance['readmorelink3'] = ( ! empty( $new_instance['readmorelink3'] ) ) ? strip_tags( $new_instance['readmorelink3'] ) : '';

$instance['slider4_img'] = ( ! empty( $new_instance['slider4_img'] ) ) ? strip_tags( $new_instance['slider4_img'] ) : '';
$instance['slider4_title'] = ( ! empty( $new_instance['slider4_title'] ) ) ? strip_tags( $new_instance['slider4_title'] ) : '';
$instance['slider4_para'] = ( ! empty( $new_instance['slider4_para'] ) ) ? strip_tags( $new_instance['slider4_para'] ) : '';
$instance['slider4_read_more'] = ( ! empty( $new_instance['slider4_read_more'] ) ) ? strip_tags( $new_instance['slider4_read_more'] ) : '';
$instance['readmorelink4'] = ( ! empty( $new_instance['readmorelink4'] ) ) ? strip_tags( $new_instance['readmorelink4'] ) : '';
return $instance;
}
}

//top slider widget ends here

// Latest News Widget Starts Here

class gl_latest_product extends WP_Widget {

function __construct() {
parent::__construct(
'gl_latest_product', 

__('Hotwoo - Latest Product', 'gl_latest_product_domain'), 

array( 'description' => __( 'Displays Hotwoo Latest Product', 'gl_latest_product_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$latest_title1 = apply_filters( 'latest_title1', $instance['latest_title1'] );
$latest_title2 = apply_filters( 'latest_title2', $instance['latest_title2'] );
$width_size1 = apply_filters( 'width_size1', $instance['width_size1'] );
$height_size1 = apply_filters( 'height_size1', $instance['height_size1'] );


echo $args['before_widget'];
if ( ! empty( $title ) )
/*echo $args['before_title'] . $title . $args['after_title'];*/

?>

<div class="wrap">
<div class="product_section latest_product ">
<div class="product_title_sec">
<h3 class='title_one'><strong> <?php echo $instance['latest_title1']; ?> </strong> <?php echo $instance['latest_title2']; ?></h3>
</div>
<div class="row_fluid">

<?php

$args = array( 'post_type' => 'product', 'stock' => 1, 'posts_per_page' =>4, 'orderby' =>'date','order' => 'DESC' );
$loop = new WP_Query( $args );
while ( $loop->have_posts() ) : $loop->the_post(); global $product;
$j++;

echo "<div class='prduct_news latest_news_list'>";
?>

<div class="span3" itemscope itemtype="http://schema.org/Product"> 
<div class="product_image_section">
<div class='lat_img product_img'> 

<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
	<?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="65px" height="115px" />'; ?>
	</a>

<div class='image_hover'></div>


</div>
<div class="box_hover">
<button class="md-trigger" data-modal="model-1<?php echo $j; ?>">Quick View</button>
</div>
</div>
<div class="md-modal md-effect-8" id="model-1<?php echo $j; ?>">
	<div class="md-content">
		<div>
			<a class="md-close">Close me!</a>
			<div class='left_popup_cnt'>
			
			<?php 
								$f_img_width9 = $instance['width_size1'];
                                $f_img_height9 = $instance['height_size1'];
								
								// Auto feature image defaults
								$thumb = get_post_thumbnail_id(); 
								$img_url = wp_get_attachment_url( $thumb,'full' ); 
								$image = aq_resize( $img_url, $f_img_width9, $f_img_height9, true );
								// Catch the Image defaults
								$catch_img_url = catch_that_image( $thumb,'full' );
								$catch_image = aq_resize( $catch_img_url, $f_img_width9, $f_img_height9, true );
								if(has_post_thumbnail())
								echo
								"<div class=\"featured_image\">\n".
								"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width9 . "\" height=\"" . $f_img_height9 . "\" alt=\"" . get_the_title() . "\"></a>\n".
								"</div>\n";
								elseif (catch_that_image()){ 
								echo
								"<div class=\"featured_image\">\n".
								"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width9 . "\" height=\"" . $f_img_height9 . "\" alt=\"" . get_the_title() . "\"></a>\n".
								"</div>\n"; 
								} 
								
else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder"/>'; ?>
			
			</div>
			<div class='right_popup_cnt'>
			<?php
			do_action( 'woocommerce_single_product_summary' );
			?>
			</div>
		</div>

	</div>
</div>
<div class="md-overlay"></div><!-- the overlay element -->
<div class='btm_product'>
<h3><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
<?php the_title(); ?>
</a></h3>
<span class="price"><?php echo $product->get_price_html(); ?></span>

<?php

/**
Product Ratings
 */

if ( ! defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly
}

global $product;

if ( get_option( 'woocommerce_enable_review_rating' ) === 'no' ) {
  return;
}

$rating_count = $product->get_rating_count();
$review_count = $product->get_review_count();
$average      = $product->get_average_rating();

if ( $rating_count > 0 ) : ?>

	<div class="woocommerce-product-rating" itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">
		<div class="star-rating" title="<?php printf( __( 'Rated %s out of 5', 'woocommerce' ), $average ); ?>">
			<span style="width:<?php echo ( ( $average / 5 ) * 100 ); ?>%">
				<strong itemprop="ratingValue" class="rating"><?php echo esc_html( $average ); ?></strong> <?php printf( __( 'out of %s5%s', 'woocommerce' ), '<span itemprop="bestRating">', '</span>' ); ?>
				<?php printf( _n( 'based on %s customer rating', 'based on %s customer ratings', $rating_count, 'woocommerce' ), '<span itemprop="ratingCount" class="rating">' . $rating_count . '</span>' ); ?>
			</span>
		</div>
	</div>

<?php endif; ?>

<?php do_action( 'woocommerce_after_shop_loop_item' ); ?>
</div>
</div>
</div>
<!-- /span3 -->

 <?php

 endwhile; ?>
<?php wp_reset_query(); ?>

</div><!-- /row-fluid -->

</div><!-- /recent -->
</div>

<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {

if ( isset( $instance[ 'latest_title1' ] ) ) {
$latest_title1 = $instance[ 'latest_title1' ];
}
else {
$latest_title1 = __( 'New', 'gl_latest_product_domain' );
}

if ( isset( $instance[ 'latest_title2' ] ) ) {
$latest_title2 = $instance[ 'latest_title2' ];
}
else {
$latest_title2 = __( 'Product', 'gl_latest_product_domain' );
}

 if ( isset( $instance[ 'width_size1' ] ) ) {
$width_size1 = $instance[ 'width_size1' ];
}
else {
$width_size1 = __( '382', 'gl_latest_product_domain' );
}

 if ( isset( $instance[ 'height_size1' ] ) ) {
$height_size1 = $instance[ 'height_size1' ];
}
else {
$height_size1 = __( '319', 'gl_latest_product_domain' );
}

?>

<p>
<label for="<?php echo $this->get_field_id( 'latest_title1' ); ?>"><?php _e( 'Title1:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'latest_title1' ); ?>" name="<?php echo $this->get_field_name( 'latest_title1' ); ?>" type="text" value="<?php echo esc_attr( $latest_title1 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'latest_title2' ); ?>"><?php _e( 'Title2:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'latest_title2' ); ?>" name="<?php echo $this->get_field_name( 'latest_title2' ); ?>" type="text" value="<?php echo esc_attr( $latest_title2 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'width_size1' ); ?>"><?php _e( 'Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size1' ); ?>" name="<?php echo $this->get_field_name( 'width_size1' ); ?>" type="text" value="<?php echo esc_attr( $width_size1 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size1' ); ?>"><?php _e( 'Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size1' ); ?>" name="<?php echo $this->get_field_name( 'height_size1' ); ?>" type="text" value="<?php echo esc_attr( $height_size1 ); ?>" />
</p>

<?php 
}

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';

$instance['latest_title1'] = ( ! empty( $new_instance['latest_title1'] ) ) ? strip_tags( $new_instance['latest_title1'] ) : '';
$instance['latest_title2'] = ( ! empty( $new_instance['latest_title2'] ) ) ? strip_tags( $new_instance['latest_title2'] ) : '';
$instance['width_size1'] = ( ! empty( $new_instance['width_size1'] ) ) ? strip_tags( $new_instance['width_size1'] ) : '';
$instance['height_size1'] = ( ! empty( $new_instance['height_size1'] ) ) ? strip_tags( $new_instance['height_size1'] ) : '';
return $instance;
}
}

//Latest News Widget Ends Here


//Best Product Widget Starts Here

class gl_best_product extends WP_Widget {

function __construct() {
parent::__construct(
'gl_best_product', 

__('Hotwoo - Best Product', 'gl_best_product_domain'), 

array( 'description' => __( 'Displays Best Product', 'gl_best_product_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$best_title1 = apply_filters( 'best_title1', $instance['best_title1'] );
$best_title2 = apply_filters( 'best_title2', $instance['best_title2'] );
$best_cnt = apply_filters( 'best_cnt', $instance['best_cnt'] );
$best_read = apply_filters( 'best_read', $instance['best_read']); 
$best_read_link = apply_filters( 'best_read_link', $instance['best_read_link']); 


echo $args['before_widget'];
if ( ! empty( $title ) )
/*echo $args['before_title'] . $title . $args['after_title'];*/

?>
<div class="wrap">
<div class="product_section best_product">
<div class="best_product_section_cnt">
<div class="best_product_title_sec">
<div class="best_title_sec">
<h3 class='title_one'> <?php echo $instance['best_title1']; ?><em> <?php echo $instance['best_title2']; ?></em></h3>
</div>
<p><?php echo $instance['best_cnt']; ?></p>
<a href='<?php echo $instance['best_read_link']; ?>'><?php echo $instance['best_read']; ?></a>
</div>
<div class="row_fluid">
<?php
$args = array(
'post_type' => 'product',
'posts_per_page' => 4,
'meta_key' => 'total_sales',
'orderby' => 'meta_value_num',
);

$loop = new WP_Query( $args );
if ( $loop->have_posts() ) {
while ( $loop->have_posts() ) : $loop->the_post();
global $product;
$k++;
echo "<div class='prduct_news best_product_list'>";
?>

<div class="span3" itemscope itemtype="http://schema.org/Product"> 
<div class="product_image_section">
<div class='best_product_img product_img'> 

<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
	<?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="65px" height="115px" />'; ?>
	</a>

<div class='image_hover'></div>


</div>
<div class="box_hover">
<button class="md-trigger" data-modal="model-2<?php echo $k; ?>">Quick View</button>
</div>
</div>
<div class="md-modal md-effect-8" id="model-2<?php echo $k; ?>">
	<div class="md-content">
		<div>
			<a class="md-close">Close me!</a>
			<div class='left_popup_cnt'>
			<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
			<?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); 
			else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="400px" height="400px" />'; ?>
			</a>
			</div>
			<div class='right_popup_cnt'>
			<?php
			do_action( 'woocommerce_single_product_summary' );
			?>
			</div>
		</div>

	</div>
</div>
<div class="md-overlay"></div><!-- the overlay element -->

<div class='btm_product'>
<h3><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
<?php the_title(); ?>
</a></h3>
<span class="price"><?php echo $product->get_price_html(); ?></span>

<?php

/**
Product Ratings
 */

if ( ! defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly
}

global $product;

if ( get_option( 'woocommerce_enable_review_rating' ) === 'no' ) {
  return;
}

$rating_count = $product->get_rating_count();
$review_count = $product->get_review_count();
$average      = $product->get_average_rating();

if ( $rating_count > 0 ) : ?>

	<div class="woocommerce-product-rating" itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">
		<div class="star-rating" title="<?php printf( __( 'Rated %s out of 5', 'woocommerce' ), $average ); ?>">
			<span style="width:<?php echo ( ( $average / 5 ) * 100 ); ?>%">
				<strong itemprop="ratingValue" class="rating"><?php echo esc_html( $average ); ?></strong> <?php printf( __( 'out of %s5%s', 'woocommerce' ), '<span itemprop="bestRating">', '</span>' ); ?>
				<?php printf( _n( 'based on %s customer rating', 'based on %s customer ratings', $rating_count, 'woocommerce' ), '<span itemprop="ratingCount" class="rating">' . $rating_count . '</span>' ); ?>
			</span>
		</div>
	</div>

<?php endif; ?>

<?php woocommerce_template_loop_add_to_cart( $loop->post, $product ); ?>
</div>
</div>
</div>
<?php
endwhile;
} else {
echo __( 'No products found' );
}

wp_reset_query();

?>
</div><!-- /row-fluid -->
</div>
</div><!-- /recent -->
</div>

<?php

echo $args['after_widget'];
}
		
public function form( $instance ) {

if ( isset( $instance[ 'best_title1' ] ) ) {
$best_title1 = $instance[ 'best_title1' ];
}
else {
$best_title1 = __( 'Best', 'gl_best_product_domain' );
}

if ( isset( $instance[ 'best_title2' ] ) ) {
$best_title2 = $instance[ 'best_title2' ];
}
else {
$best_title2 = __( 'Product', 'gl_best_product_domain' );
}

 if ( isset( $instance[ 'best_cnt' ] ) ) {
$best_cnt = $instance[ 'best_cnt' ];
}
else {
$best_cnt = __( '', 'gl_best_product_domain' );
}

 if ( isset( $instance[ 'best_read' ] ) ) {
$best_read = $instance[ 'best_read' ];
}
else {
$best_read = __( '', 'gl_best_product_domain' );
}

 if ( isset( $instance[ 'best_read_link' ] ) ) {
$best_read_link = $instance[ 'best_read_link' ];
}
else {
$best_read_link = __( '', 'gl_best_product_domain' );
}

?>


<p>
<label for="<?php echo $this->get_field_id( 'best_title1' ); ?>"><?php _e( 'Best Product Title1:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'best_title1' ); ?>" name="<?php echo $this->get_field_name( 'best_title1' ); ?>" type="text" value="<?php echo esc_attr( $best_title1 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'best_title2' ); ?>"><?php _e( 'Best Product Title2:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'best_title2' ); ?>" name="<?php echo $this->get_field_name( 'best_title2' ); ?>" type="text" value="<?php echo esc_attr( $best_title2 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'best_cnt' ); ?>"><?php _e( 'Best Product Title Content :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'best_cnt' ); ?>" name="<?php echo $this->get_field_name( 'best_cnt' ); ?>" type="text" value="<?php echo esc_attr( $best_cnt ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'best_read' ); ?>"><?php _e( ' Best Product Read More Text:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'best_read' ); ?>" name="<?php echo $this->get_field_name( 'best_read' ); ?>" type="text" value="<?php echo esc_attr( $best_read ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'best_read_link' ); ?>"><?php _e( 'Best Product Read More URL Link:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'best_read_link' ); ?>" name="<?php echo $this->get_field_name( 'best_read_link' ); ?>" type="text" value="<?php echo esc_attr( $best_read_link ); ?>" />
</p>

<?php 
}

public function update( $new_instance, $old_instance ) {
$instance = array();

$instance['best_title1'] = ( ! empty( $new_instance['best_title1'] ) ) ? strip_tags( $new_instance['best_title1'] ) : '';
$instance['best_title2'] = ( ! empty( $new_instance['best_title2'] ) ) ? strip_tags( $new_instance['best_title2'] ) : '';
$instance['best_cnt'] = ( ! empty( $new_instance['best_cnt'] ) ) ? strip_tags( $new_instance['best_cnt'] ) : '';
$instance['best_read'] = ( ! empty( $new_instance['best_read'] ) ) ? strip_tags( $new_instance['best_read'] ) : '';
$instance['best_read_link'] = ( ! empty( $new_instance['best_read_link'] ) ) ? strip_tags( $new_instance['best_read_link'] ) : '';
return $instance;
}
}
//Best Product Widget ends Here



//Feature Product Widget Starts Here

class gl_feature_product extends WP_Widget {

function __construct() {
parent::__construct(
'gl_feature_product', 

__('Hotwoo - Feature Product', 'gl_feature_product_domain'), 

array( 'description' => __( 'Displays Hotwoo Feature Product', 'gl_feature_product_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$feature_title1 = apply_filters( 'feature_title1', $instance['feature_title1'] );
$feature_title2 = apply_filters( 'feature_title2', $instance['feature_title2'] );
$feature_cnt = apply_filters( 'feature_cnt', $instance['feature_cnt'] );
$feature_read = apply_filters( 'feature_read', $instance['feature_read'] ); 
$feature_read_link = apply_filters( 'feature_read_link', $instance['feature_read_link'] ); 


echo $args['before_widget'];
if ( ! empty( $title ) )
/*echo $args['before_title'] . $title . $args['after_title'];*/

?>

<div class="wrap">
<div class="product_section feature_product">
<div class="best_product_section_cnt feature_product_section_cnt">
<div class="best_product_title_sec feature_product_title_sec">
<div class="best_title_sec">
<h3 class='title_one'> <?php echo genesism_option('feature_title1'); ?> <em> <?php echo genesism_option('feature_title2'); ?></em></h3>
</div>
<p><?php echo $instance['feature_cnt']; ?></p>
<a href="<?php echo $instance['feature_read_link']; ?>"><?php echo $instance['feature_read']; ?></a>
</div>
<div class="row_fluid">
<?php
$args1 = array(  
    'post_type' => 'product',  
    'meta_key' => '_featured',  
    'meta_value' => 'yes',  
    'posts_per_page' => 4  
);  
  
$featured_query = new WP_Query( $args1 );  
      
if ($featured_query->have_posts()) {   
while ($featured_query->have_posts()) :   
$featured_query->the_post();  
$product = get_product( $featured_query->post->ID ); 
global $product;
$l++;
echo "<div class='prduct_news best_product_list'>";
?>

<div class="span3" itemscope itemtype="http://schema.org/Product"> 
<div class="product_image_section">
<div class='best_product_img product_img'> 

<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
	<?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="65px" height="115px" />'; ?>
	</a>

<div class='image_hover'></div>


</div>
<div class="box_hover">
<button class="md-trigger" data-modal="model-3<?php echo $l; ?>">Quick View</button>
</div>
</div>
<div class="md-modal md-effect-8" id="model-3<?php echo $l; ?>">
	<div class="md-content">
		<div>
			<a class="md-close">Close me!</a>
			<div class='left_popup_cnt'>
			<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
			<?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); 
			else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="400px" height="400px" />'; ?>
			</a>
			</div>
			<div class='right_popup_cnt'>
			<?php
			do_action( 'woocommerce_single_product_summary' );
			?>
			</div>
		</div>

	</div>
</div>
<div class="md-overlay"></div><!-- the overlay element -->
<div class='btm_product'>
<h3><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
<?php the_title(); ?>
</a></h3>
<span class="price"><?php echo $product->get_price_html(); ?></span>

<?php

/**
Product Ratings
 */

if ( ! defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly
}

global $product;

if ( get_option( 'woocommerce_enable_review_rating' ) === 'no' ) {
  return;
}

$rating_count = $product->get_rating_count();
$review_count = $product->get_review_count();
$average      = $product->get_average_rating();

if ( $rating_count > 0 ) : ?>

	<div class="woocommerce-product-rating" itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">
		<div class="star-rating" title="<?php printf( __( 'Rated %s out of 5', 'woocommerce' ), $average ); ?>">
			<span style="width:<?php echo ( ( $average / 5 ) * 100 ); ?>%">
				<strong itemprop="ratingValue" class="rating"><?php echo esc_html( $average ); ?></strong> <?php printf( __( 'out of %s5%s', 'woocommerce' ), '<span itemprop="bestRating">', '</span>' ); ?>
				<?php printf( _n( 'based on %s customer rating', 'based on %s customer ratings', $rating_count, 'woocommerce' ), '<span itemprop="ratingCount" class="rating">' . $rating_count . '</span>' ); ?>
			</span>
		</div>
	</div>

<?php endif; ?>

<?php woocommerce_template_loop_add_to_cart( $loop->post, $product ); ?>
</div>
</div>
</div>
<?php
endwhile;
} else {
echo __( 'No products found' );
}

wp_reset_query();

?>
</div><!-- /row-fluid -->
</div>
</div><!-- /recent -->
</div>



<?php

echo $args['after_widget'];
}
		
public function form( $instance ) {

if ( isset( $instance[ 'feature_title1' ] ) ) {
$feature_title1 = $instance[ 'feature_title1' ];
}
else {
$feature_title1 = __( 'Feature', 'gl_feature_product_domain' );
}

if ( isset( $instance[ 'feature_title2' ] ) ) {
$feature_title2 = $instance[ 'feature_title2' ];
}
else {
$feature_title2 = __( 'Product', 'gl_feature_product_domain' );
}

 if ( isset( $instance[ 'feature_cnt' ] ) ) {
$feature_cnt = $instance[ 'feature_cnt' ];
}
else {
$feature_cnt = __( '', 'gl_feature_product_domain' );
}

 if ( isset( $instance[ 'feature_read' ] ) ) {
$feature_read = $instance[ 'feature_read' ];
}
else {
$feature_read = __( '', 'gl_feature_product_domain' );
}

 if ( isset( $instance[ 'feature_read_link' ] ) ) {
$feature_read_link = $instance[ 'feature_read_link' ];
}
else {
$feature_read_link = __( '', 'gl_feature_product_domain' );
}

?>


<p>
<label for="<?php echo $this->get_field_id( 'feature_title1' ); ?>"><?php _e( 'Feature Product Title1:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'feature_title1' ); ?>" name="<?php echo $this->get_field_name( 'feature_title1' ); ?>" type="text" value="<?php echo esc_attr( $feature_title1 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'feature_title2' ); ?>"><?php _e( 'Feature Product Title2:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'feature_title2' ); ?>" name="<?php echo $this->get_field_name( 'feature_title2' ); ?>" type="text" value="<?php echo esc_attr( $feature_title2 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'feature_cnt' ); ?>"><?php _e( 'Feature Product Title Content :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'feature_cnt' ); ?>" name="<?php echo $this->get_field_name( 'feature_cnt' ); ?>" type="text" value="<?php echo esc_attr( $feature_cnt ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'feature_read' ); ?>"><?php _e( ' Feature Product Read More Text:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'feature_read' ); ?>" name="<?php echo $this->get_field_name( 'feature_read' ); ?>" type="text" value="<?php echo esc_attr( $feature_read ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'feature_read_link' ); ?>"><?php _e( 'Feature Product Read More URL Link:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'feature_read_link' ); ?>" name="<?php echo $this->get_field_name( 'feature_read_link' ); ?>" type="text" value="<?php echo esc_attr( $feature_read_link ); ?>" />
</p>

<?php 
}

public function update( $new_instance, $old_instance ) {
$instance = array();

$instance['feature_title1'] = ( ! empty( $new_instance['feature_title1'] ) ) ? strip_tags( $new_instance['feature_title1'] ) : '';
$instance['feature_title2'] = ( ! empty( $new_instance['feature_title2'] ) ) ? strip_tags( $new_instance['feature_title2'] ) : '';
$instance['feature_cnt'] = ( ! empty( $new_instance['feature_cnt'] ) ) ? strip_tags( $new_instance['feature_cnt'] ) : '';
$instance['feature_read'] = ( ! empty( $new_instance['feature_read'] ) ) ? strip_tags( $new_instance['feature_read'] ) : '';
$instance['feature_read_link'] = ( ! empty( $new_instance['feature_read_link'] ) ) ? strip_tags( $new_instance['feature_read_link'] ) : '';
return $instance;
}
}
//Feature Product Widget ends Here

//Special Product Widget Starts Here

class gl_special_product extends WP_Widget {

function __construct() {
parent::__construct(
'gl_special_product', 

__('Hotwoo - Special Product', 'gl_special_product_domain'), 

array( 'description' => __( 'Displays Hotwoo Special Product', 'gl_special_product_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$special_title1 = apply_filters( 'special_title1', $instance['special_title1'] );
$special_title2 = apply_filters( 'special_title2', $instance['special_title2'] );
$special_cnt = apply_filters( 'special_cnt', $instance['special_cnt'] );
$special_read = apply_filters( 'special_read', $instance['special_read'] ); 
$special_read_link = apply_filters( 'special_read_link', $instance['special_read_link'] ); 
$special_product_id1 = apply_filters( 'special_product_id1', $instance['special_product_id1'] );
$special_product_id2 = apply_filters( 'special_product_id2', $instance['special_product_id2'] );
$special_product_id3 = apply_filters( 'special_product_id3', $instance['special_product_id3'] );
$special_product_id4 = apply_filters( 'special_product_id4', $instance['special_product_id4'] );

echo $args['before_widget'];
if ( ! empty( $title ) )
/*echo $args['before_title'] . $title . $args['after_title'];*/

?>

<div class="wrap">
<div class="product_section best_product">
<div class="best_product_section_cnt">
<div class="best_product_title_sec">
<div class="best_title_sec special_title_sec">
<h3 class='title_one'> <?php echo $instance['special_title1']; ?> <em> <?php echo $instance['special_title2']; ?></em></h3>
</div>
<p><?php echo $instance['special_cnt']; ?></p>
<a href="<?php echo $instance['special_read_link']; ?>"><?php echo $instance['special_read']; ?></a>
</div>
<div class="row_fluid">
<?php
$args = array(
'post_type' => 'product',
'posts_per_page' => 1,
'p' => $instance['special_product_id1']
//'p' => genesism_get_option('special_product_id1')
);

$loop = new WP_Query( $args );
if ( $loop->have_posts() ) {

while ( $loop->have_posts() ) : $loop->the_post();
global $product;
$h++;
echo "<div class='prduct_news best_product_list'>";
?>

<div class="span3" itemscope itemtype="http://schema.org/Product"> 
<div class="product_image_section">
<div class='best_product_img product_img'> 

<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
	<?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="65px" height="115px" />'; ?>
	</a>

<div class='image_hover'></div>


</div>
<div class="box_hover">
<button class="md-trigger" data-modal="model-4<?php echo $h; ?>">Quick View</button>
</div>
</div>
<div class="md-modal md-effect-8" id="model-4<?php echo $h; ?>">
	<div class="md-content">
		<div>
			<a class="md-close">Close me!</a>
			<div class='left_popup_cnt'>
			<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
			<?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); 
			else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="400px" height="400px" />'; ?>
			</a>
			</div>
			<div class='right_popup_cnt'>
			<?php
			do_action( 'woocommerce_single_product_summary' );
			?>
			</div>
		</div>

	</div>
</div>
<div class="md-overlay"></div><!-- the overlay element -->

<div class='btm_product'>
<h3><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
<?php the_title(); ?>
</a></h3>
<span class="price"><?php echo $product->get_price_html(); ?></span>

<?php

/**
Product Ratings
 */

if ( ! defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly
}

global $product;

if ( get_option( 'woocommerce_enable_review_rating' ) === 'no' ) {
  return;
}

$rating_count = $product->get_rating_count();
$review_count = $product->get_review_count();
$average      = $product->get_average_rating();

if ( $rating_count > 0 ) : ?>

	<div class="woocommerce-product-rating" itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">
		<div class="star-rating" title="<?php printf( __( 'Rated %s out of 5', 'woocommerce' ), $average ); ?>">
			<span style="width:<?php echo ( ( $average / 5 ) * 100 ); ?>%">
				<strong itemprop="ratingValue" class="rating"><?php echo esc_html( $average ); ?></strong> <?php printf( __( 'out of %s5%s', 'woocommerce' ), '<span itemprop="bestRating">', '</span>' ); ?>
				<?php printf( _n( 'based on %s customer rating', 'based on %s customer ratings', $rating_count, 'woocommerce' ), '<span itemprop="ratingCount" class="rating">' . $rating_count . '</span>' ); ?>
			</span>
		</div>
	</div>

<?php endif; ?>

<?php woocommerce_template_loop_add_to_cart( $loop->post, $product ); ?>
</div>
</div>
</div>
<?php
endwhile;
} else {
echo __( 'No products found' );
}

wp_reset_query();

?>

<?php
$args = array(
'post_type' => 'product',
'posts_per_page' => 1,
'p' => $instance['special_product_id2']
);

$loop = new WP_Query( $args );
if ( $loop->have_posts() ) {

while ( $loop->have_posts() ) : $loop->the_post();
global $product;
$g++;
echo "<div class='prduct_news best_product_list'>";
?>

<div class="span3" itemscope itemtype="http://schema.org/Product"> 
<div class="product_image_section">
<div class='best_product_img product_img'> 

<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
	<?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="65px" height="115px" />'; ?>
	</a>

<div class='image_hover'></div>


</div>
<div class="box_hover">
<button class="md-trigger" data-modal="model-5<?php echo $g; ?>">Quick View</button>
</div>
</div>
<div class="md-modal md-effect-8" id="model-5<?php echo $g; ?>">
	<div class="md-content">
		<div>
			<a class="md-close">Close me!</a>
			<div class='left_popup_cnt'>
			<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
			<?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); 
			else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="400px" height="400px" />'; ?>
			</a>
			</div>
			<div class='right_popup_cnt'>
			<?php
			do_action( 'woocommerce_single_product_summary' );
			?>
			</div>
		</div>

	</div>
</div>
<div class="md-overlay"></div><!-- the overlay element -->

<div class='btm_product'>
<h3><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
<?php the_title(); ?>
</a></h3>
<span class="price"><?php echo $product->get_price_html(); ?></span>

<?php

/**
Product Ratings
 */

if ( ! defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly
}

global $product;

if ( get_option( 'woocommerce_enable_review_rating' ) === 'no' ) {
  return;
}

$rating_count = $product->get_rating_count();
$review_count = $product->get_review_count();
$average      = $product->get_average_rating();

if ( $rating_count > 0 ) : ?>

	<div class="woocommerce-product-rating" itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">
		<div class="star-rating" title="<?php printf( __( 'Rated %s out of 5', 'woocommerce' ), $average ); ?>">
			<span style="width:<?php echo ( ( $average / 5 ) * 100 ); ?>%">
				<strong itemprop="ratingValue" class="rating"><?php echo esc_html( $average ); ?></strong> <?php printf( __( 'out of %s5%s', 'woocommerce' ), '<span itemprop="bestRating">', '</span>' ); ?>
				<?php printf( _n( 'based on %s customer rating', 'based on %s customer ratings', $rating_count, 'woocommerce' ), '<span itemprop="ratingCount" class="rating">' . $rating_count . '</span>' ); ?>
			</span>
		</div>
	</div>

<?php endif; ?>

<?php woocommerce_template_loop_add_to_cart( $loop->post, $product ); ?>
</div>
</div>
</div>
<?php
endwhile;
} else {
echo __( 'No products found' );
}

wp_reset_query();

?>

<?php
$args = array(
'post_type' => 'product',
'posts_per_page' => 1,
'p' => $instance['special_product_id3']
);

$loop = new WP_Query( $args );
if ( $loop->have_posts() ) {

while ( $loop->have_posts() ) : $loop->the_post();
global $product;
$f++;
echo "<div class='prduct_news best_product_list'>";
?>

<div class="span3" itemscope itemtype="http://schema.org/Product"> 
<div class="product_image_section">
<div class='best_product_img product_img'> 

<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
	<?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="65px" height="115px" />'; ?>
	</a>

<div class='image_hover'></div>


</div>
<div class="box_hover">
<button class="md-trigger" data-modal="model-6<?php echo $f; ?>">Quick View</button>
</div>
</div>
<div class="md-modal md-effect-8" id="model-6<?php echo $f; ?>">
	<div class="md-content">
		<div>
			<a class="md-close">Close me!</a>
			<div class='left_popup_cnt'>
			<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
			<?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); 
			else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="400px" height="400px" />'; ?>
			</a>
			</div>
			<div class='right_popup_cnt'>
			<?php
			do_action( 'woocommerce_single_product_summary' );
			?>
			</div>
		</div>

	</div>
</div>
<div class="md-overlay"></div><!-- the overlay element -->

<div class='btm_product'>
<h3><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
<?php the_title(); ?>
</a></h3>
<span class="price"><?php echo $product->get_price_html(); ?></span>
<?php

/**
Product Ratings
 */

if ( ! defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly
}

global $product;

if ( get_option( 'woocommerce_enable_review_rating' ) === 'no' ) {
  return;
}

$rating_count = $product->get_rating_count();
$review_count = $product->get_review_count();
$average      = $product->get_average_rating();

if ( $rating_count > 0 ) : ?>

	<div class="woocommerce-product-rating" itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">
		<div class="star-rating" title="<?php printf( __( 'Rated %s out of 5', 'woocommerce' ), $average ); ?>">
			<span style="width:<?php echo ( ( $average / 5 ) * 100 ); ?>%">
				<strong itemprop="ratingValue" class="rating"><?php echo esc_html( $average ); ?></strong> <?php printf( __( 'out of %s5%s', 'woocommerce' ), '<span itemprop="bestRating">', '</span>' ); ?>
				<?php printf( _n( 'based on %s customer rating', 'based on %s customer ratings', $rating_count, 'woocommerce' ), '<span itemprop="ratingCount" class="rating">' . $rating_count . '</span>' ); ?>
			</span>
		</div>
	</div>

<?php endif; ?>

<?php woocommerce_template_loop_add_to_cart( $loop->post, $product ); ?>
</div>
</div>
</div>
<?php
endwhile;
} else {
echo __( 'No products found' );
}

wp_reset_query();

?>


<?php
$args = array(
'post_type' => 'product',
'posts_per_page' => 1,
'p' => $instance['special_product_id4']
);

$loop = new WP_Query( $args );
if ( $loop->have_posts() ) {

while ( $loop->have_posts() ) : $loop->the_post();
global $product;
$m++;
echo "<div class='prduct_news best_product_list'>";
?>

<div class="span3" itemscope itemtype="http://schema.org/Product"> 
<div class="product_image_section">
<div class='best_product_img product_img'> 

<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
	<?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="65px" height="115px" />'; ?>
	</a>

<div class='image_hover'></div>


</div>
<div class="box_hover">
<button class="md-trigger" data-modal="model-7<?php echo $m; ?>">Quick View</button>
</div>
</div>
<div class="md-modal md-effect-8" id="model-7<?php echo $m; ?>">
	<div class="md-content">
		<div>
			<a class="md-close">Close me!</a>
			<div class='left_popup_cnt'>
			<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
			<?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); 
			else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="400px" height="400px" />'; ?>
			</a>
			</div>
			<div class='right_popup_cnt'>
			<?php
			do_action( 'woocommerce_single_product_summary' );
			?>
			</div>
		</div>

	</div>
</div>
<div class="md-overlay"></div><!-- the overlay element -->

<div class='btm_product'>
<h3><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
<?php the_title(); ?>
</a></h3>
<span class="price"><?php echo $product->get_price_html(); ?></span>

<?php

/**
Product Ratings
 */

if ( ! defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly
}

global $product;

if ( get_option( 'woocommerce_enable_review_rating' ) === 'no' ) {
  return;
}

$rating_count = $product->get_rating_count();
$review_count = $product->get_review_count();
$average      = $product->get_average_rating();

if ( $rating_count > 0 ) : ?>

	<div class="woocommerce-product-rating" itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">
		<div class="star-rating" title="<?php printf( __( 'Rated %s out of 5', 'woocommerce' ), $average ); ?>">
			<span style="width:<?php echo ( ( $average / 5 ) * 100 ); ?>%">
				<strong itemprop="ratingValue" class="rating"><?php echo esc_html( $average ); ?></strong> <?php printf( __( 'out of %s5%s', 'woocommerce' ), '<span itemprop="bestRating">', '</span>' ); ?>
				<?php printf( _n( 'based on %s customer rating', 'based on %s customer ratings', $rating_count, 'woocommerce' ), '<span itemprop="ratingCount" class="rating">' . $rating_count . '</span>' ); ?>
			</span>
		</div>
	</div>

<?php endif; ?>

<?php woocommerce_template_loop_add_to_cart( $loop->post, $product ); ?>
</div>
</div>
</div>
<?php
endwhile;
} else {
echo __( 'No products found' );
}

wp_reset_query();

?>


</div><!-- /row-fluid -->
</div>
</div><!-- /recent -->
</div>


<?php

echo $args['after_widget'];
}
		
public function form( $instance ) {

if ( isset( $instance[ 'special_title1' ] ) ) {
$special_title1 = $instance[ 'special_title1' ];
}
else {
$special_title1 = __( 'Special', 'gl_special_product_domain' );
}

if ( isset( $instance[ 'special_title2' ] ) ) {
$special_title2 = $instance[ 'special_title2' ];
}
else {
$special_title2 = __( 'Product', 'gl_special_product_domain' );
}

 if ( isset( $instance[ 'special_cnt' ] ) ) {
$special_cnt = $instance[ 'special_cnt' ];
}
else {
$special_cnt = __( '', 'gl_special_product_domain' );
}

 if ( isset( $instance[ 'special_read' ] ) ) {
$special_read = $instance[ 'special_read' ];
}
else {
$special_read = __( '', 'gl_special_product_domain' );
}

 if ( isset( $instance[ 'special_read_link' ] ) ) {
$special_read_link = $instance[ 'special_read_link' ];
}
else {
$special_read_link = __( '', 'gl_special_product_domain' );
}



if ( isset( $instance[ 'special_product_id1' ] ) ) {
$special_product_id1 = $instance[ 'special_product_id1' ];
}
else {
$special_product_id1 = __( '125', 'gl_special_product_domain' );
}

if ( isset( $instance[ 'special_product_id2' ] ) ) {
$special_product_id2 = $instance[ 'special_product_id2' ];
}
else {
$special_product_id2 = __( '112', 'gl_special_product_domain' );
}

if ( isset( $instance[ 'special_product_id3' ] ) ) {
$special_product_id3 = $instance[ 'special_product_id3' ];
}
else {
$special_product_id3 = __( '120', 'gl_special_product_domain' );
}

if ( isset( $instance[ 'special_product_id4' ] ) ) {
$special_product_id4 = $instance[ 'special_product_id4' ];
}
else {
$special_product_id4 = __( '106', 'gl_special_product_domain' );
}

?>


<p>
<label for="<?php echo $this->get_field_id( 'special_title1' ); ?>"><?php _e( 'Special Product Title1:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'special_title1' ); ?>" name="<?php echo $this->get_field_name( 'special_title1' ); ?>" type="text" value="<?php echo esc_attr( $special_title1 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'special_title2' ); ?>"><?php _e( 'Special Product Title2:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'special_title2' ); ?>" name="<?php echo $this->get_field_name( 'special_title2' ); ?>" type="text" value="<?php echo esc_attr( $special_title2 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'special_cnt' ); ?>"><?php _e( 'Special Product Content :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'special_cnt' ); ?>" name="<?php echo $this->get_field_name( 'special_cnt' ); ?>" type="text" value="<?php echo esc_attr( $special_cnt ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'special_read' ); ?>"><?php _e( ' Special Product Read More Text:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'special_read' ); ?>" name="<?php echo $this->get_field_name( 'special_read' ); ?>" type="text" value="<?php echo esc_attr( $special_read ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'special_read_link' ); ?>"><?php _e( 'Special Product Read More URL Link:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'special_read_link' ); ?>" name="<?php echo $this->get_field_name( 'special_read_link' ); ?>" type="text" value="<?php echo esc_attr( $special_read_link ); ?>" />
</p>


<p>
<label for="<?php echo $this->get_field_id( 'special_product_id1' ); ?>"><?php _e( 'Special Product Id1:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'special_product_id1' ); ?>" name="<?php echo $this->get_field_name( 'special_product_id1' ); ?>" type="text" value="<?php echo esc_attr( $special_product_id1 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'special_product_id2' ); ?>"><?php _e( 'Special Product Id2:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'special_product_id2' ); ?>" name="<?php echo $this->get_field_name( 'special_product_id2' ); ?>" type="text" value="<?php echo esc_attr( $special_product_id2 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'special_product_id3' ); ?>"><?php _e( 'Special Product Id3:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'special_product_id3' ); ?>" name="<?php echo $this->get_field_name( 'special_product_id3' ); ?>" type="text" value="<?php echo esc_attr( $special_product_id3 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'special_product_id4' ); ?>"><?php _e( 'Special Product Id4:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'special_product_id4' ); ?>" name="<?php echo $this->get_field_name( 'special_product_id4' ); ?>" type="text" value="<?php echo esc_attr( $special_product_id4 ); ?>" />
</p>

<?php 
}

public function update( $new_instance, $old_instance ) {
$instance = array();

$instance['special_title1'] = ( ! empty( $new_instance['special_title1'] ) ) ? strip_tags( $new_instance['special_title1'] ) : '';
$instance['special_title2'] = ( ! empty( $new_instance['special_title2'] ) ) ? strip_tags( $new_instance['special_title2'] ) : '';
$instance['special_cnt'] = ( ! empty( $new_instance['special_cnt'] ) ) ? strip_tags( $new_instance['special_cnt'] ) : '';
$instance['special_read'] = ( ! empty( $new_instance['special_read'] ) ) ? strip_tags( $new_instance['special_read'] ) : '';
$instance['special_read_link'] = ( ! empty( $new_instance['special_read_link'] ) ) ? strip_tags( $new_instance['special_read_link'] ) : '';
$instance['special_product_id1'] = ( ! empty( $new_instance['special_product_id1'] ) ) ? strip_tags( $new_instance['special_product_id1'] ) : '';
$instance['special_product_id2'] = ( ! empty( $new_instance['special_product_id2'] ) ) ? strip_tags( $new_instance['special_product_id2'] ) : '';
$instance['special_product_id3'] = ( ! empty( $new_instance['special_product_id3'] ) ) ? strip_tags( $new_instance['special_product_id3'] ) : '';
$instance['special_product_id4'] = ( ! empty( $new_instance['special_product_id4'] ) ) ? strip_tags( $new_instance['special_product_id4'] ) : '';

return $instance;
}
}

//Special Product Widget ends Here

// Bottom Latest News Widget Starts Here

class gl_bottom_latest_news extends WP_Widget {

function __construct() {
parent::__construct(
'gl_bottom_latest_news', 

__('Hotwoo - Bottom Latest News', 'gl_bottom_latest_news_domain'), 

array( 'description' => __( 'Displays Bottom Hotwoo Latest News', 'gl_bottom_latest_news_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$latest_news_title = apply_filters( 'latest_news_title', $instance['latest_news_title'] );
$latest_news_read = apply_filters( 'latest_news_read', $instance['latest_news_read'] );
$width_size1 = apply_filters( 'width_size1', $instance['width_size1'] );
$height_size1 = apply_filters( 'height_size1', $instance['height_size1'] );


echo $args['before_widget'];
if ( ! empty( $title ) )
/*echo $args['before_title'] . $title . $args['after_title'];*/

?>

<div class="latest_news_section">
	<div class="latest_news wrap">
		<div class="latest_new_title">
			<div class="liner-continer"> 
			<span class="left-line"></span> 
			<span class="title"><?php echo $instance['latest_news_title']; ?><span class="title-separator">
			<span></span>
			</span>
			</span> 
			<span class="right-line"></span> 
			</div>
		</div>
<div class="auto_load_cnt">
<div class="blog-widget-wrap">
<div class="blog-widget-list infinite-content">
<?php $paged = (get_query_var('page')) ? get_query_var('page') : 1; query_posts(array( 'posts_per_page' => 6, 'paged' =>$paged )); if (have_posts()) : while (have_posts()) : the_post(); ?>
<div class="infinite-post post_contant_sec">
<div class="post_img_section">
<?php 
// Defaults
$f_img_width = $instance['width_size1'];
$f_img_height =$instance['height_size1'];
// Auto feature image defaults
$thumb = get_post_thumbnail_id(); 
$img_url = wp_get_attachment_url( $thumb,'full' ); 
$image = aq_resize( $img_url, $f_img_width, $f_img_height, true );
// Catch the Image defaults
$catch_img_url = catch_that_image( $thumb,'full' );
$catch_image = aq_resize( $catch_img_url, $f_img_width, $f_img_height, true );
if(has_post_thumbnail())
echo
"<div class=\"featured_image\">\n".
"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width . "\" height=\"" . $f_img_height . "\" alt=\"" . get_the_title() . "\"><div class='image_overlay'></div></a>\n".
"</div>\n";
elseif (catch_that_image()){ 
echo
"<div class=\"featured_image\">\n".
"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width . "\" height=\"" . $f_img_height . "\" alt=\"" . get_the_title() . "\"><div class='image_overlay'></div></a>\n".
"</div>\n"; 
} 
/*featured image ends here*/
?>									
</div>

<div class="post_date" itemprop="datePublished">
<span class="post_date_day">
<?php the_time('d') ?>
</span>
<span class="post_date_month">
<?php the_time('M') ?>
</span>
</div>

<div class="meta_post_categories">
<?php
$category = get_the_category(); 
?>
<a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a>
</div>
<?php echo "<h3 itemprop='headline' class='post_title_sec'><a href='". get_permalink() ."'>".get_the_title()."";
echo "</a></h3>";?>
<div class="hme_byline">
<span class="author" itemprop="author"><?php the_author() ?></span>
<span class="info_comments"><a  href="<?php the_permalink(); ?>#comments" title="<?php comments_number(__('0','fb'),__('1','periodic'),__('%','fb')); ?>"><?php comments_number(__('0','periodic'),__('1','periodic'),__('%','fb')); ?> </a></span>	
<span class="edit_link"><?php edit_post_link(); ?></span>
</div>
<div class="entry_expert" itemprop="text">
<?php 
echo"<p>";
$excerpt=get_the_excerpt();
echo string_limit_words($excerpt,20);
echo "</p>"; ?>
</div>


</div>
<?php endwhile; endif; ?>
</div>

<a href="#" class="inf-more-but"><?php echo $instance['latest_news_read']; ?></a>
<div class="nav-links">
<?php if (function_exists("pagination")) { pagination($wp_query->max_num_pages); } ?>
</div>
</div>
</div>	
	</div>
</div>
<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {

if ( isset( $instance[ 'latest_news_title' ] ) ) {
$latest_news_title = $instance[ 'latest_news_title' ];
}
else {
$latest_news_title = __( 'Latest News', 'gl_bottom_latest_news_domain' );
}

if ( isset( $instance[ 'latest_news_read' ] ) ) {
$latest_news_read = $instance[ 'latest_news_read' ];
}
else {
$latest_news_read = __( 'Load More Post', 'gl_bottom_latest_news_domain' );
}

 if ( isset( $instance[ 'width_size1' ] ) ) {
$width_size1 = $instance[ 'width_size1' ];
}
else {
$width_size1 = __( '370', 'gl_bottom_latest_news_domain' );
}

 if ( isset( $instance[ 'height_size1' ] ) ) {
$height_size1 = $instance[ 'height_size1' ];
}
else {
$height_size1 = __( '235', 'gl_bottom_latest_news_domain' );
}

?>

<p>
<label for="<?php echo $this->get_field_id( 'latest_news_title' ); ?>"><?php _e( 'Title1:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'latest_news_title' ); ?>" name="<?php echo $this->get_field_name( 'latest_news_title' ); ?>" type="text" value="<?php echo esc_attr( $latest_news_title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'latest_news_read' ); ?>"><?php _e( 'Title2:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'latest_news_read' ); ?>" name="<?php echo $this->get_field_name( 'latest_news_read' ); ?>" type="text" value="<?php echo esc_attr( $latest_news_read ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'width_size1' ); ?>"><?php _e( 'Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size1' ); ?>" name="<?php echo $this->get_field_name( 'width_size1' ); ?>" type="text" value="<?php echo esc_attr( $width_size1 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size1' ); ?>"><?php _e( 'Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size1' ); ?>" name="<?php echo $this->get_field_name( 'height_size1' ); ?>" type="text" value="<?php echo esc_attr( $height_size1 ); ?>" />
</p>

<?php 
}

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';

$instance['latest_news_title'] = ( ! empty( $new_instance['latest_news_title'] ) ) ? strip_tags( $new_instance['latest_news_title'] ) : '';
$instance['latest_news_read'] = ( ! empty( $new_instance['latest_news_read'] ) ) ? strip_tags( $new_instance['latest_news_read'] ) : '';
$instance['width_size1'] = ( ! empty( $new_instance['width_size1'] ) ) ? strip_tags( $new_instance['width_size1'] ) : '';
$instance['height_size1'] = ( ! empty( $new_instance['height_size1'] ) ) ? strip_tags( $new_instance['height_size1'] ) : '';
return $instance;
}
}

//Latest News Widget Ends Here

// Popular Widget Starts Here

class gl_popular_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_popular_widget', 

__('Hotwoo - Popular Post', 'gl_popular_widget_domain'), 

array( 'description' => __( 'Displays Popular Post', 'gl_popular_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );

echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];

?>
<div class="popular_post">

	<div class='popular_post_cnt sidebar_content'>
		<?php
			query_posts('post_type=post&posts_per_page= '. $post_count .' &orderby=comment_count&order=DESC');
			while (have_posts()): the_post(); 
		?>
			<div class='popular_post_section entry_cnt'>
				<div class='popular_img category_setion entry_img' itemprop="image">
					<?php
						// Defaults
						$f_img_width5 = $instance['width_size'];
						$f_img_height5 = $instance['height_size'];
						$default_img =  'Feature_image'; 
						// Auto feature image defaults
						$thumb = get_post_thumbnail_id(); 
						$img_url = wp_get_attachment_url( $thumb,'full' ); 
						$image = aq_resize( $img_url,$f_img_width5,$f_img_height5, true );
						// Catch the Image defaults
						$catch_img_url = catch_that_image( $thumb,'full' );
						$catch_image = aq_resize( $catch_img_ur5, $f_img_width5, $f_img_height5, true );
						// Default Image
						$default_image = aq_resize( $default_img, $f_img_width5, $f_img_height5, true );
						
						if(has_post_thumbnail())
						echo
						"<div class=\"featured_image\">\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width5 . "\" height=\"" . $f_img_height5 . "\" alt=\"" . get_the_title() . "\"></a><div class='img-overlay'><a class=\"link\" href=\"" . get_permalink() . "\"></a></div>\n".
						"</div>\n";
						elseif (catch_that_image()){ 
						echo
						"<div class=\"featured_image\">\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width5 . "\" height=\"" . $f_img_height5 . "\" alt=\"" . get_the_title() . "\"></a><div class='img-overlay'><a class=\"link\" href=\"" . get_permalink() . "\"></a></div>\n".
						"</div>\n";  
						} 
					?>
				</div>
				<div class="popular_cnt entry_right_cnt">
					<h3 itemprop='headline'><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a></h3>
					<time class='date' datetime="<?php the_time('c') ?>" itemprop="datePublished"><?php the_time('M jS, Y') ?></time>
				</div>
			</div>
		<?php
			endwhile;
		?>
	</div>
</div>

<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Popular Posts', 'gl_popular_widget_domain' );
}

 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '4', 'gl_popular_widget_domain' );
}

 if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '102', 'gl_popular_widget_domain' );
}

 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '80', 'gl_popular_widget_domain' );
}

?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>
<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';
return $instance;
}
}

// Popular Post Widget ends here


//Last Updated Post Widget Starts Here
class gl_last_update_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_last_update_widget', 

__('Hotwoo- Last Updated Post', 'gl_last_update_widget_domain'), 

array( 'description' => __( 'Displays Last Updated Post', 'gl_last_update_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );

echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];

?>
<div class="last_updated_pst">

	<div class="last_updated sidebar_content">
		<?php
			function wpb_lastupdated_posts() { 
			// Query Arguments
			$lastupdated_args = array(
			'orderby' => 'modified',
			);
			//Loop to display 5 recently updated posts
			$lastupdated_loop = new WP_Query( $lastupdated_args );
			$counter = 1;
			echo '<ul>';
			while( $lastupdated_loop->have_posts() && $counter <= 5 ) : $lastupdated_loop->the_post();
			echo '<li><a href="' . get_permalink( $lastupdated_loop->post->ID ) . '"> ' .get_the_title( $lastupdated_loop->post->ID ) . '</a> ( '. get_the_modified_date() .') </li>';
			$counter++;
			endwhile; 
			echo '</ul>';
			wp_reset_postdata(); 
			}
			if (function_exists(wpb_lastupdated_posts)) : 
			wpb_lastupdated_posts();
			endif;
		?>
	</div>
</div>

<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Last Updated Posts ', 'gl_last_update_widget_domain' );
}

 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '4', 'gl_last_update_widget_domain' );
}

?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>
<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
return $instance;
}
} 

//Last Updated Post Widget Ends Here

//Single Page Related Post Widget starts Here


class gl_related_post_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_related_post_widget', 

__('Hotwoo - Single Related Post', 'gl_related_post_widget_domain'), 

array( 'description' => __( 'Displays Single Related Post', 'gl_related_post_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$related_title = apply_filters( 'related_title', $instance['related_title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );


echo $args['before_widget'];
if ( ! empty( $title ) )
//echo $args['before_title'] . $title . $args['after_title'];

?>
<div class="thesis_related single_page_cnt">
<?php
global $post;

	if ( is_single() ) {
		$tags = get_the_tags($post->ID);
			if ($tags) {
			$tag_ids = array();
			foreach($tags as $individual_tag) $tag_ids[] = $individual_tag->term_id;
			$args=array(
			'tag__in' => $tag_ids,
			'post__not_in' => array($post->ID),
			'showposts'=>$instance[ 'post_count' ],  // Number of related posts that will be shown.
			'caller_get_posts'=>1
			);
	$my_query = new wp_query($args);
			if( $my_query->have_posts() ) {
	echo	'<div id="relatedposts">'.
				'<div class="single_page_title">'.
					'<h3>'. $related_title .'</h3>'.
					'<span class="sep"></span>'.
				'</div>'.
			'<div class="related_section">';
		while ($my_query->have_posts()) {
			$my_query->the_post();
			$i++;
			$class = ( $i % 3 ) ? 'related_post_section' : 'related_post_section last'; 
	 ?>
			<div class="<?php echo $class; ?>">
							<div class="rel_image" itemprop="image">
								<?php
								// Auto feature image defaults
								$thumb = get_post_thumbnail_id(); 
								$img_url = wp_get_attachment_url( $thumb,'full' ); 
								$f_img_width6 = $instance['width_size'];
								$f_img_height6 = $instance['height_size'];
								$image = aq_resize( $img_url, $f_img_width6, $f_img_height6, true );
								// Catch the Image defaults
								$catch_img_url = catch_that_image( $thumb,'full' );
								$catch_image = aq_resize( $catch_img_url, $f_img_width6, $f_img_height6, true );
								if(has_post_thumbnail())
								echo
								"<div class=\"featured_image\">\n".
								"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width6 . "\" height=\"" . $f_img_height6 . "\" alt=\"" . get_the_title() . "\"><div class='img-overlay'></div></a>\n".
								"</div>\n";
								elseif (catch_that_image()){ 
								echo
								"<div class=\"featured_image\">\n".
								"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width6 . "\" height=\"" . $f_img_height6 . "\" alt=\"" . get_the_title() . "\"><div class='img-overlay'></div></a>\n".
								"</div>\n"; 
								} 
								/*featured image ends here*/
								?>
								
							</div>

							<div class="related_post_cnt">
								<div class="entry_title">
									<?php echo "<h3 itemprop='headline'><a href='". get_permalink() ."'>".get_the_title()."";
									echo "</a></h3>";?>
								</div>
									<time  datetime="<?php the_time('c') ?>" itemprop="datePublished" class='date'><?php the_time('M jS, Y') ?></time>
									
							</div>
					</div>
	<?php
			}
			echo '</div>';
			echo '</div>';
			}
		}
	$post = $backup;
			wp_reset_query();
			?>
			<div class="clear"></div>
			<?php
			 }
		
?>
</div>
<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {
if ( isset( $instance[ 'related_title' ] ) ) {
$related_title = $instance[ 'related_title' ];
}
else {
$related_title = __( 'Related Post', 'gl_related_post_widget_domain' );
}

 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '6', 'gl_related_post_widget_domain' );
}

if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '371', 'gl_related_post_widget_domain' );
}

 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '192', 'gl_related_post_widget_domain' );
}


?>
<p>
<label for="<?php echo $this->get_field_id( 'related_title' ); ?>"><?php _e( 'Post Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'related_title' ); ?>" name="<?php echo $this->get_field_name( 'related_title' ); ?>" type="text" value="<?php echo esc_attr( $related_title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Left Latest News Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Left Latest News  Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>
<?php 
}
	
public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['related_title'] = ( ! empty( $new_instance['related_title'] ) ) ? strip_tags( $new_instance['related_title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';
return $instance;
}
}

//Single Page Related Post Widget Ends Here
// Register and load the widget
function gl_load_widget() {
	register_widget( 'gl_top_slider_widget' );
	register_widget( 'gl_latest_product' );
	register_widget( 'gl_best_product' );
	register_widget( 'gl_feature_product' );
	register_widget( 'gl_special_product' );
	register_widget( 'gl_bottom_latest_news' );
	register_widget( 'gl_popular_widget' );
	register_widget( 'gl_last_update_widget' );
	register_widget( 'gl_related_post_widget' );
	
	
}
add_action( 'widgets_init', 'gl_load_widget' );