jQuery(document).ready(function(){
    jQuery( ".menu-toggle" ).on('click', function() {
      jQuery( ".site-header" ).toggleClass( "site-header-toggle" );
      jQuery( ".menu-overlay").toggleClass( "overlay-active");
    });
    jQuery( ".menu-overlay").on('click', function(){
        jQuery(this).toggleClass( "overlay-active");
        jQuery( ".site-header").toggleClass( "site-header-toggle");
    });
});