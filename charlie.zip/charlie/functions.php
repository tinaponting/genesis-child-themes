<?php
//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );

//* Child theme (do not remove)
define( 'CHILD_THEME_NAME', 'Charlie' );
define( 'CHILD_THEME_VERSION', '1.0' );

//* Enqueue Lato Google font
add_action( 'wp_enqueue_scripts', 'charlie_styles_scripts' );
function charlie_styles_scripts() {
    wp_enqueue_script( 'charlie', get_bloginfo( 'stylesheet_directory' ) . '/js/charlie.js', array( 'jquery' ), '1.0.0' );
    wp_enqueue_style( 'dashicons' );
	wp_enqueue_style( 'google-font', '//fonts.googleapis.com/css?family=Open+Sans:800,700,600,400', array(), CHILD_THEME_VERSION );
}

//* Add HTML5 markup structure
add_theme_support( 'html5' );

//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Remove Genesis Layout Settings
remove_theme_support( 'genesis-inpost-layouts' );

//* Add support for 3-column footer widgets
add_theme_support( 'genesis-footer-widgets', 3 );

remove_theme_support( 'genesis-menus' );

unregister_sidebar( 'sidebar' );
unregister_sidebar( 'sidebar-alt' );

function charlie_menu_toggle() {
    echo'<div class="menu-overlay"></div>';
    echo'<div class="dashicons dashicons-menu menu-toggle"></div>';
}
add_action('genesis_before_header', 'charlie_menu_toggle');

//* Unregister content/sidebar layout setting
genesis_unregister_layout( 'content-sidebar' );
genesis_unregister_layout( 'sidebar-content' );
genesis_unregister_layout( 'content-sidebar-sidebar' );
genesis_unregister_layout( 'sidebar-sidebar-content' );
genesis_unregister_layout( 'sidebar-content-sidebar' );

remove_action( 'genesis_site_description', 'genesis_seo_site_description' );

genesis_register_sidebar( array(
    'id'          => 'after-entry',
    'name'        => __( 'After Entry', 'charlie' ),
    'description' => __( 'This is the after entry widget area.', 'beta' ),
) );