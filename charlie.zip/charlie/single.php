<?php

add_action('genesis_after_entry', 'charlie_after_entry', 5);
function charlie_after_entry() {
    genesis_widget_area( 'after-entry', array(
        'before' => '<div class="after-entry widget-area">',
        'after'  => '</div>',
    ) );
}

genesis();