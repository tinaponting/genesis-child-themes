<?php

function charlie_category_header() {
    echo'<div class="home-header">';
        echo '<h1>' . get_bloginfo('description') . '</h1>';
    echo'</div>';
}
add_action('genesis_after_header', 'charlie_category_header');

//* Remove the post content (requires HTML5 theme support)
remove_action( 'genesis_entry_content', 'genesis_do_post_content' );

//* Remove the entry meta in the entry header (requires HTML5 theme support)
remove_action( 'genesis_entry_header', 'genesis_post_info', 12 );
remove_action( 'genesis_entry_footer', 'genesis_post_meta' );

function charlie_read_more() {
    echo'<a class="readmore" href="' . get_permalink() . '">';
        echo'<p>Read</p>';
    echo'</a>';
}
add_action('genesis_entry_footer', 'charlie_read_more', 20);



genesis();
