<?php
//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );

//* Child theme (do not remove)
define( 'CHILD_THEME_NAME', 'Foxglove Child Theme' );
define( 'CHILD_THEME_URL', 'http://www.wildflowersandpixels.co.uk/' );
define( 'CHILD_THEME_VERSION', '1.0' );

// Enqueue scripts and styles
add_action( 'wp_enqueue_scripts', 'foxglove_scripts_styles' );
function foxglove_scripts_styles() {

	wp_enqueue_script( 'foxglove-responsive-menu', get_stylesheet_directory_uri() . '/js/responsive-menu.js', array( 'jquery' ), '1.0.0' );
	wp_enqueue_style( 'dashicons' );

}
//* Add Google Font in Genesis  
add_action( 'wp_enqueue_scripts', 'genesis_ig_google_fonts' );
function genesis_ig_google_fonts() {
	wp_enqueue_style( 'google-fonts', '//fonts.googleapis.com/css?family=Lato:400,700,900,300|Oswald:400,300,700', array(), CHILD_THEME_VERSION );
}
//* Add HTML5 markup structure
add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list' ) );

//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Add support for 1-column footer widgets
add_theme_support( 'genesis-footer-widgets', 1 );
add_filter( 'genesis_gravatar_sizes', 'ck_user_profile' );
function ck_user_profile( $sizes ) {
	$sizes['Extra Large Image'] = 300;
	return $sizes;
}
//* Change the footer text
add_filter('genesis_footer_creds_text', 'sp_footer_creds_filter');
function sp_footer_creds_filter( $creds ) {
	$creds = '[footer_copyright] &middot; <a href="http://www.wildflowersandpixels.co.uk/">MADE WITH LOVE by WILDFLOWERS AND PIXELS</a>';
	return $creds;
}
add_image_size( 'featuredlarge', 300, 200 );/* Code to Display Featured Image on top of the post */
add_action( 'genesis_before_entry', 'featured_post_image', 8 );
function featured_post_image() {
  if ( ! is_singular( 'post' ) )  return;
	the_post_thumbnail('post-image');
}