<?php
/*
Template Name: Front Page
*/

// Add custom body class to the head
add_filter( 'body_class', 'metro_add_body_class' );
function metro_add_body_class( $classes ) {
   $classes[] = 'frontpage';
   return $classes;
}

// set full width layout

remove_action( 'genesis_entry_content', 'genesis_do_post_content' );
remove_action( 'genesis_loop', 'genesis_do_loop' );
remove_action('genesis_before_loop', 'genesis_do_breadcrumbs');



add_action('genesis_before_content_sidebar_wrap','top_category',1);
function top_category(){
?>

<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Front Page Top Widget') ) : ?>
<div class="widget">
<h4 itemprop="headline"><?php _e("Front Page Top #Widget", 'genesis'); ?></h4>
<p><?php _e("Displays Latest posts with thumbnails.", 'genesis'); ?></p>
</div><!-- end .widget -->
<?php endif; ?> 

<?php 
}



add_action('genesis_before_loop','content_category',1);
function content_category(){
?>
<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Front Page Content Widget') ) : ?>
<div class="widget">
<h4 itemprop="headline"><?php _e("Front Page Content #Widget", 'genesis'); ?></h4>
<p><?php _e("Displays Front Page Content posts with thumbnails.", 'genesis'); ?></p>
</div><!-- end .widget -->
<?php endif; ?> 

<?php 
}




add_action('genesis_after_content_sidebar_wrap','bottom_category',1);
function bottom_category(){
?>
<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Front Page Bottom Widget') ) : ?>
<div class="widget">
<h4 itemprop="headline"><?php _e("Front Page Bottom #Widget", 'genesis'); ?></h4>
<p><?php _e("Displays Category posts with thumbnails.", 'genesis'); ?></p>
</div><!-- end .widget -->
<?php endif; ?> 
<?php 
}

genesis();