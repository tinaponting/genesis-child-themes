
var j=jQuery.noConflict();
  j(document).ready(function () {
            var $tabs = j('#horizontalTab');
            $tabs.responsiveTabs({
                rotate: false,
                startCollapsed: 'accordion',
                collapsible: 'accordion',
                setHash: true,
                disabled: [3,4],
                activate: function(e, tab) {
                    j('.info').html('Tab <strong>' + tab.id + '</strong> activated!');
                },
                activateState: function(e, state) {
                    //console.log(state);
                    j('.info').html('Switched from <strong>' + state.oldState + '</strong> state to <strong>' + state.newState + '</strong> state!');
                }
            });

            j('#start-rotation').on('click', function() {
                $tabs.responsiveTabs('startRotation', 1000);
            });
            j('#stop-rotation').on('click', function() {
                $tabs.responsiveTabs('stopRotation');
            });
            j('#start-rotation').on('click', function() {
                $tabs.responsiveTabs('active');
            });
            j('#enable-tab').on('click', function() {
                $tabs.responsiveTabs('enable', 3);
            });
            j('#disable-tab').on('click', function() {
                $tabs.responsiveTabs('disable', 3);
            });
            j('.select-tab').on('click', function() {
                $tabs.responsiveTabs('activate', j(this).val());
            });

        });