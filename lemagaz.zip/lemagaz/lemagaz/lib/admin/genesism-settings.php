<?php
 /* This adds our genesism settings sub menu page
 */
add_action('admin_menu', 'genesism_add_admin');
function genesism_add_admin() { 
	global $_genesism_settings_pagehook;
	
	$_genesism_settings_pagehook = add_submenu_page('genesis', "genesism Settings","Lemagaz Settings", 'edit_theme_options', 'genesism', 'genesism_theme_settings_admin');
}

/**
 * This adds our genesism settings CSS
 */
add_action('admin_init', 'genesism_load_admin_styles');
function genesism_load_admin_styles() {
	wp_enqueue_style('genesism_admin_css', CHILD_THEME_LIB_URL.'/css/genesism-admin.css');
}

/**
 * This registers the settings field and adds defaults to the options table.
 * It also handles settings resets by pushing in the defaults.
 */
add_action('admin_init', 'genesism_register_theme_settings', 5);
function genesism_register_theme_settings() {
	register_setting( LEMAGAZ_SETTINGS_FIELD, LEMAGAZ_SETTINGS_FIELD );
	add_option( LEMAGAZ_SETTINGS_FIELD, genesism_theme_settings_defaults() );
	
	if ( !isset($_REQUEST['page']) || $_REQUEST['page'] != 'genesism' )
		return;
		
	if ( genesism_get_option('reset') ) {
		update_option(LEMAGAZ_SETTINGS_FIELD, genesism_theme_settings_defaults());
		wp_redirect( admin_url( 'admin.php?page=genesism&reset=true' ) );
		exit;
	}
}

/**
 * This is the notice that displays when you successfully save or reset
 * the theme settings.
 */
add_action('admin_notices', 'genesism_theme_settings_notice');
function genesism_theme_settings_notice() {
	
	if ( !isset($_REQUEST['page']) || $_REQUEST['page'] != 'genesism' )
		return;
	
	if ( isset( $_REQUEST['reset'] ) && $_REQUEST['reset'] == 'true' ) {
		echo '<div id="message" class="updated"><p><strong>'.__('Theme Settings Reset', 'genesism').'</strong></p></div>';
	}
	if ( isset($_REQUEST['updated']) && $_REQUEST['updated'] == 'true') {  
		echo '<div id="message" class="updated"><p><strong>'.__('Theme Settings Saved', 'genesism').'</strong></p></div>';
	}
	elseif ( isset($_REQUEST['settings-updated']) && $_REQUEST['settings-updated'] == 'true') {  
		echo '<div id="message" class="updated"><p><strong>'.__('Theme Settings Saved', 'genesism').'</strong></p></div>';
	}
	
}

/**
 * This is a necessary go-between to get our scripts and boxes loaded
 * on the theme settings page only, and not the rest of the admin
 */
add_action('admin_menu', 'genesism_theme_settings_init');
function genesism_theme_settings_init() {
	global $_genesism_settings_pagehook;
	
	if (function_exists('add_screen_option')) { add_screen_option('layout_columns', array('max' => 2, 'default' => 2) ); }
	
	add_action('load-'.$_genesism_settings_pagehook, 'genesism_theme_settings_scripts');
	add_action('load-'.$_genesism_settings_pagehook, 'genesism_theme_settings_boxes');
}

function genesism_theme_settings_scripts() {	
	wp_enqueue_script('common');
	wp_enqueue_script('wp-lists');
	wp_enqueue_script('postbox');
}

/**
 * Tell WordPress that we want only 2 columns available for our meta-boxes
 */
add_filter('screen_layout_columns', 'genesism_theme_settings_layout_columns', 10, 2);
function genesism_theme_settings_layout_columns($columns, $screen) {

	  //Set the default column layout in the New Post section to one column for new users
	  global $current_user;
	  get_currentuserinfo();
	  $user_id = $current_user->ID;
	  $prev_value = NULL;
	  update_user_meta($user_id, screen_layout_appearance_page_genesism, 2, $prev_value);

	global $_genesism_settings_pagehook;
	
	if (function_exists('add_screen_option')) { add_screen_option('layout_columns', array('max' => 2, 'default' => 2) ); }
	if ($screen == $_genesism_settings_pagehook) {
		// This page should only have 2 column options
		$columns[$_genesism_settings_pagehook] = 2;
	}
	return $columns;
}

/**
 * This function is what actually gets output to the page. It handles the markup,
 * builds the form, outputs necessary JS stuff, and fires <code>do_meta_boxes()</code>
 */
function genesism_theme_settings_admin() { 

	global $_genesism_theme_settings_pagehook, $screen_layout_columns;
	$screen = get_current_screen();
	
	if ( $screen_layout_columns == 2 ) {
		$width = 'width: 49%;';
		$hide2 = ' display: block;';
		$hide3 = ' display: none;';
	}
	else {
		$width = 'width: 50%;';
		$hide2 = $hide3 = ' display: block;';
	}
?>	
	<div id="genesism-theme-settings" class="wrap genesism-metaboxes">
	<form method="post" action="options.php">
		
		<?php wp_nonce_field('closedpostboxes', 'closedpostboxesnonce', false ); ?>
		<?php wp_nonce_field('meta-box-order', 'meta-box-order-nonce', false ); ?>
		<?php settings_fields(LEMAGAZ_SETTINGS_FIELD); // important! ?>
		<input type="hidden" name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[theme_version]>" value="<?php echo esc_attr(genesism_option('theme_version')); ?>" />
		
		<?php screen_icon('options-general'); ?>
		<h2>
			<?php _e(CHILD_THEME_NAME.' - Lemagaz Settings', 'genesism'); ?>
			<input type="submit" class="button-primary" value="<?php _e('Save Settings', 'genesism') ?>" />
			<input type="submit" class="button-highlighted" name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[reset]" value="<?php _e('Reset Settings', 'genesism'); ?>" onclick="return confirm('<?php echo esc_js( __('Are you sure you want to reset?', 'genesism') ); ?>');" />
		</h2>
		
		<div class="metabox-holder">
            <?php 
            echo "\t<div id='postbox-container-1' class='postbox-container' style='$width'>\n";
			do_meta_boxes( $screen->id, 'normal', '' );
		
			echo "\t</div><div id='postbox-container-2' class='postbox-container' style='{$hide2}$width'>\n";
			do_meta_boxes( $screen->id, 'side', '' );
				?>
		</div></div>
		
		<div class="bottom-buttons">
			<input type="submit" class="button-primary" value="<?php _e('Save Settings', 'genesism') ?>" />
			<input type="submit" class="button-highlighted" name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[reset]" value="<?php _e('Reset Settings', 'genesism'); ?>" onclick="return confirm('<?php echo esc_js( __('Are you sure you want to reset?', 'genesism') ); ?>');" />
		</div>
	</form>
	</div>
	<script src="http://code.jquery.com/jquery-1.8.3.js"></script>
    <script src="http://code.jquery.com/ui/1.9.2/jquery-ui.js"></script>
    <script>
        $(function() {
            $('#tabs')
                .tabs()
                .addClass('ui-tabs-vertical ui-helper-clearfix');
        });
    </script>
	<script type="text/javascript">
		//<![CDATA[
		jQuery(document).ready( function($) {
			// close postboxes that should be closed
			$('.if-js-closed').removeClass('if-js-closed').addClass('closed');
			// postboxes setup
			postboxes.add_postbox_toggles('<?php echo $_genesism_theme_settings_pagehook; ?>');
		});
		//]]>
	</script>
	
	<script type="text/javascript">
		//<![CDATA[
		jQuery(document).ready( function($) {
			// close postboxes that should be closed
			$('.if-js-closed').removeClass('if-js-closed').addClass('closed');
			// postboxes setup
			postboxes.add_postbox_toggles('<?php echo $_genesism_theme_settings_pagehook; ?>');
		});
		//]]>
		
		jQuery(document).ready(function() {
jQuery('#cssmenu > ul > li:has(ul)').addClass("has-sub");
jQuery('#cssmenu > ul > li > a').click(function() 
{
	var checkElement = jQuery(this).next();
	jQuery('#cssmenu li').removeClass('active');
	jQuery(this).closest('li').addClass('active');
	if ((checkElement.is('ul')) && (checkElement.is(':visible'))) 
	{
		jQuery(this).closest('li').removeClass('active');checkElement.slideUp('normal');
		}
		if ((checkElement.is('ul')) && (!checkElement.is(':visible'))) 
		{
			jQuery('#cssmenu ul ul:visible').slideUp('normal');
			checkElement.slideDown('normal');
			}if (checkElement.is('ul')) 
			{
				return false;
				} 
				else 
				{
					return true;
					}
					});
	});
	
			jQuery(document).ready(function() {
jQuery('#cssmenu2 > ul > li:has(ul)').addClass("has-sub");
jQuery('#cssmenu2 > ul > li > a').click(function() 
{
	var checkElement = jQuery(this).next();
	jQuery('#cssmenu2 li').removeClass('active');
	jQuery(this).closest('li').addClass('active');
	if ((checkElement.is('ul')) && (checkElement.is(':visible'))) 
	{
		jQuery(this).closest('li').removeClass('active');checkElement.slideUp('normal');
		}
		if ((checkElement.is('ul')) && (!checkElement.is(':visible'))) 
		{
			jQuery('#cssmenu2 ul ul:visible').slideUp('normal');
			checkElement.slideDown('normal');
			}if (checkElement.is('ul')) 
			{
				return false;
				} 
				else 
				{
					return true;
					}
					});
	});
	</script>
<?php
}