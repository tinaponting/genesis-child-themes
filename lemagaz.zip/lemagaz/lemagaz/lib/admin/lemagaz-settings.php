<?php

/**
 * This function registers the default values for genesis theme settings
 */
 
function genesism_theme_settings_defaults() {
$defaults = array( // define our defaults
'style' => 'default',
'custom' => 0,
'shortcodes-css' => 1,

'first_post_num'=>5,
'second_post_num'=>5,
'fourth_post_num'=>4,
'fifth_post_num'=>4,

'header' => 1,
'top_menu' => 1,
'header_social' => 1,
'top_ad' => 1,
'search_box' => 1,
'bottom_menu' => 1,
'sidebar_optin' => 1,
'read_more' => 1,
'social_post_button' => 1,
'postadcheck' => 1,
'footer_logo' => 1,
'footer_about' => 1,
'footer_menu' => 1,
'landing_video' => 1,
'landing_optin' => 1,
'landing_feature' => 1,
'footer1' => 1,

'body_img' => 'http://lemagaz.genesislovers.com/wp-content/uploads/2016/08/backimg.jpg',
'header_text' => 'http://lemagaz.genesislovers.com/wp-content/uploads/2016/08/Untitled-1.png',
'top_ad_img' => '<img alt="Header Ad" src="http://lemagaz.genesislovers.com/wp-content/uploads/2016/08/topad.jpg"/>',
'search_text' => 'Search here...',
'optin_header' => 'Subscribe me',
'name_text' => 'Enter your name',
'email_text' => 'Enter your email',
'submit_text' => 'Subscribe me',
'read_text' => 'Read More',
'sharehead' => 'Share This :',
'postad' => '<img alt="Single Ad" src="http://lemagaz.genesislovers.com/wp-content/uploads/2016/08/singlead.jpg"/>',
'header_text1' => 'http://lemagaz.genesislovers.com/wp-content/uploads/2016/08/footerlogosec.png',
'about_title' => 'About Us',
'about_cnt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam ut ex eu ante lacinia egestas eu ac nisl. Vivamus porttitor sed orci ac condimentum.',
'landing_bg' => 'http://lemagaz.genesislovers.com/wp-content/uploads/2016/08/landingpagebg.jpeg',
'landing_video_title' => 'Landing Page Video Title',
'landing_subtitle' => 'All in One Landing Page that Converts',
'landing_vide_img' => '<iframe src="https://player.vimeo.com/video/179341398" width="640" height="360"   allowfullscreen></iframe>',
'landing_optin_header' => 'Lorem ipsum dolor sit amet',
'landing_optin_cnt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam ut ex eu ante lacinia egestas eu ac nisl.',
'name_text1' => 'Enter your Name',
'email_text1' => 'Enter your Email',
'submit_text1' => 'Subscribe me',
'landing_title' => 'Landing Page Feature ',
'landing_feature_cnt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam ut ex eu ante lacinia egestas eu ac nisl.',
'landing_feature_img1' => 'http://lemagaz.genesislovers.com/wp-content/uploads/2016/08/landingfeature2.jpg',
'landing_subtitle1' => 'Lorem ipsum dolor sit amet',
'landing_feature_cnt1' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam ut ex eu ante lacinia egestas eu ac nisl.',
'landing_feature_readmore1' => 'View More',
'landing_feature_img2' => 'http://lemagaz.genesislovers.com/wp-content/uploads/2016/08/landingfeature3.jpg',
'landing_subtitle2' => 'Lorem ipsum dolor sit amet',
'landing_feature_cnt2' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam ut ex eu ante lacinia egestas eu ac nisl.',
'landing_feature_readmore2' => 'View More',
'landing_feature_img3' => 'http://lemagaz.genesislovers.com/wp-content/uploads/2016/08/landingfeature4.jpg',
'landing_subtitle3' => 'Lorem ipsum dolor sit amet',
'landing_feature_cnt3' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam ut ex eu ante lacinia egestas eu ac nisl.',
'landing_feature_readmore3' => 'View More',


'f_img_width'=>'379',
'f_img_height'=>'246',


'footer_text' => 'Copyright &copy;'.date('Y') .  ' <a href="'. get_bloginfo('url') .'">' . get_bloginfo('name') . '</a>'
	
	);
	
	return apply_filters('genesism_theme_settings_defaults', $defaults);

}



function genesism_theme_settings_boxes() {
	global $_genesism_theme_settings_pagehook;
	
	if (function_exists('add_screen_option')) { add_screen_option('layout_columns', array('max' => 2, 'default' => 2) ); }

add_meta_box('genesism-theme-settings-version', __('Theme Information', 'genesism'), 'genesism_theme_settings_info_box', $_genesism_theme_settings_pagehook, 'normal');	
 }
  
 function genesism_theme_settings_info_box() { 
?>

<p class="bolder"><strong><?php echo CHILD_THEME_NAME; ?></strong> by <a href="http://genesislovers.com/">genesislovers.com</a></p>
<p><strong>
  <?php _e('Version:', 'genesism'); ?>
  </strong> <?php echo CHILD_THEME_VERSION; ?> <strong>
   </p>
<p><span class="description">
  <?php _e('For support, please visit <a href="http://genesislovers.com/contact-us/">http://genesislovers.com/contact-us/</a>', 'genesism'); ?>
  </span></p>

<div id="tabs">  
	<ul>
		<li><a href="#tabs-1"><?php _e("Background Image", 'genesism'); ?></a></li>
		<li><a href="#tabs-2"><?php _e("Header Logo", 'genesism'); ?></a></li>
		<li><a href="#tabs-3"><?php _e("Top Menu", 'genesism'); ?></a></li>
		<li><a href="#tabs-4"><?php _e("Header Social Follow", 'genesism'); ?></a></li>		
		<li><a href="#tabs-5"><?php _e("Header Advertisement", 'genesism'); ?></a></li>
		<li><a href="#tabs-6"><?php _e("Search Box", 'genesism'); ?></a></li>
		<li><a href="#tabs-7"><?php _e("Bottom Menu", 'genesism'); ?></a></li>
		
		<li><a href="#tabs-8"><?php _e("Sidebar Optin Section", 'genesism'); ?></a></li>
		
		<li><a href="#tabs-9"><?php _e("Blog Featured Image", 'genesism'); ?></a></li>
		<li><a href="#tabs-10"><?php _e("Blog Read More", 'genesism'); ?></a></li>		
		<li><a href="#tabs-11"><?php _e("Social Share", 'genesism'); ?></a></li>
		
		<li><a href="#tabs-12"><?php _e("Post Top Advertisement", 'genesism'); ?></a></li>
		<li><a href="#tabs-13"><?php _e("Footer Logo ", 'genesism'); ?></a></li>
		<li><a href="#tabs-14"><?php _e("Footer About US", 'genesism'); ?></a></li>
		<li><a href="#tabs-15"><?php _e("Footer Menu", 'genesism'); ?></a></li>
		<li><a href="#tabs-16"><?php _e("Landing Page Video", 'genesism'); ?></a></li>		
		<li><a href="#tabs-17"><?php _e("Landing Page Optin", 'genesism'); ?></a></li>
		<li><a href="#tabs-18"><?php _e("Landing Page Feature", 'genesism'); ?></a></li>		
		<li><a href="#tabs-19"><?php _e("Footer Text section", 'genesism'); ?></a></li>
		<li><a href="#tabs-20"><?php _e("Custom CSS section", 'genesism'); ?></a></li>
	</ul>
		
	<div id="tabs-1">
		<ul>
			<li class="second_list"><label>Change the Body Background Image URL Link:</label>
				<textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[body_img]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('body_img') ); ?></textarea>
			</li>
			
		</ul>
	</div>	
	
	<div id="tabs-2">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[header]" id="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[header]" value="1" <?php checked(1, genesism_get_option('header')); ?> />
				<label for="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[header]">
				<?php _e("Enable Header Logo", 'genesism'); ?>
				</label>
			</li>
			<li class="second_list">
				<label>Enter the Logo image url here</label>
				<textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[header_text]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('header_text') ); ?></textarea>
			</li>
		</ul>
	</div>	
	
	<div id="tabs-3">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[top_menu]" id="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[top_menu]" value="1" <?php checked(1, genesism_get_option('top_menu')); ?> />
				<label for="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[top_menu]">
				<?php _e("Enable Top Menu Section", 'genesism'); ?>
				</label>
			</li>
		</ul>
	</div>
	
	<div id="tabs-4">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[header_social]" id="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[header_social]" value="1" <?php checked(1, genesism_get_option(header_social)); ?> />
				<label for="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[header_social]">
				<?php _e("Enable Social follow", 'genesism'); ?>
				</label>
			</li>
			
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[fbcheck]" id="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[fbcheck]" value="1" <?php checked(1, genesism_get_option(fbcheck)); ?> />
				<label for="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[fbcheck]">
				<?php _e("Enable Facebook icon", 'genesism'); ?>
				</label>
			</li>
			<li class="second_list"><label>Paste Your Facebook URL Link</label>
				<textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[facebook_text2]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('facebook_text2') ); ?></textarea> 
			</li>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[gpcheck]" id="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[gpcheck]" value="1" <?php checked(1, genesism_get_option(gpcheck)); ?> />
				<label for="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[gpcheck]">
				<?php _e("Enable Googleplus icon", 'genesism'); ?>
				</label>
			</li>
			<li class="second_list"><label>Paste Your Googleplus URL Link</label>
				<textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[googleplus_text2]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('googleplus_text2') ); ?></textarea> 
			</li>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[tcheck]" id="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[tcheck]" value="1" <?php checked(1, genesism_get_option(tcheck)); ?> />
				<label for="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[tcheck]">
				<?php _e("Enable Twitter icon", 'genesism'); ?>
				</label>
			</li>
			<li class="second_list"><label>Paste Your Twitter URL Link</label>
				<textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[twitter_text2]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('twitter_text2') ); ?></textarea> 
			</li>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[pcheck]" id="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[pcheck]" value="1" <?php checked(1, genesism_get_option(pcheck)); ?> />
				<label for="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[pcheck]">
				<?php _e("Enable Pinterest icon", 'genesism'); ?>
				</label>
			</li>
			<li class="second_list"><label>Paste Your Pinterest URL Link</label>
				<textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[pinterest_text2]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('pinterest_text2') ); ?></textarea>
			</li>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[lncheck]" id="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[lncheck]" value="1" <?php checked(1, genesism_get_option(lncheck)); ?> />
				<label for="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[lncheck]">
				<?php _e("Enable Linkedin icon", 'genesism'); ?>
				</label>
			</li>
			<li class="second_list"><label>Paste Your Linkedin URL Link</label>
				<textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[linkedin_text2]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('linkedin_text2') ); ?></textarea> 
			</li>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[ytcheck]" id="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[ytcheck]" value="1" <?php checked(1, genesism_get_option(ytcheck)); ?> />
				<label for="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[ytcheck]">
				<?php _e("Enable Youtube icon", 'genesism'); ?>
				</label>
			</li>
			<li class="second_list"><label>Paste Your Youtube URL Link</label>
				<textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[youtube_text2]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('youtube_text2') ); ?></textarea>
			</li>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[vcheck]" id="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[vcheck]" value="1" <?php checked(1, genesism_get_option(vcheck)); ?> />
				<label for="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[vcheck]">
				<?php _e("Enable Vimeo icon", 'genesism'); ?>
				</label>
			</li>
			<li class="second_list"><label>Paste Your Vimeo URL Link</label>
				<textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[vimeo_text2]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('vimeo_text2') ); ?></textarea>
			</li>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[inscheck]" id="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[inscheck]" value="1" <?php checked(1, genesism_get_option(inscheck)); ?> />
				<label for="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[inscheck]">
				<?php _e("Enable Instagram icon", 'genesism'); ?>
				</label>
			</li>
			<li class="second_list"><label>Paste Your Instagram URL Link</label>
				<textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[instagram_text2]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('instagram_text2') ); ?></textarea>
			</li>
			
		</ul>			
	</div>
	
	<div id="tabs-5">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[top_ad]" id="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[top_ad]" value="1" <?php checked(1, genesism_get_option('top_ad')); ?> />
				<label for="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[top_ad]">
				<?php _e("Enable Header Advertisement", 'genesism'); ?>
				</label>
			</li>
				<li class="second_list">
				<label>Enter the Header Advertisement URL Link here</label>
				<textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[top_ad_img]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('top_ad_img') ); ?></textarea>
			</li>
		</ul>
	</div>
	
	<div id="tabs-6">
		 <ul>
			<li class="first_list chkbox">
			  <input type="checkbox" name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[search_box]" id="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[search_box]" value="1" <?php checked(1, genesism_get_option('search_box')); ?> />
			   <label for="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[search_box]">
			  <?php _e("Enable Search Box", 'genesism'); ?>
			 </label>
			</li>
			 <li class="second_list">
			  <label>Enter the Search Place holder Text here</label>
			  <textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[search_text]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('search_text') ); ?></textarea>
			</li>
		</ul>
	</div>
	
	<div id="tabs-7">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[bottom_menu]" id="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[bottom_menu]" value="1" <?php checked(1, genesism_get_option('bottom_menu')); ?> />
				<label for="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[bottom_menu]">
				<?php _e("Enable Bottom Menu Section", 'genesism'); ?>
				</label>
			</li>
		</ul>
	</div>
	
	
	<div id="tabs-8">
		 <ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[sidebar_optin]" id="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[sidebar_optin]" value="1" <?php checked(1, genesism_get_option('sidebar_optin')); ?> />
				<label for="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[sidebar_optin]">
				<?php _e("Enable Sidebar Optin Box", 'genesism'); ?>
				</label>
			</li>
			<li class="second_list">
				<label>Paste your optin code and Press Tab Button</label>
				<textarea id="optin_code" name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[optin_code]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_code') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form name</label>
				<textarea id="optin_name" name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[optin_name]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('optin_name') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form Email</label>
				<textarea id="optin_email" name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[optin_email]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('optin_email') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form action url</label>
				<textarea id="optin_url" name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[optin_url]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_url') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Hidden fields</label>
				<textarea id="optin_hidden" name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[optin_hidden]" rows="10" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_hidden') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Enter your Optin Header Text</label>
				<textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[optin_header]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('optin_header') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change your Enter your name text here</label>
				<textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[name_text]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('name_text') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change your Enter your email text here</label>
				<textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[email_text]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('email_text') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change your Subscribe me button text</label>
				<textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[submit_text]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('submit_text') ); ?></textarea>
			</li>
		  </ul>
		  
<script type="text/javascript">
var j = jQuery.noConflict();
j(document).ready(function(){
j("#optin_code").blur(function(){
var txt=j(this).val();
if(txt=="")
{
j("#optin_url").val("");
j("#optin_hidden").val("");
j("#optin_name").val("");
j("#optin_email").val("");
return false;
}
var pos1=0;
var pos2=0;
var i=1;
var hidden="";
while(1)
{
pos1=txt.indexOf("<input",pos1);
if(pos1<0) break;
pos2=txt.indexOf(">",pos1+1);
var text=txt.substr(pos1,pos2-pos1);
pp=text.indexOf('type="hidden"');
pp1=text.indexOf('type="submit"');
if(pp>0)
{
hidden+=text+">";
}
if(pp<0 && pp1<0){
pp=text.indexOf('name="');
pp=pp+6;
pp1=text.indexOf('"',pp+1);
var tt=text.substr(pp,pp1-pp);
if(i==1) j("#optin_name").val(tt);
else j("#optin_email").val(tt);
i++;
}
pos1=pos2+1;
}
pos1=txt.indexOf("<form",0);
pos2=txt.indexOf(">",pos1+1);
text=txt.substr(pos1,pos2-pos1);
pp=text.indexOf('action="');
pp=pp+8;
pp1=text.indexOf('"',pp+1);
var tt=text.substr(pp,pp1-pp);
j("#optin_url").val(tt);
j("#optin_hidden").val(hidden);
});
});
</script>		  
	</div>
	
		
	<div id="tabs-9">
		<ul>
			<li class="second_list"><label>Width of the Featured Image</label>
				<textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[f_img_width]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('f_img_width') ); ?></textarea> 
			</li>
			<li class="second_list"><label>Height of the Featured Image</label>
				<textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[f_img_height]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('f_img_height') ); ?></textarea> 
			</li>
		</ul>
	</div>
	
	<div id="tabs-10">
		<ul>
			<li class="first_list chkbox">
			  <input type="checkbox" name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[read_more]" id="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[read_more]" value="1" <?php checked(1, genesism_get_option('read_more')); ?> />
			   <label for="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[read_more]">
			  <?php _e("Enable Blog Read More Box", 'genesism'); ?>
			 </label>
			</li>
			 <li class="second_list">
			  <label>Change Your Read More Text here</label>
			  <textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[read_text]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('read_text') ); ?></textarea>
			</li>
		</ul>
	</div>
	
	
	
	<div id="tabs-11">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[social_post_button]" id="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[social_post_button]" value="1" <?php checked(1, genesism_get_option('social_post_button')); ?> />
				<label for="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[social_post_button]">
				<?php _e("Enable post social share section", 'genesism'); ?>
				</label>
			</li>
			<li class="second_list">
				<label>Enter the Social Share Title here</label>
				<textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[sharehead]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('sharehead') ); ?></textarea>
			</li>
		</ul>
	</div>
	
		
	<div id="tabs-12">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[postadcheck]" id="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[postadcheck]" value="1" <?php checked(1, genesism_get_option('postadcheck')); ?> />
				<label for="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[postadcheck]">
				<?php _e("Enable Post Advertisement Section", 'genesism'); ?>
				</label>
			</li>
			<li class="second_list">
				<label>Enter the Advertisement Image URL Link</label>
				<textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[postad]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('postad') ); ?></textarea>
			</li>
		</ul>
	</div>
	
	<div id="tabs-13">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[footer_logo]" id="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[footer_logo]" value="1" <?php checked(1, genesism_get_option('footer_logo')); ?> />
				<label for="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[footer_logo]">
				<?php _e("Enable Footer Logo", 'genesism'); ?>
				</label>
			</li>
			<li class="second_list">
				<label>Paste the Footer Logo image url here</label>
				<textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[header_text1]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('header_text1') ); ?></textarea>
			</li>
			
		</ul>
	</div>	
	
	<div id="tabs-14">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[footer_about]" id="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[footer_about]" value="1" <?php checked(1, genesism_get_option('footer_about')); ?> />
				<label for="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[footer_about]">
				<?php _e("Enable Footer About Us", 'genesism'); ?>
				</label>
			</li>
			
			<li class="second_list">
				<label>Enter the Footer About Us Title here</label>
				<textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[about_title]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('about_title') ); ?></textarea>
			</li>
						
			<li class="second_list">
				<label>Enter the Footer About Us Content here</label>
				<textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[about_cnt]" rows="4" cols="70"><?php echo htmlspecialchars( genesism_get_option('about_cnt') ); ?></textarea>
			</li>
		</ul>
	</div>	
	
	<div id="tabs-15">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[footer_menu]" id="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[footer_menu]" value="1" <?php checked(1, genesism_get_option('footer_menu')); ?> />
				<label for="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[footer_menu]">
				<?php _e("Enable Footer Menu Section", 'genesism'); ?>
				</label>
			</li>
		</ul>
	</div>
	
	<div id="tabs-16">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[landing_video]" id="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[landing_video]" value="1" <?php checked(1, genesism_get_option('landing_video')); ?> />
				<label for="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[landing_video]">
				<?php _e("Enable Landing Page Video", 'genesism'); ?>
				</label>
			</li>
						
			<li class="second_list">
				<label>Paste the Landing Page Background Image URL Link here</label>
				<textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[landing_bg]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_bg') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Paste the Landing Page Video Title here</label>
				<textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[landing_video_title]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_video_title') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Paste the Landing Page Video Content here</label>
				<textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[landing_subtitle]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_subtitle') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Paste the Landing Page Video Image URL Link here</label>
				<textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[landing_vide_img]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_vide_img') ); ?></textarea>
			</li>
			
		</ul>
	</div>	
	
		
	<div id="tabs-17">
		<ul>
			<li class="first_list chkbox">
			  <input type="checkbox" name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[landing_optin]" id="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[landing_optin]" value="1" <?php checked(1, genesism_get_option('landing_optin')); ?> />
			   <label for="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[landing_optin]">
			  <?php _e("Enable Landing Page Optin Box", 'genesism'); ?>
			 </label>
			</li>
			<li class="second_list">
				<label>Paste your optin code and Press Tab Button</label>
				<textarea id="optin_code1" name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[optin_code1]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_code1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form name</label>
				<textarea id="optin_name1" name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[optin_name1]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('optin_name1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form Email</label>
				<textarea id="optin_email1" name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[optin_email1]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('optin_email1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form action url</label>
				<textarea id="optin_url1" name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[optin_url1]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_url1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Hidden fields</label>
				<textarea id="optin_hidden1" name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[optin_hidden1]" rows="10" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_hidden1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Enter your Optin Header Text</label>
				<textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[landing_optin_header]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('landing_optin_header') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Enter your Optin Header Text</label>
				<textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[landing_optin_cnt]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_optin_cnt') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change your Enter your Name Place holder text here</label>
				<textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[name_text1]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('name_text1') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Change your Enter your Email Place holder text here</label>
				<textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[email_text1]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('email_text1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change your Subscribe me button text</label>
				<textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[submit_text1]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('submit_text1') ); ?></textarea>
			</li>
			
		</ul>
<script type="text/javascript">
var j = jQuery.noConflict();
j(document).ready(function(){
j("#optin_code1").blur(function(){
var txt=j(this).val();
if(txt=="")
{
j("#optin_url1").val("");
j("#optin_hidden1").val("");
j("#optin_name1").val("");
j("#optin_email1").val("");
return false;
}
var pos1=0;
var pos2=0;
var i=1;
var hidden="";
while(1)
{
pos1=txt.indexOf("<input",pos1);
if(pos1<0) break;
pos2=txt.indexOf(">",pos1+1);
var text=txt.substr(pos1,pos2-pos1);
pp=text.indexOf('type="hidden"');
pp1=text.indexOf('type="submit"');
if(pp>0)
{
hidden+=text+">";
}
if(pp<0 && pp1<0){
pp=text.indexOf('name="');
pp=pp+6;
pp1=text.indexOf('"',pp+1);
var tt=text.substr(pp,pp1-pp);
if(i==1) j("#optin_name1").val(tt);
else j("#optin_email1").val(tt);
i++;
}
pos1=pos2+1;
}
pos1=txt.indexOf("<form",0);
pos2=txt.indexOf(">",pos1+1);
text=txt.substr(pos1,pos2-pos1);
pp=text.indexOf('action="');
pp=pp+8;
pp1=text.indexOf('"',pp+1);
var tt=text.substr(pp,pp1-pp);
j("#optin_url1").val(tt);
j("#optin_hidden1").val(hidden);
});
});
</script> 		
	</div>
	
	<div id="tabs-18">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[landing_feature]" id="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[landing_feature]" value="1" <?php checked(1, genesism_get_option('landing_feature')); ?> />
				<label for="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[landing_feature]">
				<?php _e("Enable Landing Page Feature Section", 'genesism'); ?>
				</label>
			</li>
			<li class="second_list">
				<label>Change the Landing Page Feature Title text here</label>
				<textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[landing_title]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('landing_title') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Page Feature Content here</label>
				<textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[landing_feature_cnt]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_cnt') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Paste the Landing Page Feature Image1 URL Link here</label>
				<textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[landing_feature_img1]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_img1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Page Feature Subtitle1 here</label>
				<textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[landing_subtitle1]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('landing_subtitle1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Page Feature Content1 here</label>
				<textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[landing_feature_cnt1]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_cnt1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Page Feature Read More Text1 here</label>
				<textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[landing_feature_readmore1]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('landing_feature_readmore1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Paste the Landing Page Feature Read More Text1 URL Link here</label>
				<textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[landing_feature_readmore_link1]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_readmore_link1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Paste the Landing Page Feature Image2 URL Link here</label>
				<textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[landing_feature_img2]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_img2') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Page Feature Subtitle2 here</label>
				<textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[landing_subtitle2]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('landing_subtitle2') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Page Feature Content2 here</label>
				<textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[landing_feature_cnt2]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_cnt2') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Page Feature Read More Text2 here</label>
				<textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[landing_feature_readmore2]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('landing_feature_readmore2') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Paste the Landing Page Feature Read More Text2 URL Link here</label>
				<textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[landing_feature_readmore_link2]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_readmore_link2') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Paste the Landing Page Feature Image3 URL Link here</label>
				<textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[landing_feature_img3]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_img3') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Page Feature Subtitle3 here</label>
				<textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[landing_subtitle3]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('landing_subtitle3') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Page Feature Content3 here</label>
				<textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[landing_feature_cnt3]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_cnt3') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Page Feature Read More Text3 here</label>
				<textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[landing_feature_readmore3]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('landing_feature_readmore3') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Paste the Landing Page Feature Read More Text3 URL Link here</label>
				<textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[landing_feature_readmore_link3]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_readmore_link3') ); ?></textarea>
			</li>
		</ul>
	</div>
	
		
	<div id="tabs-19">
		 <ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[footer1]" id="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[footer1]" value="1" <?php checked(1, genesism_get_option('footer1')); ?> />
				<label for="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[footer1]">
				<?php _e("Enable Footer text", 'genesism'); ?>
				</label>
			</li>
			<li class="second_list"><label>Use custom footer text?</label>
				<textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[footer_text]" rows="5" cols="50"><?php echo htmlspecialchars( genesism_get_option('footer_text') ); ?></textarea> 
			</li>
		</ul>
	</div>
	
	<div id="tabs-20">
		 <ul>
			
			<li class="second_list"><label>Use Custom CSS</label>
				<textarea name="<?php echo LEMAGAZ_SETTINGS_FIELD; ?>[custom_css]" rows="30" cols="70"><?php echo htmlspecialchars( genesism_get_option('custom_css') ); ?></textarea> 
			</li>
		</ul>
	</div>
	
</div>

 
 
<?php
}
 
 
 