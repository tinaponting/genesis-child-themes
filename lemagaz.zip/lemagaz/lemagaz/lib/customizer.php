<?php

function lemagaz_customize_register( $wp_customize ) {
 /*******************************************
Color scheme
********************************************/
 
// add the section to contain the settings
$wp_customize->add_section( 'textcolors' , array(
    'title' =>  'Color Scheme',
) );

 
// Body Text Color
$txtcolors[] = array(
    'slug'=>'body_txt_color', 
    'default' => '#888',
    'label' => 'Body Text Color'
);


// Top Header Background Color
$txtcolors[] = array(
    'slug'=>'top_header_bg', 
    'default' => '#111',
    'label' => 'Top Header Background Color'
);


// Bottom Header Background Color
$txtcolors[] = array(
    'slug'=>'bottom_header_bg', 
    'default' => '#111',
    'label' => 'Bottom Header Background Color'
);

// Content Background Color
$txtcolors[] = array(
    'slug'=>'content_bg', 
    'default' => '#F1F2F6',
    'label' => 'Content Background Color'
);


// Title Text Color

$txtcolors[] = array(
    'slug'=>'title_txt_color', 
    'default' => '#191b28',
    'label' => 'Title Text Color'
);


// Title Text Hover Color
$txtcolors[] = array(
    'slug'=>'title_hover_color', 
    'default' => '#fd5a53',
    'label' => 'Title Text Hover Color '
);


// Title Background Color
$txtcolors[] = array(
    'slug'=>'title_bg_color', 
    'default' => '#1b1b1b',
    'label' => 'Title Background Color '
);

// Border color1 
$txtcolors[] = array(
    'slug'=>'border_color', 
    'default' => '#eee',
    'label' => 'Border Color1'
);

// Border color2 
$txtcolors[] = array(
    'slug'=>'border_color2', 
    'default' => '#dddddd',
    'label' => 'Border Color2'
);


// Avatar Image Background color 
$txtcolors[] = array(
    'slug'=>'avatar_clr', 
    'default' => '#f1f1f1',
    'label' => 'Avatar Image Background color'
);


//Top Footer Background color 
$txtcolors[] = array(
    'slug'=>'footer_bg', 
    'default' => '#464646',
    'label' => 'Top Footer Background color'
);

//Bottom Footer Background color 
$txtcolors[] = array(
    'slug'=>'btm_footer_bg', 
    'default' => '#e6e6e6',
    'label' => 'Bottom Footer Background color'
);

//Footer Text color 
$txtcolors[] = array(
    'slug'=>'footer_text_clr', 
    'default' => '#666',
    'label' => 'Footer Text color'
);

//Footer Border color 
$txtcolors[] = array(
    'slug'=>'footer_border_color', 
    'default' => '#666',
    'label' => 'Footer Border color'
);

//Landing Page Optin Background color
$txtcolors[] = array(
    'slug'=>'landing_page_optin_bg', 
    'default' => '#1b1349',
    'label' => 'Landing Page Optin Background color'
);

//Landing Page Feature Background color
$txtcolors[] = array(
    'slug'=>'landing_feature_clr', 
    'default' => '#f7f8f9',
    'label' => 'Landing Page Feature Background color'
);

// add the settings and controls for each color
foreach( $txtcolors as $txtcolor ) {
 
    // SETTINGS
    $wp_customize->add_setting(
        $txtcolor['slug'], array(
            'default' => $txtcolor['default'],
            'type' => 'option', 
            'capability' => 
            'edit_theme_options'
        )
    );
    // CONTROLS
    $wp_customize->add_control(
        new WP_Customize_Color_Control(
            $wp_customize,
            $txtcolor['slug'], 
            array('label' => $txtcolor['label'], 
            'section' => 'textcolors',
            'settings' => $txtcolor['slug'])
        )
    );
}
}
add_action( 'customize_register', 'lemagaz_customize_register' );