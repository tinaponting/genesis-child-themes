<?php

// Define Constants
define('CHILD_THEME_NAME', 'Lemagaz Genesis Child Theme');
define('CHILD_THEME_VERSION', '2.0');
define('CHILD_THEME_RELEASE_DATE', date_i18n('F j, Y', '1316412000'));
define('CHILD_THEME_CSS_DEPENDENCY', 'Lemagaz Genesis Child Theme');

define('PARENT_DIR', TEMPLATEPATH);
define('CHILD_DIR', STYLESHEETPATH);

define('CHILD_THEME_LIB_DIR', CHILD_DIR.'/lib');
define('CHILD_THEME_LIB_URL', CHILD_URL.'/lib');

define('STYLES_URL', CHILD_URL.'/styles');

// Options
define('genesism_SETTINGS_FIELD', apply_filters('genesism_settings_field', 'genesism-settings'));

// Add Options
require_once(CHILD_THEME_LIB_DIR.'/functions/genesism-options.php');

// Add Settings pages
require_once(CHILD_THEME_LIB_DIR.'/admin/genesism-settings.php'); // genesism
require_once(CHILD_THEME_LIB_DIR.'/admin/lemagaz-settings.php'); // Child Theme

// Localization
load_theme_textdomain( 'genesism', CHILD_THEME_LIB_DIR . '/languages');