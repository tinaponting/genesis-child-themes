<div class="footer-widgets">
	<div class="wrap">
    	<div class="footer_widgets_1 footer_widget">
			
			<div class="footer_logo">
				<?php
				if (genesism_get_option('footer_logo')){?>
					<a title="<?php bloginfo('name'); ?>" href="<?php bloginfo('wpurl'); ?>"><img src="<?php echo genesism_option('header_text1'); ?>" alt="<?php bloginfo('name'); ?>"/></a>
				<?php
				}
				else { ?>
					<h1 itemprop="headline"><a title="<?php bloginfo('name'); ?>" href="<?php bloginfo('wpurl'); ?>"><?php bloginfo('name');?> </a></h1>
					<p><?php bloginfo('description'); ?></p>
				<?php } ?>
			</div>
			<?php
			if (genesism_get_option('footer_about')){
			?>
			<div class="footer_aboutus_cnt">
				<h3 class="widgettitle"><?php echo genesism_option('about_title'); ?></h3>
				<p><?php  echo stripslashes((genesism_get_option('about_cnt')));?></p>
			</div>
			<?php
			}
			?>
		</div>

   		<!-- end .footer-Widget1 -->
    
		<div class="footer_widgets_2 footer_widget">
			<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer Widget1') ) : ?>
    			<div class="widget">
            		<h4 itemprop="headline"><?php _e("Footer #Widget1", 'genesis'); ?></h4>
            		<p><?php _e("This is an example of a widget area that you can place text to describe a product or service. You can also use other WordPress widgets such as recent posts, recent comments, a tag cloud or more.", 'genesis'); ?></p>
	    		</div><!-- end .widget -->
	    	<?php endif; ?> 		
    	</div><!-- end .footer-right -->
	
    	<!-- end .footer-middle -->
    	<div class="footer_widgets_3 footer_widget">
			<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer Widget2') ) : ?>
    			<div class="widget">
            		<h4 itemprop="headline"><?php _e("Footer #Widget2", 'genesis'); ?></h4>
            		<p><?php _e("This is an example of a widget area that you can place text to describe a product or service. You can also use other WordPress widgets such as recent posts, recent comments, a tag cloud or more.", 'genesis'); ?></p>
	    		</div><!-- end .widget -->
			<?php endif; ?> 
        		
    	</div><!-- end .footer-right -->
		<div class="footer_widgets_4 footer_widget">
        	<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer Widget3') ) : ?>
    			<div class="widget">
            		<h4 itemprop="headline"><?php _e("Footer #Widget3", 'genesis'); ?></h4>
            		<p><?php _e("This is an example of a widget area that you can place text to describe a product or service. You can also use other WordPress widgets such as recent posts, recent comments, a tag cloud or more.", 'genesis'); ?></p>
	    		</div><!-- end .widget -->
			<?php endif; ?> 	
    	</div><!-- end .footer-right -->
		
		
    	</div><!-- end .wrap -->
</div><!-- end #footer-widgets -->