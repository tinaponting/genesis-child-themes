<?php
require_once(TEMPLATEPATH.'/lib/init.php'); // Start Genesis Engine
require_once(STYLESHEETPATH.'/lib/init.php'); // Start blog Options
require_once(STYLESHEETPATH.'/lib/updates.php'); // updates


include_once( 'lib/customizer.php' );

//* Add HTML5 markup structure
add_theme_support( 'html5' );


/** Support for various Image sizes */
add_theme_support('post-thumbnails');
//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Add support for custom background
add_theme_support( 'custom-background' );

//* Remove for custom background
 remove_custom_background(); 
 
// Add widgeted footer section
add_action('genesis_before_footer', 'footer_bottom_widgets'); 
function footer_bottom_widgets() {
    require(CHILD_DIR.'/footer-widgeted.php');
}

add_filter( 'genesis_term_meta_headline', 'be_default_category_title', 10, 2 );
function be_default_category_title( $headline, $term ) {
	if( ( is_category() || is_tag() || is_tax() ) && empty( $headline ) )
		$headline = $term->name;
		
	return $headline;
}

/** Register widget areas */

genesis_register_sidebar( array(
	'id'			=> 'front_page_top_widget',
	'name'			=> __( 'Front Page Top Widget', 'Lemagaz Genesis Theme' ),
	'description'	=> __( 'This is the front page top widget if you are using a two or three column site layout option.', 'Lemagaz Genesis Theme' ),
	
) );

genesis_register_sidebar( array(
	'id'			=> 'front_page_content_widget',
	'name'			=> __( 'Front Page Content Widget', 'Lemagaz Genesis Theme' ),
	'description'	=> __( 'This is the front page Content widget if you are using a two or three column site layout option.', 'Lemagaz Genesis Theme' ),
	
) );

genesis_register_sidebar( array(
	'id'			=> 'front_page_bottom_widget',
	'name'			=> __( 'Front Page Bottom Widget', 'Lemagaz Genesis Theme' ),
	'description'	=> __( 'This is the front page bottom widget if you are using a two or three column site layout option.', 'Lemagaz Genesis Theme' ),
	
) );

genesis_register_sidebar( array(
	'id'			=> 'single_post_related',
	'name'			=> __( 'Single Page Related Post Widget', 'Lemagaz Genesis Theme' ),
	'description'	=> __( 'This is the Single Page Related Post widget if you are using a two or three column site layout option.', 'Lemagaz Genesis Theme' ),
	
) );

genesis_register_sidebar( array(
	'id'			=> 'sidebar',
	'name'			=> __( 'Primary Sidebar', 'Lemagaz Genesis Child Theme' ),
	'description'	=> __( 'This is the primary sidebar if you are using a two or three column site layout option.', 'Lemagaz Genesis Child Theme' ),
	'before_title' => '<div class="sidebar_title"><h3>',
	'after_title' => '</h3></div>',
	
) );


genesis_register_sidebar( array(
	'id'			=> 'sidebar-alt',
	'name'			=> __( 'Secondary Sidebar ', 'Lemagaz Genesis Child Theme' ),
	'description'	=> __( 'This is the secondary sidebar if you are using a three column site layout option.', 'Lemagaz Genesis Child Theme' ),
	'before_title' => '<div class="sidebar_title"><h3>',
	'after_title' => '</h3></div>',
	
) );

genesis_register_sidebar( array(
	'id'			=> 'footer_widget1',
	'name'			=> __( 'Footer Widget1', 'Lemagaz Genesis Child Theme' ),
	'description'	=> __( 'This is the footer Widget1 section.', 'Lemagaz Genesis Child Theme' ),
) );

genesis_register_sidebar( array(
	'id'			=> 'footer_widget2',
	'name'			=> __( 'Footer Widget2', 'Lemagaz Genesis Child Theme' ),
	'description'	=> __( 'This is the footer widget2 section.', 'Lemagaz Genesis Child Theme' ),
) );

genesis_register_sidebar( array(
	'id'			=> 'footer_widget3',
	'name'			=> __( 'Footer Widget3', 'Lemagaz Genesis Child Theme' ),
	'description'	=> __( 'This is the footer widget3 section.', 'Lemagaz Genesis Child Theme' ),
) );



//Remove Post  entry footer  Meta data 
remove_action( 'genesis_entry_footer', 'genesis_post_meta' );
//remove archive description
remove_action( 'genesis_before_content', 'genesis_do_taxonomy_title_description', 15 );


//placeholder for comment box in single page
add_filter('comment_form_default_fields','comment_form_placeholder');
function comment_form_placeholder($fields){ 
	$fields['author'] = '<p class="comment-form-author">' . '<label for="author">' . __( '', 'genesis' ) . '</label> ' . 	
	( $req ? '<span class="required">*</span>' : '' ) .                   
	'<input id="author" name="author" type="text" placeholder="Name *" value="' . 				
	esc_attr( $commenter['comment_author'] ) . '" size="30"' . $aria_req . ' /></p>';				
    $fields['email'] = '<p class="comment-form-email"><label for="email">' . __( '', 'genesis' ) . '</label> ' .
	( $req ? '<span class="required">*</span>' : '' ) .
	'<input id="email" name="email" type="text" placeholder="Email *" value="' . 	
	esc_attr(  $commenter['comment_author_email'] ) . '" size="30"' . $aria_req . ' /></p>';	
	$fields['url'] = '<p class="comment-form-url"><label for="url">' . __( '', 'genesis' ) . '</label>' .    
	'<input id="url" name="url" type="text" placeholder="URL *" value="' . 	
	esc_attr( $commenter['comment_author_url'] ) . '" size="30" /></p>';	
    return $fields;
}

function string_limit_words($string, $word_limit)
{
  $words = explode(' ', $string, ($word_limit + 1));
  if(count($words) > $word_limit)
  array_pop($words);
  return implode(' ', $words);
}
 
// Customizes Footer Text (set in options) 
if (genesism_get_option('footer1')) { 
	add_filter('genesis_footer_creds_text', 'custom_footer_creds_text');
	function custom_footer_creds_text($creds) {
    	$creds = genesism_get_option('footer_text');
    return $creds;
	}
}



add_filter( 'genesis_before_header', 'search_box',2 );
function search_box( $text ) {
	return esc_attr( 'Go' );
}
remove_action( 'genesis_site_title', 'genesis_seo_site_title' );
remove_action( 'genesis_site_description', 'genesis_seo_site_description' );
/* BEGIN Custom User Contact Info */
function extra_contact_info($contactmethods) {

$contactmethods['facebook'] = 'Facebook';
$contactmethods['twitter'] = 'Twitter';

return $contactmethods;
}
add_filter('user_contactmethods', 'extra_contact_info');


//* Modify the length of post excerpts
add_filter( 'excerpt_length', 'sp_excerpt_length' );
function sp_excerpt_length( $length ) {
	return 30; // pull first 50 words
}

add_action( 'genesis_before_comments', 'themeprefix_alt_author_box',3 );
function themeprefix_alt_author_box() {
if( is_single() ) {
 
echo "<div class=\"about-author single_page_cnt\">";?>
	<div class='single_page_title'>
	<h3>About Author</h3>
	</div>
	<?php 
echo "<div class=\"author-info\" itemscope=\"itemscope\" itemtype=\"http://schema.org/person\" itemprop=\"Authorpost\" >" . get_avatar( get_the_author_meta( 'ID' ), '100' ) . "</div>
  <div class='author_right_cnt'>
  <div class='author_name_social'>";?>
<p class="author_name"><?php the_author_posts_link(); ?></p> 
 <?php echo "<div class=\"author_social\">";

 if ( get_the_author_meta( 'facebook' ) != '' ) {
 echo "<a title='Facebook' class=\"afb fa\" href=\"https://www.facebook.com/". get_the_author_meta( 'facebook' ) . "\"><i class='fa icon-facebook'></i></a>";
 }
 if ( get_the_author_meta( 'googleplus' ) != '' ) {
 echo "<a title='Googleplus' class=\"agp fa\" href=\"https://plus.google.com/". get_the_author_meta( 'googleplus' ) . "\"><i class='fa icon-google'></i></a>";
 }
 if ( get_the_author_meta( 'twitter' ) != '' ) {
 echo "<a title='Twitter' class=\"atw fa\" href=\"https://twitter.com/". get_the_author_meta( 'twitter' ) . "\"><i class='fa icon-twitter'></i></a>";
 }
 
echo "</div></div>".
  "<div class='author_description'><p itemprop=\"description\">" . get_the_author_meta( 'description' ) . 
 "</p></div>";

 
echo "</div></div>";
 }
}


//* Remove the entry meta in the entry header 
 

 add_filter( 'genesis_post_info', 'sp_post_info_filter' );
function sp_post_info_filter($post_info) {
if ( is_single() ) {
	$post_info = '[post_date] by [post_author_posts_link] [post_comments]';
	return $post_info;
}}

// Register Genesis Menus
add_action( 'init', 'register_additional_menu' );
function register_additional_menu() {
  
register_nav_menu( 'FirstMenu' ,__( 'Top Menu' ));
register_nav_menu( 'Secondmenu' ,__( 'Bottom Menu' ));
register_nav_menu( 'Thirdmenu' ,__( 'Footer Menu' ));
     
}  
 

add_action('genesis_before_header','before_header');	
function before_header() { ?>
<div class="headermain" itemscope="itemscope" itemtype="http://schema.org/WPHeader">
<?php
}

/** Remove Header */
remove_action( 'genesis_header', 'genesis_header_markup_open', 5 );
remove_action( 'genesis_header', 'genesis_do_header' );
remove_action( 'genesis_header', 'genesis_header_markup_close', 15 );

/** Add custom header support */

add_action('genesis_header','injectHeader');
		  
function injectHeader(){ 
?>
<div class="top_header">
	<div class="top_inner_header wrap ">
		<div class="top_left_header">
			<?php if (genesism_get_option('top_menu')){
			?>
			<div class="top_menu">
				<span class="menu_control">≡ Menu</span>
				<?php wp_nav_menu( array( 'theme_location' => 'FirstMenu','container' => false,'menu_id' => 'menu_top_menu' ) );?>
			</div>
			<?php 
			}
			?>
			
		</div>
		
		<div class="top_right_header">
			<?php if (genesism_get_option('header_social')){
			?>
			<ul class="header_social">
				<?php if (genesism_get_option('fbcheck')){
				?>
				<li class="social_icons">
					<a class="facebook" title="Facebook" href="<?php echo genesism_option('facebook_text2'); ?>" target="_blank">
					<i class="fa icon-facebook"></i>
					</a>
				</li>
				<?php
				}
				?>
				<?php if (genesism_get_option('gpcheck')){
				?>
				<li class="social_icons">
					<a class="googleplus" title="google plus" href="<?php echo genesism_option('googleplus_text2'); ?>" target="_blank">
					<i class="fa icon-google"></i>
					</a>
				</li>
				<?php
				}
				?>
				<?php if (genesism_get_option('tcheck')){
				?>
				<li class="social_icons">
					<a class="twitter" title="Twitter" href="<?php echo genesism_option('twitter_text2'); ?>" target="_blank">
					<i class="fa icon-twitter"></i>
					</a>
				</li>
				<?php
				}
				?>
				<?php if (genesism_get_option('pcheck')){
				?>
				<li class="social_icons">
					<a class="pinterest" title="pinterest" href="<?php echo genesism_option('pinterest_text2'); ?>" target="_blank">
					<i class="fa icon-pinterest"></i>
					</a>
				</li>
				<?php
				}
				?>
				<?php if (genesism_get_option('lncheck')){
				?>
				<li class="social_icons">
					<a class="linkedin" title="linkedin" href="<?php echo genesism_option('linkedin_text2'); ?>" target="_blank">
					<i class="fa icon-linkedin"></i>
					</a>
				</li>
				<?php
				}
				?>
				<?php if (genesism_get_option('ytcheck')){
				?>
				<li class="social_icons">
					<a class="youtube" title="youtube" href="<?php echo genesism_option('youtube_text2'); ?>" target="_blank">
					<i class="fa icon-youtube"></i>
					</a>
				</li>
				<?php
				}
				?>
				<?php if (genesism_get_option('vcheck')){
				?>
				<li class="social_icons">
					<a class="viemo" title="Viemo" href="<?php echo genesism_option('vimeo_text2'); ?>" target="_blank">
					<i class="fa icon-vimeo-square"></i>
					</a>
				</li>
				<?php
				}
				?>
				<?php if (genesism_get_option('inscheck')){
				?>
				<li class="social_icons">
					<a class="instagram" title="Instagram" href="<?php echo genesism_option('instagram_text2'); ?>" target="_blank">
					<i class="fa icon-instagram"></i>
					</a>
				</li>
				<?php
				}
				?>
			</ul>
			<?php 
			}
			?>
		</div>
	</div>
</div>

<div class="center_header">
	<div class="center_inner_header wrap">
		<div class="center_left_header">
			<div class="logo_section">
				<?php
				if (genesism_get_option('header')){?>
					<a title="<?php bloginfo('name'); ?>" href="<?php bloginfo('wpurl'); ?>"><img src="<?php echo genesism_option('header_text'); ?>" alt="<?php bloginfo('name'); ?>"/></a>
				<?php
				}
				else { ?>
					<h1 itemprop="headline"><a title="<?php bloginfo('name'); ?>" href="<?php bloginfo('wpurl'); ?>"><?php bloginfo('name');?> </a></h1>
					<p><?php bloginfo('description'); ?></p>
				<?php } ?>
			</div>	
			
			
		</div>
		<div class="center_right_header">
		<?php 
		if (genesism_get_option('top_ad')){
		?>
			<?php  echo stripslashes((genesism_get_option('top_ad_img')));?>
		<?php 
		}
		?>	
		</div>
	</div>
</div>
<div class="bottom_header">
	<div class="bottom_inner_header wrap">
		<?php 
		if (genesism_get_option('bottom_menu')){
		?>
		<div class="bottom_menu">
			<span class="menu_control">≡ Menu</span>
			<?php wp_nav_menu( array( 'theme_location' => 'Secondmenu','container' => false,'menu_class' => 'menu2','menu_id' => 'menu_bottom_menu' ) );?>
		</div>
		<?php 
		}
		?>
		
			
			
		<div class="search_box_section">
			<?php if (genesism_get_option('search_box')){
			?>
				<div class='widget_search'>
					<form method='get' action='<?php echo get_bloginfo('home'); ?>'>
						<input class="search_text" type='text' placeholder='<?php echo genesism_option('search_text'); ?>' name='s' id='s' />			
						<button type='submit' class='btn btn-success'>
						<i class='fa icon-search'></i>
						</button>
					</form>
				</div>
			<?php 
			}
			?>
		</div>	
			
	</div>
</div>	
<?php 
}  
add_action('genesis_before_content','before_content');
function before_content(){
?>
<div class='main_content'>
<?php
}

add_action('genesis_after_content','after_content');
function after_content(){
?>
</div>
<?php
}

add_action('genesis_footer','footer_menu');			
function footer_menu() { ?>
	<?php 
	if (genesism_get_option('footer_menu')){
	?>
		<div class="footer_menu">
			<span class="menu_control">≡ Menu</span>
			<?php wp_nav_menu( array( 'theme_location' => 'Thirdmenu','container' => false,'menu_class' => 'menu1','menu_id' => 'footer_menu' ) );?>
		</div>
	<?php 
	}
	?>
<?php
}
 
add_action('genesis_after_header','after_header');			
function after_header() { ?>
<div class="click_icon"></div>
 </div>	

<?php
}


add_action ('genesis_before_sidebar_widget_area','sidebar_optin',1);
function sidebar_optin(){
if (genesism_get_option('sidebar_optin')){
?>
<div class="sidebar_widget sidebar_optin">
	<div class="inner_sidebar_optin">
		<div class="sidebar_optin_title">
			<h3><?php echo genesism_option('optin_header'); ?></h3>
		</div>
		<div class="sidebar_optin_cnt">
			<form method="post" class="form" action="<?php echo stripslashes(genesism_option('optin_url')); ?>" target="_blank">
				<div class="names"><input class="name search_text" type="text" name="<?php echo stripslashes(genesism_option('optin_name')); ?>" placeholder="<?php echo stripslashes(genesism_option('name_text')); ?>"><div class='admins'></div></div>
				<div class="names"><input class="email search_text" type="text" name="<?php echo stripslashes(genesism_option('optin_email')); ?>" placeholder="<?php echo stripslashes(genesism_option('email_text')); ?>"><div class='mails'></div></div>
				<?php echo stripslashes(genesism_option('optin_hidden')); ?>
				<input name="submit" class="submit" type="submit" value="<?php echo stripslashes(genesism_option('submit_text')); ?>"/>
			</form>
		</div>
	</div>
</div>
<?php 
}
}




add_action ('genesis_entry_header','single_byline');
function single_byline(){
if ( is_single() ) { 	
?>
<div class="single_byline">
		<span class="author"><?php the_author() ?></span>
		<span class='date'><?php the_time('M jS, Y') ?></span>
		<span class='info_comments'><a  href="<?php the_permalink(); ?>#comments" title="<?php comments_number(__('0 Comment','fb'),__('1 Comment','periodic'),__('% Comments','fb')); ?>"><?php comments_number(__('0 Comment','periodic'),__('1 Comment','periodic'),__('% Comments','fb')); ?> </a></span>						
		<span class="edit_link"><?php edit_post_link(); ?></span>
</div>
<?php 
}
}

/** Genesis Previous/Next Post Post Navigation */
add_action ('genesis_before_comments','prev_next_post_nav',1);
function prev_next_post_nav(){
if ( is_single() ) {
echo '<div class="prev-next-navigation single_page_cnt">';?>
<div class="previous_post prev_next">
<?php
$prev_post = get_previous_post();
if (!empty( $prev_post )): ?>
  <a href="<?php echo get_permalink( $prev_post->ID ); ?>"><span><?php echo get_the_title( $prev_post->ID );?></span></a>
<?php endif; ?>
</div>
<div class="next_post prev_next">
<?php
$nextPost = get_next_post();
if (!empty( $nextPost )): ?>
  <a href="<?php echo get_permalink( $nextPost->ID ); ?>"><span><?php echo get_the_title( $nextPost->ID );?></span></a>
<?php endif; ?>


</div>
<?php

echo '</div><!-- .prev-next-navigation -->';
}
}	  	

// Customize the post meta function
add_filter('genesis_entry_footer', 'post_meta_filter',1);
function post_meta_filter() {
if ( is_single() ) {?>
<p class='post_tags'> 
	<?php // Tag
		$posttags = get_the_tags();
		if ($posttags) {
		foreach($posttags as $tag) {
		echo "Tags : ";
		echo $tag->name .' '; 
		}
		}
	?>
</p>
<?php
}
}


add_action ('genesis_entry_content','post_byline');
function post_byline(){
if(!is_page()&&!is_single()){	
?>
<div class="post_byline">
	<div class="post_byline_meta">
		<?php
		$category = get_the_category(); 
		?>
		<span class='date'><?php the_time('M jS, Y') ?></span>
		<span class="cat"><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></span>	
		<span class='info_comments'><a  href="<?php the_permalink(); ?>#comments" title="<?php comments_number(__('0 Comment','fb'),__('1 Comment','periodic'),__('% Comments','fb')); ?>"><?php comments_number(__('0 Comment','periodic'),__('1 Comment','periodic'),__('% Comments','fb')); ?> </a></span>						
		
	</div>
</div>
<?php 
}
}

add_action ('genesis_entry_content','post_read_more');
function post_read_more(){
if(!is_page()&&!is_single()){
if (genesism_get_option('read_more')){	
?>
<div class="post_read_more">
	<a class="pst_read_more_btn hvr-outline-out" href="<?php echo the_permalink(); ?>"><span><?php  echo (genesism_get_option('read_text'));?></span></a>
</div>
<?php 
}
}
}




add_action('genesis_entry_content','post_ad',2);
function post_ad(){
if(genesism_get_option('postadcheck')){
if ( is_single() ) {?>
		<div class="post-ad">
		<?php  echo stripslashes((genesism_get_option('postad')));?>
		</div>
        <?php
		}
	}
	}


add_action( 'genesis_before_comments', 'social_post',1);
function social_post(){
if (genesism_get_option('social_post_button')){
if ( is_single() ) {?>
<div class="sharing group sharing_social_count single_page_cnt">
<h3><?php echo genesism_option('sharehead'); ?></h3>
<ul class="nav post-social social_share_count">	
		<li class="share_tweet">
		<a href="http://twitter.com/share?text=<?php echo htmlspecialchars(urlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8')), ENT_COMPAT, 'UTF-8'); ?>&amp;url=<?php the_permalink(); ?>" target="_blank">
		<i class="icon-twitter icon"></i>
		<span>
		 Twitter
		</span>
		</a>
		</li>
		<li class="share_fb">
		<a href="http://www.facebook.com/sharer.php?u=<?php the_permalink(); ?>&amp;t=<?php echo htmlspecialchars(urlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8')), ENT_COMPAT, 'UTF-8'); ?>" target="_blank">
		<i class="icon-facebook2 icon"></i>
		<span>
		 Facebook
		</span>
		</a>
		</li>
		<li class="share_plus">
		<a href="https://plus.google.com/share?url=<?php the_permalink(); ?>" target="_blank" title="Click to share">
		<i class="icon-google icon"></i>
		<span>
		 G-plus
		</span>
		</a>
		</li>
		<li class="share_linkedin">
		<a target="_blank" href="http://www.linkedin.com/shareArticle?mini=true&amp;url=<?php the_permalink(); ?>">
		<i class="icon-linkedin icon"></i>
		<span>
		 Linkedin
		</span>
		</a> 
		</li>
		<li class="share_pintrest">
		<a target="_blank" href="http://pinterest.com/pinthis?url=<?php the_permalink(); ?>&amp;title=<?php echo htmlspecialchars(urlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8')), ENT_COMPAT, 'UTF-8'); ?>">
		<i class="icon-pinterest icon"></i>
		<span>
		 pinterest
		</span>
		</a>
		</li>
		<li class="share_reddit">
		<a target="_blank" href="http://www.reddit.com/submit?url=<?php the_permalink(); ?>&amp;title=<?php echo htmlspecialchars(urlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8')), ENT_COMPAT, 'UTF-8'); ?>">
		<i class="icon-reddit icon"></i>
		<span>
		 Reddit
		</span>
		</a>
		</li>
				
	</ul>

</div>
<?php
}
}
}


	//Related Post Box

add_action( 'genesis_before_comments', 'related_posts',4);
function related_posts(){
?>
<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Single Page Related Post Widget') ) : ?>
<div class="widget">
<h4 itemprop="headline"><?php _e("Single Page Related Post #Widget", 'genesis'); ?></h4>
<p><?php _e("Displays Single Page Realated Post with thumbnails.", 'genesis'); ?></p>
</div><!-- end .widget -->
<?php endif; ?> 
<?php
}


add_action('wp_head','color_box');
function color_box(){
$body_txt_color = get_option('body_txt_color');
$top_header_bg = get_option('top_header_bg');
$bottom_header_bg = get_option('bottom_header_bg');
$content_bg = get_option('content_bg');
$title_txt_color = get_option('title_txt_color');
$title_hover_color = get_option('title_hover_color');
$title_bg_color = get_option('title_bg_color');
$border_color = get_option('border_color');
$border_color2 = get_option('border_color2');
$avatar_clr = get_option('avatar_clr');
$footer_bg = get_option('footer_bg');
$btm_footer_bg = get_option('btm_footer_bg');
$footer_text_clr = get_option('footer_text_clr');
$footer_border_color = get_option('footer_border_color');
$landing_page_optin_bg = get_option('landing_page_optin_bg');
$landing_feature_clr = get_option('landing_feature_clr');
?>
<style type="text/css">
a{
color: <?php echo $title_hover_color; ?>;
}

body{
color: <?php echo $body_txt_color; ?>;
background-image:url(<?php echo genesism_option('body_img'); ?>);
}

.top_header,.menu .sub-menu{
background: <?php echo $top_header_bg; ?>;
}


.bottom_header,.menu2 .sub-menu {
background: <?php echo $bottom_header_bg; ?>; 
}

.site-inner {
    background: <?php echo $content_bg; ?>; 
}

.fitst_cat_btm_cnt h3 a,.latest_btm_cnt h3 a,.fourth_cat_btm_sec h3 a,.sixth_inner_btm_cnt h3 a,
.seven_cat_title h3 a,.recent_cnt h3 a,.sidebar .widget a,.entry-title,.related-posts-box h4 a,
.moreon a:hover,.r-tabs .r-tabs-accordion-title.r-tabs-state-active .r-tabs-anchor,.menu a:hover,
.sidebar_optin_cnt input[type="submit"],.seven_ca_date,.landingpage_feature_title h3,.author_name_social .author_name a,
.site-footer a:hover{
color: <?php echo $title_txt_color; ?>;
}

.entry-comments h3, .comment-respond h3.comment-reply-title,.single_page_cnt .single_page_title h3,.social_share_count h3,h1.archive-title{
color: <?php echo $title_txt_color; ?>;
border-bottom-color: <?php echo $title_txt_color; ?>;
}

.fitst_cat_btm_cnt h3 a:hover,.latest_btm_cnt h3 a:hover,.fourth_cat_btm_sec h3 a:hover,.sixth_inner_btm_cnt h3 a:hover,
.seven_cat_title h3 a:hover,.recent_cnt h3 a:hover,.popular_cnt h3 a:hover,.sidebar .widget a:hover,.related-posts-box h4 a:hover,
.prev_next a:hover span,.single_byline span a:hover,.menu1 a:hover,.site-footer a,.footer-widgets a:hover,
.moreon a,.home_byline a:hover,.third_category_bottom_content h3 a:hover,.latest_btm_cnt .home_byline span a:hover,
.menu2 .current-menu-item > a,.menu2 a:hover,p.comment-meta a:hover,.post_byline span a:hover,.menu1 .current-menu-item > a,
.author_name_social .author_name a:hover,.site-footer .menu1 a:hover,.site-footer .menu1 .current-menu-item > a{
color: <?php echo $title_hover_color; ?>;
}

.block_title h3,.r-tabs .r-tabs-nav .r-tabs-state-active .r-tabs-anchor,.sidebar_optin,.sidebar_widget .sidebar_title h3, .sidebar .widget .widget-title,
.editor_picks_content:before,.fitst_cat_date,.flex-control-nav li a.flex-active,.flex-control-nav li a:hover,
.author_social a:hover,.post_read_more a:before ,.post_read_more a:hover:before,.sidebar_optin_cnt input[type="submit"]:hover,
.tagcloud a:hover,.first_cat h6 a,.menu .current-menu-item > a,.archive-pagination li a:hover,.archive-pagination li a:focus,
.archive-pagination .active a,.comment-reply a:hover,.comment-respond .form-submit input[type="submit"]:hover,
.entry-header:hover .entry-title a,.entry-header:hover .entry-title a:after,.landing_optin_cnt input[type="submit"],
.landing_optin_inputs .names:after,.l_f_b a,.latest_author_sec,.entry-content .search-form input[type="submit"]:hover{
background: <?php echo $title_hover_color; ?>;
}

.post_read_more a:hover,.menu2 .sub-menu,.menu .sub-menu {
border-color: <?php echo $title_hover_color; ?>;
}

.menu2 .sub-menu:before,.menu .sub-menu:before {
border-bottom-color: <?php echo $title_hover_color; ?>;
}

.comment-respond .form-submit input[type="submit"],.author_social a,.inner_sidebar_optin,.r-tabs .r-tabs-accordion-title .r-tabs-anchor,
.r-tabs .r-tabs-nav .r-tabs-tab,.editor_picks_content1,.flex-control-nav li a,
.first_cat_btm_sec:hover .fitst_cat_date,.archive-pagination li a ,.l_f_t h4,.comment-reply a,
.latest_date_sec,.third_category_bottom_content,.sixth_date_sec,.popular_cnt,
.ten_catgory_cnt_section,.entry-title a:after,.landing_optin_cnt input[type="submit"]:hover,.l_f_b a:hover,
.entry-content .search-form input[type="submit"]{
background: <?php echo $title_bg_color; ?>;
}
.r-tabs .r-tabs-nav{
background: <?php echo $title_bg_color; ?> !important;
}

.post_read_more a{
background: <?php echo $title_bg_color; ?>;
border-color: <?php echo $title_bg_color; ?>;
}

.third_category_bottom_content:before{
border-bottom-color: <?php echo $title_bg_color; ?>;
}

.popular_cnt:after {
    border-top-color: <?php echo $title_bg_color; ?>;
}

.fourth_cat_btm_sec,.moreon,.editor_picks_content1,.recent_post_section,
.sidebar_optin_cnt input[type="text"],.popular_post_section,.post_byline{
border-bottom-color: <?php echo $border_color; ?>;
}

.post_byline{
border-top-color: <?php echo $border_color; ?>;
}

.first_cat_byline{
color: <?php echo $border_color; ?>;
}

.blog .entry,.archive .entry,.search .entry,.about-author,#relatedposts ul li,
.comment-respond textarea ,.comment-respond  input[type="text"],.entry-content .search-form input[type="search"]{
border-color: <?php echo $border_color; ?>;
}

.single_byline{
border-bottom-color: <?php echo $border_color2; ?>;
border-top-color: <?php echo $border_color2; ?>;
}


.author-info img{
background:<?php echo $avatar_clr; ?>;
}

.prev-next-navigation{
border-color: <?php echo $border_color2; ?>;
}

.previous_post a:before,.next_post a:before{
border-bottom-color: <?php echo $border_color2; ?>;
color: <?php echo $body_txt_color; ?>;
}

.previous_post{
border-right-color: <?php echo $border_color2; ?>;
}



pre{
background-color: <?php echo $border_color2; ?>;
}

.home_byline span,.home_byline span a,.seven_cat_img:before,
.sixth_btm_cnt,.post_byline span a,.single_byline span,.single_byline span a,.prev_next a,
p.comment-meta a,.latest_btm_cnt .home_byline span a,.latest_btm_cnt .home_byline span{
    color: <?php echo $body_txt_color; ?>;
}

.latest_btm_cnt .home_byline span.cat{
	border-right-color: <?php echo $body_txt_color; ?>;
}

.footer-widgets{
background-color:<?php echo $footer_bg; ?>; 
}

.footer-widgets ul li{
border-bottom-color: <?php echo $footer_border_color; ?>; 
}

.tagcloud a{
    background:<?php echo $footer_text_clr; ?>; 
}

.site-footer p,.site-footer .menu1 a ,.footer_menu .menu_control{
    color: <?php echo $footer_text_clr; ?>; 
}
  
.hero-split-right{
    background:<?php echo $landing_page_optin_bg; ?>; 
}  

.landingpage_feature{
    background:<?php echo $landing_feature_clr; ?>;
}

.site-footer{
    background: <?php echo $btm_footer_bg; ?>;
}



@media only screen and (max-width: 768px) {
.previous_post {
    border-bottom-color: <?php echo $border_color2; ?>;
}
}

<?php echo genesism_option('custom_css'); ?>
  
  
</style>
<?php
}

add_action( 'wp_enqueue_scripts', 'mytheme_enqueue_scripts' );
function mytheme_enqueue_scripts() {
    wp_register_script( 'jquery.flexslider-min', get_stylesheet_directory_uri() . '/scripts/jquery.flexslider-min.js', array( 'jquery' ) );
    wp_enqueue_script( 'jquery.flexslider-min' );
	wp_register_script( 'jquery.responsiveTabs.min', get_stylesheet_directory_uri() . '/scripts/jquery.responsiveTabs.min.js', array( 'jquery' ) );
    wp_enqueue_script( 'jquery.responsiveTabs.min' );
	wp_register_script( 'flexslider', get_stylesheet_directory_uri() . '/scripts/flexslider.js', array( 'jquery' ) );
    wp_enqueue_script( 'flexslider' );
	wp_register_script( 'tab', get_stylesheet_directory_uri() . '/scripts/tab.js', array( 'jquery' ) );
    wp_enqueue_script( 'tab' );
	
}



add_action('wp_footer','script_box');
function script_box(){?>
<script type="text/javascript">
function loadScript(src) {
     var element = document.createElement("script");
     element.src = src;
     document.body.appendChild(element);
}
// Add a script element as a child of the body
function downloadJSAtOnload() {

	loadScript("<?php bloginfo('stylesheet_directory'); ?>/scripts/main.js");	

}
 // Check for browser support of event handling capability
 if (window.addEventListener)
     window.addEventListener("load", downloadJSAtOnload, false);
	 else if (window.attachEvent)
     window.attachEvent("onload", downloadJSAtOnload);
 else window.onload = downloadJSAtOnload; 
 (function() {
      function getScript(url,success){
        var script=document.createElement('script');
        script.src=url;
        var head=document.getElementsByTagName('head')[0],
            done=false;
        script.onload=script.onreadystatechange = function(){
          if ( !done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete') ) {
            done=true;
            success();
            script.onload = script.onreadystatechange = null;
            head.removeChild(script);
          }
        };
        head.appendChild(script);
      }
        getScript('http://ajax.googleapis.com/ajax/libs/jquery/1.7.0/jquery.min.js',function(){
        });
    })();
</script>
<?php
}

// Auto Resize Image

function aq_resize( $url, $width, $height = null, $crop = null, $single = true ) {

//validate inputs
if(!$url OR !$width ) return false;

//define upload path & dir
$upload_info = wp_upload_dir();
$upload_dir = $upload_info['basedir'];
$upload_url = $upload_info['baseurl'];

//check if $img_url is local
if(strpos( $url, $upload_url ) === false) return false;

//define path of image
$rel_path = str_replace( $upload_url, '', $url);
$img_path = $upload_dir . $rel_path;

//check if img path exists, and is an image indeed
if( !file_exists($img_path) OR !getimagesize($img_path) ) return false;

//get image info
$info = pathinfo($img_path);
$ext = $info['extension'];
list($orig_w,$orig_h) = getimagesize($img_path);

//get image size after cropping
$dims = image_resize_dimensions($orig_w, $orig_h, $width, $height, $crop);
$dst_w = $dims[4];
$dst_h = $dims[5];

//use this to check if cropped image already exists, so we can return that instead
$suffix = "{$dst_w}x{$dst_h}";
$dst_rel_path = str_replace( '.'.$ext, '', $rel_path);
$destfilename = "{$upload_dir}{$dst_rel_path}-{$suffix}.{$ext}";

if(!$dst_h) {
//can't resize, so return original url
$img_url = $url;
$dst_w = $orig_w;
$dst_h = $orig_h;
}
//else check if cache exists
elseif(file_exists($destfilename) && getimagesize($destfilename)) {
$img_url = "{$upload_url}{$dst_rel_path}-{$suffix}.{$ext}";
}
//else, we resize the image and return the new resized image url
else {

// Note: This pre-3.5 fallback check will edited out in subsequent version
if(function_exists('wp_get_image_editor')) {

$editor = wp_get_image_editor($img_path);

if ( is_wp_error( $editor ) || is_wp_error( $editor->resize( $width, $height, $crop ) ) )
return false;

$resized_file = $editor->save();

if(!is_wp_error($resized_file)) {
$resized_rel_path = str_replace( $upload_dir, '', $resized_file['path']);
$img_url = $upload_url . $resized_rel_path;
} else {
return false;
}

} else {

$resized_img_path = image_resize( $img_path, $width, $height, $crop ); // Fallback foo
if(!is_wp_error($resized_img_path)) {
$resized_rel_path = str_replace( $upload_dir, '', $resized_img_path);
$img_url = $upload_url . $resized_rel_path;
} else {
return false;
}

}

}

//return the output
if($single) {
//str return
$image = $img_url;
} else {
//array return
$image = array (
0 => $img_url,
1 => $dst_w,
2 => $dst_h
);
}

return $image;
}

function catch_that_image() {
        global $post, $posts;
        $first_img = '';
        ob_start();
        ob_end_clean();
        $output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
        if(count($matches [1]))$first_img = $matches [1] [0];
        return $first_img;
}


 

// Add Post Feature image

add_action( 'genesis_entry_header', 'custom_post_featureimage', 1 );
function custom_post_featureimage() {
if(!is_page()&&!is_single()){ 
 // Defaults
         $f_img_width = genesism_get_option('f_img_width');
        $f_img_height = genesism_get_option('f_img_height');
        $default_img =  'Feature_image'; 
      
        // Auto feature image defaults
        $thumb = get_post_thumbnail_id(); 
        $img_url = wp_get_attachment_url( $thumb,'full' ); 
        $image = aq_resize( $img_url,$f_img_width,$f_img_height, true );
        // Catch the Image defaults
        $catch_img_url = catch_that_image( $thumb,'full' );
        $catch_image = aq_resize( $catch_img_url, $f_img_width, $f_img_height, true );
        // Default Image
        $default_image = aq_resize( $default_img, $f_img_width, $f_img_height, true );		
		
			
		
		if(has_post_thumbnail()) { ?>
		<div class="featured_image">
        <a href="<?php echo the_permalink();?>" title="<?php echo the_title();?>"><img src="<?php echo $image;?>" width="<?php echo $f_img_width;?>" height="<?php echo $f_img_height;?>"  class="post-image entry-image" alt="<?php the_title(); ?>"  itemprop="image"></a></div>
		<?php        
		}
		elseif (catch_that_image()){ 	?>
		<div class="featured_image">
		<a href="<?php echo the_permalink();?>" title="<?php echo the_title();?>"><img src="<?php echo $catch_image;?>" width="<?php echo $f_img_width;?>" height="<?php echo $f_img_height;?>"  class="post-image entry-image" alt="<?php the_title(); ?>"  itemprop="image"></a></div>
		<?php        
		} 
		 else if(!empty($default_img)){     ?> 
		 <div class="featured_image">
          <a href="<?php echo the_permalink();?>" title="<?php echo the_title();?>"><img class="featured_image" src="<?php echo $default_img;?>" width="<?php echo $f_img_width;?>" height="<?php echo $f_img_height;?>"  class="post-image entry-image" alt="<?php the_title(); ?>"  itemprop="image"></a></div>
<?php     
	 }
	 } 
      
}
 
 
 
 //All Genesis Lovers Widget Starts Here

// Popular Widget Starts Here

class gl_popular_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_popular_widget', 

__('Lemagaz - Popular Post', 'gl_popular_widget_domain'), 

array( 'description' => __( 'Displays Popular Post', 'gl_popular_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );

echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];

?>
<div class="popular_post sidebar_widget">
	
	<div class='popular_post_cnt sidebar_content'>
		<?php
			query_posts('post_type=post&posts_per_page='. $post_count .' &orderby=comment_count&order=DESC');
			while (have_posts()): the_post(); 
		?>
			<div class='popular_post_section '>
				<div class='popular_img '>
					<?php
						// Defaults
						$f_img_width1 = $instance['width_size'];
						$f_img_height1 = $instance['height_size'];
						$default_img =  'Feature_image'; 
						// Auto feature image defaults
						$thumb = get_post_thumbnail_id(); 
						$img_url = wp_get_attachment_url( $thumb,'full' ); 
						$image = aq_resize( $img_url,$f_img_width1,$f_img_height1, true );
						// Catch the Image defaults
						$catch_img_url = catch_that_image( $thumb,'full' );
						$catch_image = aq_resize( $catch_img_url, $f_img_width1, $f_img_height1, true );
						// Default Image
						$default_image = aq_resize( $default_img, $f_img_width1, $f_img_height1, true );
						
						if(has_post_thumbnail())
						echo
						"<div class=\"featured_image\">\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width1 . "\" height=\"" . $f_img_height1 . "\" alt=\"" . get_the_title() . "\"></a><div class='img_hover'><a class=\"link\" href=\"" . get_permalink() . "\"></a></div>\n".
						"</div>\n";
						elseif (catch_that_image()){ 
						echo
						"<div class=\"featured_image\">\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width1 . "\" height=\"" . $f_img_height1 . "\" alt=\"" . get_the_title() . "\"></a><div class='img_hover'><a class=\"link\" href=\"" . get_permalink() . "\"></a></div>\n".
						"</div>\n";  
						} 
					?>
					<span class='date'><?php the_time('j M,Y ') ?></span>
				</div>
				<div class="popular_cnt">
					<h3><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a></h3>
					
				</div>
			</div>
		<?php
			endwhile;
		?>
	</div>
</div>

<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Popular Posts', 'gl_popular_widget_domain' );
}

 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '3', 'gl_popular_widget_domain' );
}

 if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '92', 'gl_popular_widget_domain' );
}

 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '92', 'gl_popular_widget_domain' );
}

?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>
<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';
return $instance;
}
}

//Popular Widget Ends Here

// Sidebar Tab Widget Starts Here

class gl_sidebar_tab_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_sidebar_tab_widget', 

__('Lemagaz - Sidebar Tab Widget', 'gl_sidebar_tab_widget_domain'), 

array( 'description' => __( 'Displays Sidebar Tab Widget Post', 'gl_sidebar_tab_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$title2 = apply_filters( 'title2', $instance['title2'] );
$title3 = apply_filters( 'title3', $instance['title3'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );


echo $args['before_widget'];
if ( ! empty( $title ) )
/*echo $args['before_title'] . $title . $args['after_title'];*/

?>
<div class="sidebar_widget sidebar_recent_sec">
<div id="horizontalTab">
        <ul>
            <li><a href="#tab-1"><?php echo $instance['title']; ?> </a></li>
            <li><a href="#tab-2"><?php echo $instance['title2'] ?> </a></li>
            <li><a href="#tab-3"><?php echo $instance['title3']; ?> </a></li>
            
        </ul>

        <div id="tab-1">
			<div class='recent_post_cnt sidebar_cnt'>
				<?php
					query_posts('post_type=post&posts_per_page='. $post_count .'');
					while (have_posts()): the_post(); 
				?>
					<div class='recent_post_section'>
						<div class='recent_img'>
							<?php
								$f_img_width = $instance['width_size'];
								$f_img_height = $instance['height_size'];
								// Auto feature image defaults
								$thumb = get_post_thumbnail_id(); 
								$img_url = wp_get_attachment_url( $thumb,'full' ); 
								$image = aq_resize( $img_url, $f_img_width, $f_img_height, true );
								// Catch the Image defaults
								$catch_img_url = catch_that_image( $thumb,'full' );
								$catch_image = aq_resize( $catch_img_url, $f_img_width, $f_img_height, true );
								if(has_post_thumbnail())
								echo
								"<div class=\"featured_image\">\n".
								"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width . "\" height=\"" . $f_img_height . "\" alt=\"" . get_the_title() . "\"></a>\n".
								"</div>\n";
								elseif (catch_that_image()){ 
								echo
								"<div class=\"featured_image\">\n".
								"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width . "\" height=\"" . $f_img_height . "\" alt=\"" . get_the_title() . "\"></a>\n".
								"</div>\n";  
								} 
							?>
						</div>
						<div class="recent_cnt">
							<h3 itemprop='headline'><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a></h3>
							<span class='date' itemprop="datePublished"><?php the_time('M jS, Y') ?></span>
						</div>
					</div>
				<?php
					endwhile;
					wp_reset_query(); 
				?>
			</div>
        </div>
        <div id="tab-2">
            <div class='recent_post_cnt sidebar_cnt'>
				<?php
				
					global $query_string; 
					query_posts( array( 'posts_per_page'=>$instance['post_count'], 'post_type' => 'post', 'orderby' => 'comment_count','order' => 'desc', 'paged' => get_query_var('paged')) );
					if(have_posts()) : 
					while(have_posts()) : the_post();
				?>
					<div class='recent_post_section'>
						<div class='recent_img'>
							<?php
								$f_img_width = $instance['width_size'];
								$f_img_height = $instance['height_size'];
								// Auto feature image defaults
								$thumb = get_post_thumbnail_id(); 
								$img_url = wp_get_attachment_url( $thumb,'full' ); 
								$image = aq_resize( $img_url, $f_img_width, $f_img_height, true );
								// Catch the Image defaults
								$catch_img_url = catch_that_image( $thumb,'full' );
								$catch_image = aq_resize( $catch_img_url, $f_img_width, $f_img_height, true );
								if(has_post_thumbnail())
								echo
								"<div class=\"featured_image\">\n".
								"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width . "\" height=\"" . $f_img_height . "\" alt=\"" . get_the_title() . "\"></a>\n".
								"</div>\n";
								elseif (catch_that_image()){ 
								echo
								"<div class=\"featured_image\">\n".
								"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width . "\" height=\"" . $f_img_height . "\" alt=\"" . get_the_title() . "\"></a>\n".
								"</div>\n";  
								} 
							?>
						</div>
						<div class="recent_cnt">
							<h3 itemprop='headline'><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a></h3>
							<span class='date'  itemprop="datePublished"><?php the_time('M jS, Y') ?></span>
						</div>
					</div>
				<?php
					endwhile;
					endif;
					wp_reset_query(); 
				?>
			</div>
        </div>
        <div id="tab-3">
            <div class='recent_post_cnt sidebar_cnt'>
				<?php
					query_posts('post_type=post&posts_per_page='. $post_count .'&orderby=rand&order=DESC');
					while (have_posts()): the_post(); 
				?>
					<div class='recent_post_section'>
						<div class='recent_img'>
							<?php
								$f_img_width5 = $instance['width_size'];
								$f_img_height5 = $instance['height_size'];
								// Auto feature image defaults
								$thumb = get_post_thumbnail_id(); 
								$img_url = wp_get_attachment_url( $thumb,'full' ); 
								$image = aq_resize( $img_url, $f_img_width5, $f_img_height5, true );
								// Catch the Image defaults
								$catch_img_url = catch_that_image( $thumb,'full' );
								$catch_image = aq_resize( $catch_img_url, $f_img_width5, $f_img_height5, true );
								if(has_post_thumbnail())
								echo
								"<div class=\"featured_image\">\n".
								"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width5 . "\" height=\"" . $f_img_height5 . "\" alt=\"" . get_the_title() . "\"></a>\n".
								"</div>\n";
								elseif (catch_that_image()){ 
								echo
								"<div class=\"featured_image\">\n".
								"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width5 . "\" height=\"" . $f_img_height5 . "\" alt=\"" . get_the_title() . "\"></a>\n".
								"</div>\n";  
								} 
							?>
						</div>
						<div class="recent_cnt">
							<h3 itemprop='headline'><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a></h3>
							<span class='date'  itemprop="datePublished"><?php the_time('M jS, Y') ?></span>
						</div>
					</div>
				<?php
					endwhile;
					wp_reset_query(); 
				?>
			</div>
        </div>
      

    </div>	
</div>

<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Recent', 'gl_sidebar_tab_widget_domain' );
}

 if ( isset( $instance[ 'title2' ] ) ) {
$title2 = $instance[ 'title2' ];
}
else {
$title2 = __( 'Trending', 'gl_sidebar_tab_widget_domain' );
}

 if ( isset( $instance[ 'title3' ] ) ) {
$title3 = $instance[ 'title3' ];
}
else {
$title3 = __( 'Random', 'gl_sidebar_tab_widget_domain' );
}


 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '3', 'gl_sidebar_tab_widget_domain' );
}

 if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '102', 'gl_sidebar_tab_widget_domain' );
}

 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '80', 'gl_sidebar_tab_widget_domain' );
}


?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Recent Post Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'title2' ); ?>"><?php _e( 'Trending Post Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title2' ); ?>" name="<?php echo $this->get_field_name( 'title2' ); ?>" type="text" value="<?php echo esc_attr( $title2 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'title3' ); ?>"><?php _e( 'Random Post Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title3' ); ?>" name="<?php echo $this->get_field_name( 'title3' ); ?>" type="text" value="<?php echo esc_attr( $title3 ); ?>" />
</p>


<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>



<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['title2'] = ( ! empty( $new_instance['title2'] ) ) ? strip_tags( $new_instance['title2'] ) : '';
$instance['title3'] = ( ! empty( $new_instance['title3'] ) ) ? strip_tags( $new_instance['title3'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';


return $instance;
}
}

//Sidebar Tab Widget Ends Here

// Catgory & Latest News Widget Starts Here

class gl_catgory_latest_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_catgory_latest_widget', 

__('Lemagaz - Catgory & Latest News Post', 'gl_catgory_latest_widget_domain'), 

array( 'description' => __( 'Displays Catgory & Latest News Post', 'gl_catgory_latest_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
$post_count1 = apply_filters( 'post_count1', $instance['post_count1'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );
$width_size1 = apply_filters( 'width_size1', $instance['width_size1'] );
$height_size1 = apply_filters( 'height_size1', $instance['height_size1'] );
$cat_id = apply_filters( 'cat_id', $instance['cat_id'] );
$cat_id1 = apply_filters( 'cat_id1', $instance['cat_id1'] );

echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];

?>
<div class="latest_cat_sec">
	
	<div class="first_category latest_cat_cnt">
		
		<div class="first_catgory_section">
		<?php 
		$i=1;
		query_posts( array('posts_per_page'=>$instance['post_count'], cat=>$instance['cat_id']) );
		while ( have_posts() ) : the_post();
		if( $i == 1 ){
		?>
			<div class="first_cat_sec">
				<div class="first_cat_img">
					<?php
					// Defaults
					$f_img_width5 = $instance['width_size'];
					$f_img_height5 = $instance['height_size'];
					$default_img =  'Feature_image'; 

					// Auto feature image defaults
					$thumb = get_post_thumbnail_id(); 
					$img_url = wp_get_attachment_url( $thumb,'full' ); 
					$image = aq_resize( $img_url,$f_img_width5,$f_img_height5, true );
					// Catch the Image defaults
					$catch_img_url = catch_that_image( $thumb,'full' );
					$catch_image = aq_resize( $catch_img_url, $f_img_width5, $f_img_height5, true );
					// Default Image
					$default_image = aq_resize( $default_img, $f_img_width5, $f_img_height5, true );
					
					if(has_post_thumbnail())
					echo
					"<div class=\"featured_image\"><div class='overlay'> </div>\n".
					"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width5 . "\" height=\"" . $f_img_height5 . "\" alt=\"" . get_the_title() . "\"></a>\n".
					"</div>\n";
					elseif (catch_that_image()){ 
					echo
					"<div class=\"featured_image\"><div class='overlay'> </div>\n".
					"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width5 . "\" height=\"" . $f_img_height5 . "\" alt=\"" . get_the_title() . "\"></a>\n".
					"</div>\n"; 
					} 
					/*featured image ends here*/
					?>
				</div>
				<div class="first_cat">
				<?php
								$category = get_the_category(); 
							?>
							<h6><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></h6>
				</div>
				<div class="fitst_cat_cnt">
					<div class="entry_title">
						<?php echo "<h3><a href='". get_permalink() ."'>".get_the_title()."";
						echo "</a></h3>";?>
					</div>
					<div class="first_cat_byline">
						<span class='author'><?php the_author() ?></span>
						<span class='date'><?php the_time('M jS, Y') ?></span>						
					</div>
				</div>
			</div><div class="first_cat_btm">
		<?php
		}	
		else{
		?>
			<div class="first_cat_btm_sec">
				<div class="fitst_cat_date">				
					<div  itemprop="datePublished"><h4><?php the_time('d') ?></h4><span><?php the_time('M') ?></span><span><?php the_time('Y') ?></span></div>
				</div>
				<div class="fitst_cat_btm_cnt">
					<div class="entry_title">
						<?php echo "<h3><a href='". get_permalink() ."'>".get_the_title()."";
						echo "</a></h3>";?>
					</div>
				</div>
			</div>
		<?php
		}
		$i++;
		endwhile;
		wp_reset_query();
		?></div>
		</div>	
		
	</div>
	
	



<div class="latest_news">
	<div class="latest_news_section">
		
		<div class="flexslider carousel">
			<ul class='slides'>
		<?php 
			
			query_posts( array('posts_per_page'=> $instance['post_count1'] ) );
			while ( have_posts() ) : the_post();?>

				<li>
				<div class="left_latest_news">
					<div class="latest_img_date_sec">
						<div class="latest_left_img">
							<?php
								// Defaults
								$f_img_width4 = $instance['width_size1'];
								$f_img_height4 = $instance['height_size1'];
								$default_img =  'Feature_image'; 

								// Auto feature image defaults
								$thumb = get_post_thumbnail_id(); 
								$img_url = wp_get_attachment_url( $thumb,'full' ); 
								$image = aq_resize( $img_url,$f_img_width4,$f_img_height4, true );
								// Catch the Image defaults
								$catch_img_url = catch_that_image( $thumb,'full' );
								$catch_image = aq_resize( $catch_img_url, $f_img_width4, $f_img_height4, true );
								// Default Image
								$default_image = aq_resize( $default_img, $f_img_width4, $f_img_height4, true );
								
								if(has_post_thumbnail())
								echo
								"<div class=\"featured_image\">\n".
								"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width4 . "\" height=\"" . $f_img_height4 . "\" alt=\"" . get_the_title() . "\"></a>\n".
								"</div>\n";
								elseif (catch_that_image()){ 
								echo
								"<div class=\"featured_image\">\n".
								"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width4 . "\" height=\"" . $f_img_height4 . "\" alt=\"" . get_the_title() . "\"></a>\n".
								"</div>\n"; 
								} 
								/*featured image ends here*/
								?>
						</div>
						<div class="latest_date_sec">
							<div class="inner_latest_date_sec">
							<div class="latest_year">
								<h4><?php the_time('Y') ?></h4>
							</div>
							<div class="latest_day_mnth">
								<div class="latest_day">
									<h3><?php the_time('d') ?></h3>
								</div>
								<div class="latst_mnth">
									<?php the_time('M') ?>
								</div>
							</div>
							</div>
						</div>
						
					</div>
					<div class="latest_btm_cnt">
						<div class="latest_author_sec">
							<div class="latest_avatar_img">
								<?php echo get_avatar( get_the_author_meta( 'ID' ) , 60 ); ?>
							</div>
							<div class="latest_author_name">
								<span><?php the_author() ?></span>
							</div>
						</div>
					<div class="entry_title">
						<?php echo "<h3><a href='". get_permalink() ."'>".get_the_title()."";
						echo "</a></h3>";?>
					</div>
					<div class="entry_excerpt">
						<p>
							<?php
							$excerpt=get_the_excerpt();
							echo string_limit_words($excerpt,35);
							?>
						</p>
					</div>
					<div class="home_byline">
						<?php
					$category = get_the_category(); 
					?>
					<span class="cat"><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></span>
						<span class='info_comments'><a  href="<?php the_permalink(); ?>#comments" title="<?php comments_number(__('0 ','fb'),__('1 ','periodic'),__('% ','fb')); ?>"><?php comments_number(__('0 ','periodic'),__('1 ','periodic'),__('% ','fb')); ?> </a></span>						
					</div>
					
					</div>
				</div>
				</li>
			<?php
			endwhile;
			wp_reset_query(); 
		?>
		</ul>
		</div>
		
		 
	</div>
	
</div>




	<div class="second_category latest_cat_cnt">
		
		<div class="first_catgory_section">
		<?php 
		$i=1;
		query_posts( array('posts_per_page'=>$instance['post_count'], cat=>$instance['cat_id1']) );
		while ( have_posts() ) : the_post();
		if( $i == 1 ){
		?>
			<div class="first_cat_sec">
				<div class="first_cat_img">
					<?php
					// Defaults
					$f_img_width5 = $instance['width_size'];
					$f_img_height5 = $instance['height_size'];
					$default_img =  'Feature_image'; 

					// Auto feature image defaults
					$thumb = get_post_thumbnail_id(); 
					$img_url = wp_get_attachment_url( $thumb,'full' ); 
					$image = aq_resize( $img_url,$f_img_width5,$f_img_height5, true );
					// Catch the Image defaults
					$catch_img_url = catch_that_image( $thumb,'full' );
					$catch_image = aq_resize( $catch_img_url, $f_img_width5, $f_img_height5, true );
					// Default Image
					$default_image = aq_resize( $default_img, $f_img_width5, $f_img_height5, true );
					
					if(has_post_thumbnail())
					echo
					"<div class=\"featured_image\"><div class='overlay'> </div>\n".
					"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width5 . "\" height=\"" . $f_img_height5 . "\" alt=\"" . get_the_title() . "\"></a>\n".
					"</div>\n";
					elseif (catch_that_image()){ 
					echo
					"<div class=\"featured_image\"><div class='overlay'> </div>\n".
					"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width5 . "\" height=\"" . $f_img_height5 . "\" alt=\"" . get_the_title() . "\"></a>\n".
					"</div>\n"; 
					} 
					/*featured image ends here*/
					?>
				</div>
				<div class="first_cat">
				<?php
								$category = get_the_category(); 
							?>
							<h6><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></h6>
				</div>
				<div class="fitst_cat_cnt">
					<div class="entry_title">
						<?php echo "<h3><a href='". get_permalink() ."'>".get_the_title()."";
						echo "</a></h3>";?>
					</div>
					<div class="first_cat_byline">
						<span class='author'><?php the_author() ?></span>
						<span class='date'><?php the_time('M jS, Y') ?></span>						
					</div>
				</div>
			</div><div class="first_cat_btm">
		<?php
		}	
		else{
		?>
			<div class="first_cat_btm_sec">
				<div class="fitst_cat_date">
					<div  itemprop="datePublished"><h4><?php the_time('d') ?></h4><span><?php the_time('M') ?></span><span><?php the_time('Y') ?></span></div>
				</div>
				<div class="fitst_cat_btm_cnt">
					<div class="entry_title">
						<?php echo "<h3><a href='". get_permalink() ."'>".get_the_title()."";
						echo "</a></h3>";?>
					</div>
				</div>
			</div>
		<?php
		}
		$i++;
		endwhile;
		wp_reset_query();
		?></div>
		</div>	
		
	</div>
	
</div>

<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {


 if ( isset( $instance[ 'cat_id' ] ) ) {
$cat_id = $instance[ 'cat_id' ];
}
else {
$cat_id = __( '11', 'gl_catgory_latest_widget_domain' );
}

 if ( isset( $instance[ 'cat_id1' ] ) ) {
$cat_id1 = $instance[ 'cat_id1' ];
}
else {
$cat_id1 = __( '2', 'gl_catgory_latest_widget_domain' );
}

 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '5', 'gl_catgory_latest_widget_domain' );
}

 if ( isset( $instance[ 'post_count1' ] ) ) {
$post_count1 = $instance[ 'post_count1' ];
}
else {
$post_count1 = __( '5', 'gl_catgory_latest_widget_domain' );
}

 if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '275', 'gl_catgory_latest_widget_domain' );
}

 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '275', 'gl_catgory_latest_widget_domain' );
}


if ( isset( $instance[ 'width_size1' ] ) ) {
$width_size1 = $instance[ 'width_size1' ];
}
else {
$width_size1 = __( '525', 'gl_catgory_latest_widget_domain' );
}

 if ( isset( $instance[ 'height_size1' ] ) ) {
$height_size1 = $instance[ 'height_size1' ];
}
else {
$height_size1 = __( '390', 'gl_catgory_latest_widget_domain' );
}

?>

<p>
<label for="<?php echo $this->get_field_id( 'cat_id' ); ?>"><?php _e( 'Catgory ID One:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'cat_id' ); ?>" name="<?php echo $this->get_field_name( 'cat_id' ); ?>" type="text" value="<?php echo esc_attr( $cat_id ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'cat_id1' ); ?>"><?php _e( 'Catgory ID Two:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'cat_id1' ); ?>" name="<?php echo $this->get_field_name( 'cat_id1' ); ?>" type="text" value="<?php echo esc_attr( $cat_id1 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Catgory Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_count1' ); ?>"><?php _e( 'Latest News Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count1' ); ?>" name="<?php echo $this->get_field_name( 'post_count1' ); ?>" type="text" value="<?php echo esc_attr( $post_count1 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Catgory Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Catgory Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'width_size1' ); ?>"><?php _e( 'Latest News  Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size1' ); ?>" name="<?php echo $this->get_field_name( 'width_size1' ); ?>" type="text" value="<?php echo esc_attr( $width_size1 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size1' ); ?>"><?php _e( 'Latest News Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size1' ); ?>" name="<?php echo $this->get_field_name( 'height_size1' ); ?>" type="text" value="<?php echo esc_attr( $height_size1 ); ?>" />
</p>
<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['post_count1'] = ( ! empty( $new_instance['post_count1'] ) ) ? strip_tags( $new_instance['post_count1'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';
$instance['width_size1'] = ( ! empty( $new_instance['width_size1'] ) ) ? strip_tags( $new_instance['width_size1'] ) : '';
$instance['height_size1'] = ( ! empty( $new_instance['height_size1'] ) ) ? strip_tags( $new_instance['height_size1'] ) : '';
$instance['cat_id'] = ( ! empty( $new_instance['cat_id'] ) ) ? strip_tags( $new_instance['cat_id'] ) : '';
$instance['cat_id1'] = ( ! empty( $new_instance['cat_id1'] ) ) ? strip_tags( $new_instance['cat_id1'] ) : '';
return $instance;
}
}

//Catgory & Latest News Widget Ends Here

// First Catgory Widget Starts Here

class gl_first_catgory_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_first_catgory_widget', 

__('Lemagaz - First Catgory Post', 'gl_first_catgory_widget_domain'), 

array( 'description' => __( 'Displays First Catgory Post', 'gl_first_catgory_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );
$cat_id = apply_filters( 'cat_id', $instance['cat_id'] );

echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];

?>

<div class="third_category third_category_section">
		<div class='block_title'>
				<?php 
				echo "<a title='";
				$category=get_the_category_by_id($instance['cat_id']); echo $category;
				echo "'".
				" href='";
				$category_link = get_category_link($instance['cat_id']);
				echo esc_url( $category_link );
				echo "'".
				"><h3>";
				$category=get_the_category_by_id($instance['cat_id']); echo $category;
				echo "</h3></a>";
				?>
		</div>
		<div class="third_cat_cnt">
		<?php 
			query_posts( array('posts_per_page'=>$instance['post_count'], cat=> $instance['cat_id']) );
			while ( have_posts() ) : the_post();
			
		?>
			<div class="third_category_content">
				<div class="third_category_top_content">
					<div class="third_cat_img">
						<?php
						// Defaults
						$f_img_width6 = $instance['width_size'];
						$f_img_height6 = $instance['height_size'];
						$default_img =  'Feature_image'; 

						// Auto feature image defaults
						$thumb = get_post_thumbnail_id(); 
						$img_url = wp_get_attachment_url( $thumb,'full' ); 
						$image = aq_resize( $img_url,$f_img_width6,$f_img_height6, true );
						// Catch the Image defaults
						$catch_img_url = catch_that_image( $thumb,'full' );
						$catch_image = aq_resize( $catch_img_url, $f_img_width6, $f_img_height6, true );
						// Default Image
						$default_image = aq_resize( $default_img, $f_img_width6, $f_img_height6, true );
						
						if(has_post_thumbnail())
						echo
						"<div class=\"featured_image\">\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width6 . "\" height=\"" . $f_img_height6 . "\" alt=\"" . get_the_title() . "\"></a>\n".
						"</div>\n";
						elseif (catch_that_image()){ 
						echo
						"<div class=\"featured_image\">\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width6 . "\" height=\"" . $f_img_height6 . "\" alt=\"" . get_the_title() . "\"></a>\n".
						"</div>\n"; 
						} 
						/*featured image ends here*/
						?>	
					</div>
					
					
				</div>
				<div class="third_category_bottom_content">
					<div class="entry_title">
						<?php echo "<h3><a href='". get_permalink() ."'>".get_the_title()."";
						echo "</a></h3>";?>
					</div>
					
				</div>
			</div>
		<?php
			endwhile;
			wp_reset_query(); 
		?>
		</div>
			
	</div>

<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {


 if ( isset( $instance[ 'cat_id' ] ) ) {
$cat_id = $instance[ 'cat_id' ];
}
else {
$cat_id = __( '9', 'gl_first_catgory_widget_domain' );
}


 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '4', 'gl_first_catgory_widget_domain' );
}


 if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '77', 'gl_first_catgory_widget_domain' );
}

 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '77', 'gl_first_catgory_widget_domain' );
}


?>

<p>
<label for="<?php echo $this->get_field_id( 'cat_id' ); ?>"><?php _e( 'Catgory ID:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'cat_id' ); ?>" name="<?php echo $this->get_field_name( 'cat_id' ); ?>" type="text" value="<?php echo esc_attr( $cat_id ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>

<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';
$instance['cat_id'] = ( ! empty( $new_instance['cat_id'] ) ) ? strip_tags( $new_instance['cat_id'] ) : '';

return $instance;
}
}

//First Catgory Widget Ends Here

// Second Catgory Widget Starts Here

class gl_third_catgory_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_third_catgory_widget', 

__('Lemagaz - Second Catgory Post', 'gl_third_catgory_widget_domain'), 

array( 'description' => __( 'Displays Second Catgory Post', 'gl_third_catgory_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
$read_more = apply_filters( 'read_more', $instance['read_more'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );
$cat_id = apply_filters( 'cat_id', $instance['cat_id'] );
$cat_id1 = apply_filters( 'cat_id1', $instance['cat_id1'] );

echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];

?>

<div class="fourth_fifth_category content_sec_cnt">
	
	<div class="fourth_catgory">
		<div class='block_title'>
				<?php 
				echo "<a title='";
				$category=get_the_category_by_id($instance['cat_id']); echo $category;
				echo "'".
				" href='";
				$category_link = get_category_link($instance['cat_id']);
				echo esc_url( $category_link );
				echo "'".
				"><h3>";
				$category=get_the_category_by_id($instance['cat_id']); echo $category;
				echo "</h3></a>";
				?>
		</div>		
			<div class="fourth_catgory_section">
				<?php 
				$i=1;
					query_posts( array('posts_per_page'=>$instance['post_count'], cat=> $instance['cat_id']) );
					while ( have_posts() ) : the_post();
					if( $i == 1 ){
				?>	
				
				<div class="fourth_image_title">
					<div class="fourth_img">
						<?php
						// Defaults
						$f_img_width6 = $instance['width_size'];
						$f_img_height6 = $instance['height_size'];
						$default_img =  'Feature_image'; 

						// Auto feature image defaults
						$thumb = get_post_thumbnail_id(); 
						$img_url = wp_get_attachment_url( $thumb,'full' ); 
						$image = aq_resize( $img_url,$f_img_width6,$f_img_height6, true );
						// Catch the Image defaults
						$catch_img_url = catch_that_image( $thumb,'full' );
						$catch_image = aq_resize( $catch_img_url, $f_img_width6, $f_img_height6, true );
						// Default Image
						$default_image = aq_resize( $default_img, $f_img_width6, $f_img_height6, true );
								
						if(has_post_thumbnail())
						echo
						"<div class=\"featured_image\"><div class='overlay'> </div>\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width6 . "\" height=\"" . $f_img_height6 . "\" alt=\"" . get_the_title() . "\"></a>\n".
						"</div>\n";
						elseif (catch_that_image()){ 
						echo
						"<div class=\"featured_image\"><div class='overlay'> </div>\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width6 . "\" height=\"" . $f_img_height6 . "\" alt=\"" . get_the_title() . "\"></a>\n".
						"</div>\n"; 
						} 
						/*featured image ends here*/
						?>	
					</div>
					
					<div class="entry_title">
						<?php echo "<h3><a href='". get_permalink() ."'>".get_the_title()."";
						echo "</a></h3>";?>
					</div>
					
				</div>
				<div class="fourth_cat_btm">
				
				<?php
				}
				elseif(($i == 2)){
				?>
					<div class="moreon">
					<?php
					$category = get_the_category(); 
					?>					
					<?php echo $instance['read_more']; ?>	<a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a>		</div>
					<div class="fourth_cat_btm_sec">
						<div class="entry_title">
						<?php echo "<h3><a href='". get_permalink() ."'>".get_the_title()."";
						echo "</a></h3>";?>
						</div>
						<div class="home_byline">
						<span class='author'><?php the_author() ?></span>		
						<span class='date'><?php the_time('M jS, Y') ?></span>	
						<span class='info_comments'><a  href="<?php the_permalink(); ?>#comments" title="<?php comments_number(__('0','fb'),__('1','periodic'),__('%','fb')); ?>"><?php comments_number(__('0','periodic'),__('1','periodic'),__('%','fb')); ?> </a></span>						
					</div>
					</div>
				<?php
				}
				else{
				?>
					<div class="fourth_cat_btm_sec">
						<div class="entry_title">
						<?php echo "<h3><a href='". get_permalink() ."'>".get_the_title()."";
						echo "</a></h3>";?>
						</div>
						<div class="home_byline">
						<span class='author'><?php the_author() ?></span>		
						<span class='date'><?php the_time('M jS, Y') ?></span>	
						<span class='info_comments'><a  href="<?php the_permalink(); ?>#comments" title="<?php comments_number(__('0','fb'),__('1','periodic'),__('%','fb')); ?>"><?php comments_number(__('0','periodic'),__('1','periodic'),__('%','fb')); ?> </a></span>						
					</div>
					</div>
				<?php 
				}
				$i++;
					endwhile;
					wp_reset_query();
				?></div>
			</div>
			
	</div>
	
	<div class="fifth_category fourth_catgory">
		<div class='block_title'>
				<?php 
				echo "<a title='";
				$category=get_the_category_by_id($instance['cat_id1']); echo $category;
				echo "'".
				" href='";
				$category_link = get_category_link($instance['cat_id1']);
				echo esc_url( $category_link );
				echo "'".
				"><h3>";
				$category=get_the_category_by_id($instance['cat_id1']); echo $category;
				echo "</h3></a>";
				?>
		</div>		
			<div class="fourth_catgory_section">
				<?php 
				$i=1;
					query_posts( array('posts_per_page'=>$instance['post_count'], cat=> $instance['cat_id1']) );
					while ( have_posts() ) : the_post();
					if( $i == 1 ){
				?>	
				
				<div class="fourth_image_title">
					<div class="fourth_img">
						<?php
						// Defaults
						$f_img_width6 = 387;
						$f_img_height6 = 300;
						$default_img =  'Feature_image'; 

						// Auto feature image defaults
						$thumb = get_post_thumbnail_id(); 
						$img_url = wp_get_attachment_url( $thumb,'full' ); 
						$image = aq_resize( $img_url,$f_img_width6,$f_img_height6, true );
						// Catch the Image defaults
						$catch_img_url = catch_that_image( $thumb,'full' );
						$catch_image = aq_resize( $catch_img_url, $f_img_width6, $f_img_height6, true );
						// Default Image
						$default_image = aq_resize( $default_img, $f_img_width6, $f_img_height6, true );
								
						if(has_post_thumbnail())
						echo
						"<div class=\"featured_image\"><div class='overlay'> </div>\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width6 . "\" height=\"" . $f_img_height6 . "\" alt=\"" . get_the_title() . "\"></a>\n".
						"</div>\n";
						elseif (catch_that_image()){ 
						echo
						"<div class=\"featured_image\"><div class='overlay'> </div>\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width6 . "\" height=\"" . $f_img_height6 . "\" alt=\"" . get_the_title() . "\"></a>\n".
						"</div>\n"; 
						} 
						/*featured image ends here*/
						?>	
					</div>
					
					<div class="entry_title">
						<?php echo "<h3><a href='". get_permalink() ."'>".get_the_title()."";
						echo "</a></h3>";?>
					</div>
					
				</div>
				<div class="fourth_cat_btm">
				
				<?php
				}
				elseif(($i == 2)){
				?>
					<div class="moreon">
					<?php
					$category = get_the_category(); 
					?>					
					<?php echo $instance['read_more']; ?>	<a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a>		</div>
					<div class="fourth_cat_btm_sec">
						<div class="entry_title">
						<?php echo "<h3><a href='". get_permalink() ."'>".get_the_title()."";
						echo "</a></h3>";?>
						</div>
						<div class="home_byline">
						<span class='author'><?php the_author() ?></span>		
						<span class='date'><?php the_time('M jS, Y') ?></span>	
						<span class='info_comments'><a  href="<?php the_permalink(); ?>#comments" title="<?php comments_number(__('0','fb'),__('1','periodic'),__('%','fb')); ?>"><?php comments_number(__('0','periodic'),__('1','periodic'),__('%','fb')); ?> </a></span>						
					</div>
					</div>
				<?php
				}
				else{
				?>
					<div class="fourth_cat_btm_sec">
						<div class="entry_title">
						<?php echo "<h3><a href='". get_permalink() ."'>".get_the_title()."";
						echo "</a></h3>";?>
						</div>
						<div class="home_byline">
						<span class='author'><?php the_author() ?></span>		
						<span class='date'><?php the_time('M jS, Y') ?></span>	
						<span class='info_comments'><a  href="<?php the_permalink(); ?>#comments" title="<?php comments_number(__('0','fb'),__('1','periodic'),__('%','fb')); ?>"><?php comments_number(__('0','periodic'),__('1','periodic'),__('%','fb')); ?> </a></span>						
					</div>
					</div>
				<?php 
				}
				$i++;
					endwhile;
					wp_reset_query();
				?></div>
			</div>
					
	</div>
	
</div>

<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {


 if ( isset( $instance[ 'cat_id' ] ) ) {
$cat_id = $instance[ 'cat_id' ];
}
else {
$cat_id = __( '11', 'gl_third_catgory_widget_domain' );
}

 if ( isset( $instance[ 'cat_id1' ] ) ) {
$cat_id1 = $instance[ 'cat_id1' ];
}
else {
$cat_id1 = __( '2', 'gl_third_catgory_widget_domain' );
}

 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '4', 'gl_third_catgory_widget_domain' );
}

 if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '367', 'gl_third_catgory_widget_domain' );
}

 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '300', 'gl_third_catgory_widget_domain' );
}

 if ( isset( $instance[ 'read_more' ] ) ) {
$read_more = $instance[ 'read_more' ];
}
else {
$read_more = __( 'More On', 'gl_third_catgory_widget_domain' );
}
?>

<p>
<label for="<?php echo $this->get_field_id( 'cat_id' ); ?>"><?php _e( 'Catgory ID One:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'cat_id' ); ?>" name="<?php echo $this->get_field_name( 'cat_id' ); ?>" type="text" value="<?php echo esc_attr( $cat_id ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'cat_id1' ); ?>"><?php _e( 'Catgory ID Two:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'cat_id1' ); ?>" name="<?php echo $this->get_field_name( 'cat_id1' ); ?>" type="text" value="<?php echo esc_attr( $cat_id1 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Catgory Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Catgory Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'read_more' ); ?>"><?php _e( 'Read More Text:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'read_more' ); ?>" name="<?php echo $this->get_field_name( 'read_more' ); ?>" type="text" value="<?php echo esc_attr( $read_more ); ?>" />
</p>

<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';
$instance['cat_id'] = ( ! empty( $new_instance['cat_id'] ) ) ? strip_tags( $new_instance['cat_id'] ) : '';
$instance['cat_id1'] = ( ! empty( $new_instance['cat_id1'] ) ) ? strip_tags( $new_instance['cat_id1'] ) : '';
$instance['read_more'] = ( ! empty( $new_instance['read_more'] ) ) ? strip_tags( $new_instance['read_more'] ) : '';
return $instance;
}
}

// Second Catgory Widget Ends Here

// Catgory & Editors Picks Widget Starts Here

class gl_catgory_editors_picks_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_catgory_editors_picks_widget', 

__('Lemagaz - Catgory & Editors Picks Post', 'gl_catgory_editors_picks_widget_domain'), 

array( 'description' => __( 'Displays Catgory & Editors Picks Post', 'gl_catgory_editors_picks_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );
$cat_id = apply_filters( 'cat_id', $instance['cat_id'] );
$post_id1 = apply_filters( 'post_id1', $instance['post_id1'] );
$post_id2 = apply_filters( 'post_id2', $instance['post_id2'] );
$post_id3 = apply_filters( 'post_id3', $instance['post_id3'] );
$post_id4 = apply_filters( 'post_id4', $instance['post_id4'] );
$width_size1 = apply_filters( 'width_size1', $instance['width_size1'] );
$height_size1 = apply_filters( 'height_size1', $instance['height_size1'] );


echo $args['before_widget'];
if ( ! empty( $title ) )
//echo $args['before_title'] . $title . $args['after_title'];

?>

<div class="sixth_cat_editorial_picks">
	
	<div class="sixth_catgory">
		<div class='block_title'>
				<?php 
				echo "<a title='";
				$category=get_the_category_by_id($instance['cat_id']); echo $category;
				echo "'".
				" href='";
				$category_link = get_category_link($instance['cat_id']);
				echo esc_url( $category_link );
				echo "'".
				"><h3>";
				$category=get_the_category_by_id($instance['cat_id']); echo $category;
				echo "</h3></a>";
				?>
		</div>		
			<div class="sixth_catgory_section">
				<?php 
					query_posts( array('posts_per_page'=>1, cat=> $instance['cat_id']) );
					while ( have_posts() ) : the_post();
				
				?>	
				<div class="sixth_catgory_content">
				<div class="sixth_img">
					<?php
					// Defaults
					$f_img_width6 = $instance['width_size'];
					$f_img_height6 = $instance['height_size'];
					$default_img =  'Feature_image'; 

					// Auto feature image defaults
					$thumb = get_post_thumbnail_id(); 
					$img_url = wp_get_attachment_url( $thumb,'full' ); 
					$image = aq_resize( $img_url,$f_img_width6,$f_img_height6, true );
					// Catch the Image defaults
					$catch_img_url = catch_that_image( $thumb,'full' );
					$catch_image = aq_resize( $catch_img_url, $f_img_width6, $f_img_height6, true );
					// Default Image
					$default_image = aq_resize( $default_img, $f_img_width6, $f_img_height6, true );
							
					if(has_post_thumbnail())
					echo
					"<div class=\"featured_image\">\n".
					"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width6 . "\" height=\"" . $f_img_height6 . "\" alt=\"" . get_the_title() . "\"></a>\n".
					"</div>\n";
					elseif (catch_that_image()){ 
					echo
					"<div class=\"featured_image\">\n".
					"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width6 . "\" height=\"" . $f_img_height6 . "\" alt=\"" . get_the_title() . "\"></a>\n".
					"</div>\n"; 
					} 
					/*featured image ends here*/
					?>	
				</div>
				<div class="sixth_btm_cnt">
				<div class="sixth_inner_btm_cnt">	
					<div class="sixth_date_sec">
						<div class="sixth_day">
							<?php the_time('d') ?>
						</div>
						<div class="sixth_mnth">
							<?php the_time('M') ?>
						</div>
						<div class="sixth_mnth">
							<?php the_time('Y') ?>
						</div>	
					</div>
					<div class="entry_title">
						<?php echo "<h3><a href='". get_permalink() ."'>".get_the_title()."";
						echo "</a></h3>";?>
					</div>
					
					<div class="entry_excerpt">
						<p>
							<?php
							$excerpt=get_the_excerpt();
							echo string_limit_words($excerpt,10);
							?>
						</p>
					</div>
					<div class="home_byline">
						<span class='author'><?php the_author() ?></span>		
						<span class='date'><?php the_time('M jS, Y') ?></span>	
						<span class='info_comments'><a  href="<?php the_permalink(); ?>#comments" title="<?php comments_number(__('0','fb'),__('1','periodic'),__('%','fb')); ?>"><?php comments_number(__('0','periodic'),__('1','periodic'),__('%','fb')); ?> </a></span>						
					</div>	
				</div>
				</div>
				</div>
				<?php 
					endwhile;
					wp_reset_query();
				?>
			</div>
		
		
	</div>
	
	<div class="editors_picks sixth_catgory">
	<div class="editor_picks_section">
		<div class="block_title">
			<h3><?php echo $instance['title']; ?></h3>
		</div>
		<?php
			query_posts('p='. $post_id1 .'&posts_per_page=1');
			while (have_posts()): the_post(); 
		?>
		<div class="editor_picks_content">
			
			<div class=" editor_picks_img">
				<?php
				// Defaults
				$f_img_width7 = $instance['width_size1'];
				$f_img_height7 = $instance['height_size1'];
				$default_img =  'Feature_image'; 

				// Auto feature image defaults
				$thumb = get_post_thumbnail_id(); 
				$img_url = wp_get_attachment_url( $thumb,'full' ); 
				$image = aq_resize( $img_url,$f_img_width7,$f_img_height7, true );
				// Catch the Image defaults
				$catch_img_url = catch_that_image( $thumb,'full' );
				$catch_image = aq_resize( $catch_img_url, $f_img_width7, $f_img_height7, true );
				// Default Image
				$default_image = aq_resize( $default_img, $f_img_width7, $f_img_height7, true );
				
				if(has_post_thumbnail())
				echo
				"<div class=\"featured_image\"><div class='overlay'> </div>\n".
				"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width7 . "\" height=\"" . $f_img_height7 . "\" alt=\"" . get_the_title() . "\"></a>\n".
				"</div>\n";
					elseif (catch_that_image()){ 
				echo
				"<div class=\"featured_image\"><div class='overlay'> </div>\n".
				"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width7 . "\" height=\"" . $f_img_height7 . "\" alt=\"" . get_the_title() . "\"></a>\n".
				"</div>\n"; 
				} 
				/*featured image ends here*/
				?>
			</div>
			<div class="editor_picks_cnt editor_picks_title">
				<div class="entry_title">
					<?php echo "<h3><a href='". get_permalink() ."'>".get_the_title()."";
					echo "</a></h3>";?>
				</div>
				
				
			</div>
			
		</div>
		<?php
			endwhile;
		?>
		
		<?php
			query_posts('p='. $post_id2 .'&posts_per_page=1');
			while (have_posts()): the_post(); 
		?>
		<div class="editor_picks_content editor_picks_content1">
			
			<div class="editor_picks_cnt">
				<div class="entry_title">
					<?php echo "<h3><a href='". get_permalink() ."'>".get_the_title()."";
					echo "</a></h3>";?>
				</div>
				
				
			</div>
			
		</div>
		<?php
			endwhile;
		?>
		
		<?php
			query_posts('p='. $post_id3 .'&posts_per_page=1');
			while (have_posts()): the_post(); 
		?>
		<div class="editor_picks_content editor_picks_content1 last">
			
			<div class=" editor_picks_cnt">
				
				<div class="entry_title">
					<?php echo "<h3><a href='". get_permalink() ."'>".get_the_title()."";
					echo "</a></h3>";?>
				</div>
				
				
			</div>
			
		</div>
		<?php
			endwhile;
		?>
		<?php
			query_posts('p='. $post_id4 .'&posts_per_page=1');
			while (have_posts()): the_post(); 
		?>
		<div class="editor_picks_content editor_picks_content1 last">
			
			<div class=" editor_picks_cnt">
				
				<div class="entry_title">
					<?php echo "<h3><a href='". get_permalink() ."'>".get_the_title()."";
					echo "</a></h3>";?>
				</div>
				
				
			</div>
			
		</div>
		<?php
			endwhile;
		?>
	</div>
</div>
	
</div>


<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {

if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Editors Picks', 'gl_popular_widget_domain' );
}

 if ( isset( $instance[ 'cat_id' ] ) ) {
$cat_id = $instance[ 'cat_id' ];
}
else {
$cat_id = __( '3', 'gl_catgory_editors_picks_widget_domain' );
}


 if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '367', 'gl_catgory_editors_picks_widget_domain' );
}

 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '300', 'gl_catgory_editors_picks_widget_domain' );
}

 if ( isset( $instance[ 'post_id1' ] ) ) {
$post_id1 = $instance[ 'post_id1' ];
}
else {
$post_id1 = __( '177', 'gl_catgory_editors_picks_widget_domain' );
}

 if ( isset( $instance[ 'post_id2' ] ) ) {
$post_id2 = $instance[ 'post_id2' ];
}
else {
$post_id2 = __( '28', 'gl_catgory_editors_picks_widget_domain' );
}

 if ( isset( $instance[ 'post_id3' ] ) ) {
$post_id3 = $instance[ 'post_id3' ];
}
else {
$post_id3 = __( '19', 'gl_catgory_editors_picks_widget_domain' );
}

 if ( isset( $instance[ 'post_id4' ] ) ) {
$post_id4 = $instance[ 'post_id4' ];
}
else {
$post_id4 = __( '34', 'gl_catgory_editors_picks_widget_domain' );
}

if ( isset( $instance[ 'width_size1' ] ) ) {
$width_size1 = $instance[ 'width_size1' ];
}
else {
$width_size1 = __( '367', 'gl_catgory_editors_picks_widget_domain' );
}

 if ( isset( $instance[ 'height_size1' ] ) ) {
$height_size1 = $instance[ 'height_size1' ];
}
else {
$height_size1 = __( '250', 'gl_catgory_editors_picks_widget_domain' );
}

?>


<p>
<label for="<?php echo $this->get_field_id( 'cat_id' ); ?>"><?php _e( 'Catgory ID:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'cat_id' ); ?>" name="<?php echo $this->get_field_name( 'cat_id' ); ?>" type="text" value="<?php echo esc_attr( $cat_id ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Catgory Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Catgory Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Editors Picks Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'post_id1' ); ?>"><?php _e( 'Editors Picks Post ID One:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_id1' ); ?>" name="<?php echo $this->get_field_name( 'post_id1' ); ?>" type="text" value="<?php echo esc_attr( $post_id1 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'post_id2' ); ?>"><?php _e( 'Editors Picks Post ID Two:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_id2' ); ?>" name="<?php echo $this->get_field_name( 'post_id2' ); ?>" type="text" value="<?php echo esc_attr( $post_id2 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'post_id3' ); ?>"><?php _e( 'Editors Picks Post ID Three:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_id3' ); ?>" name="<?php echo $this->get_field_name( 'post_id3' ); ?>" type="text" value="<?php echo esc_attr( $post_id3 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'post_id4' ); ?>"><?php _e( 'Editors Picks Post ID Four:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_id4' ); ?>" name="<?php echo $this->get_field_name( 'post_id4' ); ?>" type="text" value="<?php echo esc_attr( $post_id4 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'width_size1' ); ?>"><?php _e( 'Editors Picks Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size1' ); ?>" name="<?php echo $this->get_field_name( 'width_size1' ); ?>" type="text" value="<?php echo esc_attr( $width_size1 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size1' ); ?>"><?php _e( 'Editors Picks Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size1' ); ?>" name="<?php echo $this->get_field_name( 'height_size1' ); ?>" type="text" value="<?php echo esc_attr( $height_size1 ); ?>" />
</p>


<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';

$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';
$instance['width_size1'] = ( ! empty( $new_instance['width_size1'] ) ) ? strip_tags( $new_instance['width_size1'] ) : '';
$instance['height_size1'] = ( ! empty( $new_instance['height_size1'] ) ) ? strip_tags( $new_instance['height_size1'] ) : '';
$instance['cat_id'] = ( ! empty( $new_instance['cat_id'] ) ) ? strip_tags( $new_instance['cat_id'] ) : '';
$instance['post_id1'] = ( ! empty( $new_instance['post_id1'] ) ) ? strip_tags( $new_instance['post_id1'] ) : '';
$instance['post_id2'] = ( ! empty( $new_instance['post_id2'] ) ) ? strip_tags( $new_instance['post_id2'] ) : '';
$instance['post_id3'] = ( ! empty( $new_instance['post_id3'] ) ) ? strip_tags( $new_instance['post_id3'] ) : '';
$instance['post_id4'] = ( ! empty( $new_instance['post_id4'] ) ) ? strip_tags( $new_instance['post_id4'] ) : '';

return $instance;
}
}

// Catgory & Editors Picks Widget Ends Here



// Third Catgory Widget Starts Here

class gl_second_catgory_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_second_catgory_widget', 

__('Lemagaz - Third Catgory Post', 'gl_second_catgory_widget_domain'), 

array( 'description' => __( 'Displays Third Catgory Post', 'gl_second_catgory_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
$read_more = apply_filters( 'read_more', $instance['read_more'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );
$cat_id = apply_filters( 'cat_id', $instance['cat_id'] );
$cat_id1 = apply_filters( 'cat_id1', $instance['cat_id1'] );

echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];

?>

<div class="ten_catgory_section">

	<div class="ten_catgory">
		<div class='block_title'>
				<?php 
				echo "<a title='";
				$category=get_the_category_by_id($instance['cat_id']); echo $category;
				echo "'".
				" href='";
				$category_link = get_category_link($instance['cat_id']);
				echo esc_url( $category_link );
				echo "'".
				"><h3>";
				$category=get_the_category_by_id($instance['cat_id']); echo $category;
				echo "</h3></a>";
				?>
		</div>		
			<div class="ten_catgory_cnt_section">
				<?php 
					query_posts( array('posts_per_page'=>1, cat=> $instance['cat_id']) );
					while ( have_posts() ) : the_post();
					
				?>	
				<div class="ten_cat_cnt">
					
					<div class="ten_cat_img">
						<?php
						// Defaults
						$f_img_width6 = $instance['width_size'];
						$f_img_height6 = $instance['height_size'];
						$default_img =  'Feature_image'; 

						// Auto feature image defaults
						$thumb = get_post_thumbnail_id(); 
						$img_url = wp_get_attachment_url( $thumb,'full' ); 
						$image = aq_resize( $img_url,$f_img_width6,$f_img_height6, true );
						// Catch the Image defaults
						$catch_img_url = catch_that_image( $thumb,'full' );
						$catch_image = aq_resize( $catch_img_url, $f_img_width6, $f_img_height6, true );
						// Default Image
						$default_image = aq_resize( $default_img, $f_img_width6, $f_img_height6, true );
								
						if(has_post_thumbnail())
						echo
						"<div class=\"featured_image\">\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width6 . "\" height=\"" . $f_img_height6 . "\" alt=\"" . get_the_title() . "\"></a>\n".
						"</div>\n";
						elseif (catch_that_image()){ 
						echo
						"<div class=\"featured_image\">\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width6 . "\" height=\"" . $f_img_height6 . "\" alt=\"" . get_the_title() . "\"></a>\n".
						"</div>\n"; 
						} 
						/*featured image ends here*/
						?>	
					</div>
					<div class="ten_cat_right_cnt">	
					
						<?php echo "<h3><a href='". get_permalink() ."'>".get_the_title()."";
						echo "</a></h3>";?>
						<div class="home_byline">
							<span class='author'><?php the_author() ?></span>		
							<span class='date'><?php the_time('M jS, Y') ?></span>	
							<span class='info_comments'><a  href="<?php the_permalink(); ?>#comments" title="<?php comments_number(__('0','fb'),__('1','periodic'),__('%','fb')); ?>"><?php comments_number(__('0','periodic'),__('1','periodic'),__('%','fb')); ?> </a></span>						
						</div>
						<p>
							<?php
							$excerpt=get_the_excerpt();
							echo string_limit_words($excerpt,15);
							?>
						</p>
					</div>
				</div>
				
				<?php 
				
					endwhile;
					wp_reset_query();
				?>
			</div>
		
	</div>
	
</div>

<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {


 if ( isset( $instance[ 'cat_id' ] ) ) {
$cat_id = $instance[ 'cat_id' ];
}
else {
$cat_id = __( '13', 'gl_second_catgory_widget_domain' );
}



 if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '304', 'gl_second_catgory_widget_domain' );
}

 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '220', 'gl_second_catgory_widget_domain' );
}


?>

<p>
<label for="<?php echo $this->get_field_id( 'cat_id' ); ?>"><?php _e( 'Catgory ID:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'cat_id' ); ?>" name="<?php echo $this->get_field_name( 'cat_id' ); ?>" type="text" value="<?php echo esc_attr( $cat_id ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>


<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';
$instance['cat_id'] = ( ! empty( $new_instance['cat_id'] ) ) ? strip_tags( $new_instance['cat_id'] ) : '';
return $instance;
}
}

// Third Catgory Widget Ends Here


// Fourth Catgory Widget Starts Here

class gl_fourth_catgory_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_fourth_catgory_widget', 

__('Lemagaz - Fourth Catgory Post', 'gl_fourth_catgory_widget_domain'), 

array( 'description' => __( 'Displays Fourth Catgory Post', 'gl_fourth_catgory_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );
$cat_id = apply_filters( 'cat_id', $instance['cat_id'] );
$cat_id1 = apply_filters( 'cat_id1', $instance['cat_id1'] );
$cat_id2 = apply_filters( 'cat_id2', $instance['cat_id2'] );

echo $args['before_widget'];
if ( ! empty( $title ) )
//echo $args['before_title'] . $title . $args['after_title'];

?>
<div class="category_section">
	
	<div class="seventh_catgory">
		<div class='block_title'>
				<?php 
				echo "<a title='";
				$category=get_the_category_by_id($instance['cat_id']); echo $category;
				echo "'".
				" href='";
				$category_link = get_category_link($instance['cat_id']);
				echo esc_url( $category_link );
				echo "'".
				"><h3>";
				$category=get_the_category_by_id($instance['cat_id']); echo $category;
				echo "</h3></a>";
				?>
		</div>		
			<div class="seven_catgory_section">
				<?php 
					query_posts( array('posts_per_page'=>$instance['post_count'], cat=> $instance['cat_id']) );
					while ( have_posts() ) : the_post();
					
				?>	
				<div class="seven_cat_cnt">
					<div class="seven_ca_date">
						<h4><?php the_time('d') ?></h4>
						<?php the_time('M') ?>
						<?php the_time('Y') ?>
					</div>
					<div class="seven_cat_cnt_wrapper">
					<div class="seven_cat_img">
						<?php
						// Defaults
						$f_img_width6 = $instance['width_size'];
						$f_img_height6 = $instance['height_size'];
						$default_img =  'Feature_image'; 

						// Auto feature image defaults
						$thumb = get_post_thumbnail_id(); 
						$img_url = wp_get_attachment_url( $thumb,'full' ); 
						$image = aq_resize( $img_url,$f_img_width6,$f_img_height6, true );
						// Catch the Image defaults
						$catch_img_url = catch_that_image( $thumb,'full' );
						$catch_image = aq_resize( $catch_img_url, $f_img_width6, $f_img_height6, true );
						// Default Image
						$default_image = aq_resize( $default_img, $f_img_width6, $f_img_height6, true );
								
						if(has_post_thumbnail())
						echo
						"<div class=\"featured_image\">\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width6 . "\" height=\"" . $f_img_height6 . "\" alt=\"" . get_the_title() . "\"></a>\n".
						"</div>\n";
						elseif (catch_that_image()){ 
						echo
						"<div class=\"featured_image\">\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width6 . "\" height=\"" . $f_img_height6 . "\" alt=\"" . get_the_title() . "\"></a>\n".
						"</div>\n"; 
						} 
						/*featured image ends here*/
						?>	
					</div>
					<div class="seven_cat_title">	
							<?php echo "<h3><a href='". get_permalink() ."'>".get_the_title()."";
							echo "</a></h3>";?>
						
					</div>
					</div>
				</div>
				
				<?php 
				
					endwhile;
					wp_reset_query();
				?>
			</div>
		
	</div>
	
	
	<div class="seventh_catgory eight_catgory">
		<div class='block_title'>
				<?php 
				echo "<a title='";
				$category=get_the_category_by_id($instance['cat_id1']); echo $category;
				echo "'".
				" href='";
				$category_link = get_category_link($instance['cat_id1']);
				echo esc_url( $category_link );
				echo "'".
				"><h3>";
				$category=get_the_category_by_id($instance['cat_id1']); echo $category;
				echo "</h3></a>";
				?>
		</div>		
			<div class="seven_catgory_section">
				<?php 
					query_posts( array('posts_per_page'=>$instance['post_count'], cat=> $instance['cat_id1']) );
					while ( have_posts() ) : the_post();
					
				?>	
				<div class="seven_cat_cnt">
					<div class="seven_ca_date">
						<h4><?php the_time('d') ?></h4>
						<?php the_time('M') ?>
						<?php the_time('Y') ?>
					</div>
					<div class="seven_cat_cnt_wrapper">
					<div class="seven_cat_img">
						<?php
						// Defaults
						$f_img_width6 = $instance['width_size'];
						$f_img_height6 = $instance['height_size'];
						$default_img =  'Feature_image'; 

						// Auto feature image defaults
						$thumb = get_post_thumbnail_id(); 
						$img_url = wp_get_attachment_url( $thumb,'full' ); 
						$image = aq_resize( $img_url,$f_img_width6,$f_img_height6, true );
						// Catch the Image defaults
						$catch_img_url = catch_that_image( $thumb,'full' );
						$catch_image = aq_resize( $catch_img_url, $f_img_width6, $f_img_height6, true );
						// Default Image
						$default_image = aq_resize( $default_img, $f_img_width6, $f_img_height6, true );
								
						if(has_post_thumbnail())
						echo
						"<div class=\"featured_image\">\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width6 . "\" height=\"" . $f_img_height6 . "\" alt=\"" . get_the_title() . "\"></a>\n".
						"</div>\n";
						elseif (catch_that_image()){ 
						echo
						"<div class=\"featured_image\">\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width6 . "\" height=\"" . $f_img_height6 . "\" alt=\"" . get_the_title() . "\"></a>\n".
						"</div>\n"; 
						} 
						/*featured image ends here*/
						?>	
					</div>
					<div class="seven_cat_title">	
							<?php echo "<h3><a href='". get_permalink() ."'>".get_the_title()."";
							echo "</a></h3>";?>
						
					</div>
					</div>
				</div>
				
				<?php 
				
					endwhile;
					wp_reset_query();
				?>
			</div>
		
	</div>
	
	<div class="seventh_catgory nine_catgory">
		<div class='block_title'>
				<?php 
				echo "<a title='";
				$category=get_the_category_by_id($instance['cat_id2']); echo $category;
				echo "'".
				" href='";
				$category_link = get_category_link($instance['cat_id2']);
				echo esc_url( $category_link );
				echo "'".
				"><h3>";
				$category=get_the_category_by_id($instance['cat_id2']); echo $category;
				echo "</h3></a>";
				?>
		</div>		
			<div class="seven_catgory_section">
				<?php 
					query_posts( array('posts_per_page'=>$instance['post_count'], cat=> $instance['cat_id2']) );
					while ( have_posts() ) : the_post();
					
				?>	
				<div class="seven_cat_cnt">
					<div class="seven_ca_date">
						<h4><?php the_time('d') ?></h4>
						<?php the_time('M') ?>
						<?php the_time('Y') ?>
					</div>
					<div class="seven_cat_cnt_wrapper">
					<div class="seven_cat_img">
						<?php
						// Defaults
						$f_img_width6 = $instance['width_size'];
						$f_img_height6 = $instance['height_size'];
						$default_img =  'Feature_image'; 

						// Auto feature image defaults
						$thumb = get_post_thumbnail_id(); 
						$img_url = wp_get_attachment_url( $thumb,'full' ); 
						$image = aq_resize( $img_url,$f_img_width6,$f_img_height6, true );
						// Catch the Image defaults
						$catch_img_url = catch_that_image( $thumb,'full' );
						$catch_image = aq_resize( $catch_img_url, $f_img_width6, $f_img_height6, true );
						// Default Image
						$default_image = aq_resize( $default_img, $f_img_width6, $f_img_height6, true );
								
						if(has_post_thumbnail())
						echo
						"<div class=\"featured_image\">\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width6 . "\" height=\"" . $f_img_height6 . "\" alt=\"" . get_the_title() . "\"></a>\n".
						"</div>\n";
						elseif (catch_that_image()){ 
						echo
						"<div class=\"featured_image\">\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width6 . "\" height=\"" . $f_img_height6 . "\" alt=\"" . get_the_title() . "\"></a>\n".
						"</div>\n"; 
						} 
						/*featured image ends here*/
						?>	
					</div>
					<div class="seven_cat_title">	
							<?php echo "<h3><a href='". get_permalink() ."'>".get_the_title()."";
							echo "</a></h3>";?>
						
					</div>
					</div>
				</div>
				
				<?php 
				
					endwhile;
					wp_reset_query();
				?>
			</div>
		
	</div>
		
</div>
<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {


 if ( isset( $instance[ 'cat_id' ] ) ) {
$cat_id = $instance[ 'cat_id' ];
}
else {
$cat_id = __( '11', 'gl_fourth_catgory_widget_domain' );
}

 if ( isset( $instance[ 'cat_id1' ] ) ) {
$cat_id1 = $instance[ 'cat_id1' ];
}
else {
$cat_id1 = __( '3', 'gl_fourth_catgory_widget_domain' );
}

 if ( isset( $instance[ 'cat_id2' ] ) ) {
$cat_id2 = $instance[ 'cat_id2' ];
}
else {
$cat_id2 = __( '2', 'gl_fourth_catgory_widget_domain' );
}


 if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '122', 'gl_fourth_catgory_widget_domain' );
}

 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '122', 'gl_fourth_catgory_widget_domain' );
}

 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '4', 'gl_fourth_catgory_widget_domain' );
}
?>

<p>
<label for="<?php echo $this->get_field_id( 'cat_id' ); ?>"><?php _e( 'Catgory ID One:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'cat_id' ); ?>" name="<?php echo $this->get_field_name( 'cat_id' ); ?>" type="text" value="<?php echo esc_attr( $cat_id ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'cat_id1' ); ?>"><?php _e( 'Catgory ID Two:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'cat_id1' ); ?>" name="<?php echo $this->get_field_name( 'cat_id1' ); ?>" type="text" value="<?php echo esc_attr( $cat_id1 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'cat_id2' ); ?>"><?php _e( 'Catgory ID Three:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'cat_id2' ); ?>" name="<?php echo $this->get_field_name( 'cat_id2' ); ?>" type="text" value="<?php echo esc_attr( $cat_id2 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>


<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';
$instance['cat_id'] = ( ! empty( $new_instance['cat_id'] ) ) ? strip_tags( $new_instance['cat_id'] ) : '';
$instance['cat_id1'] = ( ! empty( $new_instance['cat_id1'] ) ) ? strip_tags( $new_instance['cat_id1'] ) : '';
$instance['cat_id2'] = ( ! empty( $new_instance['cat_id2'] ) ) ? strip_tags( $new_instance['cat_id2'] ) : '';
return $instance;
}
}

// Fourth Catgory Widget Ends Here

// Realated Post Widget Starts Here

class gl_related_post_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_related_post_widget', 

__('Lemagaz - Realated Post', 'gl_related_post_widget_domain'), 

array( 'description' => __( 'Displays Realated Post', 'gl_related_post_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );


echo $args['before_widget'];
if ( ! empty( $title ) )
/*echo $args['before_title'] . $title . $args['after_title'];*/

?>


<?php
global $post;
$ads .= '<div class="thesis_related ">';
	if ( is_single() ) {
		$tags = get_the_tags($post->ID);
			if ($tags) {
			$tag_ids = array();
			foreach($tags as $individual_tag) $tag_ids[] = $individual_tag->term_id;
			$args=array(
			'tag__in' => $tag_ids,
			'post__not_in' => array($post->ID),
			'showposts'=>$instance['post_count'],  // Number of related posts that will be shown.
			'caller_get_posts'=>1
			);
	$my_query = new wp_query($args);
			if( $my_query->have_posts() ) {
		echo '<div id="relatedposts" class="single_page_cnt">';
		?>
		<div class="single_page_title">
			<h3><?php echo $instance['title']; ?></h3>
		</div>	
		<?php echo '<ul>';
		while ($my_query->have_posts()) {
			$my_query->the_post();
	if ( has_post_thumbnail() ) { ?>
			<li>
			
			<div class="related-posts-box" itemscope="itemscope" itemtype="http://schema.org/blogposting">
			<?php
						// Defaults
						$f_img_width1 = $instance['width_size'];
						$f_img_height1 = $instance['height_size'];
						$default_img =  'Feature_image'; 

						// Auto feature image defaults
						$thumb = get_post_thumbnail_id(); 
						$img_url = wp_get_attachment_url( $thumb,'full' ); 
						$image = aq_resize( $img_url,$f_img_width1,$f_img_height1, true );
						// Catch the Image defaults
						$catch_img_url = catch_that_image( $thumb,'full' );
						$catch_image = aq_resize( $catch_img_url, $f_img_width1, $f_img_height1, true );
						// Default Image
						$default_image = aq_resize( $default_img, $f_img_width1, $f_img_height1, true );
								
						if(has_post_thumbnail())
						echo
						"<div class=\"featured_image\">\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width1 . "\" height=\"" . $f_img_height1 . "\" alt=\"" . get_the_title() . "\"></a>\n".
						"</div>\n";
						elseif (catch_that_image()){ 
						echo
						"<div class=\"featured_image\">\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width1 . "\" height=\"" . $f_img_height1 . "\" alt=\"" . get_the_title() . "\"></a>\n".
						"</div>\n"; 
						} 
						?>
			<h4><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h4>
			<span class='date'><?php the_time('M jS, Y') ?></span>
			</div>
			</li>
			<?php } else { ?>
		<li><div class="relatedthumb"><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><img src="<?php echo get_post_meta($post->ID, 'Image',true) ?>" width="100" height="100" alt="<?php the_title_attribute(); ?>" /><?php the_title(); ?></a></div></li>
			<?php }
			?>
	<?php
			}
			echo '</ul>';
			echo '</div>';
			}
		}
	$post = $backup;
			wp_reset_query();
			?>
			<div class="clear"></div>
			<?php
			 }
		$ads .= '</div>';
		echo $ads;
?>

<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Related Post', 'gl_related_post_widget_domain' );
}

 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '3', 'gl_related_post_widget_domain' );
}

 if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '206', 'gl_related_post_widget_domain' );
}

 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '165', 'gl_related_post_widget_domain' );
}


?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>


<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>



<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';


return $instance;
}
}

//Realated Post Widget Ends Here

// Register and load the widget
function gl_load_widget() {
	register_widget( 'gl_popular_widget' );
	register_widget( 'gl_sidebar_tab_widget' );
	register_widget( 'gl_catgory_latest_widget' );
	register_widget( 'gl_first_catgory_widget' );
	register_widget( 'gl_third_catgory_widget' );
	register_widget( 'gl_catgory_editors_picks_widget' );
	register_widget( 'gl_second_catgory_widget' );
	register_widget( 'gl_fourth_catgory_widget' );
	register_widget( 'gl_related_post_widget' );
}
add_action( 'widgets_init', 'gl_load_widget' );