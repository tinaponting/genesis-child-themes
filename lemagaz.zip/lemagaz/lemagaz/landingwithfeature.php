<?php
/*
Template Name: Landing Page with Feature
*/


// Add custom body class to the head
add_filter( 'body_class', 'metro_add_body_class' );
function metro_add_body_class( $classes ) {
   $classes[] = 'landingpage';
   return $classes;
}

add_filter ( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );
remove_action( 'genesis_sidebar_alt', 'genesis_do_sidebar_alt' );
remove_action( 'genesis_sidebar', 'genesis_do_sidebar' );
remove_action( 'genesis_after_header', 'genesis_do_nav' );
 remove_action('genesis_before_footer', 'footer_bottom_widgets');
remove_action( 'genesis_sidebar', 'genesis_do_sidebar' );


add_action('genesis_before_content_sidebar_wrap','landingpage_optin',1);
function landingpage_optin(){
?>
<div class="landing_page_section" style="background-image:url(<?php echo genesism_option('landing_bg'); ?>);">
<div class="hero-split-right"></div>
<div class="landing_page_color">
<div class="inner_landing_page wrap">
<div class="left_landing_page">
<div class="landin_page_logo">
	<?php
	if (genesism_get_option('header')){?>
		<a title="<?php bloginfo('name'); ?>" href="<?php bloginfo('wpurl'); ?>"><img src="<?php echo genesism_option('header_text'); ?>" alt="<?php bloginfo('name'); ?>"/></a>
	<?php
	}
	else { ?>
		<h1 itemprop="headline"><a title="<?php bloginfo('name'); ?>" href="<?php bloginfo('wpurl'); ?>"><?php bloginfo('name');?> </a></h1>
		<p><?php bloginfo('description'); ?></p>
	<?php } ?>	
</div>
<?php 
if(genesism_get_option('landing_video')){
?>
<div class="landing_page_cnt">
<div class="inner_landing_page_cnt">
<h1 class="top_optc"><?php echo genesism_option('landing_video_title'); ?></h1>
<h2 class="top_optc"><?php echo genesism_option('landing_subtitle'); ?></h2>
<div class="landing_page_video"><div class="squeeze_vide">
<?php  echo stripslashes((genesism_get_option('landing_vide_img')));?>

</div>
</div>
</div>
</div>
<?php 
}
?>
</div>
<div class="right_landing_page">
<?php
if (genesism_get_option('landing_optin')){
?>
<div class="form_content">
<div class="form_content_inner">
<h3><?php echo genesism_option('landing_optin_header'); ?></h3>
<p><?php echo genesism_option('landing_optin_cnt'); ?></p>
</div>

</div>

<div class="landingpage_optin">
	<div class="landingpage_optin_section">
		
		<div class="landing_optin_cnt">
			
			<form method="post" class="form" action="<?php echo stripslashes(genesism_option('optin_url1')); ?>" target="_blank">
				<div class="landing_optin_inputs">
				<div class="names"><input class="name search_text" type="text" name="<?php echo stripslashes(genesism_option('optin_name1')); ?>" placeholder="<?php echo stripslashes(genesism_option('name_text1')); ?>"><div class='admins'></div></div>
				<div class="names"><input class="email search_text" type="text" name="<?php echo stripslashes(genesism_option('optin_email1')); ?>" placeholder="<?php echo stripslashes(genesism_option('email_text1')); ?>"><div class='mails'></div></div>
				</div>
				<?php echo stripslashes(genesism_option('optin_hidden1')); ?>
				<input name="submit" class="submit" type="submit" value="<?php echo stripslashes(genesism_option('submit_text1')); ?>"/>
			</form>
		</div>
	</div>
</div>
<?php } ?>	
</div>
</div>
</div>
</div>
<?php 
}
add_action('genesis_before_content','before_content1');
function before_content1(){
?>
<div class="main_container wrap">
<?php 
}

add_action('genesis_after_content','after_content1');
function after_content1(){
?>
</div>
<?php
}



add_action('genesis_before_content_sidebar_wrap','landingpage_feature',2);
function landingpage_feature(){
if (genesism_get_option('landing_feature')){
?>
<div class="landingpage_feature">
	<div class="landingpage_feature_section">
		<div class="landingpage_feature_title">
			<h3><?php echo genesism_option('landing_title'); ?></h3>
			<p><?php echo genesism_option('landing_feature_cnt'); ?></p>
		</div>
		<div class="landingpage_feature_cnt">
						
			<div class="landingpage_feature_cnt_section">

				<div class="landingpage_feature1 ">
					<div class="l_f_t">

						<img src="<?php echo genesism_option('landing_feature_img1'); ?>" alt="<?php echo genesism_option('landing_subtitle1'); ?>" style="visibility: visible; ">
						<h4><?php echo genesism_option('landing_subtitle1'); ?></h4>

					</div> 

					<div class="l_f_b">

						<h4><?php echo genesism_option('landing_subtitle1'); ?></h4>
						<p><?php echo genesism_option('landing_feature_cnt1'); ?></p>
						
						<a href="<?php echo genesism_option('landing_feature_readmore_link1'); ?>" target="_blank" class="cta cta-default all-caps"><?php echo genesism_option('landing_feature_readmore1'); ?></a>

					</div> 
				</div> 

				<div class="landingpage_feature1 ">
					<div class="l_f_t">

						<img src="<?php echo genesism_option('landing_feature_img2'); ?>" alt="<?php echo genesism_option('landing_subtitle2'); ?>" style="visibility: visible; ">
						<h4><?php echo genesism_option('landing_subtitle2'); ?></h4>

					</div> 

					<div class="l_f_b">

						<h4><?php echo genesism_option('landing_subtitle2'); ?></h4>
						<p><?php echo genesism_option('landing_feature_cnt2'); ?></p>
						
						<a href="<?php echo genesism_option('landing_feature_readmore_link2'); ?>" target="_blank" class="cta cta-default all-caps"><?php echo genesism_option('landing_feature_readmore2'); ?></a>

					</div> 
				</div> 

				<div class="landingpage_feature1 ">
					<div class="l_f_t">

						<img src="<?php echo genesism_option('landing_feature_img3'); ?>" alt="<?php echo genesism_option('landing_subtitle3'); ?>" style="visibility: visible; ">
						<h4><?php echo genesism_option('landing_subtitle3'); ?></h4>

					</div> 

					<div class="l_f_b">

						<h4><?php echo genesism_option('landing_subtitle3'); ?></h4>
						<p><?php echo genesism_option('landing_feature_cnt3'); ?></p>
						
						<a href="<?php echo genesism_option('landing_feature_readmore_link3'); ?>" target="_blank" class="cta cta-default all-caps"><?php echo genesism_option('landing_feature_readmore3'); ?></a>

					</div> 
				</div> 


			</div>
			
		</div>
	</div>
</div>
<?php 
}
}

genesis();