<?php
/**
 * Canvas template file.
 * 
 * Template Name: Canvas
 *
 * @package 	Jono
 * @author   	aprakasa
 * @license  	GPL-2.0+
 * @link     	http://prakasa.me/go/jono
 */

/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;

get_header();

while ( have_posts() ) : the_post();
	the_content();
endwhile;

get_footer();