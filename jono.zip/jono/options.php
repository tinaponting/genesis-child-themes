<?php
/**
 * This file control options
 * 
 * Require Options Framework Plugin
 *
 * @package 	Jono
 * @author   	aprakasa
 * @license  	GPL-2.0+
 * @link     	http://prakasa.me/go/jono
 */

/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Defines an array of options that will be used to generate the settings page and be saved in the database.
 * 
 * @since 	1.0
 */
function optionsframework_options() {

	$options = array();

	/** General settings section */
	$options[] = array(
		"name" => __( 'General', 'jono' ),
		"type" => "heading" );

		$options[] = array(
			'name' 		=> __( 'Top Header', 'jono'),
			'desc' 		=> __( 'Display email and phone number at the left side of top header.', 'jono'),
			'class'		=> 'infobox first',
			'type' 		=> 'info');

		$options['email_address'] = array(
			'name'		=> __( 'Email Address', 'jono' ),
			'desc'		=> __( 'Safely display clickable email address at the top of your site.', 'jono' ),
			'id'		=> 'email_address',
			'std'		=> '',
			'type'		=> 'text' );

		$options['phone_number'] = array(
			'name'		=> __( 'Phone Number', 'jono' ),
			'desc'		=> __( 'Display clickable phone number at the top of your site. (e.g +1-800-555-5555)', 'jono' ),
			'id'		=> 'phone_number',
			'std'		=> '',
			'type'		=> 'text' );

		$options[] = array(
			'name' 		=> __( 'Favicons', 'jono'),
			'desc' 		=> __( 'This section control favicons.', 'jono'),
			'class'		=> 'infobox',
			'type' 		=> 'info');

		$options['old_favicon'] = array( 
			"name" 		=> __( 'Favicon Image for older browser', 'jono' ),
			"desc" 		=> sprintf( __( '16x16px %s file.', 'jono' ), '<code>.ico</code>'),
			"std"		=> '',
			"id" 		=> "old_favicon",
			"type" 		=> "upload" );

		$options['favicon_image'] = array( 
			"name" 		=> __( 'Favicon Image', 'jono' ),
			"desc" 		=> sprintf( __( '16x16px or 32x32px %s, %s, %s file.', 'jono' ), '<code>.png</code>', '<code>.gif</code>', '<code>.jpeg</code>'),
			"std"		=> '',
			"id" 		=> "favicon_image",
			"type" 		=> "upload" );

		$options['apple_touch_144'] = array( 
			"name" 		=> __( 'Apple Touch Icon', 'jono' ),
			"desc" 		=> sprintf( __( '144x144px %s file.', 'jono' ), '<code>.png</code>'),
			"id" 		=> "apple_touch_144",
			"type" 		=> "upload" );

		$options['apple_touch_114'] = array( 
			"name" 		=> __( 'Apple Touch Icon', 'jono' ),
			"desc" 		=> sprintf( __( '114x114px %s file.', 'jono' ), '<code>.png</code>'),
			"id" 		=> "apple_touch_114",
			"type" 		=> "upload" );

		$options['apple_touch_72'] = array( 
			"name" 		=> __( 'Apple Touch Icon', 'jono' ),
			"desc" 		=> sprintf( __( '72x72px %s file.', 'jono' ), '<code>.png</code>'),
			"id" 		=> "apple_touch_72",
			"type" 		=> "upload" );

		$options['apple_touch_57'] = array( 
			"name" 		=> __( 'Apple Touch Icon', 'jono' ),
			"desc" 		=> sprintf( __( '57x57px %s file.', 'jono' ), '<code>.png</code>'),
			"id" 		=> "apple_touch_57",
			"type" 		=> "upload" );

		$options[] = array(
			'name' 		=> __( 'Website Logo', 'jono'),
			'desc' 		=> __( 'This section control Image Logo.', 'jono'),
			'class'		=> 'infobox',
			'type' 		=> 'info');

		$options['image_logo'] = array( 
			"name" 		=> __( 'Image Logo', 'jono' ),
			"desc" 		=> __( 'upload an image or insert url.', 'jono' ),
			"id" 		=> "image_logo",
			"type" 		=> "upload" );

		$options['image_logo_width'] = array(
			'name'		=> __( 'Logo Width', 'jono' ),
			'desc'		=> __( 'Specify logo width in <code>px</code>', 'jono' ),
			'id'		=> 'image_logo_width',
			'class' 	=> 'mini',
			'std'		=> '',
			'type'		=> 'text' );

		$options['image_logo_height'] = array(
			'name'		=> __( 'Logo Height', 'jono' ),
			'desc'		=> __( 'Specify logo height in <code>px</code>. Recommended size for logo height is 48px', 'jono' ),
			'id'		=> 'image_logo_height',
			'class' 	=> 'mini',
			'std'		=> '',
			'type'		=> 'text' );

		$options[] = array(
			'name' 		=> __( 'Footer', 'jono'),
			'desc' 		=> __( 'This section control footer text/copyright.', 'jono' ),
			'class'		=> 'infobox',
			'type' 		=> 'info');

		$options['footer_text'] = array(
			'name'		=> __( 'Footer Copyright', 'jono' ),
			'desc'		=> sprintf( __( 'You can use %sGenesis shortcode%s at footer text.', 'jono' ), '<a href="http://my.studiopress.com/docs/shortcode-reference/">', '</a>' ),
			'id'		=> 'footer_text',
			'std'		=> '',
			'type'		=> 'textarea' );

	/** Style settings section */
	$options[] = array(
		"name" => __( 'Colors', 'jono' ),
		"type" => "heading" );

		$options[] = array(
			'name' 		=> __( 'Colors', 'jono'),
			'desc' 		=> __( 'This section control website colors.', 'jono'),
			'class'		=> 'infobox first',
			'type' 		=> 'info');

		$options['primary_color'] = array(
			"name"		=> __( 'Primary color', 'jono' ),
			"id"		=> "primary_color",
			"std"		=> "#16a085",
			"type"		=> "color" );

		$options['hyperlink_color'] = array(
			"name"		=> __( 'Hyperlink color', 'jono' ),
			"id"		=> "hyperlink_color",
			"std"		=> "#1abc9c",
			"type"		=> "color" );

		$options['hover_color'] = array(
			"name"		=> __( 'Hover color', 'jono' ),
			"id"		=> "hover_color",
			"std"		=> "#16a085",
			"type"		=> "color" );

	/** Font settings section */
	$options[] = array(
		"name" => __( 'Fonts', 'jono' ),
		"type" => "heading" );

		$options[] = array(
			'name' 		=> __( 'Font Family', 'jono'),
			'desc' 		=> __( 'This section control font family.', 'jono'),
			'class'		=> 'infobox first',
			'type' 		=> 'info');

		$options['heading_font'] = array(
			'name' 		=> __( 'Heading', 'jono' ),
			'desc'		=> __( 'Font family for heading tag.', 'jono' ),
			'id'		=> 'heading_font',
			'class'		=> 'select-js',
			'std'		=> 'Open Sans',
			'type'		=> 'select',
			'options'	=> jono_get_webfonts() );

		$options['body_font'] = array(
			'name' 		=> __( 'Paragraph', 'jono' ),
			'desc'		=> __( 'Base font-family for body and paragraph.', 'jono' ),
			'id'		=> 'body_font',
			'class'		=> 'select-js',
			'std'		=> 'Open Sans',
			'type'		=> 'select',
			'options'	=> jono_get_webfonts() );

		$options['heading_weight'] = array(
			"name" 		=> __( 'Heading Font Weight', 'jono' ),
			"desc" 		=> __( 'Font weight for all heading tag', 'jono' ),
			"id" 		=> "heading_weight",
			'class'		=> 'select-js',
			"std" 		=> "700",
			"class"		=> "mini",
			"type" 		=> "select",
			"options"	=> array(
				"700"	=> "Bold",
				"400"	=> "Normal" ) );

		$options[] = array(
			'name' 		=> __( 'Font Size', 'jono'),
			'desc' 		=> __( 'Font size for all text.', 'jono'),
			'class'		=> 'infobox',
			'type' 		=> 'info');

		$options['heading_one'] = array(
			"name" 		=> __( 'Heading One', 'jono' ),
			"desc" 		=> sprintf( __( 'Font size for heading one %s in px', 'jono' ), '<code>h1</code>'),
			"id" 		=> "heading_one",
			"std" 		=> "36",
			"class"		=> "mini",
			"type" 		=> "select",
			"options"	=> jono_get_number() );

		$options['heading_two'] = array(
			"name" 		=> __( 'Heading Two', 'jono' ),
			"desc" 		=> sprintf( __( 'Font size for heading two %s in px', 'jono' ), '<code>h2</code>'),
			"id" 		=> "heading_two",
			"std" 		=> "30",
			"class"		=> "mini",
			"type" 		=> "select",
			"options"	=> jono_get_number() );

		$options['heading_three'] = array(
			"name" 		=> __( 'Heading Three', 'jono' ),
			"desc" 		=> sprintf( __( 'Font size for heading three %s in px', 'jono' ), '<code>h3</code>'),
			"id" 		=> "heading_three",
			"std" 		=> "24",
			"class"		=> "mini",
			"type" 		=> "select",
			"options"	=> jono_get_number() );

		$options['heading_four'] = array(
			"name" 		=> __( 'Heading Four', 'jono' ),
			"desc" 		=> sprintf( __( 'Font size for heading four %s in px', 'jono' ), '<code>h4</code>'),
			"id" 		=> "heading_four",
			"std" 		=> "20",
			"class"		=> "mini",
			"type" 		=> "select",
			"options"	=> jono_get_number() );

		$options['heading_five'] = array(
			"name" 		=> __( 'Heading Five', 'jono' ),
			"desc" 		=> sprintf( __( 'Font size for heading five %s in px', 'jono' ), '<code>h5</code>'),
			"id" 		=> "heading_five",
			"std" 		=> "18",
			"class"		=> "mini",
			"type" 		=> "select",
			"options"	=> jono_get_number() );

		$options['heading_six'] = array(
			"name" 		=> __( 'Heading Six', 'jono' ),
			"desc" 		=> sprintf( __( 'Font size for heading five %s in px', 'jono' ), '<code>h6</code>'),
			"id" 		=> "heading_six",
			"std" 		=> "16",
			"class"		=> "mini",
			"type" 		=> "select",
			"options"	=> jono_get_number() );

		$options['body_font_size'] = array(
			"name" 		=> __( 'Paragraph Size', 'jono' ),
			"desc" 		=> sprintf( __( 'Font size for paragraph %s in px', 'jono' ), '<code>p</code>'),
			"id" 		=> "body_font_size",
			"std" 		=> "14",
			"class"		=> "mini",
			"type" 		=> "select",
			"options"	=> jono_get_number() );

		$options['widget_size'] = array(
			"name" 		=> __( 'Widget Title Font Size', 'jono' ),
			"desc" 		=> __( 'Font size for widget title in px', 'jono' ),
			"id" 		=> "widget_size",
			"std" 		=> "15",
			"class"		=> "mini",
			"type" 		=> "select",
			"options"	=> jono_get_number() );

	if ( class_exists( 'Custom_Content_Portfolio' ) ) {

		/** Portfolio settings section */
		$options[] = array(
			"name" => __( 'Portfolio', 'jono' ),
			"type" => "heading" );

		$options[] = array(
			'name' 		=> __( 'Portfolio Label', 'jono' ),
			'desc' 		=> __( 'This section control Portfolio label.', 'jono' ),
			'class'		=> 'infobox first',
			'type' 		=> 'info' );

		$options['portfolio_name'] = array(
			'name'		=> __( 'Name', 'jono' ),
			'desc'		=> __( 'Name', 'jono' ),
			'id'		=> 'portfolio_name',
			'std'		=> 'Portfolio',
			'type'		=> 'text' );

		$options['portfolio_menu_name'] = array(
			'name'		=> __( 'Menu Name', 'jono' ),
			'desc'		=> __( 'Menu Name', 'jono' ),
			'id'		=> 'portfolio_menu_name',
			'std'		=> 'Portfolio',
			'type'		=> 'text' );

		$options['portfolio_archive_title'] = array(
			'name'		=> __( 'Archive Title', 'jono' ),
			'desc'		=> __( 'Archive Title', 'jono' ),
			'id'		=> 'portfolio_archive_title',
			'std'		=> 'Portfolio',
			'type'		=> 'text' );

		$options[] = array(
			'name' 		=> __( 'Portfolio Archive', 'jono' ),
			'desc' 		=> __( 'This section control archive page for portfolio.', 'jono' ),
			'class'		=> 'infobox',
			'type' 		=> 'info' );

		$options['portfolio_posts'] = array(
			'name' 		=> __( 'Portfolio Posts Per Page', 'jono' ),
			'desc' 		=> __( 'Number of portfolio post type to display per page.', 'jono' ),
			'id' 		=> 'portfolio_posts',
			'std'		=> '12',
			'class'		=> 'mini',
			'type' 		=> 'select',
			'options' 	=> jono_get_number() );

		$options['portfolio_columns'] = array(
			'name' 		=> __( 'Select Portfolio Columns', 'jono' ),
			'desc' 		=> __( 'Columns grid for portfolio post type.', 'jono' ),
			'id' 		=> 'portfolio_columns',
			'std'		=> '3',
			'class'		=> 'mini',
			'type' 		=> 'select',
			'options' 	=> array(
				'2' => __( 'Two Columns', 'jono' ),
				'3'	=> __( 'Three Columns', 'jono' ),
				'4' => __( 'Four Columns', 'jono' ) ) );

		$options['portfolio_order'] = array(
			'name' 		=> __( 'Portfolio Order', 'jono' ),
			'desc' 		=> __( 'Select portfolio post order.', 'jono' ),
			'id' 		=> 'portfolio_order',
			'std'		=> 'DESC',
			'class'		=> 'mini',
			'type' 		=> 'select',
			'options' 	=> array(
				'ASC' 	=> __( 'Ascending', 'jono' ),
				'DESC' 	=> __( 'Descending', 'jono' ) ) );

		$options['portfolio_orderby'] = array(
			'name' 		=> __( 'Portfolio OrderBy', 'jono' ),
			'desc' 		=> __( 'Select portfolio post orderby.', 'jono' ),
			'id' 		=> 'portfolio_orderby',
			'std'		=> 'date',
			'class'		=> 'mini',
			'type' 		=> 'select',
			'options' 	=> array(
				'title'	=> __( 'Title', 'jono' ),
				'date'	=> __( 'Date', 'jono' ),
				'rand'	=> __( 'Random', 'jono' ) ) );

	} /** EOF Custom_Content_Portfolio() */

	$options[] = array(
		"name" => __( 'Misc', 'jono' ),
		"type" => "heading" );

		$options['scripts_cdn'] = array(
			"name" 		=> __( 'Script and Styles', 'jono' ),
			"desc" 		=> sprintf( __( 'Safely load %s script and styles from %s and %s to save bandwidth and increase performance.', 'jono' ), CHILD_THEME_NAME, '<a href="//netdna.bootstrapcdn.com">NetDNA</a>','<a href="//cdnjs.com">cdnjs</a>' ),
			"id" 		=> "scripts_cdn",
			"std" 		=> 0,
			"type" 		=> "checkbox" );

		$options['gallery_style'] = array(
			"name" 		=> __( 'Gallery Shortcode', 'jono' ),
			"desc" 		=> sprintf( __( 'Use built-in %s gallery shortcode style. This will replace default WP gallery shortcode style.', 'jono' ), CHILD_THEME_NAME ),
			"id" 		=> "gallery_style",
			"std" 		=> 0,
			"type" 		=> "checkbox" );		

	return $options;

}