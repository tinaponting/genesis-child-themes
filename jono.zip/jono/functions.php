<?php
/**
 * Main function file
 *
 * @package 	Jono
 * @author   	aprakasa
 * @license  	GPL-2.0+
 * @link     	http://prakasa.me/go/jono
 */

/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;

/** Load Jono child theme library */
require_once( get_stylesheet_directory() . '/lib/init.php' );