<?php
/**
 * Initial all widgets functions and tweaks
 *
 * @package 	Jono
 * @author   	aprakasa
 * @license  	GPL-2.0+
 * @link     	http://prakasa.me/go/jono
 */

/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;

/** Load widgets init */
include( JONO_WIDGETS_DIR . 'jono-organization-info.php' );
if ( class_exists( 'Custom_Content_Portfolio') )
	include( JONO_WIDGETS_DIR . 'jono-recent-portfolio.php' );

add_action( 'widgets_init', 'jono_unregister_sidebar' );
/** 
 * Unregister sidebar area
 * 
 * @since 1.0 
 */
function jono_unregister_sidebar(){
	/** Unregister Genesis Sidebars */		
	unregister_sidebar( 'header-right' );
	unregister_sidebar( 'sidebar-alt' );

	register_widget( 'Jono_Organization_Widget' );
	if ( class_exists( 'Custom_Content_Portfolio') )
		register_widget( 'Jono_Recent_Portfolio' );
}

add_filter( 'widget_tag_cloud_args', 'jono_widget_tag_cloud_args' );
/** 
 * Widget Tag clound font size
 * 
 * @since 1.0 
 */
function jono_widget_tag_cloud_args( $args ) {
	$args['largest'] 	= 12;
	$args['smallest'] 	= 12;
	$args['unit'] 		= 'px';
	return $args;	
}