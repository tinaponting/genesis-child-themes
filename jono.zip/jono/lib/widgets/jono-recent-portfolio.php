<?php
/**
 * Recent Portfolio
 *
 * @package 	Jono
 * @author   	aprakasa
 * @license  	GPL-2.0+
 * @link     	http://prakasa.me/go/jono
 */

/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Jono Featured Portfolio widget class.
 *
 * @since 1.0
 */
class Jono_Recent_Portfolio extends WP_Widget {

	/**
	 * Holds widget settings defaults,
	 * populated in constructor.
	 *
	 * @var array
	 */
	protected $defaults;

	/**
	 * Constructor.
	 * Set the default widget options and create widget.
	 *
	 * @since 1.0
	 */
	function __construct() {

		$this->defaults = array(
			'title' 		=> '',
			'portfolio_num'	=> 6,
			'display'		=> 'slideshow',
			'effect'		=> 'slide',
		);

		$widget_ops = array(
			'classname'   => 'jono-recent-portfolio',
			'description' => __( 'Displays Recent portfolio slideshow', 'jono' ),
		);

		$control_ops = array(
			'id_base' => 'jono-recent-portfolio',
			//'width'   => 505,
			//'height'  => 350,
		);

		parent::__construct( 'jono-recent-portfolio', __( 'Jono - Recent Portfolio', 'jono' ), $widget_ops, $control_ops );
		
	}

	/**
	 * Widget Form.
	 * Outputs the widget form that allows users to control the output of the widget.
	 *
	 */
	function form( $instance ) {
		/** Merge with defaults */
		$instance = wp_parse_args( (array) $instance, $this->defaults );

		?>
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title', 'jono' ); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $instance['title'] ); ?>" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'portfolio_num' ); ?>"><?php _e( 'Number of Portfolio to Show', 'Jono' ); ?>:</label>
			<input type="text" id="<?php echo $this->get_field_id( 'portfolio_num' ); ?>" name="<?php echo $this->get_field_name( 'portfolio_num' ); ?>" value="<?php echo esc_attr( $instance['portfolio_num'] ); ?>" size="2" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'display' ); ?>"><?php _e( 'Display portfolio as', 'jono' ); ?>:</label>
			<select id="<?php echo $this->get_field_id( 'display' ); ?>" name="<?php echo $this->get_field_name( 'display' ); ?>">
				<option value="thumbnail" <?php selected( 'fade', $instance['display'] ); ?>><?php _e( 'Thumbnail', 'jono' ); ?></option>
				<option value="slideshow" <?php selected( 'slide', $instance['display'] ); ?>><?php _e( 'Slideshow', 'jono' ); ?></option>
			</select>
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'effect' ); ?>"><?php _e( 'Slideshow effect', 'jono' ); ?>:</label>
			<select id="<?php echo $this->get_field_id( 'effect' ); ?>" name="<?php echo $this->get_field_name( 'effect' ); ?>">
				<option value="fade" <?php selected( 'fade', $instance['effect'] ); ?>><?php _e( 'Fade', 'jono' ); ?></option>
				<option value="slide" <?php selected( 'slide', $instance['effect'] ); ?>><?php _e( 'Slide', 'jono' ); ?></option>
			</select>
		</p>

		<?php
	}

	/**
	 * Form validation and sanitization.
	 *
	 * Runs when you save the widget form.
	 * Allows you to validate or sanitize widget options before they are saved.
	 *
	 */
	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = strip_tags( $new_instance['title'] );
		$instance['portfolio_num'] = (int)$new_instance['portfolio_num'];
		$instance['display'] = $new_instance['display'];
		$instance['effect'] = strip_tags( $new_instance['effect'] );
		return $instance;
	}

	/**
	 * Widget Output.
	 *
	 * Outputs the actual widget on the front-end based on the widget options the user selected.
	 *
	 */
	function widget( $args, $instance ) {

		global $wp_query, $_genesis_displayed_ids;

		extract( $args );

		/** Merge with defaults */
		$instance = wp_parse_args( (array) $instance, $this->defaults );

		wp_enqueue_script( 'jquery-flexslider' );

		echo $before_widget;

		if ( ! empty( $instance['title'] ) )
			echo $before_title . apply_filters( 'widget_title', $instance['title'], $instance, $this->id_base ) . $after_title;

		if ( $instance['display'] == 'slideshow' ) {
			$output = '<div id="jono-slider-'. rand( 1, 100 ) .'" class="jono-flexslider attachment-slideshow" data-effect="'. esc_attr( $instance['effect'] ) .'">';
				$output .= '<ul class="jono-slides cf">';
		} else {
			$output = '<div class="portfolio-grid">';
				$output .= '<ul class="cf">';
		}

			$wp_query = new WP_Query( array(
				'post_type' 				=> 'portfolio_item',
				'showposts'					=> $instance['portfolio_num'],
				'no_found_rows' 			=> true,
	    		'update_post_term_cache' 	=> false,
	    		'update_post_meta_cache' 	=> false ) );

				if ( have_posts() ) :
					while ( have_posts() ) : the_post();
					if ( $instance['display'] == 'slideshow' ) {
						$img = genesis_get_image( array( 'format' => 'url', 'size' => 'jono-featured' ) );
					} else {
						$img = genesis_get_image( array( 'format' => 'url', 'size' => 'jono-square' ) );
					}
					$output .= '<li>';
						$output .= '<a class="portfolio-widget-link" href="'. get_permalink() .'" title="'. get_the_title() .'">';
						if ( has_post_thumbnail() || genesis_get_image_id() ) {
							$output .= '<img src="'. esc_url( $img ) .'" alt="'. get_the_title() .'" title="'. get_the_title() .'" />';
						} else {
							$output .= '<img src="'. JONO_ASSETS_URI .'images/placeholder.png" alt="'. get_the_title() .'" title="'. get_the_title() .'" />';
						}
						$output .= '</a>';
					$output .=	'</li>';

					endwhile;
				endif;

			$output .= '</ul>';
		$output .= '</div>';
		echo $output;

		wp_reset_query();

		echo $after_widget;
		
	}

}