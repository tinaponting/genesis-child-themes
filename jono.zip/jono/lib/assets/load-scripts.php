<?php
/**
 * This file control Jono Theme Scripts
 *
 * @package     Jono
 * @author      aprakasa
 * @license     GPL-2.0+
 * @link        http://prakasa.me/go/jono
 */

/** Exit if accessed directly */
if ( ! defined( "ABSPATH" ) ) exit;

add_action( 'wp_enqueue_scripts', 'jono_enqueue_scripts', 5 );
/**
 * This function control scripts loader
 *
 * @since 	1.0
 */
function jono_enqueue_scripts(){
	if ( is_post_type_archive( 'portfolio_item' ) || is_tax( 'portfolio' ) )
		wp_enqueue_script( 'jquery-isotope' );
	if ( is_post_type_archive( 'portfolio_item' ) || is_tax( 'portfolio' ) || is_singular( 'portfolio_item' ) )
		wp_enqueue_script( 'jquery-magnific-popup' );
	if ( is_singular() && has_shortcode( get_post_field( 'post_content', get_the_ID() ), 'slideshow' ) ) {
		wp_enqueue_script( 'jquery-flexslider' );
		wp_enqueue_script( 'jquery-magnific-popup' );
	}
	wp_enqueue_script( 'jono' );
}

remove_action( 'wp_head', 'genesis_html5_ie_fix' );
add_action( 'wp_head', 'jono_html5_ie_fix', 9 );
/**
 * Replace genesis_html5_ie_fix() with jono_html5_ie_fix().
 *
 * @since 1.0.0
 */
function jono_html5_ie_fix() {
	if ( ! genesis_html5() )
		return;	
		$output = '<!--[if lt IE 9]><script src="//cdnjs.cloudflare.com/ajax/libs/html5shiv/3.6.2/html5shiv.min.js"></script><![endif]-->' . "\n";
		$output .= '<!--[if lt IE 9]><script src="//cdnjs.cloudflare.com/ajax/libs/respond.js/1.2.0/respond.min.js"></script><![endif]-->' . "\n";
		$output .= '<!--[if lt IE 9]><script src="//cdnjs.cloudflare.com/ajax/libs/selectivizr/1.0.2/selectivizr-min.js"></script><![endif]-->' . "\n";
	echo $output;
}