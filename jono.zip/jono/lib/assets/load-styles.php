<?php
/**
 * This file control Jono Theme styles
 *
 * @package     Jono
 * @author      aprakasa
 * @license     GPL-2.0+
 * @link        http://prakasa.me/go/jono
 */

/** Exit if accessed directly */
if ( ! defined( "ABSPATH" ) ) exit;

add_action( 'wp_enqueue_scripts', 'jono_enqueue_styles', 5 );
/**
 * This function control styles registration and style enqueue
 *
 * @since 1.0
 */
function jono_enqueue_styles(){
    $browser = $_SERVER['HTTP_USER_AGENT'];
    $browser = substr( "$browser", 25, 8 );
    /** Enqueue Google Webfonts */
    jono_enqueue_google_webfonts();
    /** Jono Style */
    wp_enqueue_style( "jono" );
    /** Jono Plugins */
    if (class_exists( 'GFForms' ) ||
        class_exists( 'FluidVideoEmbed' ) ||
        class_exists( 'Genesis_Latest_Tweets' ) ||
        class_exists( 'BJGK_Genesis_eNews_Extended' ) ||
        function_exists( 'wpcf7_enqueue_styles' ) ||
        ( is_singular() && has_shortcode( get_post_field( 'post_content', get_the_ID() ), 'slideshow' ) ) )
            wp_enqueue_style( "jono-plugins" );
    /** Portfolio Style */
    if ( is_post_type_archive( 'portfolio_item' ) || is_singular( 'portfolio_item' ) || is_tax( 'portfolio' ) )
        wp_enqueue_style( 'jono-plugins' );
    /** AQPB Style */
    if ( class_exists( 'AQ_Page_Builder' ) ) {
        if ( is_singular() && has_shortcode( get_post_field( 'post_content', get_the_ID() ), 'template' ) )
            wp_enqueue_style( 'jono-aqpb' );
        if ( class_exists( 'Custom_Content_Portfolio' ) && is_singular() && has_shortcode( get_post_field( 'post_content', get_the_ID() ), 'template' ) ) {
            wp_enqueue_style( 'jono-plugins' );
        }
    }
    wp_enqueue_style( 'jono-ie8' );
}

/**
 * This function control google fonts enqueue
 *
 * @since 1.0
 */
function jono_enqueue_google_webfonts(){
    $browser = $_SERVER['HTTP_USER_AGENT'];
    $browser = substr( "$browser", 25, 8 );
    $heading 	= jono_get_option( 'heading_font' );
    $bodyfont 	= jono_get_option( 'body_font' );
    if ( ! empty( $heading ) ) {        
        $gheading = str_replace(" ", "+", $heading );
        $gheading_id = strtolower( str_replace(" ", "-", $heading ) );
        if ( in_array( $heading, jono_get_google_webfonts() ) ) {
            if ( $browser == "MSIE 7.0" || $browser == "MSIE 8.0" ) {
                wp_enqueue_style( "$gheading_id-400", "//fonts.googleapis.com/css?family=$gheading:400", array(), CHILD_THEME_VERSION, "all" );
                wp_enqueue_style( "$gheading_id-400italic", "//fonts.googleapis.com/css?family=$gheading:400italic", array(), CHILD_THEME_VERSION, "all" );
                wp_enqueue_style( "$gheading_id-700", "//fonts.googleapis.com/css?family=$gheading:700", array(), CHILD_THEME_VERSION, "all" );
                wp_enqueue_style( "$gheading_id-700italic", "//fonts.googleapis.com/css?family=$gheading:700italic", array(), CHILD_THEME_VERSION, "all" );
                wp_enqueue_style( "$gheading_id-subset", "//fonts.googleapis.com/css?family=$gheading&subset=latin,latin-ext,greek,greek-ext,cyrillic,cyrillic-ext,vietnamese,khmer", array(), CHILD_THEME_VERSION, "all" );
            } else {
                wp_enqueue_style( "$gheading_id", "//fonts.googleapis.com/css?family=$gheading:400,400italic,700,700italic&subset=latin,latin-ext,greek,greek-ext,cyrillic,cyrillic-ext,vietnamese,khmer", array(), CHILD_THEME_VERSION, "all" );
            }
        }
    }
    if ( ! empty( $bodyfont ) ) {
        if( $heading == $bodyfont )
            return;
        $gbodyfont = str_replace(" ", "+", $bodyfont );
        $gbodyfont_id = strtolower( str_replace(" ", "-", $bodyfont ) );
        if ( in_array( $bodyfont, jono_get_google_webfonts() ) ) {
            if ( $browser == "MSIE 7.0" || $browser == "MSIE 8.0" ) {
                wp_enqueue_style( "$gbodyfont_id-400", "//fonts.googleapis.com/css?family=$gbodyfont:400", array(), CHILD_THEME_VERSION, "all" );
                wp_enqueue_style( "$gbodyfont_id-400italic", "//fonts.googleapis.com/css?family=$gbodyfont:400italic", array(), CHILD_THEME_VERSION, "all" );
                wp_enqueue_style( "$gbodyfont_id-700", "//fonts.googleapis.com/css?family=$gbodyfont:700", array(), CHILD_THEME_VERSION, "all" );
                wp_enqueue_style( "$gbodyfont_id-700italic", "//fonts.googleapis.com/css?family=$gbodyfont:700italic", array(), CHILD_THEME_VERSION, "all" );
                wp_enqueue_style( "$gbodyfont_id-subset", "//fonts.googleapis.com/css?family=$gbodyfont&subset=latin,latin-ext,greek,greek-ext,cyrillic,cyrillic-ext,vietnamese,khmer", array(), CHILD_THEME_VERSION, "all" );
            } else {
                wp_enqueue_style( "$gbodyfont_id", "//fonts.googleapis.com/css?family=$gbodyfont:400,400italic,700,700italic&subset=latin,latin-ext,greek,greek-ext,cyrillic,cyrillic-ext,vietnamese,khmer", array(), CHILD_THEME_VERSION, "all" );
            }
        }
    }
}

/**
 * Callback function for custom-background
 *
 * @since   1.0
 */
function jono_custom_background_cb() {
    $background = get_background_image();
    $color = get_background_color();
    if ( ! $background && ! $color )
        return;
    $style = $color ? "background-color: #$color;" : '';
    if ( $background ) {
        $image = " background-image: url('$background');";
        $repeat = get_theme_mod( 'background_repeat', 'repeat' );
        if ( ! in_array( $repeat, array( 'no-repeat', 'repeat-x', 'repeat-y', 'repeat' ) ) )
            $repeat = 'repeat';
        $repeat = " background-repeat: $repeat;";
        $position = get_theme_mod( 'background_position_x', 'left' );
        if ( ! in_array( $position, array( 'center', 'right', 'left' ) ) )
            $position = 'left';
        $position = " background-position: top $position;";
        $attachment = get_theme_mod( 'background_attachment', 'scroll' );
        if ( ! in_array( $attachment, array( 'fixed', 'scroll' ) ) )
            $attachment = 'scroll';
        $attachment = " background-attachment: $attachment;";
        $style .= $image . $repeat . $position . $attachment;
    }
    return trim( $style );
}


add_action( 'wp_head', 'jono_print_inline_styles', 8 );
/**
 * This function control custom styles
 *
 * @since 1.0
 * @todo cleanup code
 */
function jono_print_inline_styles(){
    $browser = $_SERVER['HTTP_USER_AGENT'];
    $browser = substr( "$browser", 25, 8);

    $logo_img       = jono_get_option( 'image_logo' );
    $logo_width     = jono_get_option( 'image_logo_width' );
    $logo_height    = jono_get_option( 'image_logo_height' );

    $css= '';
    $css .= 'body.custom-background{'. jono_custom_background_cb() .'}';

    if ( ! empty( $logo_img ) ) {
        $css .=
        '.image-logo .site-title a { 
            background-image: url('. esc_url( $logo_img ) .');
            width: '. (int)$logo_width  .'px;
            height: '. (int)$logo_height .'px;
            max-width: 100%;
        }';
    }

    if ( jono_get_option( 'heading_font' ) ) {
        $aqpb_heading_font = ( class_exists( 'AQ_Page_Builder') ) ? ', .aq-block-jono_action_block .large-text' : '';
        $css .= '
            h1, h2, h3, h4 ,h5, h5, h6,
            .site-title '. $aqpb_heading_font .' {
                font-family:"'. jono_get_option( 'heading_font' ) .'", sans-serif;
                font-weight:'. jono_get_option( 'heading_weight' ) .';
            }
        ';
    }

    if ( jono_get_option( 'body_font' ) ) {
        $css .= '
            body,
            .site-description,
            .genesis-nav-menu {
                font-family:"'. jono_get_option( 'body_font' ) .'", sans-serif;
            }
        ';
    }

    if ( jono_get_option( 'heading_one' ) ) {
        $css .=' h1 { font-size: '. (int)jono_get_option( 'heading_one' ) .'px } ';
    }

    if ( jono_get_option( 'heading_two' ) ) {
        $css .=' h2 { font-size: '. (int)jono_get_option( 'heading_two' ) .'px } ';
    }

    if ( jono_get_option( 'heading_three' ) ) {
        $css .=' h3 { font-size: '. (int)jono_get_option( 'heading_three' ) .'px } ';
    }

    if ( jono_get_option( 'heading_four' ) ) {
        $css .=' h4 { font-size: '. (int)jono_get_option( 'heading_four' ) .'px } ';
    }

    if ( jono_get_option( 'heading_five' ) ) {
        $css .=' h5 { font-size: '. (int)jono_get_option( 'heading_five' ) .'px } ';
    }

    if ( jono_get_option( 'heading_six' ) ) {
        $css .=' h6 { font-size: '. (int)jono_get_option( 'heading_six' ) .'px } ';
    }

    if ( jono_get_option( 'body_font_size' ) ) {
        $css .=' body { font-size: '. (int)jono_get_option( 'body_font_size' ) .'px } ';
    }

    if ( jono_get_option( 'widget_size' ) ) {
        $aqpb_widget_size = ( class_exists( 'AQ_Page_Builder') ) ? ', h4.aq-block-title' : '';
        $css .=' h4.widget-title '. $aqpb_widget_size .' { font-size: '. (int)jono_get_option( 'widget_size' ) .'px } ';
    }

    if ( jono_get_option( 'primary_color' ) ) {
        $aqpb_primary_color = ( class_exists( 'AQ_Page_Builder') ) ? ', ol.jono-control-nav a.jono-active, .jono-direction-nav a:hover, .client-prev:hover, .client-next:hover' : '';
        $css .= '
            .site-header,
            .widget-title:after,
            .entry-footer:after,
            .genesis-nav-menu .sub-menu a:hover,
            #wp-calendar caption,
            .pagination li a:hover,
            .pagination li.active a
            '. $aqpb_primary_color .'{ background-color: '. jono_get_option( 'primary_color' ) .' }

            ::-moz-selection { background-color: '. jono_get_option( 'primary_color' ) .' }

            ::selection { background-color: '. jono_get_option( 'primary_color' ) .' }

            .footer-widgets { border-color: '. jono_get_option( 'primary_color' ) .' }
        ';
    }

    if ( jono_get_option( 'hyperlink_color' ) ) {
        $aqpb_hyperlink_color = ( class_exists( 'AQ_Page_Builder') ) ? ', .portfolio-filter li a.active' : '';
        $css .= '
            a '. $aqpb_hyperlink_color .' { color: '. jono_get_option( 'hyperlink_color' ) .' }
        ';

        $aqpb_hyperlink_color_bg = ( class_exists( 'AQ_Page_Builder') ) ? ', a.featured-button' : '';
        $css .= '
            .widget_tag_cloud a,
            button,
            input[type="button"],
            input[type="reset"],
            input[type="submit"],
            .button,
            .entry-content .button,
            .sidebar .featuredpage a.more-link
            '. $aqpb_hyperlink_color_bg .'{ background-color: '. jono_get_option( 'hyperlink_color' ) .' }
        ';

        $css .= '
            input:focus,
            textarea:focus { border-color: '. jono_get_option( 'hover_color' ) .' }
        ';
    }

    if ( jono_get_option( 'hover_color' ) ) {        
        $aqpb_hover_color = ( class_exists( 'AQ_Page_Builder' ) ) ? ', .featured-page h2 a:hover, .portfolio-filter li a:hover' : '';        
        $css .= '
            a:hover,
            .entry-title a:hover,
            .sidebar .current-menu-item,
            .sidebar .current-menu-item a,
            .portfolio-meta a:hover'
            . $aqpb_hover_color .' { color: '. jono_get_option( 'hover_color' ) .' }
        ';
        
        $aqpb_hover_color_bg = ( class_exists( 'AQ_Page_Builder' ) ) ? ', a.featured-button:hover, .featured-page:hover .featured-icon, .featured-page:hover .featured-icon:after' : '';
        $css .= '
            .widget_tag_cloud a:hover,
            button:hover,
            input:hover[type="button"],
            input:hover[type="reset"],
            input:hover[type="submit"],
            .button:hover,
            .sidebar .featuredpage a.more-link:hover,
            .entry-content .button:hover,
            .portfolio-thumbnail:before,
            a.portfolio-widget-link:before'
            . $aqpb_hover_color_bg .' { background-color: '. jono_get_option( 'hover_color' ) .'}
        ';
    }

    if ( ! empty( $css ) ) {
       echo "<!-- Custom Style -->\n<style type='text/css'>". jono_minify( $css ) ."</style>\n";
    }
}