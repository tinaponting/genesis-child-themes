<?php
/**
 * This file controls plugins tweaks
 *
 * @package 	Jono
 * @author   	aprakasa
 * @license  	GPL-2.0+
 * @link     	http://prakasa.me/go/jono
 */

/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! function_exists( 'jono_require_plugin' ) ) :
/**
 * Helper function if some feature require plugin
 * 
 * @since   1.0
 */
function jono_require_plugin( $slug, $name ) { 
    return sprintf( __( 'Please install and activate %s%s%s plugin if want to use this feature.', 'jono' ), '<a href="//wordpress.org/extend/plugins/'. esc_attr( $slug ) .'" target="_blank">', esc_attr( $name ), '</a>' );
}
endif; /** EOF jono_require_plugin() */

add_filter( 'wpseo_opengraph_type', 'jono_opengraph_type', 10, 1 );
/**
 * Force front page opengraph type into website if using canvas template
 * 
 * @since   1.0
 */
function jono_opengraph_type( $type ) {
    if ( is_front_page() && is_page_template( 'canvas.php' ) ) {
        return 'website';
    } else {
        return 'article';
    }
}

add_action( 'wp_enqueue_scripts', 'jono_unregister_default_wpcf7_styles' );
/**
 * Unregister default Contact Form 7 Sylesheet plugin
 * 
 * @since  	1.0
 */
function jono_unregister_default_wpcf7_styles(){
	if ( function_exists( 'wpcf7_enqueue_styles' ) )
		wp_dequeue_style( 'contact-form-7' );	
}

add_action( 'init', 'jono_unregister_plugin_scripts', 15 );
/** 
 * Remove default script and style from some plugin
 * 
 * @since 	1.0
 */
function jono_unregister_plugin_scripts() {
    if ( class_exists( 'AQ_Page_Builder' ) ) {
        wp_dequeue_style( 'aqpb-view-css' );
        wp_dequeue_script( 'aqpb-view-js' );
    }
    if ( class_exists( 'FluidVideoEmbed' ) ) {
        global $fve;
        remove_action( 'wp_head', array( $fve, 'add_head_css' ) );
    }
}