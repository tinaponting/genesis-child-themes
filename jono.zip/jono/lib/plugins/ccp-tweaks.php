<?php
/**
 * This file controls custom content portfolio tweaks
 *
 * @package 	Jono
 * @author   	aprakasa
 * @license  	GPL-2.0+
 * @link     	http://prakasa.me/go/jono
 */

/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;

/** Fix pagination bugs for taxonomy */
remove_action( 'init', 'ccp_register_taxonomies' );
add_action( 'init', 'ccp_register_taxonomies', 9 );

add_filter( 'option_plugin_custom_content_portfolio', 'jono_ccp_plugin_settings' );
add_filter( 'default_option_plugin_custom_content_portfolio', 'jono_ccp_plugin_settings' );
/**
 * Function to filter portfolio slug
 *
 * @since   1.0
 */
function jono_ccp_plugin_settings( $settings ) {
    $portfolio = ( genesis_get_option( 'portfolio_name', JONO_SETTINGS ) ) ? genesis_get_option( 'portfolio_name', JONO_SETTINGS ) : 'portfolio';
    $settings['portfolio_root'] = sanitize_title_with_dashes( $portfolio );
    return $settings;
}

add_filter( 'post_type_labels_portfolio_item', 'jono_portfolio_labels' );
/**
 * Function to filter portfolio label
 *
 * @since   1.0
 */
function jono_portfolio_labels( $labels ) {
    $labels->name           = ( genesis_get_option( 'portfolio_name', JONO_SETTINGS ) ) ? genesis_get_option( 'portfolio_name', JONO_SETTINGS ) : 'portfolio';
    $labels->menu_name      = ( genesis_get_option( 'portfolio_menu_name', JONO_SETTINGS ) ) ? genesis_get_option( 'portfolio_menu_name', JONO_SETTINGS ) : 'portfolio';
    $labels->archive_title  = ( genesis_get_option( 'portfolio_archive_title', JONO_SETTINGS ) ) ? genesis_get_option( 'portfolio_archive_title', JONO_SETTINGS ) : 'portfolio';
    return $labels;
}

add_filter( 'post_class', 'jono_portfolio_posts_class' );
/** 
 * Custom post classes for Portfolio item
 * 
 * @since   1.0 
 */
function jono_portfolio_posts_class( $classes ) {
    if ( is_post_type_archive( 'portfolio_item' ) || is_tax( 'portfolio' ) ) {
        $classes[] = 'portfolio-entry';
        if ( genesis_get_option( 'portfolio_columns', JONO_SETTINGS ) == '2' ) {
            $classes[] = 'span6';
        } elseif ( genesis_get_option( 'portfolio_columns', JONO_SETTINGS ) == '3' ) {
            $classes[] = 'span4';
        } elseif ( genesis_get_option( 'portfolio_columns', JONO_SETTINGS ) == '4' ) {
            $classes[] = 'span3';
        }
        $terms = get_the_terms( get_the_ID(), 'portfolio' );
        if( $terms ) {
            foreach ( $terms as $term ) { 
                $classes[] = 'portfolio-'.$term->slug; 
            }
        }
    }
    return $classes;
}

add_filter( 'pre_get_posts', 'jono_portfolio_archive' );
/**
 * Customize portfolio archive query.
 *
 * @since   1.0
 */
function jono_portfolio_archive( $q ) {
    if ( ! class_exists( 'Custom_Content_Portfolio' ) )
        return;
    if ( ! $q->is_main_query() )
        return;
    if ( ! $q->is_post_type_archive( 'portfolio_item' ) && ! $q->is_tax( 'portfolio' ) )
        return;
    if ( ! $q->is_tax( 'portfolio' ) )
        $q->set( 'post_type', 'portfolio_item' );
        $q->set( 'posts_per_page', $q->get( 'posts_per_page' ) ? $q->get( 'posts_per_page' ) : genesis_get_option( 'portfolio_posts', JONO_SETTINGS ) );
        $q->set( 'order', $q->get( 'order' ) ? $q->get( 'order' ) : genesis_get_option( 'portfolio_order', JONO_SETTINGS ) );
        $q->set( 'orderby', $q->get( 'orderby' ) ? $q->get( 'orderby' ) : genesis_get_option( 'portfolio_orderby', JONO_SETTINGS ) );
}

/** Add Genesis metabox at Portfolio */
add_post_type_support( 'portfolio_item', 
    array(
        'genesis-layouts',
        'genesis-seo',
        'genesis-scripts',
        'genesis-cpt-archives-settings',
        'genesis-simple-sidebars' ) );

add_filter( 'genesis_attr_content', 'jono_attributes_portfolio', 20 );
/**
 * Function to filter genesis_attr_content
 *
 * @since   1.0
 */
function jono_attributes_portfolio( $attributes ) {
    if ( is_post_type_archive( 'portfolio_item' ) || is_singular( 'portfolio_item' ) || is_tax( 'portfolio' ) )
        $attributes['itemscope']    = 'itemscope';
        $attributes['itemtype']     = '';
    return $attributes;
}

add_filter( 'genesis_attr_entry-content', 'jono_attributes_entry_portfolio', 20 );
/**
 * Function to filter genesis_attr_entry-content
 *
 * @since   1.0
 */
function jono_attributes_entry_portfolio( $attributes ) {
    if ( is_post_type_archive( 'portfolio_item' ) || is_singular( 'portfolio_item' ) || is_tax( 'portfolio' ) )
        $attributes['itemprop'] = 'text';
    return $attributes;
}

add_action( 'genesis_meta', 'jono_portfolio_loop' );
/**
 * Custom loop for portfolio.
 *
 * @since   1.0
 */
function jono_portfolio_loop() {

    if ( is_post_type_archive( 'portfolio_item' ) || is_tax( 'portfolio' ) ) {
        remove_action( 'genesis_entry_header', 'genesis_do_post_format_image', 4 );
        remove_action( 'genesis_entry_content', 'genesis_do_post_image', 8 );
        remove_action( 'genesis_entry_header', 'genesis_post_info', 12 );   
        remove_action( 'genesis_entry_content', 'genesis_do_post_content' );
        remove_action( 'genesis_entry_content', 'genesis_do_post_permalink', 14 );
        remove_action( 'genesis_entry_footer', 'genesis_post_meta' );
        remove_action( 'genesis_entry_content', 'genesis_do_post_content_nav', 12 );
        remove_action( 'genesis_after_endwhile', 'genesis_posts_nav' );

        add_action( 'genesis_before_loop', 'jono_isotope_container_open', 99 );
        add_action( 'genesis_after_loop', 'jono_isotope_container_close', 5 );
        add_action( 'genesis_after_loop', 'genesis_posts_nav' );
        add_action( 'genesis_entry_header', 'jono_portfolio_thumbnail', 8 );
        add_action( 'genesis_entry_footer', 'jono_portfolio_footer_meta' );

        add_filter( 'genesis_site_layout', '__genesis_return_full_width_content' );
    }

    if ( is_post_type_archive( 'portfolio_item' ) ) {
        add_action( 'genesis_before_loop', 'jono_portfolio_filter', 15 );
    }

    if ( is_singular( 'portfolio_item' ) ) {
        remove_action( 'genesis_entry_header', 'genesis_do_post_format_image', 4 );
        remove_action( 'genesis_entry_header', 'genesis_post_info', 12 );
        remove_action( 'genesis_entry_content', 'genesis_do_post_image', 8 );
        remove_action( 'genesis_entry_content', 'genesis_do_post_permalink', 14 );
        remove_action( 'genesis_entry_footer', 'genesis_post_meta' );
        remove_action( 'genesis_after_entry', 'genesis_do_author_box_single', 8 );

        add_action( 'genesis_entry_header', 'jono_portfolio_info', 10 );
    }

}

/**
 * Portfolio filter markup.
 *
 * @since   1.0
 */
function jono_portfolio_filter(){
    $terms = get_terms( 'portfolio', array( 'hide_empty' => '1' ) );
    if ( ! empty( $terms ) ) {
        $output = '<div class="portfolio-filter">';
            $output .= '<ul>';
                $output .= '<li><a href="#" data-filter="*" class="active">'. __( 'All', 'jono' ) .'</a></li>';
            foreach ( $terms as $term ) : 
                $output .= '<li><a href="#" data-filter=".portfolio-'. $term->slug .'"><span>'. $term->name .'</span></a></li>';
            endforeach;
            $output .= '</ul>';
        $output .= '</div>';
    }
    echo $output;
}

/**
 * Open Isotope container.
 *
 * @since   1.0
 */
function jono_isotope_container_open(){
    echo '<div class="isotope-container">';
}

/**
 * CLose Isotope container.
 *
 * @since   1.0
 */
function jono_isotope_container_close(){
    echo '</div>';
}


/**
 * Portfolio thumbnail markup.
 *
 * @since   1.0
 */
function jono_portfolio_thumbnail(){
    $featured  = genesis_get_image( array( 'format' => 'url', 'size' => 'jono-featured' ) );
    $images    = genesis_get_image( array( 'format' => 'url', 'size' => 'large' ) );
    $thumbnail = genesis_get_image( array( 'format' => 'url', 'size' => 'thumbnail' ) );
    $output = '';
    if ( has_post_thumbnail() || genesis_get_image_id() ) {
        $output .= '<div class="portfolio-thumbnail">';
            $output .= '<link itemprop="thumbnailUrl" href="'. $thumbnail .'" />';
            $output .= '<img src="'. esc_url( $featured ) .'" alt="'. get_the_title() .'" itemprop="image"/>';
            $output .= '<a href="'. esc_url( $images ) .'" class="portfolio-resize" title="'. get_the_title() .'"></a>';
        $output .= '</div>';
    } else {
        $output .= '<div class="no-thumbnail">';
            $output .= '<img src="'. JONO_ASSETS_URI .'images/placeholder.png" alt="'. get_the_title() .'" />';
        $output .= '</div>';
    }
    echo $output;
}

/**
 * Single Portfolio info.
 *
 * @since   1.0
 */
function jono_portfolio_info() {
    $output ='';
    if ( has_post_thumbnail() ) {
        $thumbnail = genesis_get_image( array( 'format' => 'url', 'size'  => 'thumbnail' ) );
        $output .= '<link itemprop="thumbnailUrl" href="'. $thumbnail .'" />';
    }
    $output .= '<div class="portfolio-detail cf">';

        $output .= '<ul>';
            $output .=
                sprintf( '<li><i class="icon-calendar"></i><b>%s :</b> %s</li>',
                    __( 'Date Published', 'jono' ), 
                    do_shortcode( '[post_date]' ) );

            if ( genesis_get_custom_field( '_portfolio_item_client' ) ) {
            $output .= 
                sprintf( '<li><i class="icon-star"></i><b>%s :</b> %s </li>',
                    __( 'Client', 'jono' ),
                    genesis_get_custom_field( '_portfolio_item_client' ) );
            }

            $output .= 
                sprintf( '<li><i class="icon-tag"></i><b>%s :</b> %s</li>',
                    __( 'Tags', 'jono' ),
                    get_the_term_list( get_the_ID(), 'portfolio', '', ', ', '' ) );

            if ( genesis_get_custom_field( 'portfolio_item_url' ) ) {
                $output .=
                sprintf( '<li><i class="icon-link"></i><a class="project-link" href="%s">%s</a></li>', 
                    esc_url( genesis_get_custom_field( 'portfolio_item_url' ) ),
                    __( 'Visit Project &rarr;', 'jono' ) );
            }

        $output .= '</ul>';

    $output .= '</div>';

    echo $output;
}

/**
 * Portfolio meta at portfolio archive.
 *
 * @since   1.0
 */
function jono_portfolio_footer_meta() {
    echo sprintf( '<span class="portfolio-meta" itemprop="keywords">%s</span> ', get_the_term_list( get_the_ID(), 'portfolio', '', ', ', '' ) );
}

add_shortcode( 'slideshow', 'jono_attachment_slideshow' );
/**
 * Attachment slideshow shortcode.
 *
 * @since   1.0
 */
function jono_attachment_slideshow( $atts ) {
    $defaults = array(
        'effect'    => 'slide' );
    $atts = shortcode_atts( $defaults, $atts );
    $args = array(
        'post_type'                 => 'attachment',
        'numberposts'               => -1,
        'post_status'               => null,
        'post_parent'               => get_the_ID(),
        'order'                     => 'ASC',
        'orderby'                   => 'menu_order',
        'no_found_rows'             => true,
        'cache_results'             => false,
        'update_post_term_cache'    => false,
        'update_post_meta_cache'    => false  );
    $output = '';
    $output .= '<div id="jono-slider-'. rand( 1, 100 ) .'" class="jono-flexslider attachment-slideshow" data-effect="'. esc_attr( $atts['effect'] ) .'">';
        $output .= '<ul class="jono-slides cf">';
        $attachments = get_posts( $args );        
            if ( $attachments ) {
                foreach ( $attachments as $post ) {                    
                setup_postdata( $post );
                $output .= '<li>';
                    $output .= '<div class="portfolio-thumbnail">';
                    $output .= sprintf( '<img src="%1$s" alt="%2$s" title="%2$s" itemprop="image"/>',
                                        wp_get_attachment_url( $post->ID, 'large' ),
                                        $post->post_title );
                    $output .= sprintf( '<a href="%1$s" title="%2$s" class="portfolio-resize"></a>',
                                        wp_get_attachment_url( $post->ID, 'large' ),
                                        $post->post_title );
                    $output .= '</div>';
                $output .= '</li>';
            }
        }
        $output .= '</ul>';
    $output .= '</div>';
    return apply_filters( 'jono_attachment_slideshow', $output, $atts );
    wp_reset_postdata();
}