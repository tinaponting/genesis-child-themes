<?php
/**
 * Tweaks some function that are already exist from Genesis core
 *
 * @package 	Jono
 * @author   	aprakasa
 * @license  	GPL-2.0+
 * @link     	http://prakasa.me/go/jono
 */

/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;

add_action( 'genesis_admin_before_metaboxes', 'jono_remove_genesis_theme_metaboxes' );
/**
 * Remove selected Genesis metaboxes from the Settings pages.
 * 
 * @since 1.0.0
 */
function jono_remove_genesis_theme_metaboxes( $hook ) {
	remove_meta_box( 'genesis-theme-settings-header', $hook, 'main' );
	remove_meta_box( 'genesis-theme-settings-nav', $hook, 'main' );
	remove_meta_box( 'genesis-cpt-archives-layout-settings', 'portfolio_item_page_genesis-cpt-archive-portfolio_item', 'main' );
}

global $wp_embed;
/**
 * Render shortcode and add autoembed for post type archive text.
 * 
 * @since 1.0.2
 */
add_filter( 'genesis_cpt_archive_intro_text_output', 'do_shortcode' );
add_filter( 'genesis_cpt_archive_intro_text_output', array( $wp_embed, 'run_shortcode'), 8 );
add_filter( 'genesis_cpt_archive_intro_text_output', array( $wp_embed, 'autoembed'), 8 );

if ( is_front_page() && is_page_template( 'canvas.php' ) ) {
	add_filter( 'genesis_seo_title', 'jono_title', 10, 3 );
}
/**
 * Wrap canvas page title into <H1> if set as front page.
 * 
 * @since 1.0.0
 */
function jono_title( $title, $inside, $wrap ){
	$inside = sprintf( '<a href="%s" title="%s">%s</a>', trailingslashit( home_url() ), esc_attr( get_bloginfo( 'name' ) ), get_bloginfo( 'name' ) );
	$wrap = is_home() && 'title' === genesis_get_seo_option( 'home_h1_on' ) || is_front_page() && is_page_template( 'canvas.php' ) && 'title' === genesis_get_seo_option( 'home_h1_on' )? 'h1' : 'p';
	$wrap = is_home() && ! genesis_get_seo_option( 'home_h1_on' ) || is_front_page() && is_page_template( 'canvas.php' ) && ! genesis_get_seo_option( 'home_h1_on' )? 'h1' : $wrap;
	$wrap = genesis_html5() && genesis_get_seo_option( 'semantic_headings' ) ? 'h1' : $wrap;
	$title  = genesis_html5() ? sprintf( "<{$wrap} %s>", genesis_attr( 'site-title' ) ) : sprintf( '<%s id="title">%s</%s>', $wrap, $inside, $wrap );
	$title .= genesis_html5() ? "{$inside}</{$wrap}>" : '';
	echo $title;
}

if ( jono_get_option( 'old_favicon' ) ) {
	remove_action( 'wp_head', 'genesis_load_favicon' );
	add_action( 'wp_head', 'jono_load_favicon', 5 );
}
/**
 * Branding Meta.
 * 
 * @since 1.0.0
 */
function jono_load_favicon() {
	$output = '';
	if ( jono_get_option( 'old_favicon' ) )
		$output .= '<link rel="icon" href="'. esc_url( jono_get_option( 'old_favicon' ) ) .'">'."\n";
	if ( jono_get_option( 'favicon_image' ) )
		$output .= '<link rel="icon" href="'. esc_url( jono_get_option( 'favicon_image' ) ) .'">'."\n";
	if ( jono_get_option( 'apple_touch_144' ) )
		$output .= '<link rel="apple-touch-icon" sizes="144x144" href="'. esc_url( jono_get_option( 'apple_touch_144' ) ) .'">';
	if ( jono_get_option( 'apple_touch_114' ) )
		$output .= '<link rel="apple-touch-icon" sizes="114x114" href="'. esc_url( jono_get_option( 'apple_touch_114' ) ) .'">';
	if ( jono_get_option( 'apple_touch_72' ) )
		$output .= '<link rel="apple-touch-icon" sizes="72x72" href="'. esc_url( jono_get_option( 'apple_touch_72' ) ) .'">';
	if ( jono_get_option( 'apple_touch_57' ) )
		$output .= '<link rel="apple-touch-icon" href="'. esc_url( jono_get_option( 'apple_touch_57' ) ) .'">';
	if ( jono_get_option( 'apple_touch_144') )
		$output .= '<meta name="msapplication-TileImage" content="'. esc_url( jono_get_option( 'apple_touch_144' ) ) .'">';
	if ( jono_get_option( 'apple_touch_144' ) && jono_get_option( 'primary_color') )
		$output .= '<meta name="msapplication-TileColor" content="'. jono_get_option( 'primary_color' ) .'">'."\n";
	echo apply_filters( 'jono_load_favicon', $output );
}

add_filter( 'genesis_breadcrumb_args', 'jono_breadcrumb_args' );
/**
 * Function to filter Genesis Breadcrumb
 *
 * @since 1.0
 */
function jono_breadcrumb_args( $args ) {
	$args['home']                    = __( 'Home', 'jono' );
	$args['sep']                     = ' / ';
	$args['list_sep']                = ', '; // Genesis 1.5 and later
	$args['prefix']                  = '<div class="breadcrumb">';
	$args['suffix']                  = '</div>';
	$args['heirarchial_attachments'] = true; // Genesis 1.5 and later
	$args['heirarchial_categories']  = true; // Genesis 1.5 and later
	$args['display']                 = true;
	$args['labels']['prefix']        = ' ';
	$args['labels']['author']        = ' ';
	$args['labels']['category']      = ' '; // Genesis 1.6 and later
	$args['labels']['tag']           = ' ';
	$args['labels']['date']          = ' ';
	$args['labels']['search']        = ' ';
	$args['labels']['tax']           = ' ';
	$args['labels']['post_type']     = ' ';
	$args['labels']['404']           = ' '; // Genesis 1.5 and later
	return $args;
}

remove_action( 'genesis_before_loop', 'genesis_do_breadcrumbs' );
add_action( 'genesis_after_header', 'jono_do_breadcrumb' );
/**
 * Replace genesis_do_breadcrumbs()
 * Wrap .breadcrumb with #breadcrumb.
 * 
 * @since 1.0.0
 */
function jono_do_breadcrumb(){
	if (
		( ( 'posts' === get_option( 'show_on_front' ) && is_home() ) && ! genesis_get_option( 'breadcrumb_home' ) ) ||
		( ( 'page' === get_option( 'show_on_front' ) && is_front_page() ) && ! genesis_get_option( 'breadcrumb_front_page' ) ) ||
		( ( 'page' === get_option( 'show_on_front' ) && is_home() ) && ! genesis_get_option( 'breadcrumb_posts_page' ) ) ||
		( is_single() && ! genesis_get_option( 'breadcrumb_single' ) ) ||
		( is_page() && ! genesis_get_option( 'breadcrumb_page' ) ) ||
		( ( is_archive() || is_search() ) && ! genesis_get_option( 'breadcrumb_archive' ) ) ||
		( is_404() && ! genesis_get_option( 'breadcrumb_404' ) ) ||
		( is_attachment() && ! genesis_get_option( 'breadcrumb_attachment' ) ) ||
		( is_page_template( 'canvas.php' ) )
	)
		return;
	echo '<div id="breadcrumb">';
		genesis_do_breadcrumbs();
	echo '</div>';
}

add_action( 'genesis_header', 'jono_do_nav' );
/**
 * Echo the "Header Navigation" menu.
 *
 * @since 1.0.0
 */
function jono_do_nav() {
	if ( ! genesis_nav_menu_supported( 'header' ) )
		return;	
	if ( has_nav_menu( 'header' ) ) {
		$class = 'menu genesis-nav-menu menu-header';
		if ( genesis_superfish_enabled() )
			$class .= ' js-superfish';
		$args = array(
			'theme_location' => 'header',
			'container'      => '',
			'menu_class'     => $class,
			'echo'           => 0,
		);
		$nav = wp_nav_menu( $args );
		if ( ! $nav )
			return;
		$nav_markup_open = genesis_markup( array(
			'html5'   => '<nav %s>',
			'xhtml'   => '<div id="nav">',
			'context' => 'nav-header',
			'echo'    => false ) );
		$nav_markup_open .= genesis_structural_wrap( 'menu-header', 'open', 0 );
		$nav_markup_close  = genesis_structural_wrap( 'menu-header', 'close', 0 );
		$nav_markup_close .= genesis_html5() ? '</nav>' : '</div>';
		$nav_output = $nav_markup_open . $nav . $nav_markup_close;
		echo apply_filters( 'jono_do_nav', $nav_output, $nav, $args );
	}
}

add_action( 'genesis_before_header', 'jono_header_info' );
/**
 * Custom hook for header info
 *
 * @since 	1.0.0
 */
function jono_header_info() {
	$email 		= jono_get_option( 'email_address' );
	$phone 		= jono_get_option( 'phone_number' );
	$output = '';
	if ( $email || $phone || has_nav_menu( 'header_social' ) ) {
		$output .= '<aside class="header-info">';
			$output .= '<div class="wrap">';
			if ( $email || $phone ) {
				if ( is_email( $email ) || $phone ) {
					$output .= '<div class="header-info-contact" itemscope="itemscope" itemtype="http://schema.org/ContactPoint">';
					if ( is_email( $email ) )
						$output .= '<span itemprop="telephone"><a href="mailto:'. antispambot( $email ) .'" class="email-address"><i class="icon-envelope"></i>'. antispambot( $email ) .'</a></span>';
					if ( $phone )
						$output .= '<span itemprop="email"><a href="tel:'. $phone .'" class="phone-number"><i class="icon-phone-sign icon-large"></i>'. $phone .'</a></span>';
					$output .= '</div>';
				} /** EOF $email && $phone */
			}
			if ( has_nav_menu( 'header_social' ) ) {
				$output .= wp_nav_menu( array(
							'theme_location'  	=> 'header_social',
							'container'       	=> 'div',
							'container_id'    	=> '',
							'container_class' 	=> 'header-social',
							'menu_id'         	=> '',
							'menu_class'      	=> 'social-profiles',
							'depth'           	=> 1,
							'link_before'     	=> '<span class="screen-reader-text">',
							'link_after'      	=> '</span>',
							'fallback_cb'     	=> '',
							'echo'           	=> 0, ) );
			}
			$output .= '</div>';
		$output .= '</aside>';
	}
	echo apply_filters( 'jono_header_info', $output );
}

add_action( 'genesis_footer', 'jono_footer_social', 8 );
/**
 * Echo the "Footer Social" menu.
 *
 * @since 1.0.0
 */
function jono_footer_social() {
	if ( has_nav_menu( 'footer_social' ) )
		echo wp_nav_menu( array(
			'theme_location'  	=> 'footer_social',
			'container'       	=> 'div',
			'container_id'    	=> '',
			'container_class' 	=> 'footer-social',
			'menu_id'         	=> '',
			'menu_class'      	=> 'social-profiles',
			'depth'           	=> 1,
			'link_before'     	=> '<span class="screen-reader-text">',
			'link_after'      	=> '</span>',
			'fallback_cb'     	=> '',
			'echo'           	=> 0, ) );
}

if ( jono_get_option( 'footer_text' ) ) {
	add_filter( 'genesis_footer_creds_text', 'jono_footer_text' );
}
function jono_footer_text( $creds_text ) {
	$creds_text = jono_get_option( 'footer_text' );
	return $creds_text;
}