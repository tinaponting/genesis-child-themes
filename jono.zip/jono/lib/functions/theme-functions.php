<?php
/**
 * This file controls all part of misc helper functions that can be reused as need it
 *
 * @package 	Jono
 * @author   	aprakasa
 * @license  	GPL-2.0+
 * @link     	http://prakasa.me/go/jono
 */

/** Exit if accessed directly */
if ( ! defined( "ABSPATH" ) ) exit;

if ( ! function_exists( 'jono_get_option' ) ) :
	/** 
	 * Get options value
	 * Set value to false since we want to sync with it with theme customizer
	 * 
	 * @since 	1.0
	 */
	function jono_get_option( $key, $use_cache = false ) {
		return genesis_get_option( $key, JONO_SETTINGS, $use_cache );
	}
	
endif;

if ( ! function_exists( 'jono_get_number' ) ) {
	/** 
	 * This file contain numbers in an array
	 * 
	 * @since 		1.0
	 */
	function jono_get_number() {
		$number = range( 0, 120 );
		$number = array_map( 'absint', $number );
		return $number;
	}
}/** EOF jono_get_number() */


if ( ! function_exists( 'jono_get_published_posts' ) ) {
	/**
	 * Returns published post type into an array
	 *
	 * @since 1.0
	 * @return array()
	 */
	function jono_get_published_posts( $name, $placeholder = '' ) {
		$post_type 	= array();
		$titles 	= get_posts( array( 
			'post_type' 		=> $name, 
			'posts_per_page'	=> -1,
			'orderby' 			=> 'menu_order',
			'order' 			=> 'ASC',
			'post_status' 		=> 'publish' ) );
		$placeholder = ( ! empty( $placeholder ) ) ? $placeholder : '';
		$post_type[''] = $placeholder;
		foreach ( $titles as $title ) :
			$post_type[$title->ID] = $title->post_title;
		endforeach;
		return $post_type;
	}

}/** EOF jono_get_published_posts() */


if ( ! function_exists( 'jono_minify' ) ) {
	/**
	 * Quick and dirty way to mostly minify CSS.
	 *
	 * @since 		1.0
	 * @author 		Gary Jones
	 * @link 		https://github.com/GaryJones/Simple-PHP-CSS-Minification
	 * @param 		string $css CSS to minify
	 * @return 		string Minified CSS
	 */
	function jono_minify( $css ) {
		// Normalize whitespace
		$css = preg_replace( '/\s+/', ' ', $css );
		// Remove comment blocks, everything between /* and */, unless
		// preserved with /*! ... */
		$css = preg_replace( '/\/\*[^\!](.*?)\*\//', '', $css );
		// Remove space after , : ; { }
		$css = preg_replace( '/(,|:|;|\{|}) /', '$1', $css );
		// Remove space before , ; { }
		$css = preg_replace( '/ (,|;|\{|})/', '$1', $css );
		// Strips leading 0 on decimal values (converts 0.5px into .5px)
		$css = preg_replace( '/(:| )0\.([0-9]+)(%|em|ex|px|in|cm|mm|pt|pc)/i', '${1}.${2}${3}', $css );
		// Strips units if value is 0 (converts 0px to 0)
		$css = preg_replace( '/(:| )(\.?)0(%|em|ex|px|in|cm|mm|pt|pc)/i', '${1}0', $css );
		// Converts all zeros value into short-hand
		$css = preg_replace( '/0 0 0 0/', '0', $css );
		// Shortern 6-character hex color codes to 3-character where possible
		$css = preg_replace( '/#([a-f0-9])\\1([a-f0-9])\\2([a-f0-9])\\3/i', '#\1\2\3', $css );
		return trim( $css );
	}

} /** EOF jono_minify() */

if( ! function_exists( 'is_login_page' ) ) {
	/**
	 * Conditional tag for WordPress login page
	 *
	 * @since 	1.0
	 * @see 	http://wordpress.stackexchange.com/questions/12863/check-if-were-on-the-wp-login-page
	 * @return 	bool
	 */
	function is_login_page() {
	    return (bool) in_array( $GLOBALS['pagenow'], array( 'wp-login.php', 'wp-register.php' ) );	    
	}
} /** EOF is_login_page() */


/**
 * Get Attachment ID from URI
 *
 * @since 	1.0
 * @see 	http://philipnewcomer.net/2012/11/get-the-attachment-id-from-an-image-url-in-wordpress/
 */
function jono_get_attachment_id_from_url( $attachment_url = '' ) {
 
	global $wpdb;
	$attachment_id = false;
 
	// If there is no url, return.
	if ( '' == $attachment_url )
		return;
 
	// Get the upload directory paths
	$upload_dir_paths = wp_upload_dir();
 
	// Make sure the upload path base directory exists in the attachment URL, to verify that we're working with a media library image
	if ( false !== strpos( $attachment_url, $upload_dir_paths['baseurl'] ) ) {
 
		// If this is the URL of an auto-generated thumbnail, get the URL of the original image
		$attachment_url = preg_replace( '/-\d+x\d+(?=\.(jpg|jpeg|png|gif)$)/i', '', $attachment_url );
 
		// Remove the upload path base directory from the attachment URL
		$attachment_url = str_replace( $upload_dir_paths['baseurl'] . '/', '', $attachment_url );
 
		// Finally, run a custom database query to get the attachment ID from the modified attachment URL
		$attachment_id = $wpdb->get_var( $wpdb->prepare( "SELECT wposts.ID FROM $wpdb->posts wposts, $wpdb->postmeta wpostmeta WHERE wposts.ID = wpostmeta.post_id AND wpostmeta.meta_key = '_wp_attached_file' AND wpostmeta.meta_value = '%s' AND wposts.post_type = 'attachment'", $attachment_url ) );
 
	}
 
	return $attachment_id;
}/** EOF jono_get_attachment_id_from_url() */

if ( ! function_exists( 'has_shortcode' ) ) {
	/**
	 * Whether a registered shortcode exists named $tag
	 *
	 * @since 3.6.0
	 *
	 * @global array $shortcode_tags
	 * @param string $tag
	 * @return boolean
	 */
	function shortcode_exists( $tag ) {
		global $shortcode_tags;
		return array_key_exists( $tag, $shortcode_tags );
	}
	/**
	 * Whether the passed content contains the specified shortcode
	 *
	 * @since 3.6.0
	 *
	 * @global array $shortcode_tags
	 * @param string $tag
	 * @return boolean
	 */
	function has_shortcode( $content, $tag ) {
		if ( shortcode_exists( $tag ) ) {
			preg_match_all( '/' . get_shortcode_regex() . '/s', $content, $matches, PREG_SET_ORDER );
			if ( empty( $matches ) )
				return false;

			foreach ( $matches as $shortcode ) {
				if ( $tag === $shortcode[2] )
					return true;
			}
		}
		return false;
	}
}/** EOF has_shortcode() */

if ( ! function_exists( 'jono_get_fontawesome' ) ) :
/**
 * This function is an array for listing fontawesome classes
 *
 * @since 		1.0
 * @link 		http://fortawesome.github.com/Font-Awesome/
 * @version 	3.2.1
 */
function jono_get_fontawesome() {
	if( false === ( $icons  = get_transient( 'jono_get_fontawesome' ) ) ){	
		/** taken from vafpress library for this regex */
		$pattern = '/\.(icon-(?:\w+(?:-)?)+):before\s*{\s*content/';
		$subject = wp_remote_retrieve_body( wp_remote_get( JONO_ASSETS_URI . 'css/font-awesome.min.css' ) );
		preg_match_all( $pattern, $subject, $matches, PREG_SET_ORDER );
		$icons = array();
		$icons[''] = '';
		foreach( $matches as $match ) {
		    $icons[ str_replace( 'icon-', '', $match[1] ) ] = str_replace( 'icon-', '', $match[1] );
		}
		asort( $icons );
		set_transient( 'jono_get_fontawesome', $icons, 60 * 60 * 24 );
	}
	return $icons;
}

endif;/** EOF jono_get_fontawesome() */


if ( ! function_exists( 'jono_get_websafe_fonts' ) ) :
/**
 * Organize web safe fonts into an array
 *
 * @since 	1.0
 */
function jono_get_websafe_fonts(){
	$jono_get_websafe_fonts = array(
		'Arial'					=> 'Arial',
		'Arial Black'			=> 'Arial Black',
		'Comic Sans MS'			=> 'Comic Sans MS',
		'Courier New'			=> 'Courier New',
		'Georgia'				=> 'Georgia',
		'Impact'				=> 'Impact',
		'Lucida Console'		=> 'Lucida Console',
		'Lucida Sans Unicode'	=> 'Lucida Sans Unicode',
		'Palatino Linotype'		=> 'Palatino Linotype',
		'Tahoma'				=> 'Tahoma',
		'Times New Roman'		=> 'Times New Roman',
		'Trebuchet MS'			=> 'Trebuchet MS',
		'Verdana'				=> 'Verdana',
	);
	asort( $jono_get_websafe_fonts );
	return apply_filters( 'jono_get_websafe_fonts', $jono_get_websafe_fonts);
}
endif; /** EOF jono_get_websafe_fonts() */


if ( ! function_exists( 'jono_get_google_webfonts' ) ) :
/** 
 * Organize All Google webfonts into an array
 * 
 * @since 	1.0
 * @see  	https://google.com/webfonts
 */
function jono_get_google_webfonts() {
	if( false === ( $gfonts  = get_transient( 'jono_get_google_webfonts' ) ) ){
		$get_fonts = wp_remote_retrieve_body( wp_remote_get( JONO_ASSETS_URI . 'font/webfonts.json' ) );
		$get_fonts = json_decode( $get_fonts );
		$gfonts = array();
		foreach ( $get_fonts->items as $font ) {
			$gfonts[$font->family] = $font->family;
		}
		asort( $gfonts );
		set_transient( 'jono_get_google_webfonts', $gfonts, 60 * 60 * 24 );
	}
	return $gfonts;
}
endif; /** EOF jono_get_google_webfonts() */

if ( ! function_exists( 'jono_get_webfonts' ) ) :
/** 
 * Marge all web safe font and google fonts into an array
 * 
 * @since 	1.0
 */
function jono_get_webfonts(){
	$jono_get_webfonts = array_merge( jono_get_websafe_fonts(), jono_get_google_webfonts() );
	return apply_filters( 'jono_get_webfonts', $jono_get_webfonts );
}
endif; /** EOF jono_get_webfonts() */

add_action( 'update_option', 'jono_development_true' );
function jono_development_true() {
	if ( ! defined( 'JONO_DEVELOPMENT' ) )
		return;
	delete_transient( 'jono_get_fontawesome' );
	delete_transient( 'jono_get_google_webfonts' );
}