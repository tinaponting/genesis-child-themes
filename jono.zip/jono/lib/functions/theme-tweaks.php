<?php
/**
 * Custom functions that act independently of the theme templates
 *
 * @package 	Jono
 * @author   	aprakasa
 * @license  	GPL-2.0+
 * @link     	http://prakasa.me/go/jono
 */

/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;

add_filter( 'embed_defaults', 'jono_embed_defaults' );
/** 
 * Set new default oembed width.
 * 
 * @since 	1.0 
 */
function jono_embed_defaults( $embed_size ) {
    $embed_size['width'] = 1170;
    return $embed_size;
}

add_filter( 'the_content', 'jono_filter_ptags_on_images' );
/** 
 * This function remove the p tag from around imgs.
 * 
 * @see 	http://css-tricks.com/snippets/wordpress/remove-paragraph-tags-from-around-images
 * @since 	1.0 
 */
function jono_filter_ptags_on_images( $content ){
	return preg_replace( '/<p>\s*(<a .*>)?\s*(<img .* \/>)\s*(<\/a>)?\s*<\/p>/iU', '\1\2\3', $content );
}

add_filter( 'body_class','jono_body_class' );
/** 
 * Function to add additional body class
 * 
 * @since 1.0 
 */
function jono_body_class( $classes ) {
	global $is_lynx, $is_gecko, $is_IE, $is_opera, $is_NS4, $is_safari, $is_chrome, $is_iphone;
	if($is_lynx) $classes[] = 'lynx';
	elseif($is_gecko) $classes[] = 'gecko';
	elseif($is_opera) $classes[] = 'opera';
	elseif($is_NS4) $classes[] = 'ns4';
	elseif($is_safari) $classes[] = 'safari';
	elseif($is_chrome) $classes[] = 'chrome';
	elseif($is_IE) {
		$browser = $_SERVER['HTTP_USER_AGENT'];
		$browser = substr( "$browser", 25, 8);
		if ($browser == "MSIE 7.0"  ) {
			$classes[] = 'ie7';
			$classes[] = 'ie';
		} elseif ($browser == "MSIE 6.0" ) {
			$classes[] = 'ie6';
			$classes[] = 'ie';
		} elseif ($browser == "MSIE 8.0" ) {
			$classes[] = 'ie8';
			$classes[] = 'ie';
		} elseif ($browser == "MSIE 9.0" ) {
			$classes[] = 'ie9';
			$classes[] = 'ie';
		} else {
			$classes[] = 'ie';
		}
	}
	else $classes[] = 'unknown';

	if( $is_iphone )
		$classes[] = 'iphone';

	if ( jono_get_option( 'image_logo' ) )
		$classes[] = 'image-logo';

	if ( is_page_template( 'canvas.php' ) )
		$classes[] = 'canvas';

	$classes[] = 'no-js';

	return $classes;
}

add_filter( 'the_password_form', 'jono_post_password');
/** 
 * Filter Password protection content form, give additional markup
 * 
 * @since 1.0 
 */
function jono_post_password(){
	global $post;
	$label = 'pwbox-' . ( empty( $post->ID ) ? rand() : $post->ID );
	$output = '<div class="jono-post-password">';
		$output .= '<form action="' . esc_url( site_url( 'wp-login.php?action=postpass', 'login_post' ) ) . '" method="post">';
			$output .= '<p>' . __( "This post is password protected. To view it please enter your password below:" ) . '</p>';
			$output .= '<input name="post_password" id="' . $label . '" type="password" size="20" />';
			$output .= '<input type="submit" name="Submit" value="' . esc_attr__("Submit") . '" />';
		$output .= '</form>';
	$output .= '</div>';
	return $output;
}

if ( genesis_get_option( 'gallery_style', JONO_SETTINGS ) ) {
	add_filter( 'post_gallery', 'jono_post_gallery', 10, 2 );
}
/** 
 * Custom Gallery Shortcode
 * 
 * @since 1.0.1
 */
function jono_post_gallery( $output, $attr ) {
	
	// load scripts
    global $post, $wp_locale;

    static $instance = 0;
    $instance++;

    // We're trusting author input, so let's at least make sure it looks like a valid orderby statement
    if ( isset( $attr['orderby'] ) ) {
        $attr['orderby'] = sanitize_sql_orderby( $attr['orderby'] );
        if ( !$attr['orderby'] )
            unset( $attr['orderby'] );
    }

    extract( shortcode_atts( array(
        'order'      => 'ASC',
        'orderby'    => 'menu_order ID',
        'id'         => $post->ID,
        'itemtag'    => 'div',
        'icontag'    => 'div',
        'captiontag' => 'div',
        'columns'    => 3,
        'include'    => '',
        'exclude'    => ''
    ), $attr) );

    $id = intval($id);
    if ( 'RAND' == $order )
        $orderby = 'none';

    if ( ! empty( $include ) ) {
        $include = preg_replace( '/[^0-9,]+/', '', $include );
        $_attachments = get_posts( array( 
				        	'include' 			=> $include,
				        	'post_status' 		=> 'inherit',
				        	'post_type' 		=> 'attachment',
				        	'post_mime_type' 	=> 'image',
				        	'order' 			=> $order,
				        	'orderby' 			=> $orderby ) );

        $attachments = array();
        foreach ( $_attachments as $key => $val ) {
            $attachments[$val->ID] = $_attachments[$key];
        }
    } elseif ( !empty($exclude) ) {
        $exclude = preg_replace( '/[^0-9,]+/', '', $exclude );
        $attachments = get_children( array(
        					'post_parent' 		=> $id,
        					'exclude' 			=> $exclude,
        					'post_status' 		=> 'inherit',
        					'post_type' 		=> 'attachment',
        					'post_mime_type' 	=> 'image',
        					'order' 			=> $order,
        					'orderby' 			=> $orderby) );
    } else {
        $attachments = get_children( array(
        					'post_parent' 		=> $id,
        					'post_status' 		=>'inherit',
        					'post_type' 		=> 'attachment',
        					'post_mime_type' 	=> 'image',
        					'order' 			=> $order,
        					'orderby' 			=> $orderby ) );
    }

    if ( empty($attachments) )
        return '';

    if ( is_feed() ) {
        $output = "\n";
        foreach ( $attachments as $att_id => $attachment )
            $output .= wp_get_attachment_link( $att_id, $size, true ) . "\n";
        return $output;
    }

    $itemtag = tag_escape( $itemtag );
    $captiontag = tag_escape( $captiontag );
    $columns = intval( $columns );
    $float = is_rtl() ? 'right' : 'left';

    $selector = "gallery-{$instance}";

    $output = apply_filters( 'gallery_style', "<div id='$selector' class='gallery jono-gallery galleryid-{$id} gallery-{$columns}-column cf'>");
		
	$gallery_id = $id;
    $count=0;
    foreach ( $attachments as $id => $attachment ) {
	$count++;
	
	$remove_margin = '';
	if( $count == $columns ){
		$remove_margin = 'remove-margin';
		$count= 0;
	}
		
		if( $columns > 1 ) {
			if ( genesis_site_layout() == 'full-width-content') {
				$img_src = wp_get_attachment_image_src( $id, 'jono-featured' );
			} else {
				$img_src = wp_get_attachment_image_src( $id, 'jono-featured' );
			}			
		} else {
			if ( genesis_site_layout() == 'full-width-content') {
				$img_src = wp_get_attachment_image_src( $id, 'jono-featured' );
			} else {
				$img_src = wp_get_attachment_image_src( $id, 'jono-featured' );
			}
		}
		$img_url = $img_src[0];
		$img_large = wp_get_attachment_image_src( $id, 'full' );
		$img_large_url = $img_large[0];

        $output .= "<{$itemtag} class='jono-gallery-item {$remove_margin}'>";
        $output .= "
            <{$icontag} class='jono-gallery-icon'>
            	<img itemprop='image' src='{$img_url}' alt='{$attachment->post_title}' />
               	<a href='$img_large_url' class='jono-gallery-resize' title='{$attachment->post_title}'></a>
            </{$icontag}>";
        $output .= "</{$itemtag}>";
		if ( $columns > 0 && ++$i % $columns == 0 )
            $output .= '<br style="clear: both" />';
    }

    $output .= "
            <div class='clear'></div>
        </div>\n";

    return $output;
}

add_filter( 'http_request_args', 'jono_prevent_theme_update', 5, 2 );
/**
 * Don't update theme from .org repo.
 *
 * If there is a theme in the repo with the same name,
 * this prevents WP from prompting an update. Future proofs themes.
 *
 * @since 	1.0
 *
 * @author 	Mark Jaquith
 * @link   	http://markjaquith.wordpress.com/2009/12/14/excluding-your-plugin-or-theme-from-update-checks/
 */
function jono_prevent_theme_update( $r, $url ) {
	if ( 0 !== strpos( $url, 'http://api.wordpress.org/themes/update-check' ) )
		return $r; // Not a theme update request. Bail immediately.
	$themes = unserialize( $r['body']['themes'] );
	unset( $themes[ get_option( 'template' ) ] );
	unset( $themes[ get_option( 'stylesheet' ) ] );
	$r['body']['themes'] = serialize( $themes );
	return $r;
}