<?php
/**
 * Some tweaks for Options framework plugin
 * 
 * Require Options Framework plugin
 *
 * @package 	Jono
 * @author   	aprakasa
 * @license  	GPL-2.0+
 * @link     	http://prakasa.me/go/jono
 */

/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;

add_action( 'init', 'jono_of_tweaks', 20 );
/**
 * function to replace optionsframework_add_page() and optionsframework_adminbar().
 *
 * @since  	1.0
 */
function jono_of_tweaks() {
	if ( current_user_can( 'edit_theme_options' ) ) {
		$options =& _optionsframework_options();
		if ( $options ) {
			remove_action( 'admin_menu', 'optionsframework_add_page' );
			remove_action( 'wp_before_admin_bar_render', 'optionsframework_adminbar' );
			add_action( 'admin_menu',  'jono_of_add_page' );
		}
	}
}

add_filter( 'optionsframework_menu', 'jono_of_menu_label' );
/**
 * function to filter optionsframework_menu.
 *
 * @since  	1.0
 */
function jono_of_menu_label( $menu ) {
	$menu['page_title'] = __( 'Jono Settings', 'jono' );
	$menu['menu_title']	= __( 'Jono Settings', 'jono' );
	$menu['menu_slug']	= JONO_SETTINGS;
	return $menu;
}

/**
 * function to replare optionsframework_add_page().
 *
 * @since  	1.0
 */
function jono_of_add_page() {
	$menu 		= optionsframework_menu_settings();
	$of_page 	= add_submenu_page( 'genesis', $menu['page_title'], $menu['menu_title'], $menu['capability'], $menu['menu_slug'], $menu['callback'] );
	/** Remove main scripts and styles hook */
	remove_action( 'admin_enqueue_scripts', 'optionsframework_load_scripts' );
	remove_action( 'admin_print_styles-' . $of_page, 'optionsframework_load_styles' );
	/** Replace with new scripts and styles */
	add_action( 'admin_enqueue_scripts', 'jono_of_load_scripts' );
	add_action( 'admin_print_styles-' . $of_page, 'jono_of_load_styles' );
}

/**
 * function to replace optionsframework_load_scripts().
 *
 * @since  	1.0
 */
function jono_of_load_scripts( $hook ) {
	$menu = optionsframework_menu_settings();	
	if ( 'genesis_page_' . $menu['menu_slug'] != $hook )
        return;
	// Enqueue colorpicker scripts for versions below 3.5 for compatibility
	if ( !wp_script_is( 'wp-color-picker', 'registered' ) ) {
		wp_register_script( 'iris', OPTIONS_FRAMEWORK_URL . 'js/iris.min.js', array( 'jquery-ui-draggable', 'jquery-ui-slider', 'jquery-touch-punch' ), false, 1 );
		wp_register_script( 'wp-color-picker', OPTIONS_FRAMEWORK_URL . 'js/color-picker.min.js', array( 'jquery', 'iris' ) );
		$colorpicker_l10n = array(
			'clear' 		=> __( 'Clear', 'jono' ),
			'defaultString' => __( 'Default', 'jono' ),
			'pick' 			=> __( 'Select Color', 'jono' )
		);
		wp_localize_script( 'wp-color-picker', 'wpColorPickerL10n', $colorpicker_l10n );
	}	
	// Enqueue custom option panel JS
	wp_enqueue_script( 'options-custom', OPTIONS_FRAMEWORK_URL . 'js/options-custom.js', array( 'jquery','wp-color-picker' ) );
	wp_enqueue_script( 'jono-admin', JONO_ASSETS_URI .'js/admin.js', array( 'options-custom', 'select2' ), CHILD_THEME_VERSION, false );
	// Inline scripts from options-interface.php
	add_action( 'admin_head', 'of_admin_head' );
}

/**
 * function to replace optionsframework_load_styles().
 *
 * @since  	1.0
 */
function jono_of_load_styles(){
	wp_enqueue_style( 'optionsframework', OPTIONS_FRAMEWORK_URL.'css/optionsframework.css' );
	if ( !wp_style_is( 'wp-color-picker','registered' ) )
		wp_register_style('wp-color-picker', OPTIONS_FRAMEWORK_URL.'css/color-picker.min.css');
	wp_enqueue_style( 'wp-color-picker' );
	wp_enqueue_style( 'jono-admin', JONO_ASSETS_URI . 'css/admin.css', array( 'optionsframework', 'select2' ) );
}

remove_action( 'admin_enqueue_scripts', 'optionsframework_media_scripts' );
add_action( 'admin_enqueue_scripts', 'jono_of_media_scripts' );
/**
 * function to replace optionsframework_media_scripts().
 *
 * @since  	1.0
 */
function jono_of_media_scripts( $hook ) {	
	$menu = optionsframework_menu_settings();	
	if ( 'genesis_page_' . $menu['menu_slug'] != $hook )
        return;        
	if ( function_exists( 'wp_enqueue_media' ) )
		wp_enqueue_media();
	wp_register_script( 'of-media-uploader', OPTIONS_FRAMEWORK_URL .'js/media-uploader.js', array( 'jquery' ) );
	wp_enqueue_script( 'of-media-uploader' );
	wp_localize_script( 'of-media-uploader', 'optionsframework_l10n', array(
		'upload' => __( 'Upload', 'optionsframework' ),
		'remove' => __( 'Remove', 'optionsframework' )
	) );	
}

/**
 * Initialize unique ID for options framwework Settings
 * 
 * @since 	1.0
 */
function optionsframework_option_name() {
	$optionsframework_settings = get_option( 'optionsframework' );	
	$optionsframework_settings['id'] = JONO_SETTINGS;
	update_option( 'optionsframework', $optionsframework_settings );
}

add_filter( 'genesis_export_options', 'jono_export_options' );
/**
* Hook Jono into Genesis Exporter, allowing Jono Setting to be exported.
*
* Requires Genesis 1.6+.
*
* @since 	1.0
*/
function jono_export_options( $options ) {
	$options['jono'] = array( 
		'label' 			=> __( 'Jono Settings', 'jono' ), 
		'settings-field' 	=> JONO_SETTINGS );
	return $options;
}