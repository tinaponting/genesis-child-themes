<?php
/**
 * This file give additional information for theme
 * 
 * Require Options Framework plugin
 *
 * @package 	Jono
 * @author   	aprakasa
 * @license  	GPL-2.0+
 * @link     	http://prakasa.me/go/jono
 */

/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;

add_action( 'load-genesis_page_jono-settings', 'jono_load_help_tab' );
/**
 * This function control options framework help tab
 *
 * @since 1.0
 */
function jono_load_help_tab() {
    
    $screen = get_current_screen();
    $of_page = 'genesis_page_jono-settings';

    if ( $screen->id != $of_page )
        return;

	$tab1_help =
		'<h3>' . __( 'General Settings' , 'jono' ) . '</h3>' .
		'<p>'. __( 'Descriptions coming soon!', 'jono' ) .'</p>';
		
	$tab2_help =
		'<h3>' . __( 'Colors Settings' , 'jono' ) . '</h3>'.
		'<p>'. __( 'Descriptions coming soon!', 'jono' ) .'</p>';
		
	$tab3_help =
		'<h3>' . __( 'Font Settings' , 'jono' ) . '</h3>'.
		'<p>'. __( 'Descriptions coming soon!', 'jono' ) .'</p>';

	$tab4_help =
		'<h3>' . __( 'Portfolio Settings' , 'jono' ) . '</h3>'.
		'<p>'. __( 'Descriptions coming soon!', 'jono' ) .'</p>';

	$tab5_help =
		'<h3>' . __( 'Misc Settings' , 'jono' ) . '</h3>'.
		'<p>'. __( 'Descriptions coming soon!', 'jono' ) .'</p>';

	$screen->add_help_tab(
	array(
		'id'		=> $of_page . '-tab1',
		'title'		=> __( 'General' , 'jono' ),
		'content'	=> $tab1_help,
	));

	$screen->add_help_tab(
		array(
			'id'		=> $of_page . '-tab2',
			'title'		=> __( 'Style' , 'jono' ),
			'content'	=> $tab2_help,
		));
		
	$screen->add_help_tab(
		array(
			'id'		=> $of_page . '-tab3',
			'title'		=> __( 'Fonts' , 'jono' ),
			'content'	=> $tab3_help,
		));

	$screen->add_help_tab(
		array(
			'id'		=> $of_page . '-tab4',
			'title'		=> __( 'Portfolio' , 'jono' ),
			'content'	=> $tab4_help,
		));

	$screen->add_help_tab(
		array(
			'id'		=> $of_page . '-tab5',
			'title'		=> __( 'Misc' , 'jono' ),
			'content'	=> $tab5_help,
		));
		
	// Add Sidebar
	$screen->set_help_sidebar(
		'<p>' .sprintf( __( '%s ver.%s was released at %s by %s. ', 'jono' ),
			'<strong><a href="'. esc_url( CHILD_THEME_URI ).'" target="_blank" title="'. CHILD_THEME_NAME .'">' . CHILD_THEME_NAME . '</a></strong>',
			'<strong>' . CHILD_THEME_VERSION . '</strong>',
			'<strong>' . JONO_RELEASE_DATE . '</strong>',
			'<strong><a href="'. esc_url( CHILD_DEVELOPER_URI ) .'" target="_blank" title="'. CHILD_DEVELOPER_NAME .'">'. CHILD_DEVELOPER_NAME .'</a></strong>' ).
		'</p>'.
		
		'<p><strong>' . __( 'Helpful link:', 'jono' ) . '</strong></p>' .
		'<p><strong><a href="//docs.prakasa.me/jono/">'. __( 'Theme Documentation', 'jono' ) .'</a></strong></p>'
	);

}