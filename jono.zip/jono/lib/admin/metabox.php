<?php
/**
 * Custom metabox for Portfolio
 *
 * @package 	Jono
 * @author   	aprakasa
 * @license  	GPL-2.0+
 * @link     	http://prakasa.me/go/jono
 */

/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;

add_action( 'ccp_item_info_meta_box', 'jono_portfolio_details' );
/**
 * Callback function for jono_portfolio_details().
 *
 * @since 	1.0
 */
function jono_portfolio_details() {
	wp_nonce_field( 'jono_portfolio_details_save', 'jono_portfolio_details_nonce' );
	?>
	<p>
		<label for="portfolio_item_client"><?php _e( 'Client name', 'jono' ); ?></label>
		<br />
		<input type="text" name="portfolio_item_client[_portfolio_item_client]" id="portfolio_item_client" value="<?php echo genesis_get_custom_field( '_portfolio_item_client' ); ?>" size="30" tabindex="30" style="width: 99%;" />
	</p>
	<?php
}

add_action( 'save_post', 'jono_portfolio_details_save', 1, 2 );
/**
 * Save jono_portfolio_details() settings
 *
 * @since 	1.0
 */
function jono_portfolio_details_save( $post_id, $post ) {
	if ( ! isset( $_POST['portfolio_item_client'] ) )
		return;
	/** Merge user submitted options with fallback defaults */
	$data = wp_parse_args( $_POST['portfolio_item_client'], array(
		'_portfolio_item_client' 		=> '',
	) );
	/** Save custom field data */
	genesis_save_custom_fields( $data, 'jono_portfolio_details_save', 'jono_portfolio_details_nonce', $post, $post_id );
}