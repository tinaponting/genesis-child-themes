<?php
/**
 * This file control Jono theme customizer
 * 
 * Require Options Framework plugin
 *
 * @package 	Jono
 * @author   	aprakasa
 * @license  	GPL-2.0+
 * @link     	http://prakasa.me/go/jono
 */

/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;

add_action ( 'admin_menu', 'jono_customize_menu' );
/**
 * Add "Customize" link in the appereance admin menu.
 *
 * @since  	1.0
 *
 * @return 	void
 */
function jono_customize_menu() {
	global $wp_version;
	if ( version_compare( $wp_version, '3.5.2', '>' ) )
		return;    
    add_theme_page( __( 'Customize', 'jono' ), __( 'Customize', 'jono' ), 'edit_theme_options', 'customize.php' );
}


add_action( 'customize_preview_init', 'jono_preview_js', 15 );
/**
 * Jono theme customizer script
 *
 * @since 	1.0
 */
function jono_preview_js(){
	wp_register_script( "jono-customizer", JONO_ASSETS_URI . "js/customizer.js", array( 'customize-preview' ), CHILD_THEME_VERSION, TRUE	);
	wp_enqueue_script( "jono-customizer" );
}

add_action( 'customize_controls_enqueue_scripts', 'jono_customizer_control');
/**
 * Jono customizer control scripts
 *
 * @since 	1.0
 */
function jono_customizer_control(){
	wp_enqueue_style( 'select2' );
	wp_enqueue_script( "jono-customizer-control", JONO_ASSETS_URI . "js/customizer-control.js", array( 'jquery', 'select2' ), FALSE, TRUE );
}

add_action( 'customize_controls_print_scripts', 'jono_customize_controls_css' );
/**
 * Add z-index:0 to customize preview init
 * since we are going to use select2 library
 *
 * @since 	1.0
 */
function jono_customize_controls_css() {
	$output = '<style type="text/css">';
	$output .= '.wp-full-overlay.expanded{ position:relative; z-index:0 }';
	$output .= '</style>';
	echo $output;
}

add_action( 'customize_register', 'jono_register_customizer_control', 1, 1 );
/**
 * Custom Control for theme customizer
 *
 * @since 	1.0
 */
function jono_register_customizer_control( $wp_customize ) {   
   
     class Jono_Webfonts_Control extends WP_Customize_Control {
          public function render_content() {
                ?>
                <label>
                  <span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
                  <select class="shorting-selector" <?php $this->link(); ?> style="width:240px">
                       <?php
						echo '<optgroup label="'. __( 'Web Safe Fonts', 'jono') .'">';
                     		foreach ( jono_get_websafe_fonts() as $font ) {                     			
        			            echo '<option value="'. $font .'"'. selected( $this->value(), $font ) .'>'. $font .'</option>';
        			        }
    		            echo '</optgroup>';						
						echo '<optgroup label="'. __( 'Google Webfonts', 'jono') .'">';
        		            foreach ( jono_get_google_webfonts() as $font ) {                     			
        			            echo '<option value="'. $font .'"'. selected( $this->value(), $font ) .'>'. $font .'</option>';        			           
        		            }
    		            echo '</optgroup>';
                       ?>
                  </select>
                </label>
                <?php
           }

     }

     class Jono_Page_Selector_Control extends WP_Customize_Control {
          public function render_content() {
                ?>
                <label>
                  <span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
                  <select class="shorting-selector" <?php $this->link(); ?> style="width:240px">
                       <?php
                        foreach ( jono_get_published_posts( 'page' ) as $pages => $page ) {                              
                            echo '<option value="'. $pages .'"'. selected( $this->value(), $pages ) .'>'. $page .'</option>';
                        }
                       ?>
                  </select>
                </label>
                <?php
           }
     }

}

add_action( 'customize_register', 'jono_topheader_customizer' );
/**
 * Typography customizer
 *
 * @since  	1.0
 */
function jono_topheader_customizer( $wp_customize ) {

	$options = optionsframework_options();

	/** Typography Settings */
	$wp_customize->add_section( 'jono_topheader_customizer', array(
		'title' 		=> __( 'Top Header', 'jono' ),
		'priority' 		=> 10
	) );

	$wp_customize->add_setting( JONO_SETTINGS . '[email_address]', array(
		'default'  	=> $options['email_address']['std'],
		'type'		=> 'option',
	));

	$wp_customize->add_control( 'email_address', array(
		'label'    	=> $options['email_address']['name'],
		'section'  	=> 'jono_topheader_customizer',
		'settings' 	=> JONO_SETTINGS . '[email_address]',
		'type'     	=> $options['email_address']['type'],
		'priority' 	=> 2,
	));

	$wp_customize->add_setting( JONO_SETTINGS . '[phone_number]', array(
		'default'  	=> $options['phone_number']['std'],
		'type' 		=> 'option',
	));

	$wp_customize->add_control( 'phone_number', array(
		'label'    	=> $options['phone_number']['name'],
		'section'  	=> 'jono_topheader_customizer',
		'settings' 	=> JONO_SETTINGS . '[phone_number]',
		'type'     	=> $options['phone_number']['type'],
		'priority' 	=> 3,
	));


	return $wp_customize;
}

add_action( 'customize_register', 'jono_colors_customizer' );
/**
 * Typography customizer
 *
 * @since  	1.0
 */
function jono_colors_customizer( $wp_customize ) {

	$options = optionsframework_options();

	/** Primary Color */
	$wp_customize->add_setting( JONO_SETTINGS . '[primary_color]', array(
		'default'       => $options['primary_color']['std'],
		'transport'		=> 'postMessage',
		'type'			=> 'option',
	) );

	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'primary_color', array(
		'label'   		=> $options['primary_color']['name'],
		'section' 		=> 'colors',
		'settings'   	=> JONO_SETTINGS . '[primary_color]',
		'priority' 		=> 1,
	)));

	/** Link Color */
	$wp_customize->add_setting( JONO_SETTINGS . '[hyperlink_color]', array(
		'default'       => $options['hyperlink_color']['std'],
		'type'			=> 'option',
	) );

	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'hyperlink_color', array(
		'label'   		=> $options['hyperlink_color']['name'],
		'section' 		=> 'colors',
		'settings'   	=> JONO_SETTINGS . '[hyperlink_color]',
		'priority' 		=> 2,
	)));

	/** Link Color */
	$wp_customize->add_setting( JONO_SETTINGS . '[hover_color]', array(
		'default'       => $options['hover_color']['std'],
		'type'			=> 'option',
	) );

	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'hover_color', array(
		'label'   		=> $options['hover_color']['name'],
		'section' 		=> 'colors',
		'settings'   	=> JONO_SETTINGS . '[hover_color]',
		'priority' 		=> 3,
	)));

	return $wp_customize;
}

add_action( 'customize_register', 'jono_fonts_customizer' );
/**
 * Typography customizer
 *
 * @since  	1.0
 */
function jono_fonts_customizer( $wp_customize ) {

	$options = optionsframework_options();

	/** Typography Settings */
	$wp_customize->add_section( 'jono_fonts_customizer', array(
		'title' 		=> __( 'Typography', 'jono' ),
		'priority' 		=> 50
	) );


	$wp_customize->add_setting( JONO_SETTINGS . '[heading_font]', array(
		'default'  		=> $options['heading_font']['std'],
		'type'			=> 'option',
	));

	$wp_customize->add_control( new Jono_Webfonts_Control( $wp_customize, 'heading_font', array(
		'label'      	=> $options['heading_font']['name'],
		'section'    	=> 'jono_fonts_customizer',
		'settings'   	=> JONO_SETTINGS . '[heading_font]',
		'priority' 		=> 1,
	) ) );

	$wp_customize->add_setting( JONO_SETTINGS . '[body_font]', array(
		'default'  		=> $options['body_font']['std'],
		'type'			=> 'option',
	));

	$wp_customize->add_control( new Jono_Webfonts_Control( $wp_customize, 'body_font', array(
		'label'      	=> $options['body_font']['name'],
		'section'    	=> 'jono_fonts_customizer',
		'settings'   	=> JONO_SETTINGS . '[body_font]',
		'priority'	 	=> 2,
	) ) );

	$wp_customize->add_setting( JONO_SETTINGS . '[heading_weight]', array(
		'default'  		=> $options['heading_weight']['std'],
		'transport'		=> 'postMessage',
		'type'			=> 'option',
	));

	$wp_customize->add_control( 'heading_weight', array(
		'label'    		=> $options['heading_weight']['name'],
		'section'  		=> 'jono_fonts_customizer',
		'settings' 		=> JONO_SETTINGS . '[heading_weight]',
		'type'     		=> $options['heading_weight']['type'],
		'choices'   	=> $options['heading_weight']['options'],
		'priority'		=> 3,
	));	

	return $wp_customize;

}

add_action( 'customize_register', 'jono_font_size_customizer' );
/**
 * Font Size customizer
 *
 * @since  	1.0
 */
function jono_font_size_customizer( $wp_customize ){

	$options = optionsframework_options();

	/** Typography Settings */
	$wp_customize->add_section( 'jono_font_size_customizer', array(
		'title' 	=> __( 'Font Size', 'jono' ),
		'priority' 	=> 55
	) );

	$wp_customize->add_setting( JONO_SETTINGS . '[heading_one]', array(
		'default'  	=> $options['heading_one']['std'],
		'transport'	=> 'postMessage',
		'type'		=> 'option',
	));

	$wp_customize->add_control( 'heading_one', array(
		'label'    	=> $options['heading_one']['name'],
		'section'  	=> 'jono_font_size_customizer',
		'settings' 	=> JONO_SETTINGS . '[heading_one]',
		'type'     	=> $options['heading_one']['type'],
		'choices'   => $options['heading_one']['options'],
		'priority'	=> 1,
	));

	$wp_customize->add_setting( JONO_SETTINGS . '[heading_two]', array(
		'default'  => $options['heading_two']['std'],
		'transport'	=> 'postMessage',
		'type'		=> 'option',
	));

	$wp_customize->add_control( 'heading_two', array(
		'label'    	=> $options['heading_two']['name'],
		'section'  	=> 'jono_font_size_customizer',
		'settings' 	=> JONO_SETTINGS . '[heading_two]',
		'type'     	=> $options['heading_two']['type'],
		'choices'   => $options['heading_two']['options'],
		'priority'	=> 2,
	));

	$wp_customize->add_setting( JONO_SETTINGS . '[heading_three]', array(
		'default'  	=> $options['heading_three']['std'],
		'transport'	=> 'postMessage',
		'type'		=> 'option',
	));

	$wp_customize->add_control( 'heading_three', array(
		'label'    	=> $options['heading_three']['name'],
		'section'  	=> 'jono_font_size_customizer',
		'settings' 	=> JONO_SETTINGS . '[heading_three]',
		'type'     	=> $options['heading_three']['type'],
		'choices'   => $options['heading_three']['options'],
		'priority'	=> 3,
	));

	$wp_customize->add_setting( JONO_SETTINGS . '[heading_four]', array(
		'default'  	=> $options['heading_four']['std'],
		'transport'	=> 'postMessage',
		'type'		=> 'option',
	));

	$wp_customize->add_control( 'heading_four', array(
		'label'    	=> $options['heading_four']['name'],
		'section'  	=> 'jono_font_size_customizer',
		'settings' 	=> JONO_SETTINGS . '[heading_four]',
		'type'     	=> $options['heading_four']['type'],
		'choices'   => $options['heading_four']['options'],
		'priority'	=> 4,
	));

	$wp_customize->add_setting( JONO_SETTINGS . '[heading_five]', array(
		'default'  	=> $options['heading_five']['std'],
		'transport'	=> 'postMessage',
		'type'		=> 'option',
	));

	$wp_customize->add_control( 'heading_five', array(
		'label'    	=> $options['heading_five']['name'],
		'section'  	=> 'jono_font_size_customizer',
		'settings' 	=> JONO_SETTINGS . '[heading_five]',
		'type'     	=> $options['heading_five']['type'],
		'choices'   => $options['heading_five']['options'],
		'priority'	=> 5,
	));

	$wp_customize->add_setting( JONO_SETTINGS . '[heading_six]', array(
		'default'  	=> $options['heading_six']['std'],
		'transport'	=> 'postMessage',
		'type'		=> 'option',
	));

	$wp_customize->add_control( 'heading_six', array(
		'label'    	=> $options['heading_six']['name'],
		'section'  	=> 'jono_font_size_customizer',
		'settings' 	=> JONO_SETTINGS . '[heading_six]',
		'type'     	=> $options['heading_six']['type'],
		'choices'   => $options['heading_six']['options'],
		'priority'	=> 6,
	));

	$wp_customize->add_setting( JONO_SETTINGS . '[body_font_size]', array(
		'default'  	=> $options['body_font_size']['std'],
		'transport'	=> 'postMessage',
		'type'		=> 'option',
	));

	$wp_customize->add_control( 'body_font_size', array(
		'label'    	=> $options['body_font_size']['name'],
		'section'  	=> 'jono_font_size_customizer',
		'settings' 	=> JONO_SETTINGS . '[body_font_size]',
		'type'     	=> $options['body_font_size']['type'],
		'choices'   => $options['body_font_size']['options'],
		'priority'	=> 7,
	));

	$wp_customize->add_setting( JONO_SETTINGS . '[widget_size]', array(
		'default'  	=> $options['widget_size']['std'],
		'transport'	=> 'postMessage',
		'type'		=> 'option',
	));

	$wp_customize->add_control( 'widget_size', array(
		'label'    	=> $options['widget_size']['name'],
		'section'  	=> 'jono_font_size_customizer',
		'settings' 	=> JONO_SETTINGS . '[widget_size]',
		'type'     	=> $options['widget_size']['type'],
		'choices'   => $options['widget_size']['options'],
		'priority'	=> 8,
	));

	return $wp_customize;
}

add_action( 'customize_register', 'jono_misc_theme_customizer' );
/**
 * Theme style customizer
 *
 * @since  	1.0
 */
function jono_misc_theme_customizer( $wp_customize ) {
	/** Default WordPress */
	$wp_customize->get_setting( 'blogname' )->transport = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport = 'postMessage';
	$wp_customize->get_setting( 'background_color' )->transport = 'postMessage';

	$options = optionsframework_options();

	return $wp_customize;
}