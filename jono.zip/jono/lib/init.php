<?php
/**
 * Initializes Jono child theme by doing some basic things like defining constants
 * and loading all components from the /lib directory.
 *
 * @package 	Jono
 * @author   	aprakasa
 * @license  	GPL-2.0+
 * @link     	http://prakasa.me/go/jono
 */

/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;

class Jono_Init {

	/** Constructor */
	function __construct() {
		add_action( 'genesis_init', array( $this, 'constants' ), 15 );
		add_action( 'genesis_setup', array( $this, 'load_translation' ) );
		add_action( 'genesis_setup', array( $this, 'theme_supports' ) );
		add_action( 'genesis_setup', array( $this, 'load_functions' ) );
		add_action( 'genesis_setup', array( $this, 'load_plugins' ) );
		add_action( 'genesis_setup', array( $this, 'load_assets' ) );
	}

	/**
	 * This function defines Jono child theme constants
	 *
	 * @since 1.0.0
	 */
	function constants() {
		$jono = wp_get_theme();
		/** Define Theme Info Constants */
		//define( 'JONO_DEVELOPMENT', true );
		define( 'CHILD_THEME_NAME', $jono->Name );
		define( 'CHILD_DEVELOPER_NAME', $jono->{'Author Name'} );
		define( 'CHILD_DEVELOPER_URI', $jono->{'Author URI'} );
		define( 'CHILD_THEME_URI', $jono->get('ThemeURI') );
		define( 'CHILD_THEME_VERSION', $jono->Version );
		/** REMEMBER TO CHANGE THIS WHEN THE THEME IS UPDATED */
		define( 'JONO_RELEASE_DATE', date_i18n( 'F j, Y', '1379394000' ) );
		/** Define Jono Settings fields */
		define( 'JONO_SETTINGS', $jono->get('TextDomain') . '-settings' );
		/** Define Directory Location Constants */
		define( 'JONO_DIR', trailingslashit( get_stylesheet_directory() ) );
		define( 'JONO_LIB_DIR', JONO_DIR . trailingslashit( 'lib' ) );
		define( 'JONO_ADMIN_DIR', JONO_LIB_DIR . trailingslashit( 'admin' ) );
		define( 'JONO_ASSETS_DIR', JONO_LIB_DIR. trailingslashit( 'assets' ) );
		define( 'JONO_BLOCKS_DIR', JONO_LIB_DIR . trailingslashit( 'blocks' ) );
		define( 'JONO_CLASSES_DIR', JONO_LIB_DIR . trailingslashit( 'classes' ) );
		define( 'JONO_FUNCTIONS_DIR', JONO_LIB_DIR . trailingslashit( 'functions' ) );
		define( 'JONO_PLUGINS_DIR', JONO_LIB_DIR . trailingslashit( 'plugins' ) );
		define( 'JONO_WIDGETS_DIR', JONO_LIB_DIR . trailingslashit( 'widgets' ) );
		/** Define URL Location Constants */
		define( 'JONO_URI', trailingslashit( get_stylesheet_directory_uri() ) );
		define( 'JONO_LIB_URI', JONO_URI . trailingslashit( 'lib' ) );		
		define( 'JONO_ADMIN_URI', JONO_LIB_URI . trailingslashit( 'admin' ) );
		define( 'JONO_ASSETS_URI', JONO_LIB_URI. trailingslashit( 'assets' ) );
		define( 'JONO_BLOCKS_URI', JONO_LIB_URI . trailingslashit( 'blocks' ) );
		define( 'JONO_CLASSES_URI', JONO_LIB_URI . trailingslashit( 'classes' ) );
		define( 'JONO_FUNCTIONS_URI', JONO_LIB_URI . trailingslashit( 'functions' ) );
		define( 'JONO_PLUGINS_URI', JONO_LIB_URI . trailingslashit( 'plugins' ) );
		define( 'JONO_WIDGETS_URI', JONO_LIB_URI . trailingslashit( 'widgets' ) );
	}

	/**
	 * This function load translation files for Jono child theme
	 *
	 * @since 1.0.0
	 */
	function load_translation() {
		/** Load Translation and localization files */
		load_child_theme_textdomain( 'jono', JONO_DIR . 'languages' );
	}

	/**
	 * This function defines Jono child theme support
	 *
	 * @since 1.0.0
	 */
	function theme_supports() {
		/** Enable WordPress $content_width and oEmbed support */
		if ( ! isset( $GLOBALS['content_width'] ) ) 
			$GLOBALS['content_width'] = 1170;
		/** Editor Styles */
		add_editor_style( JONO_ASSETS_URI . 'css/font-awesome.min.css' );
		add_editor_style( JONO_ASSETS_URI . 'css/editor-style.css' );
		/** Custom image size */
		add_image_size( 'jono-thumbnail', 64, 64, true );
		add_image_size( 'jono-square', 370, 370, true );
		add_image_size( 'jono-big-square', 720, 720, true );
		add_image_size( 'jono-featured', 770, 480, true );
		add_image_size( 'jono-slider', 1260, 480, true );
		/** Add Editor Style */
		add_editor_style( 'editor-style.css' );
		/** Add Genesis HTML5 theme support */
		add_theme_support( 'html5' );
		/** Add Genesis Responsive Viewport support */
		add_theme_support( 'genesis-responsive-viewport' );
		/** Add Genesis Menus support */
		add_theme_support(
			'genesis-menus', 
			array(
				'header'   		=> __( 'Header Menu', 'jono' ),
				'header_social' => __( 'Top Header Social', 'jono' ),
				'footer_social' => __( 'Footer Social', 'jono' ) ) );
		/** Genesis Footer Widgets #4 */
		add_theme_support( 'genesis-footer-widgets', 4 );
		/** genesis-structural-wrap */
		add_theme_support( 'genesis-structural-wraps',
			array( 
				'header',
				'nav',
				'breadcrumb',
				'inner',
				'footer-widgets',
				'footer' ) );
		/** WordPress Custom Background */
		add_theme_support( 'custom-background',
			array(
			    'default-color' 		=> 'eaeaea',
			    'background-attachment'	=> 'scroll', /** WTF */
				'wp-head-callback' 		=> 'jono_custom_background_cb' ) );
		/** Unregister Genesis layouts */
		genesis_unregister_layout( 'content-sidebar-sidebar' );
		genesis_unregister_layout( 'sidebar-sidebar-content' );
		genesis_unregister_layout( 'sidebar-content-sidebar' );
	}

	/**
	 * This function load functions files for Jono child theme
	 *
	 * @since 1.0.0
	 */
	function load_functions() {
		/** Load jono theme functions */
		include( JONO_FUNCTIONS_DIR . 'theme-functions.php' );
		/** Load jono theme tweaks */
		include( JONO_FUNCTIONS_DIR . 'theme-tweaks.php' );
		/** Load genesis tweaks */
		include( JONO_FUNCTIONS_DIR . 'genesis-tweaks.php' );
		/** Load widgets init */
		include( JONO_WIDGETS_DIR . 'widgets-init.php' );
	}

	/**
	 * This function load plugin tweaks files for Jono child theme
	 *
	 * @since 1.0.0
	 */
	function load_plugins() {
		/** Load TGM plugin activation class */
		include_once( JONO_CLASSES_DIR . 'class-tgm-plugin-activation.php' );
		/** Load plugins requirement and recommendation */
		include( JONO_PLUGINS_DIR . 'theme-plugins.php' );
		/** Load Options Framework */
		if ( function_exists( 'optionsframework_init' ) ) {
			/** Load options framework tweaks */
			include_once ( JONO_ADMIN_DIR . 'admin.php' );
			/** Load admin help tab */
			include_once ( JONO_ADMIN_DIR . 'admin-help.php' );
			/** Load the options */
			include_once ( JONO_DIR . 'options.php' );
			/** Load custom metabox */
			include_once ( JONO_ADMIN_DIR . 'metabox.php' );
			/** Load the jono customizer */
			include_once ( JONO_ADMIN_DIR . 'customizer.php' );
		}
		/** Load general plugins tweaks */
		include( JONO_PLUGINS_DIR . 'plugins-tweaks.php' );
		/** Load custom AQPB modules */
		if ( class_exists( 'AQ_Page_Builder') )
			include( JONO_BLOCKS_DIR . 'blocks-init.php' );
		/** Load CCP tweaks */
		if ( class_exists( 'Custom_Content_Portfolio') )
			include( JONO_PLUGINS_DIR . 'ccp-tweaks.php' );
	}

	/**
	 * This function load assets files for Jono child theme
	 *
	 * @since 1.0.0
	 */
	function load_assets() {
		/** Load Jono Assets */
		include( JONO_ASSETS_DIR . 'load-assets.php' );
		/** Load Jono Styles */
		include( JONO_ASSETS_DIR . 'load-styles.php' );
		/** Load Jono Scripts */
		include( JONO_ASSETS_DIR . 'load-scripts.php' );
	}

} /** EOF Jono_Init() */

$_jono_init = new Jono_Init();