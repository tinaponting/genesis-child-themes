<?php
/**
 * Initializes Aqua Page Builder custom modules
 *
 * @package 	Jono
 * @author   	aprakasa
 * @license  	GPL-2.0+
 * @link     	http://prakasa.me/go/jono
 */

/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;

global $wp_version;

$version = '3.5.2';
/** Unregister default blocks  */
aq_unregister_block( 'AQ_Alert_Block' );
aq_unregister_block( 'AQ_Tabs_Block' );
aq_unregister_block( 'AQ_Text_Block' );
/** Load all blocks  */
include_once ( JONO_BLOCKS_DIR . 'block-text.php' );
include_once ( JONO_BLOCKS_DIR . 'block-container-open.php' );
include_once ( JONO_BLOCKS_DIR . 'block-container-close.php' );
include_once ( JONO_BLOCKS_DIR . 'block-action.php' );
include_once ( JONO_BLOCKS_DIR . 'block-featured-page.php' );
include_once ( JONO_BLOCKS_DIR . 'block-recent-posts.php' );
include_once ( JONO_BLOCKS_DIR . 'block-portfolio.php' );
include_once ( JONO_BLOCKS_DIR . 'block-slider.php' );
include_once ( JONO_BLOCKS_DIR . 'block-tabs.php' );
include_once ( JONO_BLOCKS_DIR . 'block-clients.php' );
include_once ( JONO_BLOCKS_DIR . 'block-image.php' );
include_once ( JONO_BLOCKS_DIR . 'block-oembed.php' );
/** For WordPress 3.6+ */
if ( version_compare( $wp_version, '3.5.2', '>' ) ) {
	include_once ( JONO_BLOCKS_DIR . 'block-audio.php' );
	include_once ( JONO_BLOCKS_DIR . 'block-video.php' );
}
/** WordPress repo plugins */
if ( defined( 'WPCF7_VERSION' ) )
	include_once ( JONO_BLOCKS_DIR . 'block-cf7.php' );
/** Premium Slider Plugins */
if ( class_exists( 'Tgmsp' ) || class_exists( 'Tgmsp_Lite' ) )
	include_once ( JONO_BLOCKS_DIR . 'block-soliloquy.php' );
if ( class_exists( 'RevSlider' ) )
	include_once ( JONO_BLOCKS_DIR . 'block-revslider.php' );
if ( function_exists( 'layerslider' ) )
	include_once ( JONO_BLOCKS_DIR . 'block-layerslider.php' );

add_action( 'init', 'block_filter' );
function block_filter() {
	global $wp_embed;
	add_filter( 'jono_block_oembed', 'do_shortcode' );
	add_filter( 'jono_block_oembed', array( $wp_embed, 'run_shortcode' ), 8 );
	add_filter( 'jono_block_oembed', array( $wp_embed, 'autoembed'), 8 );
}