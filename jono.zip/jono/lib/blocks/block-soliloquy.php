<?php
/**
 * This file control Soliloquy slider block
 *
 * @package 	Jono
 * @author   	aprakasa
 * @license  	GPL-2.0+
 * @link     	http://prakasa.me/go/jono
 */

/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;

if( ! class_exists( 'Jono_Soliloquy_Block') ) :

class Jono_Soliloquy_Block extends AQ_Block {

	function __construct() {
		$block_options = array(
			'name' => 'Soliloquy Slider',
			'size' => 'span12',
		);		
		parent::__construct( 'Jono_Soliloquy_Block', $block_options );
	}
	
	function form( $instance ) {

		$defaults = array(
			'slider' 	=> '',
		);

		$instance = wp_parse_args( $instance, $defaults );
		extract( $instance );
		
		$sliders = jono_get_published_posts( 'soliloquy', __( 'Select slider:', 'jono' ) );
		
		if( empty( $sliders ) ) {
			echo __( 'You currently do not have any slider. Please create slider.', 'jono' );
			return false;
		}

		?>
		<div class="description">
			<label for="<?php echo $this->get_field_id( 'slider' ) ?>"><?php _e( 'Choose slider', 'jono' );?></label>
			<?php echo aq_field_select( 'slider', $block_id, $sliders, $slider ); ?>
		</div>
		<?php
	}
	
	function block($instance) {
		extract( $instance );
		if( ! class_exists( 'Tgmsp' ) && ! class_exists( 'Tgmsp_Lite' ) )
			return;
		if( ! empty( $slider ) )
			echo soliloquy_slider( $slider );
	}
 	
}

aq_register_block( 'Jono_Soliloquy_Block' );

endif;