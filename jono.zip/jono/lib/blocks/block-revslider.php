<?php
/**
 * This file control Revolution Slider block
 *
 * @package 	Jono
 * @author   	aprakasa
 * @license  	GPL-2.0+
 * @link     	http://prakasa.me/go/jono
 */

/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;

if( ! class_exists( 'Jono_RevSlider_Block' ) ) :

class Jono_RevSlider_Block extends AQ_Block {

	function __construct() {
		$block_options = array (
			'name' 		=> 'Revolution Slider',
			'size' 		=> 'span12',
			'resizable' => 0,
		);		
		parent::__construct( 'Jono_RevSlider_Block', $block_options );
	}
	
	function form( $instance ) {
		$defaults = array (
			'title'		=> ''
		);
		$instance = wp_parse_args( $instance, $defaults );
		extract($instance);		
		$slider = new RevSlider();
    	$arrSliders = $slider->getArrSlidersShort();
		if( empty( $arrSliders ) ) {
			_e( "No sliders found, Please create a slider", 'jono' );
		} else {			
			$field = "rev_slider";			
	    	$sliderID = UniteFunctionsRev::getVal($instance, $field);			
			$fieldID = $this->get_field_id( $field );
			$fieldName = $this->get_field_name( $field );			
			$select = UniteFunctionsRev::getHTMLSelect( $arrSliders, $sliderID,'name="'.$fieldName.'" id="'.$fieldID.'"', true );
		?>
			<div class="description">
			<?php _e( 'Choose Slider', 'jono' );?> : <?php echo $select; ?>
			</div>			
		<?php
		}
	}
	
	function block( $instance ) {
		extract( $instance );
		if( ! class_exists( 'RevSlider' ) )
			return;
		$sliderID = UniteFunctionsRev::getVal( $instance, "rev_slider" );				
		if( empty( $sliderID ) )
			return;						
		RevSliderOutput::putSlider( $sliderID );
	}

 	/* block header */
 	function before_block($instance) {
 		extract($instance);
 		$column_class = $first ? 'aq-first' : ''; 		
 		echo '<section id="aq-block-'.$template_id.'-'.$number.'" class="aq-block aq-block-'.$id_base.' aq_'.$size.' '.$column_class.' cf">';
 	}

 	/* block footer */
 	function after_block($instance) {
 		extract($instance);
 		echo '</section>';
 	}

}

aq_register_block( 'Jono_RevSlider_Block' );

endif;