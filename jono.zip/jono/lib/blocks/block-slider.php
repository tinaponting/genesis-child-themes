<?php
/**
 * This file controls Ayo Slider Block module
 *
 * @package 	Jono
 * @author   	aprakasa
 * @license  	GPL-2.0+
 * @link     	http://prakasa.me/go/jono
 */

/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;

if( ! class_exists( 'Jono_Slider_Block' ) ) :

class Jono_Slider_Block extends AQ_Block {

	function __construct() {
		$block_options 	= array(
			'name'	=> __( 'Slider', 'jono' ),
			'size'	=> 'span12',
		);		
		parent::__construct( 'Jono_Slider_Block', $block_options );		
		add_action( 'wp_ajax_aq_block_slides_add_new', array( $this, 'add_slide' ) );
	}
	
	function form( $instance ) {
		$defaults = array(
			'title'		=> '',
			'slides'	=> array(
				1 => array(
					'title' 	=> __( 'Slider Title Goes Here', 'jono'  ),
					'caption' 	=> '',
					'upload' 	=> '',
					'link'		=> ''
				)
			),
			'effect'	=> '',
			'max_height'=> '480',
		);
		$instance = wp_parse_args( $instance, $defaults );
		extract( $instance );

        $slide_effect = array(
            'fade'		=> 'Fade',
            'slide' 	=> 'Slide' );		
		?>
        <div class="description">
            <label for="<?php echo $this->get_field_id( 'title' ) ?>"><?php _e( 'Title', 'jono' );?> *<?php _e( 'Optional', 'jono' );?></label>
            <?php echo aq_field_input( 'title', $block_id, $title ) ?>
        </div>

		<div class="description">
			<ul id="sortable-list-<?php echo $block_id ?>" class="aq-sortable-list" rel="<?php echo $block_id ?>">
				<?php
				$slides = is_array( $slides ) ? $slides : $defaults['slides'];
				$count = 1;
				foreach( $slides as $slide ) {	
					$this->slide( $slide, $count );
					$count++;
				}
				?>
			</ul>
			<a href="#" rel="slides" class="aq-sortable-add-new button"><?php _e( 'Add New Slide', 'jono' );?></a>
		</div>

        <div class="description">
            <label for="<?php echo $this->get_field_id( 'effect' ) ?>"><?php _e( 'Slider Effect', 'jono' );?></label>
            <?php echo aq_field_select( 'effect', $block_id, $slide_effect, $effect ) ?>
        </div>

        <div class="description half">
            <label for="<?php echo $this->get_field_id( 'max_height' ) ?>"><?php _e( 'Max Height for Slider', 'jono' );?></label>
            <?php echo aq_field_input( 'max_height', $block_id, $max_height, $size = 'min', $type = 'number' ) ?>px
        </div>
		<?php
	}
	
	function slide( $slide = array(), $count = 0 ) {		
		$defaults = array (
			'title' 	=> '',
			'upload' 	=> '',
			'caption' 	=> '',
			'link'		=> ''
		);
		$slide = wp_parse_args( $slide, $defaults );
		?>
		<li id="<?php echo $this->get_field_id('slides') ?>-sortable-item-<?php echo $count ?>" class="sortable-item" rel="<?php echo $count ?>">
			
			<div class="sortable-head cf">
				<div class="sortable-title">
					<strong><?php echo __( 'Slider Title') .' : '.$slide['title'] ?></strong>
				</div>
				<div class="sortable-handle">
					<a href="#">Open / Close</a>
				</div>
			</div>
			
			<div class="sortable-body">

				<div class="description">
					<label for="<?php echo $this->get_field_id('slides') ?>-<?php echo $count ?>-title"><?php _e( 'Slider Title', 'jono' );?></label>							
					<input type="text" id="<?php echo $this->get_field_id('slides') ?>-<?php echo $count ?>-title" class="input-full" name="<?php echo $this->get_field_name('slides') ?>[<?php echo $count ?>][title]" value="<?php echo $slide['title'] ?>" />
				</div>

				<div class="description">
					<label for="<?php echo $this->get_field_id('slides') ?>-<?php echo $count ?>-caption"><?php _e( 'Slider Caption', 'jono' );?></label>
					<textarea id="<?php echo $this->get_field_id('slides') ?>-<?php echo $count ?>-caption" class="textarea-full" name="<?php echo $this->get_field_name('slides') ?>[<?php echo $count ?>][caption]" rows="5"><?php echo $slide['caption'] ?></textarea>
				</div>

				<div class="description">
					<label for="<?php echo $this->get_field_id('slides') ?>-<?php echo $count ?>-upload"><?php _e( 'Upload Image', 'jono'  );?></label>
					<input type="text" id="<?php echo $this->get_field_id('slides') ?>-<?php echo $count ?>-upload" class="input-full input-upload" value="<?php echo $slide['upload'] ?>" name="<?php echo $this->get_field_name('slides') ?>[<?php echo $count ?>][upload]">
					<a href="#" class="aq_upload_button button" rel="image"><?php _e( 'Upload', 'jono' );?></a>
				</div>

				<div class="description">
					<label for="<?php echo $this->get_field_id('slides') ?>-<?php echo $count ?>-link"><?php _e( 'Slider Link', 'jono' );?> *<?php _e( 'Optional', 'jono' );?></label>				
					<input type="text" id="<?php echo $this->get_field_id('slides') ?>-<?php echo $count ?>-link" class="input-full" name="<?php echo $this->get_field_name('slides') ?>[<?php echo $count ?>][link]" value="<?php echo $slide['link'] ?>" />
				</div>

				<div class="description"><a href="#" class="sortable-delete"><?php _e( 'Delete', 'jono' );?></a></p>

			</div>
			
		</li>
		<?php		
	}
	
	function add_slide() {
		$nonce = $_POST['security'];	
		if ( ! wp_verify_nonce( $nonce, 'aqpb-settings-page-nonce' ) ) die('-1');		
		$count = isset($_POST['count']) ? absint($_POST['count']) : false;
		$this->block_id = isset($_POST['block_id']) ? $_POST['block_id'] : 'aq-block-9999';		
		//default key/value for the tab
		$slide = array(
			'title' 	=> __( 'Slider Title Goes Here', 'jono' ),
			'caption' 	=> '',
			'upload' 	=> '',
			'link'		=> ''
		);		
		if($count) {
			$this->slide($slide, $count);
		} else {
			die(-1);
		}		
		die();
	}
	
	function block($instance) {		
		extract( $instance );
		wp_enqueue_script( "jquery-flexslider" );
		$output = '';
		if( $slides ) {
			$rand = rand( 1, 100 );			
			$output .= '<div id="jono-slider-'. $rand .'" class="jono-flexslider" data-effect="'. $effect .'">';
				$output .= '<ul class="jono-slides cf">';
				foreach ( $slides as $i => $slide ) :
					$output .= '<li style="max-height:'. (int)$max_height .'px">';
						if( ! empty( $slide['upload'] ) && ! empty( $slide['link'] ) ) :
							$output .= '<a href="'. esc_url( $slide['link'] ) .'" title="'. strip_tags( $slide['title'] ) .'"><img src="'. esc_url( $slide['upload'] ) .'" alt="'. strip_tags( $slide['title'] ) .'" /></a>';
						elseif ( ! empty( $slide['upload'] ) ) :
							$output .= '<img src="'. esc_url( $slide['upload'] ) .'" alt="'. strip_tags( $slide['title'] ) .'" />';
						else :
							$output .= '<img src="'. JONO_ASSETS_URI .'images/slider-placeholder.png" alt="'. strip_tags( $slide['title'] ) .'" />';
						endif;
						if( ! empty( $slide['title'] ) || ! empty( $slide['caption'] ) ) {
							$output .= '<div class="slide-content">';
							if ( ! empty( $slide['title'] ) ) {
								$output .= '<h4>'. strip_tags( $slide['title'] ) .'</h4>';
							}
							if ( ! empty( $slide['caption'] ) ) {
								$output .= '<p>'. esc_textarea( $slide['caption'] ) .'</p>';
							}
							$output .= '</div>';
						}
					$output .= '</li>';
				endforeach;
				$output .= '</ul>';
			$output .= '</div>';
		}		
		echo $output;
	}
	
	function update( $new_instance, $old_instance ) {
		$new_instance = aq_recursive_sanitize( $new_instance );
		return $new_instance;
	}

 	/* block header */
 	function before_block($instance) {
 		extract($instance);
 		$column_class = $first ? 'aq-first' : ''; 		
 		echo '<section id="aq-block-'.$template_id.'-'.$number.'" class="aq-block aq-block-'.$id_base.' aq_'.$size.' '.$column_class.' cf">';
 	}

 	/* block footer */
 	function after_block($instance) {
 		extract($instance);
 		echo '</section>';
 	}
}

aq_register_block( 'Jono_Slider_Block' );

endif;