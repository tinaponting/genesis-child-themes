<?php
/**
 * This file control custom text block class
 *
 * @package 	Jono
 * @author   	aprakasa
 * @license  	GPL-2.0+
 * @link     	http://prakasa.me/go/jono
 */

/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;

if( ! class_exists( 'Jono_Text_Block' ) ) :

class Jono_Text_Block extends AQ_Block {

	function __construct() {
		$block_options = array(
			'name' => __( 'Text', 'jono' ),
			'size' => 'span4',
		);
		
		parent::__construct( 'Jono_Text_Block', $block_options );
	}

 	function form( $instance ) {

		$defaults = array(
			'title'		=> '',
			'icon'		=> '',
			'content' 	=> '',
			'ptag'		=> false
		);

		$instance = wp_parse_args( $instance, $defaults );
		extract( $instance );

		?>

		<div class="description half">
			<label for="<?php echo $this->get_field_id('title') ?>"><?php _e( 'Title', 'jono' );?></label>	
			<?php echo aq_field_input('title', $block_id, $title) ?>			
		</div>

		<div class="description half last is-fontawesome">
			<label for="<?php echo $this->get_field_id( 'icon' ) ?>"><?php _e( 'Icon', 'jono' );?> *<?php _e( 'Optional', 'jono' );?></label>				
			<?php echo aq_field_select( 'icon', $block_id, jono_get_fontawesome(), $icon ) ?>
		</div>

		<div class="description">
			<label for="<?php echo $this->get_field_id( 'content' ) ?>"><?php _e( 'Content', 'jono' );?></label>
			<?php echo aq_field_textarea( 'content', $block_id, $content ) ?>			
		</div>

		<div class="description">
			<?php echo aq_field_checkbox( 'ptag', $block_id, $ptag ) ?>&nbsp;&nbsp;
			<label for="<?php echo $this->get_field_id( 'ptag' ) ?>"><?php _e( 'Automatically add paragraphs.', 'jono' );?></label>
		</div>

		<?php

	}

	function block( $instance ) {
		extract( $instance );
		$icon = ( ! empty( $icon ) ) ? '<i class="icon-'. $icon .'"></i>' : '';
		$output = ( ! empty( $title ) ) ? '<h4 class="widget-title"><span>'. $icon . strip_tags( $title ) .'</span></h4>' : '';
		$content = ( current_user_can('unfiltered_html') ) ? do_shortcode( htmlspecialchars_decode( $content ) ) : stripslashes( wp_filter_post_kses( addslashes( $content ) ) );
		if ( ! empty( $content ) ) {			
			$output .= '<div class="entry-content">';
			$output .= ( $ptag == true ) ? wpautop( $content ) : $content;
			$output .= '</div>';
		}
		echo $output;	
	}

 	/* block header */
 	function before_block($instance) {
 		extract($instance);
 		$column_class = $first ? 'aq-first' : ''; 		
 		echo '<section id="aq-block-'.$template_id.'-'.$number.'" class="aq-block aq-block-'.$id_base.' aq_'.$size.' '.$column_class.' cf">';
 	}

 	/* block footer */
 	function after_block($instance) {
 		extract($instance);
 		echo '</section>';
 	}

}

aq_register_block( 'Jono_Text_Block' );

endif;