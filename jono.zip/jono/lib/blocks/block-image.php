<?php
/**
 * This file control custom text block class
 *
 * @package 	Jono
 * @author   	aprakasa
 * @license  	GPL-2.0+
 * @link     	http://prakasa.me/go/jono
 */

/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;

if( ! class_exists( 'Jono_Image_Block' ) ) :

class Jono_Image_Block extends AQ_Block {

	function __construct() {
		$block_options = array(
			'name' => __( 'Image', 'jono' ),
			'size' => 'span4',
		);
		
		parent::__construct( 'Jono_Image_Block', $block_options );
	}

 	function form( $instance ) {

		$defaults = array(
			'title'		=> '',
			'image' 	=> ''
		);

		$instance = wp_parse_args( $instance, $defaults );
		extract( $instance );

		?>

		<div class="description">
			<label for="<?php echo $this->get_field_id('title') ?>"><?php _e( 'Title', 'jono' );?></label>	
			<?php echo aq_field_input('title', $block_id, $title) ?>			
		</div>
		<div class="description">
			<label for="<?php echo $this->get_field_id( 'image' ) ?>"><?php _e( 'Upload an Image', 'jono' );?></label>
			<?php echo aq_field_upload( 'image', $block_id, $image ); ?>
			<?php if( ! empty( $image ) ) : ?>
			<div class="screenshot">
				<img src="<?php echo $image ?>" />
			</div>
			<?php endif; ?>
		</div>

		<?php

	}

	function block( $instance ) {
		extract( $instance );
		if ( ! empty( $image ) ) 
			echo '<img class="aligncenter" src="'.$image.'" alt="'. $title .'" title="'. $title .'" />';	
	}

 	/* block header */
 	function before_block($instance) {
 		extract($instance);
 		$column_class = $first ? 'aq-first' : ''; 		
 		echo '<section id="aq-block-'.$template_id.'-'.$number.'" class="aq-block aq-block-'.$id_base.' aq_'.$size.' '.$column_class.' cf">';
 	}

 	/* block footer */
 	function after_block($instance) {
 		extract($instance);
 		echo '</section>';
 	}

}

aq_register_block( 'Jono_Image_Block' );

endif;