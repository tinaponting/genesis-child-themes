<?php
/**
 * This file control Featured Block Class
 *
 * @package 	Jono
 * @author   	aprakasa
 * @license  	GPL-2.0+
 * @link     	http://prakasa.me/go/jono
 */

/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;

if( ! class_exists( 'Jono_Featured_Page') ) :

class Jono_Featured_Page extends AQ_Block {

	function __construct() {

		$block_options = array(
			'name' 	=> __( 'Featured Page', 'jono' ),
			'size' 	=> 'span4',
		);
		
		parent::__construct( 'Jono_Featured_Page', $block_options );

	}
	
	function form( $instance ){

		$defaults = array (
			'title'		=> '',
			'icon'		=> '',
			'page' 		=> '',
			'image'		=> '',
			'limit'		=> '20',
			'more'		=> '',
		);

		$instance = wp_parse_args( $instance, $defaults );
		extract( $instance );

	?>

		<p class="description">
			<label for="<?php echo $this->get_field_id( 'icon' ) ?>"><?php _e( 'Icon', 'jono' );?> *<?php _e( 'Optional', 'jono' );?></label>				
			<?php echo aq_field_select( 'icon', $block_id, jono_get_fontawesome(), $icon ) ?>
		</p>

        <div class="description">
            <label for="<?php echo $this->get_field_id( 'page' ) ?>"><?php _e( 'Featured page', 'jono' );?></label>               
            <?php echo aq_field_select( 'page', $block_id, jono_get_published_posts( 'page' ) , $page ) ?>            
        </div>

		<p class="description">
			<?php echo aq_field_checkbox( 'image', $block_id, $image ) ?>&nbsp;&nbsp;
			<label for="<?php echo $this->get_field_id( 'image' ) ?>"><?php _e( 'Display featured image', 'jono'  );?></label>
		</p>

		<div class="description">
			<label for="<?php echo $this->get_field_id( 'limit' ) ?>"><?php _e( 'Content limit', 'jono' );?></label>&nbsp;&nbsp;
			<?php echo aq_field_input( 'limit', $block_id, $limit, $size = 'min', $type = 'number' ) ?><?php _e( 'words','jono' );?>
		</div>

		<p class="description">
			<label for="<?php echo $this->get_field_id('more') ?>"><?php _e( 'Read More Text', 'jono' );?></label>	
			<?php echo aq_field_input( 'more', $block_id, $more )  ?>			
		</p>

	<?php
		
	}
	
	function block( $instance ) {
		global $wp_query;

		extract( $instance );

		if ( empty( $page ) ) return;

		$wp_query 	= new WP_Query( array( 
			'page_id' 					=> $page,
			'no_found_rows' 			=> true,
    		'update_post_term_cache' 	=> false,
    		'update_post_meta_cache' 	=> false ) );

		if ( have_posts() ) : while ( have_posts() ) : the_post();
			$regular_icon 	= ( !empty( $icon ) ) ? '<i class="icon-'. $icon .'"></i>' : '';
			$large_icon 	= ( !empty( $icon ) ) ? '<i class="icon-'. $icon .' icon-large"></i>' : '';
			$img 			= genesis_get_image( array( 'format' => 'url', 'size' => 'romo-featured' ) );

			$output = '<article class="featured-page cf" itemscope="itemscope" itemtype="http://schema.org/CreativeWork">';
				if ( ( $image == true ) ) {
					if ( ! empty( $img ) ) {
						$output .= sprintf( '<div class="featured-image"><a href="%1$s" title="%2$s"><img src="%3$s" alt="%2$s" /></a></div>',
									get_permalink( $page ),
									get_the_title( $page ),
									$img );
					}
					$output .= sprintf( '<h2 class="aq-block-title" itemprop="headline"><a href="%1$s" title="%2$s">%3$s %2$s</a></h2>', 
								get_permalink( $page ), 
								get_the_title( $page ),
								$large_icon );
				} elseif ( ( $image == false ) && $icon ) {
					$output .='<div class="featured-icon">'. $regular_icon .'</div>';
					$output .= sprintf( '<h2 class="aq-block-title aligncenter" itemprop="headline"><a href="%1$s" title="%2$s">%2$s</a></h2>', 
									get_permalink( $page ), 
									get_the_title( $page ) );
				} else {
					$output .= sprintf( '<h2 class="aq-block-title" itemprop="headline"><a href="%1$s" title="%2$s">%2$s</a></h2>', 
									get_permalink( $page ), 
									get_the_title( $page ) );
				}
				$output .='<div class="entry-content" itemprop="text">';
				if ( ! empty( $limit ) ) :
					$output .= wpautop( wp_trim_words( get_the_content(), $limit ) );
				else :
					$output .= wpautop( get_the_content() );
				endif;
				$output .= '</div>';
				if ( !empty( $more ) ) {
					$output .= sprintf( '<a class="featured-button" href="%s" title="%s">%s</a>',
									get_permalink( $page ), 
									get_the_title( $page ),
									esc_attr( $more ) );
				}
			$output .= '</article>';
			echo $output;
			endwhile;
		endif;
		wp_reset_query();
	}

 	/* block header */
 	function before_block($instance) {
 		extract($instance);
 		$column_class = $first ? 'aq-first' : ''; 		
 		echo '<section id="aq-block-'.$template_id.'-'.$number.'" class="aq-block aq-block-'.$id_base.' aq_'.$size.' '.$column_class.' cf">';
 	}

 	/* block footer */
 	function after_block($instance) {
 		extract($instance); 		
 		echo '</section>';
 	}
 	
}

aq_register_block( 'Jono_Featured_Page' );

endif;