<?php
/**
 * Close wrapper/container
 *
 * @package 	Jono
 * @author   	aprakasa
 * @license  	GPL-2.0+
 * @link     	http://prakasa.me/go/jono
 */

/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;

if( ! class_exists( 'Jono_Close_Container_Block') ) :

class Jono_Close_Container_Block extends AQ_Block {

	function __construct() {
		$block_options = array(
			'name' 		=> 'Container (close)',
			'size' 		=> 'span12',
			'resizable' => 0,
		);		
		parent::__construct( 'Jono_Close_Container_Block', $block_options );		
	}
	
	function form( $instance ){
		extract( $instance );		
		?>
		<p class="description">
			<?php _e( 'There is no settings in here. Just make it sure to add this block if you use container (open).', 'jono' ); ?>
		</p>
		<?php
	}
	
	function block($instance) {
		extract( $instance );
		echo "</div>\n</div>";
	}


	function before_block($instance) {
		extract($instance);
		return;
	}

	function after_block($instance) {
 		extract($instance);
 		return;
	}
 	
}

aq_register_block( 'Jono_Close_Container_Block' );

endif;