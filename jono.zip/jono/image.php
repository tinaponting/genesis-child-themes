<?php
/**
 * The main template file.
 *
 * @package 	Jono
 * @author   	aprakasa
 * @license  	GPL-2.0+
 * @link     	http://prakasa.me/go/jono
 */

/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;

remove_action( 'genesis_entry_header', 'genesis_do_post_format_image', 4 );
remove_action( 'genesis_entry_content', 'genesis_do_post_image', 8 );
remove_action( 'genesis_entry_content', 'genesis_do_post_permalink', 14 );
remove_action( 'genesis_entry_footer', 'genesis_post_meta' );

add_action( 'genesis_entry_content', 'jono_attachment_image' );
/** 
 * Image post
 * 
 * @since 1.0
 */
function jono_attachment_image() {
	$caption = ( get_the_excerpt() !=="") ? '<p class="wp-caption-text">'. get_the_excerpt() .'</p>' : "";
	$img = genesis_get_image( array( 
		'format' 	=> 'html', 
		'size' 		=> 'full', 
		'attr' 		=> genesis_parse_attr( 'entry-image' ) ) );
	echo '<div class="wp-caption aligncenter">'. $img .''. $caption .'</div>';
}

genesis();