<?php
//Front Page
remove_action( 'genesis_before_content', 'genesis_do_breadcrumbs' );
add_action( 'genesis_meta', 'lush_home_genesis_meta' );
/**
 * Add widget support for homepage. If no widgets active, display the default loop.
 */
function lush_home_genesis_meta() {
	if ( is_active_sidebar( 'homewidget-area' ) ) {
		remove_action( 'genesis_loop', 'genesis_do_loop' );
		add_action( 'genesis_loop', 'lush_home_widgets' );
		}
}
/** Widget area **/
function lush_home_widgets() {
	
		genesis_widget_area( 'homewidget-area', array(
		'before'=> '<div id="homewidget-area-wrap" class="homewidget-wrap">',
		'after'=> '</div>',
	));} 
genesis();