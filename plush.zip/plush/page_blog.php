<?php /*
Template Name: Blog
*/
remove_action( 'genesis_loop', 'genesis_do_loop' );
add_action( 'genesis_loop', 'lush_do_custom_loop' ); 
function lush_do_custom_loop() { 
    global $paged;
    global $query_args; 
    $args = array(
        'post_type' => 'post',
        'paged'=> $paged,
    );
    genesis_custom_loop( wp_parse_args($query_args, $args) );
}
genesis(); 