<?php
//* Start the engine to load the core files
include_once( get_template_directory() . '/lib/init.php' );

//* Child theme (do not remove)
define( 'CHILD_THEME_NAME', 'Plush' );
define( 'CHILD_THEME_VERSION', '1.0' );

//* Enqueue Google Fonts
add_action( 'wp_enqueue_scripts', 'genesis_sample_google_fonts' );
function genesis_sample_google_fonts() {
	wp_enqueue_style( 'google-fonts', '//fonts.googleapis.com/css?family=Lato:300,400,700', array(), CHILD_THEME_VERSION );
}
//* Make Font Awesome available
add_action( 'wp_enqueue_scripts', 'enqueue_font_awesome' );
function enqueue_font_awesome() {wp_enqueue_style( 'font-awesome', '//netdna.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.css' );
}
//* Add HTML5 markup structure
add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list' ) );

//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Add support for custom background
add_theme_support( 'custom-background' );

// add support for custom background to custom post type pages
add_post_type_support( 'books', 'custom-background' );


//* Add support for 3-column footer widgets
add_theme_support( 'genesis-footer-widgets', 3 );

//* Unregister header right
unregister_sidebar(  'header-right'  );

//* Add support for structural wraps
add_theme_support( 'genesis-structural-wraps', array(
	'header',
	'nav',
	'subnav',
	'site-inner',
	'footer-widgets',
	'footer'
));
//* Reposition Breadcrumbs
remove_action( 'genesis_before_loop', 'genesis_do_breadcrumbs' );
add_action( 'genesis_before_content', 'genesis_do_breadcrumbs' );

//* Reposition the secondary navigation menu
remove_action( 'genesis_after_header', 'genesis_do_subnav' );
add_action( 'genesis_before', 'genesis_do_subnav' );

//* Customize search form input button text
add_filter( 'genesis_search_button_text', 'lush_search_button_text' );
function lush_search_button_text( $text ) {return esc_attr( '&#xf002;' );
}
/** Custom post types */
require_once(  get_stylesheet_directory(  ) . '/include/lush_post_types/book_cpt.php'   );

/** Woocommerce */
require_once(  get_stylesheet_directory(  ) . '/include/woocommerce/lush_woocommerce.php'   );

/** Post like */
require_once(  get_stylesheet_directory(  ) . '/include/postlike/post-like.php'   );

/** Widgets */
require_once(  get_stylesheet_directory(  ) . '/include/widgets/featured-custom-post-widget.php'   );

/** Author Box */
require_once(  get_stylesheet_directory(  ) . '/include/lush_author_box.php'   );

// Enqueue scripts and styles
add_action( 'wp_enqueue_scripts', 'custom_scripts_styles_mobile_responsive' );
function custom_scripts_styles_mobile_responsive() {
	wp_enqueue_script( 'responsive-menu', get_stylesheet_directory_uri() . '/js/responsive-menu.js', array( 'jquery' ), '1.0.0', true );
	wp_enqueue_style( 'dashicons' );
}
//* Enqueue sticky menu script
add_action( 'wp_enqueue_scripts', 'lush_enqueue_script' );
function lush_enqueue_script() {
wp_enqueue_script( 'sample-sticky-menu', get_bloginfo( 'stylesheet_directory' ) . '/js/sticky-menu.js', array( 'jquery' ), '1.0.0' );
}
add_action( 'wp_enqueue_scripts', 'lush_clear_search_form' );
function lush_clear_search_form() {
	wp_enqueue_script( 'clear-search-form',  get_stylesheet_directory_uri() . '/js/clear-search-form.js', array( 'jquery' ), '1.0.0', true );
}
//* Remove Default Featured Post widget
add_action( 'widgets_init', 'remove_featured_post_widget', 20 );
function remove_featured_post_widget() {unregister_widget( 'Genesis_Featured_Post' );
}
// Register custom image sizes
add_image_size( 'singular-featured-thumb', 800, 250, true );

// Register the featured thumb image size for Singular Featured posts
add_action( 'genesis_before_entry', 'lush_display_featured_image' );
function lush_display_featured_image() {
	if ( ! is_singular( array( 'post', 'page') ) ) {return;
	}
	if ( ! has_post_thumbnail() ) {return;
	}
	// Display featured image above content
	echo '<div class="singular-featured-image">';genesis_image( array( 'size' => 'singular-featured-thumb' ) );echo '</div>';
}
//* Add Color Style Options
add_theme_support( 'genesis-style-selector', array(
'lush-pink'=> __( 'Pink', 'lush' ),
'lush-green'=> __( 'Green', 'lush' ),
'lush-purple'=> __( 'Purple', 'lush' ),
));

add_filter('body_class', 'string_body_class');
function string_body_class( $classes ) {if ( isset( $_GET['color'] ) ) :$classes[] = 'lush-' . sanitize_html_class( $_GET['color'] );endif;return $classes;
}	
//* Set the width for video embeds
if ( ! isset( $content_width ) ) $content_width = 980;

//* Modify the size of the Gravatar in comments
add_filter( 'genesis_comment_list_args', 'lush_comments_gravatar' );
function lush_comments_gravatar( $args ) {$args['avatar_size'] = 80;return $args;
}
//* Modify the size of the Gravatar in the User Profile Widget
add_filter( 'genesis_gravatar_sizes', 'lush_user_profile' );
function lush_user_profile( $sizes ) {
	$sizes['Small'] = 85;
	$sizes['Medium'] = 125;
	$sizes['Large'] = 240;
	$sizes['Extra Large'] = 280;
	$sizes['Extra Large Image'] = 340;return $sizes;
}
//* Remove HTML allowed tag in comment form
add_filter( 'comment_form_defaults', 'lush_comment_form_allowed_tags' );
function lush_comment_form_allowed_tags( $defaults ) {$defaults['comment_notes_after'] = '';return $defaults;
}
// Add Read More Link to Excerpts
add_filter('excerpt_more', 'get_read_more_link');
add_filter( 'the_content_more_link', 'get_read_more_link' );
function get_read_more_link() {return '...&nbsp;<a class="more-link" href="' . get_permalink() . '">Read&nbsp;More</a>';
}
//* Add post type functionality inside and outside loops
function is_post_type($type){
    global $wp_query;
    if($type == get_post_type($wp_query->post->ID)) return true;return false;
}
/** Reposition Post Info */
remove_action( 'genesis_entry_header', 'genesis_post_info', 12 );
add_action( 'genesis_entry_header', 'genesis_post_info', 9 );

//* Customize the entry meta in the entry header
add_filter( 'genesis_post_info', 'lush_custom_post_info' );
function lush_custom_post_info($post_info) {	
	if (!is_page()) {
	$post_info = '[post_date] by [post_author_posts_link] [post_comments zero="Comment" one="1 Comment" more="% Comments"] [post_like] [post_edit]';}return $post_info;
}
//* Customize the entry meta in the entry footer 
add_filter( 'genesis_post_meta', 'lush_custom_post_meta_filter' );
function lush_custom_post_meta_filter($post_meta) {
	if (!is_page()) {
	$post_meta = '[post_categories sep="/" before="Categories: "] [post_tags sep="/" before="Tags: "]';}
	if ( is_post_type('books')) {
	$post_meta = '[post_edit]';}
	return $post_meta;
}
// Customize the previous page link
add_filter ( 'genesis_prev_link_text' , 'sp_previous_page_link' );
function sp_previous_page_link ( $text ) {
	return g_ent( '&laquo; ' ) . __( 'Previous Page', CHILD_DOMAIN );
}
// Customize the next page link
add_filter ( 'genesis_next_link_text' , 'sp_next_page_link' );
function sp_next_page_link ( $text ) {
	return __( 'Next Page', CHILD_DOMAIN ) . g_ent( ' &raquo; ' );
}
//* Change the footer text
add_filter('genesis_footer_creds_text', 'lush_footer_creds_filter');
function lush_footer_creds_filter( $creds ) {
echo'<p class=footer-credits>';
	$creds = '[footer_copyright] ' . get_bloginfo('name') .'. Made with Pride! <span class="dashicons dashicons-heart"></span> using a <a href="http://exempel.se">MY OWN DESIGN</a>.';
	return $creds;
	echo'</p>';
}
// Previous and Next Post navigation in the same category in single Posts only
add_action('genesis_after_entry', 'lush_custom_post_nav');
function lush_custom_post_nav() {
	if ( !is_singular('post') )return;
	echo '<div class="prev-next-post-links">';
		previous_post_link('<div class="previous-post-link">&laquo; Previous Post: %link</div>', '<strong>%title</strong>', true);
		next_post_link('<div class="next-post-link">Next Post: %link &raquo;</div>', '<strong>%title</strong>', true);
	echo '</div>';
}
//* Register Additional Sidebar Areas
genesis_register_sidebar( 
    array(
        'id'=> 'homewidget-area',
        'name'=> __( 'Home Widget Area', 'lush' ),
        'description'=> __( 'This is the widget area on the main homepage.', 'lush' ),
));
//* Custom Primary Sidebar for single Book entries
genesis_register_sidebar( array(
	'id'=> 'primary-sidebar-book',
	'name'=> 'Primary Sidebar - Book',
	'description'=> 'This is the primary sidebar for Single Book pages'
));
//After entry widget
genesis_register_sidebar( array(
    'id'=> 'after-entry',
    'name'=> __( 'After Entry Widget Area', 'lush' ),
    'description'=> __( 'This is the bottom widget section on single blog posts.', 'lush' ),
));
//* Hooks after-entry widget area to single blog posts
add_action( 'genesis_entry_footer', 'lush_bottom_widget'  ); 
function lush_bottom_widget() {
    if ( ! is_singular('post'))return;
    genesis_widget_area( 'after-entry', array(
		'before'=> '<div class="after-entry"><div class="wrap">',
		'after'=> '</div></div>',
    ));}
/*
 * To Top Link 
 */
add_action( 'genesis_after','lush_add_top_link' );
function lush_add_top_link(  ){echo '<a href="#top" id="top-link"> &uarr; '. __( 'Back to Top','lush' ) .'</a>';
}