<?php
//* Remove the entry meta in the entry header
remove_action( 'genesis_entry_header', 'genesis_post_info', 9 );
remove_action( 'genesis_entry_header', 'plush_genesis_post_info_sep', 9 );

add_action( 'genesis_entry_content', 'plush_show_featured_image_single_book_pages', 9 );
/**
 * Display Featured Image floated to the right in single Posts.
 */
function plush_show_featured_image_single_book_pages() {
	$image_args = array(
		'size'=> 'medium',
		'attr'=> array(
			'class'=> 'alignleft',
		),);
	genesis_image( $image_args );
}
add_action( 'genesis_before_sidebar_widget_area', 'lush_display_book_custom_fields' );
/**
 * One line description with a period at the end.
 */
add_action( 'genesis_entry_content', 'plush_add_buy_button' );
function plush_add_buy_button() {
	if ( get_field( 'book_purchase_link' ) ) {echo '<a href="' . get_field( 'book_purchase_link' ) . '" class="button">Click here to buy</a>';
	}}
//* Previous and Next Post navigation
add_action('genesis_after_content_sidebar_wrap', 'plush_custom_book_post_nav');
function plush_custom_book_post_nav() {

	echo '<div class="prev-next-post-links">';
		previous_post_link('<div class="previous-post-link">&laquo; %link</div>', '<strong>%title</strong>' );
		next_post_link('<div class="next-post-link">%link &raquo;</div>', '<strong>%title</strong>' );
	echo '</div>';
}
add_action( 'genesis_after_header', 'plush_change_genesis_primary_sidebar' );
/**
 * Show custom Primary sidebar in Primary Sidebar location.
 */
function plush_change_genesis_primary_sidebar() {
	if( is_active_sidebar( 'primary-sidebar-book' ) ) {
		remove_action( 'genesis_sidebar', 'genesis_do_sidebar' );
		add_action( 'genesis_sidebar', 'plush_do_sidebar' );
	}}
function plush_do_sidebar() {
	dynamic_sidebar( 'primary-sidebar-book' );
}
//* Remove the author box
remove_action( 'genesis_after_entry', 'genesis_do_author_box_single', 8 );
genesis();