<?php
add_filter( 'user_contactmethods', 'be_contactmethods' );
/**
 * Customize Contact Methods
 * @param array $contactmethods
 * @return array
 */
function be_contactmethods( $contactmethods ) {
    unset( $contactmethods['twitter'] );
    unset( $contactmethods['googleplus'] );
    unset( $contactmethods['facebook'] );
    $contactmethods['twitter_custom'] = 'Twitter Profile URL';
    $contactmethods['facebook_custom'] = 'Facebook Profile URL';
    $contactmethods['linkedin_custom'] = 'LinkedIn Profile URL';
    $contactmethods['goodreads_custom'] = 'Goodreads Profile URL';return $contactmethods;
}
/*
 * Removes default Genesis Author Box
 * Adds a custom author box with custom user meta fields
 */
remove_action( 'genesis_after_entry', 'genesis_do_author_box_single', 8 );
add_action( 'genesis_after_entry', 'lush_theme_author_box', 8 ); 
function lush_theme_author_box() {
if(is_singular('post')){
 ?>
	<?php $gravatar = get_avatar( get_the_author_meta( 'ID' ), 250 ); // Author Gravatar ?>
	<?php $display_name = get_the_author_meta( 'display_name' ); // Author Display Name ?>
	<?php $user_firstname = get_the_author_meta( 'user_firstname' ); // Author First Name ?>
	<?php $user_lastname = get_the_author_meta( 'user_lastname' ); // Author Last Name ?>
	<?php $authinfo = get_the_author_meta( 'description' ); // Author Bio ?>
	<?php $facebook = esc_url( htmlentities( get_the_author_meta( 'facebook_custom' ) ), array( 'https', 'http' ) ); ?>
	<?php $linkedin = esc_url( htmlentities( get_the_author_meta( 'linkedin_custom' ) ), array( 'https', 'http' ) ); ?>
	<?php $twitter = esc_url( htmlentities( get_the_author_meta( 'twitter_custom' ) ), array( 'https', 'http' ) ); ?>
	<?php $goodreads = esc_url( htmlentities( get_the_author_meta( 'goodreads_custom' ) ), array( 'https', 'http' ) ); ?>
	<?php $website = esc_url( htmlentities( get_the_author_meta( 'url' ) ), array( 'https', 'http' ) ); ?>

	<section class="author-box">
		<?php echo $gravatar; ?>
		<h2 class="author-box-title"><?php echo $user_firstname . " " . $user_lastname; ?></h2>
		<div class="author-box-content"><?php echo $authinfo; ?></div>
		<div class="author-social-links">
			<?php
			if ( $twitter || $facebook || $linkedin || $gplus || $website )
				echo 'Follow Me: ';
			if ( $twitter )
				echo '<a href="' . $twitter . '" class="author-social-link twitter" target="_blank"><i class="fa fa-2x fa-twitter"></i></a>';
			if ( $facebook )
				echo '<a href="' . $facebook . '" class="author-social-link facebook" target="_blank"><i class="fa fa-2x fa-facebook"></i></a>';
			if ( $linkedin )
				echo '<a href="' . $linkedin . '" class="author-social-link linkedin" target="_blank"><i class="fa fa-2x fa-linkedin"></i></a>';			
			if ( $goodreads )
				echo '<a href="' . $goodreads . '" class="author-social-link goodreads" href="LINK" title="Follow with Goodreads" target="_blank">g</a>';
			if ( $website )
				echo '<a href="' . $website . '" class="author-social-link website" target="_blank"><i class="fa fa-2x fa-globe"></i></a>';
			?>
		</div>
	</section>
<?php }
}