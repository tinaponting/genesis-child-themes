<?php
// ------------------ Woocommerce ------------------------ //
// Add WooCommerce support for Genesis layouts (sidebar, full-width, etc)
add_post_type_support( 'product', 'genesis-layouts' );

// Unhook WooCommerce Sidebar - use Genesis Sidebars instead
remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar', 10 );

//* Unhook the WooCommerce wrappers
remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10);
remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10);

//* Hook in functions to display the wrappers
add_action('woocommerce_before_main_content', 'lush_wrapper_start', 10);
add_action('woocommerce_after_main_content', 'lush_wrapper_end', 10);

// Add opening wrapper before WooCommerce loop
function lush_wrapper_start() {
    do_action( 'genesis_before_content_sidebar_wrap' );
    genesis_markup( array(
        'html5'=> '<div %s>',
        'xhtml'=> '<div id="content-sidebar-wrap">',
        'context'=> 'content-sidebar-wrap',
    ));
    do_action( 'genesis_before_content' );
    genesis_markup( array(
        'html5'=> '<main %s>',
        'xhtml'=> '<div id="content" class="hfeed">',
        'context'=> 'content',
    ));
    do_action( 'genesis_before_loop' );
}
/* Add closing wrapper after WooCommerce loop */
function lush_wrapper_end() {
    do_action( 'genesis_after_loop' );
    genesis_markup( array(
        'html5' => '</main>', 
        'xhtml' => '</div>', 
    ));
    do_action( 'genesis_after_content' );
    echo '</div>'; 
    do_action( 'genesis_after_content_sidebar_wrap' );
}
// Remove WooCommerce breadcrumbs, using Genesis crumbs instead.
add_action( 'get_header', 'lush_remove_wc_breadcrumbs' );
function lush_remove_wc_breadcrumbs() {
    remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20, 0 );
}
// Remove WooCommerce Theme Support admin message
add_theme_support( 'woocommerce' );

// Change number of products per row to 2
add_filter('loop_shop_columns', 'loop_columns');
if (!function_exists('loop_columns')) {
	function loop_columns() {return 2; 
	}} 
add_filter ( 'woocommerce_product_thumbnails_columns', 'lush_thumb_cols' );
function lush_thumb_cols() {return 2;
}
// Change number of products per page
add_filter( 'loop_shop_per_page', create_function( '$cols', 'return 6;' ), 20 );

/*delete this line to activate the sidebar

// Create a custom sidebar for WooCommerce store pages
add_action( 'genesis_before', 'lush_remove_store_sidebar' );

// Specify pages where the sidebar is displayed 
function lush_remove_store_sidebar() {
	if ( is_active_sidebar( 'store-sidebar' ) && (is_shop() || is_product() || is_cart() || is_checkout() ) ) {

		// Remove the standard genesis sidebar
		remove_action( 'genesis_sidebar', 'genesis_do_sidebar' );

		// Add the custom store sidebar
		add_action( 'genesis_sidebar', 'lush_do_store_sidebar' );
		function lush_do_store_sidebar() {
			echo '<div id="sidebar" class="sidebar widget-area">';
				genesis_structural_wrap( 'sidebar' );
				do_action( 'genesis_before_sidebar_widget_area' );
				dynamic_sidebar( 'store-sidebar' );
				do_action( 'genesis_after_sidebar_widget_area' );
				genesis_structural_wrap( 'sidebar', 'close' );
			echo '</div>';
		}}}
genesis_register_sidebar( array(
    'id'=> 'store-sidebar',
	'name'=> 'Store Sidebar',
	'description'=> 'This is the primary sidebar for the store.',
));