<?php
/*----------------------------------------------------*/
// Add Book Custom Post Type
/*---------------------------------------------------*/
add_action('after_setup_theme', 'book_post_type');
function book_post_type() {
$labels = array(
		'name'=> 'Books',
		'singular_name' => 'Book',
		'add_new'=> 'Add New',
		'add_new_item'=> 'Add New Book',
		'edit_item'=> 'Edit Book',
		'new_item'=> 'New Book',
		'view_item'=> 'View Book',
		'search_items'=> 'Search Books',
		'not_found'=>  'No books found',
		'not_found_in_trash'=> 'No books found in trash',
		'parent_item_colon'=> '',
		'menu_name'=> 'Books'
	);
	$args = array(
		'labels'=> $labels,
		'public'=>true,
		'publicly_queryable'=> true,
		'show_ui'=> true, 
		'show_in_menu'=> true, 
		'query_var'=> true,
		'rewrite'=> true,
		'capability_type'=> 'post',
		'has_archive'=> true,
		'hierarchical'=> false,
		'menu_icon'=> 'dashicons-book',
		'menu_position'=> null,
		'supports'=> array( 'title', 'editor', 'thumbnail'),
		'register_meta_box_cb'=> 'add_book_meta_box',
	);
	register_post_type( 'books', $args);
}
//* Add custom meta boxes for books
function get_field( $value ) {
	global $post;
	$field = get_post_meta( $post->ID, $value, true );
	if ( ! empty( $field ) ) {return is_array( $field ) ? stripslashes_deep( $field ) : stripslashes( wp_kses_decode_entities( $field ) );} else {return false;
	}}
function add_book_meta_box() {
	add_meta_box(
		'lush-book-additional-details',
		__( 'Book Additional Details', 'lush' ),
		'book_html',
		'books',
		'advanced',
		'high'
	);}
add_action( 'add_meta_boxes', 'add_book_meta_box' );
function book_html( $post) {
	wp_nonce_field( '_book_nonce', 'book_nonce' ); ?>
	<p>
		<label for="book_price"><?php _e( 'Price', 'lush' ); ?></label><br>
		<textarea name="book_price" id="book_price" class="widefat"><?php echo get_field( 'book_price' ); ?></textarea>	
	<p>
		<label for="book_author"><?php _e( 'Author', 'lush' ); ?></label><br>
		<textarea name="book_author" id="book_author" class="widefat"><?php echo get_field( 'book_author' ); ?></textarea>	
	</p><p>
		<label for="book_published_year"><?php _e( 'Year Published', 'lush' ); ?></label><br>
		<textarea name="book_published_year" id="book_published_year" class="widefat"><?php echo get_field( 'book_published_year' ); ?></textarea>
	</p><p>
		<label for="book_release_date"><?php _e( 'Release Date', 'lush' ); ?></label><br>
		<textarea name="book_release_date" id="book_release_date" class="widefat"><?php echo get_field( 'book_release_date' ); ?></textarea>
	</p>
		<p>
		<label for="book_purchase_link"><?php _e( 'Purchase Link', 'lush' ); ?></label><br>
		<textarea name="book_purchase_link" id="book_purchase_link" class="widefat"><?php echo get_field( 'book_purchase_link' ); ?></textarea>	
	</p><?php
}
function book_save( $post_id ) {
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
	if ( ! isset( $_POST['book_nonce'] ) || ! wp_verify_nonce( $_POST['book_nonce'], '_book_nonce' ) ) return;
	if ( ! current_user_can( 'edit_post' ) ) return;	
	if ( isset( $_POST['book_price'] ) )update_post_meta( $post_id, 'book_price', esc_attr( $_POST['book_price'] ) );
	if ( isset( $_POST['book_author'] ) )update_post_meta( $post_id, 'book_author', esc_attr( $_POST['book_author'] ) );
	if ( isset( $_POST['book_published_year'] ) )update_post_meta( $post_id, 'book_published_year', esc_attr( $_POST['book_published_year'] ) );
	if ( isset( $_POST['book_release_date'] ) )update_post_meta( $post_id, 'book_release_date', esc_attr( $_POST['book_release_date'] ) );
	if ( isset( $_POST['book_purchase_link'] ) )update_post_meta( $post_id, 'book_purchase_link', esc_attr( $_POST['book_purchase_link'] ) );
}
add_action( 'save_post', 'book_save' );
/*
	Usage: get_field( 'book_price' )
	Usage: get_field( 'book_author' )
	Usage: get_field( 'book_published_year' )
	Usage: get_field( 'book_release_date' )
	Usage: get_field( 'book_purchase_link' )
*/
// Move the metaboxes below the default editor
add_action('edit_form_after_editor', function() {
    global $books, $wp_meta_boxes;
    do_meta_boxes(get_current_screen(), 'advanced', $books);
    unset($wp_meta_boxes[get_post_type($books)]['advanced']);
});
//* [All Book pages] Function to display values of custom fields (if not empty)
function lush_display_book_custom_fields() {
	$book_price = get_field( 'book_price' );
	$book_author = get_field( 'book_author' );
	$book_published_year = get_field( 'book_published_year' );
	$book_release_date = get_field( 'book_release_date' );
	$book_purchase_link = get_field( 'book_purchase_link' );
	if ( $book_price || $book_author || $book_published_year || $book_release_date || $book_purchase_link ) {
		echo '<div class="book-meta">';
			if ( $book_price ) {echo '<p><strong>Price</strong>: $' . $book_price . '</p>';
			}
			if ( $book_author ) {echo '<p><strong>Author</strong>: ' . $book_author . '</p>';
			}
			if ( $book_published_year ) {echo '<p><strong>Year Published</strong>: ' . $book_published_year . '</p>';
			}				
			if ( $book_release_date ) {echo '<p><strong>Release Date</strong>: ' . $book_release_date . '</p>';
			}
			if ( $book_purchase_link ) {echo '<a href="' . $book_purchase_link . '" class="button">Buy this book</a>';
			}
		echo '</div>';
	}}
/*----------------------------------------------------*/
add_post_type_support( 'books', 'genesis-cpt-archives-settings' );