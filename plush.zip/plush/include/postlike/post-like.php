<?php
/*
Add post like
/**
 * Enqueue scripts for like system
 */
function like_scripts() {
	wp_enqueue_script( 'jquery' );
	wp_enqueue_script( 'jm_like_post', get_stylesheet_directory_uri().'/js/post-like.min.js', array('jquery'), '1.0', 1 );
	wp_localize_script( 'jm_like_post', 'ajax_var', array(
		'url'=> admin_url( 'admin-ajax.php' ),
		'nonce'=> wp_create_nonce( 'ajax-nonce' )
		));}
add_action( 'after_setup_theme', 'like_scripts' );

/**
 * Save like data
 */
add_action( 'wp_ajax_nopriv_jm-post-like', 'jm_post_like' );
add_action( 'wp_ajax_jm-post-like', 'jm_post_like' );
function jm_post_like() {
	$nonce = $_POST['nonce'];
    if ( ! wp_verify_nonce( $nonce, 'ajax-nonce' ) )die ( 'Nope!' );
	if ( isset( $_POST['jm_post_like'] ) ) {
		$post_id = $_POST['post_id']; 
		$post_like_count = get_post_meta( $post_id, "_post_like_count", true ); 	
		if ( function_exists ( 'wp_cache_post_change' ) ) { $GLOBALS["super_cache_enabled"]=1;wp_cache_post_change( $post_id );
		}
		if ( is_user_logged_in() ) { 
			$user_id = get_current_user_id();
			$meta_POSTS = get_user_option( "_liked_posts", $user_id  ); 
			$meta_USERS = get_post_meta( $post_id, "_user_liked" ); 
			$liked_POSTS = NULL; 
			$liked_USERS = NULL; 	
			if ( count( $meta_POSTS ) != 0 ) { $liked_POSTS = $meta_POSTS;
			}	
			if ( !is_array( $liked_POSTS ) ) $liked_POSTS = array();	
			if ( count( $meta_USERS ) != 0 ) {$liked_USERS = $meta_USERS[0];
			}		
			if ( !is_array( $liked_USERS ) ) $liked_USERS = array();
			$liked_POSTS['post-'.$post_id] = $post_id; 
			$liked_USERS['user-'.$user_id] = $user_id; 
			$user_likes = count( $liked_POSTS ); 
			if ( !AlreadyLiked( $post_id ) ) { 
				update_post_meta( $post_id, "_user_liked", $liked_USERS ); 
				update_post_meta( $post_id, "_post_like_count", ++$post_like_count ); 
				update_user_option( $user_id, "_liked_posts", $liked_POSTS );
				update_user_option( $user_id, "_user_like_count", $user_likes );
				echo $post_like_count; 

			} else { 
				$pid_key = array_search( $post_id, $liked_POSTS ); 
				$uid_key = array_search( $user_id, $liked_USERS ); 
				unset( $liked_POSTS[$pid_key] ); 
				unset( $liked_USERS[$uid_key] ); 
				$user_likes = count( $liked_POSTS );
				update_post_meta( $post_id, "_user_liked", $liked_USERS ); 
				update_post_meta($post_id, "_post_like_count", --$post_like_count );
				update_user_option( $user_id, "_liked_posts", $liked_POSTS ); 			
				update_user_option( $user_id, "_user_like_count", $user_likes ); 
				echo "already".$post_like_count; 	
			}	
		} else { 
			$ip = $_SERVER['REMOTE_ADDR']; 
			$meta_IPS = get_post_meta( $post_id, "_user_IP" ); 
			$liked_IPS = NULL;
			if ( count( $meta_IPS ) != 0 ) { $liked_IPS = $meta_IPS[0];
			}
			if ( !is_array( $liked_IPS ) ) 
				$liked_IPS = array();
			if ( !in_array( $ip, $liked_IPS ) ) 
				$liked_IPS['ip-'.$ip] = $ip; 
			if ( !AlreadyLiked( $post_id ) ) { 
				update_post_meta( $post_id, "_user_IP", $liked_IPS );
				update_post_meta( $post_id, "_post_like_count", ++$post_like_count );
				echo $post_like_count; 
			} else { 
				$ip_key = array_search( $ip, $liked_IPS ); 
				unset( $liked_IPS[$ip_key] ); 
				update_post_meta( $post_id, "_user_IP", $liked_IPS );
				update_post_meta( $post_id, "_post_like_count", --$post_like_count ); 
				echo "already".$post_like_count; 	}}}exit;
}

/**
 * Test if user already liked post
 */
function AlreadyLiked( $post_id ) { 
	if ( is_user_logged_in() ) {
		$user_id = get_current_user_id(); 
		$meta_USERS = get_post_meta( $post_id, "_user_liked" ); 
		$liked_USERS = ""; 
		if ( count( $meta_USERS ) != 0 ) { $liked_USERS = $meta_USERS[0];
		}	
		if( !is_array( $liked_USERS ) ) $liked_USERS = array();		
		if ( in_array( $user_id, $liked_USERS ) ) { return true;
		}
		return false;	
	} else { 
		$meta_IPS = get_post_meta( $post_id, "_user_IP" ); 
		$ip = $_SERVER["REMOTE_ADDR"];
		$liked_IPS = ""; 	
		if ( count( $meta_IPS ) != 0 ) {$liked_IPS = $meta_IPS[0];
		}	
		if ( !is_array( $liked_IPS ) )$liked_IPS = array();	
		if ( in_array( $ip, $liked_IPS ) ) { return true;}return false;
	}}

/**
 * Front end button
 */
function getPostLikeLink( $post_id ) {
	$like_count = get_post_meta( $post_id, "_post_like_count", true ); 
	$count = ( empty( $like_count ) || $like_count == "0" ) ? 'Like' : esc_attr( $like_count );
	if ( AlreadyLiked( $post_id ) ) {
		$class = esc_attr( ' liked' );
		$title = esc_attr( 'Unlike' );
		$heart = '<i id="icon-like" class="icon-like"></i>';
	} else {
		$class = esc_attr( '' );
		$title = esc_attr( 'Like' );
		$heart = '<i class="icon-unlike"></i>';
	}
	$output = '<a href="#" class="jm-post-like'.$class.'" data-post_id="'.$post_id.'" title="'.$title.'">'.$heart.'&nbsp;'.$count.'</a>';return $output;
}
/**
 * Add shortcode 
 */
function jm_like_shortcode() {return getPostLikeLink( get_the_ID() );
}
add_shortcode('post_like', 'jm_like_shortcode');