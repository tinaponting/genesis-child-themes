<?php
//* Remove breadcrumbs
remove_action( 'genesis_before_loop', 'genesis_do_breadcrumbs' );

//* Force full width content
add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );

//* Remove entry meta in entry header
remove_action( 'genesis_entry_header', 'genesis_post_info', 9 );
remove_action( 'genesis_entry_header', 'plush_genesis_post_info_sep', 9 );

//* Add 'one-third' class to Entry Header to float it left
add_filter( 'genesis_attr_entry-header', 'plush_genesis_attributes_entry_header' );
/**
 * Add attributes for entry header element.
 * @param array $attributes Existing attributes.
 * @return array Amended attributes.
 */
function plush_genesis_attributes_entry_header( $attributes ) {
	$attributes['class'] = 'entry-header one-third first';return $attributes;
}
//* Add 'two-third' class to Entry Content to float image right and content in the middle
add_filter( 'genesis_attr_entry-content', 'plush_genesis_attributes_entry_content' );
/**
 * Add attributes for entry content element.
 * @param array $attributes Existing attributes.
 * @return array Amended attributes.
 */
function plush_genesis_attributes_entry_content( $attributes ) {$attributes['class'] = 'entry-content two-third';return $attributes;
}
//* Display values of custom fields (those that are not empty)
add_action( 'genesis_entry_header', 'lush_display_book_custom_fields' );

//* Remove default post image
remove_action( 'genesis_entry_content', 'genesis_do_post_image', 8 );

//* Add post image in Entry Content above Excerpt
add_action( 'genesis_entry_content', 'plush_display_featured_image', 9 );
function plush_display_featured_image() {
	$image_args = array(
		'size'=> 'medium',
		'attr'=> array(
			'class'=> 'alignright',
		),);
	$image = genesis_get_image( $image_args );
	if ( $image ) {echo '<a href="' . get_permalink() . '">' . $image .'</a>';
	}}
genesis();