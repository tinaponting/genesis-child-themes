<?php
/**
 * Theme functionality.
 * @package Trestle
 */
/*===========================================
 * Required Files
===========================================*/
require_once dirname( __FILE__ ) . '/includes/functions/theme-functions.php';
require_once dirname( __FILE__ ) . '/includes/admin/admin.php';
require_once dirname( __FILE__ ) . '/includes/admin/customizer.php';
require_once dirname( __FILE__ ) . '/includes/shortcodes/shortcodes.php';
require_once dirname( __FILE__ ) . '/includes/widget-areas/widget-areas.php';
require_once dirname( __FILE__ ) . '/lib/class-tgm-plugin-activation.php';
require_once dirname( __FILE__ ) . '/includes/utilities/utilities.php';
add_action( 'genesis_setup', 'trestle_theme_setup', 15 );
/**
 * Initialize Trestle.
 */
function trestle_theme_setup() {
	/*===========================================
	 * Theme Setup
	===========================================*/
	define( 'TRESTLE_THEME_NAME', 'Trestle' );
    define( 'TRESTLE_THEME_URL','http://mightyminnow.com/');
	define( 'TRESTLE_UPDATED_THEME_URL','https://eatinglinks.tk/');
	define( 'TRESTLE_THEME_VERSION', '2.2.0' );
	define( 'TRESTLE_SETTINGS_FIELD', 'trestle-settings' );
	trestle_settings_defaults();
	load_theme_textdomain( 'trestle', get_stylesheet_directory() . '/languages' );
}