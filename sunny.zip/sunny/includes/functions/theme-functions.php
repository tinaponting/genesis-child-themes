<?php
/**
 * Trestle theme functions (front-end)
 * @package Trestle
 */
/*===========================================
 * Theme Setup
===========================================*/
add_action( 'after_setup_theme', 'trestle_add_theme_support' );
/**
 * Initialize Trestle defaults and theme options.
 */
function trestle_add_theme_support() {
	add_theme_support( 'html5' );
	add_theme_support( 'genesis-responsive-viewport' );
	add_theme_support( 'genesis-footer-widgets', trestle_get_option( 'footer_widgets_number' ) );
}
add_action( 'after_setup_theme', 'trestle_remove_genesis_css_enqueue' );
/**
 * Stop Genesis from enqueuing the child theme stylesheet in the usual way.
 */
function trestle_remove_genesis_css_enqueue() {remove_action( 'genesis_meta', 'genesis_load_stylesheet' );
}

/*===========================================
 * 3rd Party Libraries
===========================================*/
add_action( 'init', 'trestle_load_bfa' );
/**
 * Initialize the Better Font Awesome Library.
 */
function trestle_load_bfa() {
	require_once trailingslashit( get_stylesheet_directory() ) . 'lib/better-font-awesome-library/better-font-awesome-library.php';
	$args = array(
			'version'=> 'latest',
			'minified'=> true,
			'remove_existing_fa'=> false,
			'load_styles'=> true,
			'load_admin_styles'=> true,
			'load_shortcode'=> true,
			'load_tinymce_plugin'=> true,
	);
	Better_Font_Awesome_Library::get_instance( $args );
}

/*===========================================
 * Header
===========================================*/
add_action( 'wp_enqueue_scripts', 'trestle_header_actions', 15 );
/**
 * Loads theme scripts and styles.
 */
function trestle_header_actions() {
	wp_enqueue_style( 'trestle', get_stylesheet_uri(), array(), TRESTLE_THEME_VERSION );
	wp_enqueue_style( 'theme-google-fonts', '//fonts.googleapis.com/css?family=Lato:300,400,700' );
	wp_enqueue_script( 'theme-jquery', get_stylesheet_directory_uri() . '/includes/js/theme-jquery.js', array( 'jquery' ), TRESTLE_THEME_VERSION, true );
	$mobile_nav_text = apply_filters( 'trestle_mobile_nav_text', __( 'Navigation', 'trestle' ) );
	wp_localize_script(
		'theme-jquery',
		'trestle_vars',
		array('mobile_nav_text' => esc_attr( $mobile_nav_text ),
		));
	$upload_dir = wp_upload_dir();
	$upload_path = $upload_dir['basedir'];
	$upload_url = $upload_dir['baseurl'];
	$custom_css_file = '/trestle/custom.css';
	if ( is_readable( $upload_path . $custom_css_file ) )
		wp_enqueue_style( 'trestle-custom-css', $upload_url . $custom_css_file );
	$custom_js_file = '/trestle/custom.js';
	if ( is_readable( $upload_path . $custom_js_file ) )
		wp_enqueue_script( 'trestle-custom-jquery', $upload_url . $custom_js_file, array( 'jquery' ), TRESTLE_THEME_VERSION, true );
}
add_filter( 'genesis_pre_load_favicon', 'trestle_do_custom_favicon' );
/**
 * Output custom favicon if specified in the theme options.
 * @param   string  $favicon_url  Default favicon URL.
 * @return  string  Custom favicon URL (if specified), or the default URL.
 */
function trestle_do_custom_favicon( $favicon_url ) {
	$trestle_favicon_url = trestle_get_option( 'favicon_url' );
	return $trestle_favicon_url ? $trestle_favicon_url : $favicon_url;
}

/*===========================================
 * Body Classes
===========================================*/
add_filter( 'body_class', 'trestle_body_classes' );
/**
 * Adds custom classes to the <body> element for styling purposes.
 * @param array $classes Body classes.
 * @return array 		 Updated body classes.
 */
function trestle_body_classes( $classes ) {
	$classes[] = 'no-jquery';
	if ( 'bubble' == trestle_get_option( 'layout' ) )
		$classes[] = 'bubble';
	if ( trestle_get_option( 'external_link_icons' ) ) {$classes[] = 'external-link-icons';
	}
	if ( trestle_get_option( 'email_link_icons' ) ) {$classes[] = 'email-link-icons';
	}
	if ( trestle_get_option( 'pdf_link_icons' ) ) {$classes[] = 'pdf-link-icons';
	}
	if ( trestle_get_option( 'doc_link_icons' ) ) {$classes[] = 'doc-link-icons';
	}
	$nav_primary_location = esc_attr( trestle_get_option( 'nav_primary_location' ) );
	if ( $nav_primary_location ) {$classes[] = 'nav-primary-location-' . $nav_primary_location;
	}
	$mobile_nav_toggle = esc_attr( trestle_get_option( 'mobile_nav_toggle' ) );
	if ( 'big-button' == $mobile_nav_toggle ) {
		$classes[] = 'big-button-nav-toggle';
	} elseif ( 'small-icon' == $mobile_nav_toggle ) {
		$classes[] = 'small-icon-nav-toggle';
	}
	$footer_widgets_number = esc_attr( trestle_get_option( 'footer_widgets_number' ) );
	if ( $footer_widgets_number ) {$classes[] = 'footer-widgets-number-' . $footer_widgets_number;
	}
	if ( trestle_get_option( 'logo_id' ) || trestle_get_option( 'logo_id_mobile' ) ) {$classes[] = 'has-logo';}return $classes;
}

/*===========================================
 * Header
===========================================*/
add_filter( 'genesis_seo_title', 'trestle_do_logos', 10, 3 );
/**
 * Output logos.
 */
function trestle_do_logos( $title, $inside, $wrap ) {
	$logo_id = trestle_get_option( 'logo_id' );
	$logo_id_mobile = trestle_get_option( 'logo_id_mobile' );
	$logo_html = '';
	if ( $logo_id ) {
		$classes = array(
			'logo',
			'logo-full'
		);
		if( ! $logo_id_mobile ) {
			$classes[] = 'show';
		}
		$logo_attr = array(
			'class'=> implode( $classes, ' ' ),
		);
		$logo_html .= wp_get_attachment_image( $logo_id, 'full', false, $logo_attr );
	}
	if ( $logo_id_mobile ) {
		$classes = array(
			'logo',
			'logo-mobile'
		);

		if( ! $logo_id )
			$classes[] = 'show';
		$logo_attr = array(
			'class'=> implode( $classes, ' ' ),
		);
		$logo_html .= wp_get_attachment_image( $logo_id_mobile, 'full', false, $logo_attr );

	}
	if ( $logo_html ) {
		$inside .= sprintf( '<a href="%s" title="%s" class="logos">%s</a>',
			trailingslashit( home_url() ),
			esc_attr( get_bloginfo( 'name' ) ),
			$logo_html
		);}
	$title  = genesis_html5() ? sprintf( "<{$wrap} %s>", genesis_attr( 'site-title' ) ) : sprintf( '<%s id="title">%s</%s>', $wrap, $inside, $wrap );
	$title .= genesis_html5() ? "{$inside}</{$wrap}>" : '';return $title;

}

/*===========================================
 * Navigation
===========================================*/
add_action( 'wp_loaded', 'trestle_nav_primary_location' );
/**
 * Move primary navigation into the header if need be.
 */
function trestle_nav_primary_location() {
	if ( 'header' == trestle_get_option( 'nav_primary_location' ) ) {remove_action( 'genesis_after_header', 'genesis_do_nav' );add_action( 'genesis_header', 'genesis_do_nav', 12 );}
}
add_filter( 'wp_nav_menu_items', 'trestle_custom_nav_extras', 10, 2 );
/**
 * Add custom nav extras.
 * @param  string   $nav_items <li> list of menu items.
 * @param  stdClass $menu_args Arguments for the menu.
 * @return string   <li> list of menu items with custom navigation extras <li> appended.
 */
function trestle_custom_nav_extras( $nav_items, stdClass $menu_args ) {
	if ( 'primary' == $menu_args->theme_location && trestle_get_option( 'search_in_nav' ) ) {
		return $nav_items . '<li class="right custom">' . get_search_form( false ) . '</li>';}return $nav_items;
}

/*===========================================
 * Posts & Pages
===========================================*/
add_filter( 'post_class', 'trestle_post_classes' );
/**
 * Add extra classes to posts in certain situations.
 * @param array $classes Post classes.
 * @return array 		 Updated post classes.
 */
function trestle_post_classes( $classes ) {
	if ( ! has_post_thumbnail() ) {$classes[] = 'no-featured-image';}return $classes;
}
add_filter( 'wp_revisions_to_keep', 'trestle_update_revisions_number', 10, 2 );
/**
 * Sets the number of post revisions.
 * @param  int $num Default number of post revisions.
 * @return int      Number of post revisions specified in Trestle admin panel.
 */
function trestle_update_revisions_number( $num ) {
	$trestle_revisions_number = esc_attr( trestle_get_option( 'revisions_number' ) );
	if ( isset( $trestle_revisions_number ) ) {return $trestle_revisions_number;}return $num;
}
add_filter( 'genesis_get_image_default_args', 'trestle_featured_image_fallback' );
/**
 * Unset Genesis default featured image fallback of 'first-attached'.
 * @param array $args Default Genesis image args.
 * @return array Updated image args.
 */
function trestle_featured_image_fallback( $args ) {$args['fallback'] = false;return $args;
}

/*===========================================
 * General Actions & Filters
===========================================*/
add_filter( 'excerpt_more', 'trestle_read_more_link' );
add_filter( 'get_the_content_more_link', 'trestle_read_more_link' );
add_filter( 'the_content_more_link', 'trestle_read_more_link' );
/**
 * Displays custom Trestle "read more" text in place of WordPress default.
 * @param string $default_text Default "read more" text.
 * @return string (Updated) "read more" text.
 */
function trestle_read_more_link( $default_text ) {
	$custom_text = esc_attr( trestle_get_option( 'read_more_text' ) );
	if ( $custom_text ) {return '&hellip;&nbsp;<a class="more-link" title="' . $custom_text . '" href="' . get_permalink() . '">' . $custom_text . '</a>';
	} else {return $default_text;
	}}

//* Change the footer text
add_filter('genesis_footer_creds_text', 'sp_footer_creds_filter');
function sp_footer_creds_filter( $creds ) {
	$creds = '[footer_copyright] &middot; Handcrafted with &#10084; by <a href="http://www.exempel.se/">My own me.</a>';return $creds;
}
add_image_size( 'medium', 300, 300, TRUE );
add_image_size( 'large', 450, 450, TRUE );

/*===========================================
 * Helper Functions
===========================================*/
/**
 * Check if image has specified image size.
 * @param int $image_id ID of image to check.
 * @param string $image_size Slug of image size to check for.
 * @return true|false Whether or not the image has the specified size generated.
 */
function trestle_image_has_size( $image_id, $image_size = null ) {
	global $_wp_additional_image_sizes;
	if ( ! $image_size ) {return new WP_Error( 'no_image_size_specified', __( 'Please specify an image size.', 'trestle' ) );
	}
	$image_size_atts = $_wp_additional_image_sizes[ $image_size ];
	$img_data = wp_get_attachment_image_src( $image_id, $image_size );
	if ( $img_data[1] == $image_size_atts['width'] && $img_data[2] == $image_size_atts['height'] ) {return true;}return false;
}

/**
 * Check if post is, or is a child of, a target post.
 * @param string $post_id   Post ID to check.
 * @param string $target_id Target post ID to check against.
 * @return true|false
 */
function trestle_is_current_or_descendant_post( $post_id = '', $target_id = '' ) {
	if ( $post_id == $target_id ) {return true;
	}
	if ( in_array( $target_id, get_post_ancestors( $post_id ) ) ) {return true;}return false;
}