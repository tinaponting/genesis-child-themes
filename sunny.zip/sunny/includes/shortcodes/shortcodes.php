<?php
/**
 * Trestle shortcodes.
 * @package Trestle
 */
/*===========================================
 * Shortcodes
===========================================*/
add_filter( 'the_content', 'trestle_shortcode_empty_paragraph_fix' );
/**
 * Fix for empty <p> tags around shortcodes.
 * @param   string  $content  HTML content.
 * @return  string            Updated content.
 */
function trestle_shortcode_empty_paragraph_fix( $content ) {
    $array = array (
        '<p>['=> '[',
        ']</p>'=> ']',
        ']<br />'=> ']'
        );
    $content = strtr( $content, $array );return $content;
}
add_shortcode( 'col', 'trestle_column' );
/**
 * Columns.
 * @param   array  $atts  Shortcode attributes.
 * @return  string        Shortcode output.
 */
function trestle_column( $atts, $content = null ) {
    $atts = shortcode_atts( array(
        'class'=> '',
    ), $atts );
    return '<div class="col ' . $atts['class'] . '">' . do_shortcode( $content ) . '</div>';
}
add_shortcode( 'button', 'trestle_button' );
/**
 * Button.
 * @param   array  $atts  Shortcode attributes.
 * @return  string        Shortcode output.
 */
function trestle_button( $atts, $content = null ) {

    $atts = shortcode_atts( array(
        'href'=> '#',
        'target'=> '',
        'title'=> '',
        'class'=> '',
    ), $atts );
    return '<a class="button ' . $atts['class'] . '" href="' . $atts['href'] . '" title="' . $atts['title'] . '" target="' . $atts['target'] . '">' . do_shortcode( $content ) . '</a>';
}
add_shortcode( 'date', 'trestle_date' );
/**
 * Date.
 * @param   array  $atts  Shortcode attributes.
 * @return  string        Shortcode output.
 */
function trestle_date( $atts ) {
    $atts = shortcode_atts( array(
        'format'=> 'M d, Y',
    ), $atts );
    if ( ! $atts['format'] ) {$atts['format'] = 'M d, Y';}return date( $atts['format'] );
}
add_shortcode( 'blockquote', 'trestle_blockquote_shortcode' );
/**
 * Blockquote.
 * @param   array  $atts  Shortcode attributes.
 * @return  string        Shortcode output.
 */
function trestle_blockquote_shortcode( $atts, $content = null ) {
    $atts = shortcode_atts( array(
        'citation'=> '',
    ), $atts );
    ob_start(); ?>
        <blockquote>
        <?php if ( $content ) : ?>
            <?php echo $content; ?>
        <?php endif; ?>
        <?php if ( $atts['citation'] ) : ?>
            <cite>- <?php echo $atts['citation']; ?></cite>
        <?php endif; ?>
        </blockquote>
    <?php
    $output = ob_get_clean();
    return $output;
}