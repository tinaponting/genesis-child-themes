/**
 * Trestle theme jQuery
 * @package Trestle
 */
// Executes when the document is ready.
jQuery( document ).ready( function( $ ) {
	$body = $( 'body' );
	$body.removeClass( 'no-jquery' );
	var h = window.location.host.toLowerCase();
	$( '[href^="http"]' ).not( '[href*="' + h + '"]' ).addClass( 'external-link' ).attr( "target", "_blank" );
	$( 'a[href^="mailto:"]' ).addClass( 'email-link' );
	$( 'a[href$=".pdf"]' ).attr({ "target":"_blank" }).addClass( 'pdf-link' );
	$( 'a[href$=".doc"]' ).attr({ "target":"_blank" }).addClass( 'doc-link' );
	$( 'a' ).has( 'img' ).addClass( 'image-link' );
	$( 'li:last-child' ).addClass( 'last' );
	$( 'li:first-child' ).addClass( 'first' );
	$( 'ul, ol' ).parent( 'li' ).addClass( 'parent' );
	if ( $body.hasClass( 'big-button-nav-toggle' ) ) {$( '.site-header' ).after( '<div class="header-toggle-buttons" />' );
	} else {$( '.site-header .title-area' ).after( '<div class="header-toggle-buttons" />' );
	}
	$( '.site-header .widget-area, .nav-primary' ).each( function( i ) {
		$target = $( this );
		var $target, buttonClass, targetClass;
		buttonClass = 'toggle-button';
		targetClass = $target.attr( 'class' ).split( /\s+/ );
		$.each( targetClass, function( index, value ) {
			buttonClass += ' targets-' + value;
		});
		if ( $target.is( 'nav' ) ) {buttonClass += ' nav-toggle';
		}
		if ( $target.is( 'nav' ) && $body.hasClass( 'big-button-nav-toggle' ) ) {
			navText = trestle_vars['mobile_nav_text'];} else {navText = 'Toggle';
		}
		$( '.header-toggle-buttons' ).prepend( '<a id="toggle-button-' + i + '" class="' + buttonClass + '" href="#">' + navText + '</a>' );
		$target.addClass( 'toggle-target-' + i );
	});
	$( '.header-toggle-buttons .toggle-button' ).click( function( event ) {
		event.preventDefault();
		var $button, $target;
		$button = $( this );
		$target = $( '.toggle-target-' + $button.attr( 'id' ).match( /\d+/ ) );
		$button.toggleClass( 'open' );
		$( '.header-toggle-buttons .toggle-button' ).not( $button ).removeClass( 'open' );
		$target.toggleClass( 'open' );
		$( '[class*="toggle-target"]' ).not( $target ).removeClass( 'open' );
		$button.blur();
	});
	var closedIcon = '+';
	var openIcon = '-';
	$( '.nav-primary' ).find( '.genesis-nav-menu .parent:not( [class*="current"] ) > a' ).after( '<a class="sub-icon" href="#">' + closedIcon + '</a>' );
    $( '.nav-primary' ).find( '.genesis-nav-menu .parent[class*="current"] > a' ).after( '<a class="sub-icon" href="#">' + openIcon + '</a>' );
	$( '.sub-icon' ).click( function( event ) {
		event.preventDefault();
		var $icon = $( this );
		$icon.blur();
		$icon.next( 'ul' ).slideToggle().toggleClass( 'open' );
		if ( $icon.text().indexOf( closedIcon ) !== -1 ) {$icon.text( openIcon );
		} else if ( $icon.text().indexOf( openIcon ) !== -1 ) {$icon.text( closedIcon );
		}});
	$( '.widget-area-toggle' ).click( function( event ) {
		event.preventDefault();
		var $button = $( this );
		$button.blur();
		$button.toggleClass( 'open' ).next( '.widget-area' ).slideToggle();
	});
	$( window ).on( 'load', function() {
	});}); 