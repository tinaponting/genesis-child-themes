<?php
/**
 * Trestle admin functions.
 * @package Trestle
 */
/**
 * Set up Trestle default settings.
 * @return  array  Genesis settings updated to include Trestle defaults.
 */
function trestle_settings_defaults() {
	$trestle_defaults = array(
		'layout'=> 'solid',
		'logo_id'=> '',
		'logo_id_mobile'=> '',
		'favicon_url'=> '',
		'nav_primary_location' => 'full',
		'mobile_nav_toggle'=> 'small-icon',
		'search_in_nav'=> '',
		'read_more_text'=> __( 'Read&nbsp;More&nbsp;&raquo;', 'trestle' ),
		'revisions_number'=> 3,
		'footer_widgets_number'=> 3,
		'external_link_icons'=> 0,
		'email_link_icons'=> 0,
		'pdf_link_icons'=> 0,
		'doc_link_icons'=> 0,
	);
	$options = get_option( TRESTLE_SETTINGS_FIELD );
	if ( ! $options ) {$options = array();
	}
	if ( $options === $trestle_defaults ) {return;
	}
	foreach ( $trestle_defaults as $k => $v ) {
		if ( ! array_key_exists( $k, $options ) ) {
			$options[$k] = $v;
		}}
	update_option( TRESTLE_SETTINGS_FIELD, $options );
}

/**
 * Wrapper function to get Trestle options.
 * @return  mixed    Trestle option value.
 */
function trestle_get_option( $key, $setting = null, $use_cache = true ) {
	$setting = $setting ? $setting : TRESTLE_SETTINGS_FIELD;
	return genesis_get_option( $key, $setting, false );
}
add_action( 'admin_enqueue_scripts', 'trestle_admin_actions' );
/**
 * Loads admin scripts and styles.
 */
function trestle_admin_actions() {
	$font_url = str_replace( ',', '%2C', '//fonts.googleapis.com/css?family=Lato:300,400,700' );
	add_editor_style( $font_url );
	add_editor_style( get_stylesheet_uri() );
}
add_filter( 'tiny_mce_before_init', 'trestle_tiny_mce_before_init' );
/**
 * Add custom classes to the body of TinyMCE previews.
 */
function trestle_tiny_mce_before_init( $init_array ) {
	global $post;
	$screen = get_current_screen();
	if ( is_object( $screen ) && 'edit' == $screen->parent_base ) {
		$post_type = ( 'page' == $post->post_type ) ? 'page' : 'post';
		$init_array['body_class'] .= sprintf( ' %s-id-%s',
			$post_type,
			$post->ID
		);}
	return $init_array;
}