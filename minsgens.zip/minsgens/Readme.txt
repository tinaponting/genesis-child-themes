Hi,

Welcome to Genesislovers.com

Read the following steps before proceeding,

1. Our Child Theme surely needs Genesis Framework. If you already have the Genesis Parent theme (Framework) then move to step 2 or contact us.

2. After installing Genesis Framework, go to Appearance -> Themes -> upload -> minsgens.zip file

3. Install and Activate. Thats it.

4. If you are good in Theme Setting Options then stop seeing Readme.txt file and proceed or read the Documentation folder attached with this package.





For More Details,

Contact Us:

1. Mail Id - genesisthemelovers@gmail.com

2. Contact Us - http://genesislovers.com/contact-us/




Tutorials:

1. Documentation is attached with this package

2. Video Tutorial - https://www.youtube.com/watch?v=5wCpKBAbEC0