<div class="footer-widgets" id="footer-left">
	<div class="wrap">
	
<?php
if (!genesism_get_option('footer_social_follow_box')){
?>		 
		 <div class="footer_social_follow">

		
<div class="social_widget">
	
	<?php if (!genesism_get_option('fbcheck1')){
			?>
	<div class="sw-ft-icon">
	<a href="<?php echo genesism_get_option('facebook_text1'); ?>" target="_blank" class="fb" title="Facebook"><i class="fa icon-facebook"></i></a>
	<div class="sw-comnt">Facebook</div>
	</div>
	<?php }
			?>
	
	<?php if (!genesism_get_option('twittercheck1')){
			?>
	<div class="sw-ft-icon">
	<a href="<?php echo genesism_get_option('twitter_text1'); ?>" target="_blank" class="twt" title="Twitter"><i class="fa icon-twitter"></i></a>  
	<div class="sw-comnt">Twitter</div>
	</div>	
	<?php }
			?>
	
	<?php if (!genesism_get_option('googlepluscheck1')){
			?>
	<div class="sw-ft-icon">
	<a href="<?php echo genesism_get_option('googleplus_text1'); ?>" target="_blank" class="gp" title="Google-plus"><i class="fa icon-google-plus"></i></a> 
	<div class="sw-comnt">Goole Plus</div>
	</div>
	<?php }
			?>
			
	<?php if (!genesism_get_option('instagramcheck1')){
			?>
	<div class="sw-ft-icon">
	<a href="<?php echo genesism_get_option('instagram_text1'); ?>" target="_blank" class="inst" title="Instagram"><i class="fa icon-instagram"></i></a>  
	<div class="sw-comnt">Instagram</div>
	</div>
<?php }
			?>	
	
	<?php if (!genesism_get_option('youtubecheck1')){
			?>
	<div class="sw-ft-icon">
	<a href="<?php echo genesism_get_option('youtube_text1'); ?>" target="_blank" class="yt" title="YouTube"><i class="fa icon-youtube"></i></a> 
	<div class="sw-comnt">You Tube</div>
	</div>
<?php }
			?>	
	
</div>
				
				
				
</div>
<?php
				}
				?>
   		<!-- end .footer-left -->

    
 
    	</div><!-- end .wrap -->
</div><!-- end #footer-widgets -->