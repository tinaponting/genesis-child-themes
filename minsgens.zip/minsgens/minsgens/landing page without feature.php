<?php
/*
Template Name: Landing Page With Out Feature
*/


// Add custom body class to the head
add_filter( 'body_class', 'metro_add_body_class' );
function metro_add_body_class( $classes ) {
   $classes[] = 'landingpage';
   return $classes;
}

// set full width layout
add_filter ( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );
remove_action( 'genesis_sidebar', 'genesis_do_sidebar' ); 
add_action('genesis_before_content','before_content');
function before_content(){
?>
<div class="landing_page_container wrap">
<?php
}

add_action('genesis_after_content','after_content');
function after_content(){
?>
</div>
<?php
}


add_action('genesis_before_content_sidebar_wrap','landing_page_optin',1);
function landing_page_optin(){
if (genesism_get_option('landing_content_optin')){	
?>

<div class="landingpage_optin" style='background-image:url(<?php echo genesism_option('land_optin_bg');?> )'>
<div class="landingpage_optin_color">
<div class="landingpage_inner_optin">

<div class='land_top_left'>
<h3><?php echo genesism_option('top_left_title'); ?></h3>
<p>
<?php echo genesism_option('top_left_para'); ?></p>
<div class='land_top_read'> <a href="<?php echo genesism_option('top_read_link'); ?>" ><?php echo genesism_option('top_read_txt'); ?></a></div>
</div>


<div class='land_top_right'>
<div class="landing_optin">
<div class="inner_landingpage_optin">
<div class="landing_optin_header">
<h3><?php echo genesism_option('land_optin_title'); ?></h3>
<p><?php echo genesism_option('land_optin_para'); ?></p>
</div>
<div class="landing_right_optin">

<form method="post" class="form" action="<?php echo stripslashes(genesism_option('optin_url1')); ?>" target="_blank">
<div class="names"><input class="name" type="text" name="<?php echo stripslashes(genesism_get_option('optin_name1')); ?>" placeholder="<?php echo stripslashes(genesism_get_option('name_text1')); ?>"><div class='admins'></div></div>
<div class="names"><input class="email" type="text" name="<?php echo stripslashes(genesism_option('optin_email1')); ?>" placeholder="<?php echo stripslashes(genesism_option('email_text1')); ?>"><div class='mails'></div></div>
<?php echo stripslashes(genesism_option('optin_hidden1')); ?>
<input name="submit" class="submit" type="submit" value="<?php echo stripslashes(genesism_option('submit_text1')); ?>"/>
</form>
</div>
</div>
</div>
</div>
	
</div>
</div>
</div>
<?php 
}
}


genesis();