var j=jQuery.noConflict();
(function(){
var classes = document.getElementsByClassName('menu_control');
for (i = 0; i < classes.length; i++) {
classes[i].onclick = function() {
var menu = this.nextElementSibling;
if (/show_menu/.test(menu.className))
menu.className = menu.className.replace('show_menu', '').trim();
else
menu.className += ' show_menu';
};
}
})();