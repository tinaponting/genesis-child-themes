<?php
require_once(TEMPLATEPATH.'/lib/init.php'); // Start Genesis Engine
require_once(STYLESHEETPATH.'/lib/init.php'); // Start blog Options
require_once(STYLESHEETPATH.'/lib/updates.php'); // updates

include_once( 'lib/customizer.php' );

//* Add HTML5 markup structure
add_theme_support( 'html5' );


/** Support for various Image sizes */
add_theme_support('post-thumbnails');
//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Add support for custom background
//add_theme_support( 'custom-background' );

 

// Add widgeted footer section
add_action('genesis_before_footer', 'footer_bottom_widgets',2); 
function footer_bottom_widgets() {
    require(CHILD_DIR.'/footer-widgeted.php');
}

/** Register widget areas */

genesis_register_sidebar( array(
	'id'			=> 'editor_picks_widget',
	'name'			=> __( 'Editor Picks Widget', 'Minsandgens Genesis Theme' ),
	'description'	=> __( 'This is the editor picks widget.', 'Minsandgens Genesis Theme' ),
	
) );

genesis_register_sidebar( array(
	'id'			=> 'trending_post_widget',
	'name'			=> __( 'Trending  Post Widget', 'Minsandgens Genesis Theme' ),
	'description'	=> __( 'This is the trending post widget .', 'Minsandgens Genesis Theme' ),
	
) );

register_sidebar( array(
        'name' => __( 'Single Related Post Widget ', 'Minsandgens Genesis Theme' ),
        'id' => 'single_related_post_widget',
        'description' => __( 'This is the single page related post widget.', 'Minsandgens Genesis Theme' ),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget'  => '</div>',
	
    ) );
	


//Remove Post  entry footer  Meta data 
remove_action( 'genesis_entry_footer', 'genesis_post_meta' );

//remove archive description
remove_action( 'genesis_before_content', 'genesis_do_taxonomy_title_description', 15 );

//placeholder for comment box in single page
add_filter('comment_form_default_fields','comment_form_placeholder');
function comment_form_placeholder($fields){ 
	$fields['author'] = '<p class="comment-form-author">' . '<label for="author">' . __( '', 'genesis' ) . '</label> ' . 	
	( $req ? '<span class="required">*</span>' : '' ) .                   
	'<input id="author" name="author" type="text" placeholder="Name *" value="' . 				
	esc_attr( $commenter['comment_author'] ) . '" size="30"' . $aria_req . ' /></p>';				
    $fields['email'] = '<p class="comment-form-email"><label for="email">' . __( '', 'genesis' ) . '</label> ' .
	( $req ? '<span class="required">*</span>' : '' ) .
	'<input id="email" name="email" type="text" placeholder="Email *" value="' . 	
	esc_attr(  $commenter['comment_author_email'] ) . '" size="30"' . $aria_req . ' /></p>';	
	$fields['url'] = '<p class="comment-form-url"><label for="url">' . __( '', 'genesis' ) . '</label>' .    
	'<input id="url" name="url" type="text" placeholder="URL *" value="' . 	
	esc_attr( $commenter['comment_author_url'] ) . '" size="30" /></p>';	
    return $fields;
}

 
// Customizes Footer Text (set in options) 
if (genesism_get_option('footer1')) { 
	add_filter('genesis_footer_creds_text', 'custom_footer_creds_text');
	function custom_footer_creds_text($creds) {
    	$creds = genesism_get_option('footer_text');
    return $creds;
	}
}



add_filter( 'genesis_before_header', 'search_box',2 );
function search_box( $text ) {
	return esc_attr( 'Go' );
}
remove_action( 'genesis_site_title', 'genesis_seo_site_title' );
remove_action( 'genesis_site_description', 'genesis_seo_site_description' );
/* BEGIN Custom User Contact Info */
function extra_contact_info($contactmethods) {

$contactmethods['facebook'] = 'Facebook';
$contactmethods['twitter'] = 'Twitter';

return $contactmethods;
}
add_filter('user_contactmethods', 'extra_contact_info');
/* END Custom User Contact Info */

 
//* Remove the entry meta in the entry header 
 

 add_filter( 'genesis_post_info', 'sp_post_info_filter' );
function sp_post_info_filter($post_info) {
if ( is_single() ) {
	$post_info = '[post_date] by [post_author_posts_link] [post_comments]';
	return $post_info;
}}
 
 
//* Display author box on archive pages
add_filter( 'get_the_author_genesis_author_box_archive', '__return_true' );

//* Customize the author box title
add_filter( 'genesis_author_box_title', 'custom_author_box_title' );
function custom_author_box_title() {
	return "<h3 itemscope=\"Name\"> " . get_the_author() . "</h3>";
} 
 
add_action( 'genesis_before_comments', 'themeprefix_alt_author_box',3 );
function themeprefix_alt_author_box() {
if( is_single() ) {
 
echo "<div class=\"about-author single_page_cnt\">";?>
	<div class='single_title'>
	<h3>About Author</h3>
	</div>
	<?php 
echo "<div class=\"author-info\" itemscope=\"itemscope\" itemtype=\"http://schema.org/person\" itemprop=\"Authorpost\" >" . get_avatar( get_the_author_meta( 'ID' ), '100' ) . "</div>
  <div class='author_right_cnt'>
  <div class='author_name_social'>";?>
 <h3 class="author_name"><?php the_author_posts_link(); ?></h3> 
 <?php echo "</div>".
  "<div class='author_description'><p itemprop=\"description\">" . get_the_author_meta( 'description' ) . 
 "</p></div>";

  echo "<div class=\"author_social\">";

 if ( get_the_author_meta( 'facebook' ) != '' ) {
 echo "<a title='Facebook' class=\"afb fa\" href=\"https://www.facebook.com/". get_the_author_meta( 'facebook' ) . "\"></a>";
 }
 if ( get_the_author_meta( 'googleplus' ) != '' ) {
 echo "<a title='Googleplus' class=\"agp fa\" href=\"https://plus.google.com/". get_the_author_meta( 'googleplus' ) . "\"></a>";
 }
 if ( get_the_author_meta( 'twitter' ) != '' ) {
 echo "<a title='Twitter' class=\"atw fa\" href=\"https://twitter.com/". get_the_author_meta( 'twitter' ) . "\"></a>";
 }
 
echo "</div>";
 
echo "</div></div>";
 }
} 

// Register Genesis Menus
add_action( 'init', 'register_additional_menu' );
function register_additional_menu() {
  
register_nav_menu( 'FirstMenu' ,__( 'Top Menu' ));
register_nav_menu( 'SecondMenu' ,__( 'Bottom Menu' )); 
register_nav_menu( 'ThirdMenu' ,__( 'Footer Menu' ));   
}

/** Remove Header */
remove_action( 'genesis_header', 'genesis_header_markup_open', 5 );
remove_action( 'genesis_header', 'genesis_do_header' );
remove_action( 'genesis_header', 'genesis_header_markup_close', 15 );

		  
add_action('genesis_header','injectHeader');	  
function injectHeader(){ 

?>

<div class="top_header_cont">
<div class="top_inner_header wrap">
<div class="top_menu_sec">
<?php 
if (genesism_get_option('top_menu')){
?>
<div class="top_menu">
<span class="menu_control">≡ Menu</span>
<?php wp_nav_menu( array( 'theme_location' => 'FirstMenu','container' => false,'menu_id' => 'menu_top_menu' ) );?>
</div>

<?php 
}
?>
</div>

<div class="top_header_right">

<?php
if (!genesism_get_option('header_social')){?>
<div class="header_social_icons">
			
			<?php
				if (!genesism_get_option('rsscheck2')){
				?>
			<div class="social_icons">
				<a class="rss" title="RSS" href="<?php echo genesism_get_option('rss_text2'); ?>" target="_blank">
					<i class="fa icon-rss"></i>
				</a>
			</div>
			<?php
			}
			?>
			
			<?php if (!genesism_get_option('fbcheck2')){
			?>
			<div class="social_icons">
				<a class="facebook" title="Facebook" href="<?php echo genesism_get_option('facebook_text2'); ?>" target="_blank">
					<i class="fa icon-facebook"></i>
				</a>
			</div>
			<?php
				}
				?>
			
			<?php
				if (!genesism_get_option('twittercheck2')){
				?>
			<div class="social_icons">
				<a class="twitter" title="Twitter" href="<?php echo genesism_get_option('twitter_text2'); ?>" target="_blank">
					<i class="fa icon-twitter"></i>
				</a>
			</div>
			<?php
				}
				?>
			
			
			<?php
				if (!genesism_get_option('googlepluscheck2')){
				?>	
			<div class="social_icons">
				<a class="googleplus" title="google plus" href="<?php echo genesism_get_option('googleplus_text2'); ?>" target="_blank">
					<i class="fa icon-google-plus"></i>
				</a>
			</div>
			<?php
				}
				?>
			
			<?php
				if (!genesism_get_option('pinterestcheck2')){
				?>
			<div class="social_icons">
				<a class="pinterest" title="pinterest" href="<?php echo genesism_get_option('pinterest_text2'); ?>" target="_blank">
					<i class="fa icon-pinterest"></i>
				</a>
			</div>
			<?php
				}
				?>
			
				<?php
				if (!genesism_get_option('instagramcheck2')){
				?>			
			<div class="social_icons">
				<a class="instagram" title="instagram" href="<?php echo genesism_get_option('instagram_text2'); ?>" target="_blank">
					<i class="fa icon-instagram"></i>
				</a>
			</div>
			<?php
				}
				?>
				
			<?php
				if (!genesism_get_option('youtubecheck2')){
				?>	
			<div class="social_icons">
				<a class="youtube" title="Youtube" href="<?php echo genesism_get_option('youtube_text2'); ?>" target="_blank">
					<i class="fa icon-youtube"></i>
				</a>
			</div>
			<?php
				}
				?>
				
		</div>
		<?php
		}
		?>
</div>
</div>
</div>

<div class="center_header_cont">
<div class="center_inner_header wrap">

 <div class="logo_section">
				<?php
				if (genesism_get_option('center_header')){
				?>
					<a title="<?php bloginfo('name'); ?>" href="<?php bloginfo('wpurl'); ?>"><img src="<?php echo genesism_get_option('center_header_logo_img'); ?>" alt="<?php bloginfo('name'); ?>"/></a>
				<?php
				}
				else { ?>
					<h1 itemprop="headline"><a title="<?php bloginfo('name'); ?>" href="<?php bloginfo('wpurl'); ?>"><?php bloginfo('name');?> </a></h1>
					
				<?php } ?>
</div>

 
</div>
</div>



<div class="btm_header_cont">
 <div class="btm_inner_header wrap ">
	<div class="btm_menu">
		
		<div class="bottom_menu_sec">
	
			<?php 
			if (genesism_get_option('btm_menu')){
			?>
			<div class="btm_menu">
				<span class="menu_control">≡ Menu</span>
				<?php wp_nav_menu( array( 'theme_location' => 'SecondMenu','container' => false,'menu_id' => 'menu_btm_menu' ) );?>
			</div>
			
			<?php 
			}
			?>
			
			</div>
		</div> 	
		<div class='btm_right_header'>
		<?php 
			if (genesism_get_option('btm_header_search')){
			?>
			
			<div class="top_header_search_box">
					<div class="th_search">
						<form method='get' action='<?php echo get_bloginfo('home'); ?>'>
							<input class='search_text' type='text' placeholder='<?php echo genesism_option('search_text'); ?>' name='s' />
							<button type='submit' class='btn btn-success'>
								<i class='fa icon-search'></i>
							</button>			
						</form>
					</div>
		</div>		
		<?php 
			}
			?>
		</div>
		
		
	
	
 </div>
</div>


<?php 
}



//add after header
add_action('genesis_after_header','top_optin_section',1);
function top_optin_section(){
if (genesism_get_option('top_optin')){
if ( is_home() ) {
?>

<div class="header_optin_section front_cont" style='background-image:url(<?php echo genesism_option('top_optin_bg');?> )'>
<div class="header_optin_color">
<div class="inner_header_optin wrap">

<div class="header_optin_left">
<div class="optin_left_header">
	<h3><?php echo genesism_option('hdr_optin_title'); ?></h3>
	<p><?php echo genesism_option('hdr_optin_para'); ?></p>
</div>
<div class="landing_left_optin">
	<form method="post" class="form" action="<?php echo stripslashes(genesism_option('optin_url4')); ?>" target="_blank">
	<div class="names"><input class="name" type="text" name="<?php echo stripslashes(genesism_option('optin_name4')); ?>" placeholder="<?php echo stripslashes(genesism_option('name_text4')); ?>"><div class='admins'></div></div>					
	<div class="names"><input class="email" type="text" name="<?php echo stripslashes(genesism_option('optin_email4')); ?>" placeholder="<?php echo stripslashes(genesism_option('email_text4')); ?>"><div class='mails'></div></div>
	<?php echo stripslashes(genesism_option('optin_hidden4')); ?>
	<input name="submit" class="submit" type="submit" value="<?php echo stripslashes(genesism_option('submit_text4')); ?>"/>
	</form>
</div>

</div>

</div>
</div>
</div>

<?php
}
} 
 }

 
 
 
add_action('genesis_before_header','before_header');	
function before_header() { ?>
<div class="header" itemscope="itemscope" itemtype="http://schema.org/WPHeader">
<?php
}
 
add_action('genesis_after_header','after_header');			
function after_header() { ?>

 </div>	

<?php
}



//add before content sidebar wrap

 
 add_action('genesis_before_content_sidebar_wrap','top_editor_pick_section',1);
function top_editor_pick_section(){
if ( is_home() ) {
?>
<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Editor Picks Widget') ) : ?>
<div class="widget">
<h4 itemprop="headline"><?php _e("Editor Picks #Widget", 'genesis'); ?></h4>
<p><?php _e("Displays Editor Pickst posts with thumbnails.", 'genesis'); ?></p>
</div><!-- end .widget -->
<?php endif; ?> 


<?php
}
} 

 
 /*feature image starts*/
 
  /*feature image ends*/
add_action( 'genesis_post_info', 'post_info_filter');
function post_info_filter() {
if(!is_page()){ 
?>
<div class="byline">
	<span class='author'><?php the_author() ?></span>
	<?php
		$category = get_the_category(); 
	?>
	<span class="cat"><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></span>
	
	<span class='date'><?php the_time('j M , Y') ?></span>
	
<span class='info_comments'><a  href="<?php the_permalink(); ?>#comments" title="<?php comments_number(__('0 ','fb'),__('1 ','periodic'),__('% ','fb')); ?>"><?php comments_number(__('0 ','periodic'),__('1 ','periodic'),__('% ','fb')); ?> </a></span>

	
</div>								
<?php
}
}



add_action('genesis_entry_content','post_ad',2);
function post_ad(){
if(genesism_get_option('postadcheck')){
if ( is_single() ) {?>
		<div class="post-ad" style="float:<?php echo genesism_option('float');?>; padding-right:5px; padding-left:15px; padding-top: 10px;">
		<?php  echo stripslashes((genesism_get_option('postad')));?>
		</div>
        <?php
		}
	}
	}
	
add_action ('genesis_entry_content','post_read_more');
function post_read_more(){
if (genesism_get_option('read_more')){
if(!is_page()&&!is_single()){
?>
<div class="read_more">
	<a class="read_more_btn" href="<?php echo the_permalink(); ?>"><span><?php  echo (genesism_get_option('read_text'));?></span></a>
</div>
<?php 
}
}	
}	
	
add_action( 'genesis_entry_content', 'post_info_share');
function post_info_share() {
if (genesism_get_option('blog_social_share')){
if(!is_page()&&!is_single()){ 

?>
	
	<div class="blog_social_sharing">
	
<ul>
<li class="share_tweet">
		<a href="http://twitter.com/share?text=<?php echo htmlspecialchars(urlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8')), ENT_COMPAT, 'UTF-8'); ?>&amp;url=<?php the_permalink(); ?>" target="_blank">
		<i class="icons-twitter icon"></i>
		<span>
		 Twitter
		</span>
		</a>
		</li>
		<li class="share_fb">
		<a href="http://www.facebook.com/sharer.php?u=<?php the_permalink(); ?>&amp;t=<?php echo htmlspecialchars(urlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8')), ENT_COMPAT, 'UTF-8'); ?>" target="_blank">
		<i class="icons-facebook icon"></i>
		<span>
		 Facebook
		</span>
		</a>
		</li>
		<li class="share_plus">
		<a href="https://plus.google.com/share?url=<?php the_permalink(); ?>" target="_blank" title="Click to share">
		<i class="icons-google-plus icon"></i>
		<span>
		 Google
		</span>
		</a>
		</li>
		<li class="share_linkedin">
		<a target="_blank" href="http://www.linkedin.com/shareArticle?mini=true&amp;url=<?php the_permalink(); ?>">
		<i class="icons-linkedin icon"></i>
		<span>
		 Linkedin
		</span>
		</a> 
		</li>
		
		<li class="share_pintrest">
		<a target="_blank" href="http://pinterest.com/pinthis?url=<?php the_permalink(); ?>&amp;title=<?php echo htmlspecialchars(urlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8')), ENT_COMPAT, 'UTF-8'); ?>">
		<i class="icons-pinterest icon"></i>
		<span>
		 Pintrest
		</span>
		</a>
		</li>	


</ul>


</div>

							
<?php
}
}
}


add_action ('genesis_before_sidebar_widget_area','before_sidebar_widget_area');
function before_sidebar_widget_area(){

?>
<div class="sidebar_section">
<?php 
}



add_action ('genesis_after_sidebar_widget_area','after_sidebar_widget_area');
function after_sidebar_widget_area(){
?>
</div>
<?php 
}


/*trending news*/
add_action ('genesis_before_footer','trending_post',1);
function trending_post(){
if ( is_home() ) {
?>
<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Trending Post Widget') ) : ?>
<div class="widget">
<h4 itemprop="headline"><?php _e("Trending Post #Widget", 'genesis'); ?></h4>
<p><?php _e("Displays Trending post with thumbnails.", 'genesis'); ?></p>
</div><!-- end .widget -->
<?php endif; ?> 

<?php 
}
}


// Customize the post meta function
add_filter('genesis_entry_footer', 'post_meta_filter',1);
function post_meta_filter() {
if ( is_single() ) {?>
<p class='post_tags'> 
	
	<?php the_tags( 'Tagged with: ', ' • ', '<br />' ); ?>
	
</p>
<?php
}
}

add_filter( 'genesis_term_meta_headline', 'be_default_category_title', 10, 2 );
function be_default_category_title( $headline, $term ) {
	if( ( is_category() || is_tag() || is_tax() ) && empty( $headline ) )
		$headline = $term->name;
		
	return $headline;
}
	
/** Genesis Previous/Next Post Post Navigation */
add_action ('genesis_entry_footer','prev_next_post_nav',3);
function prev_next_post_nav(){
if ( is_single() ) {
echo '<div class="prev-next-navigation">';
previous_post_link( '<div class="previous"><span>Previous article:</span> %link</div>', '%title' );
next_post_link( '<div class="next"><span>Next article:</span> %link</div>', '%title' );
echo '</div><!-- .prev-next-navigation -->';
}
}	


add_action( 'genesis_entry_header', 'breadcrumbs',2);
function breadcrumbs(){
if ( is_single() ) {

}
}



add_action( 'genesis_entry_footer', 'single_page_socialshare',2);
function single_page_socialshare(){
if (genesism_get_option('single_social_share')){
if ( is_single() ) {?>
<div class="sharing group sharing_social_count">
<div class="single_title">
	<h3><?php  echo (genesism_get_option('single_share_title'));?></h3>
	
</div>
<ul class="social_share_count">

	
		<li class="share_tweet">
		<a href="http://twitter.com/share?text=<?php echo htmlspecialchars(urlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8')), ENT_COMPAT, 'UTF-8'); ?>&amp;url=<?php the_permalink(); ?>" target="_blank">
		<i class="icon-twitter icon"></i>
		<span>
		 Twitter
		</span>
		</a>
		</li>
		<li class="share_fb">
		<a href="http://www.facebook.com/sharer.php?u=<?php the_permalink(); ?>&amp;t=<?php echo htmlspecialchars(urlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8')), ENT_COMPAT, 'UTF-8'); ?>" target="_blank">
		<i class="icon-facebook icon"></i>
		<span>
		 Facebook
		</span>
		</a>
		</li>
		<li class="share_plus">
		<a href="https://plus.google.com/share?url=<?php the_permalink(); ?>" target="_blank" title="Click to share">
		<i class="icon-google-plus icon"></i>
		<span>
		 G-plus
		</span>
		</a>
		</li>
		<li class="share_linkedin">
		<a target="_blank" href="http://www.linkedin.com/shareArticle?mini=true&amp;url=<?php the_permalink(); ?>">
		<i class="icon-linkedin icon"></i>
		<span>
		 Linkedin
		</span>
		</a> 
		</li>
		<li class="share_reddit">
		<a target="_blank" href="http://www.reddit.com/submit?url=<?php the_permalink(); ?>&amp;title=<?php echo htmlspecialchars(urlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8')), ENT_COMPAT, 'UTF-8'); ?>">
		<i class="icon-reddit icon"></i>
		<span>
		 Reddit
		</span>
		</a>
		</li>
		<li class="share_pintrest">
		<a target="_blank" href="http://pinterest.com/pinthis?url=<?php the_permalink(); ?>&amp;title=<?php echo htmlspecialchars(urlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8')), ENT_COMPAT, 'UTF-8'); ?>">
		<i class="icon-pinterest icon"></i>
		<span>
		 Pintrest
		</span>
		</a>
		</li>		
	</ul>

</div>
<?php
}
}
}
	//Related Post Box

add_action( 'genesis_before_comments', 'related_posts');
function related_posts(){
if ( is_single() ) {
?>

<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Single Related Post Widget') ) : ?>
<div class="widget">
<h4 itemprop="headline"><?php _e("Single Related Post Widget", 'genesis'); ?></h4>
<p><?php _e("Displays Related posts with thumbnails.", 'genesis'); ?></p>
</div><!-- end .widget -->
<?php endif; ?> 
</div>
<?php
}
}


//Single Optin Box


add_action('wp_head','color_box');
function color_box(){

$body_bg_color = get_option('body_bg_color');
$btm_header_bg_clr = get_option('btm_header_bg_clr');
$search_bg = get_option('search_bg');
$body_txt_color = get_option('body_txt_color');
$header_text_color = get_option('header_text_color');
$link_color =get_option('link_color');
$sidebar_hdr_bg =get_option('sidebar_hdr_bg');
$txt_color =get_option('txt_color');
$border_color = get_option('border_color');

?>
<style type="text/css">

body{
background-color:<?php echo $body_bg_color; ?>;
}

body, .blog .entry-header .byline a, .archive .entry-header .byline a, .search .entry-header .byline a{
color:<?php echo $body_txt_color; ?>;
}
.menu .sub-menu a:hover{
background:<?php echo $body_txt_color; ?>;
}

.btm_header_cont, .editor_news_sec  .editor_cont, .single .post .byline, .footer_social_follow{
background: <?php echo $btm_header_bg_clr; ?>;
}

.th_search input[type="text"] {
border-color: <?php echo $search_bg; ?>;
    background: <?php echo $search_bg; ?>;
}

a, .entry-title, .aboutus_cnt_main .abt_read_more, .editor_cont .readmore a,
.trend_cont p, .read_more_btn, .blog .entry-content p, .archive .entry-content p, .search .entry-content p,
.related_post_cnt h3 a, .feature_cont .about_read a:hover, .sw-ft-icon:hover .sw-comnt{
color:<?php echo $header_text_color; ?>;
}

.site-header, .site-title a:hover{
background:<?php echo $header_text_color; ?>;
}

a:hover, .menu .current-menu-item > a, .editor_cont .readmore a:hover, .last_title span, 
.sidebar .widget_categories ul li  a:hover, .site-footer p a,.blog .entry-header .byline a:hover, .archive .entry-header .byline a:hover, .search .entry-header .byline a:hover,.related_post_cnt h3 a:hover {
color:<?php echo $link_color; ?>;
}

.editor_cont .readmore a:hover, 
.land_top_read a:hover, .landing_right_optin input[type="submit"], .feature_cont .about_read a{
 border-color:<?php echo $link_color; ?>;
}
.header_optin_left .form input[type="submit"]:hover, .ran_cat h4 a:hover, .form-submit input[type="submit"]:hover, 
.comment-reply a, .land_top_read a:hover, .landing_right_optin input[type="submit"], .feature_cont .about_read a, 
.archive-pagination li a:hover, .archive-pagination .active a, .blog_social_sharing ul li a:hover{
background:<?php echo $link_color; ?>;
}

.header_optin_left .form input[type="submit"]:hover, .archive-pagination li a, .sidebar h4.widgettitle, .sidebar_widget  .sidebar_heading h3, .aboutus_cnt h3, 
.aboutus_cnt_main .abt_read_more:hover, .ran_cat h4 a, .read_more_btn:hover,
.comment-reply a:hover, .content .single_title h3, #reply-title,.entry-comments h3,  .footer_social_follow .social_widget .sw-ft-icon:hover a,
.site-footer{
background:<?php echo $sidebar_hdr_bg; ?>;
}

.aboutus_cnt_main .abt_read_more, .editor_cont .readmore a, .read_more_btn, .feature_cont .about_read a:hover,
.header_optin_left .form input[type="submit"]:hover,li.comment{
border-color:<?php echo $sidebar_hdr_bg; ?>;
}
.read_more_btn:hover{
color:<?php echo $txt_color; ?>;
}

.border_line, .sidebar .widget_categories ul li, .ftr_col, .archive-description .archive-title {
border-bottom-color:<?php echo $border_color; ?>;
}



<?php echo genesism_option('custom_css'); ?>

</style>
<?php
}

add_action('wp_footer','script_box');
function script_box(){?>
<script type="text/javascript">
function loadScript(src) {
     var element = document.createElement("script");
     element.src = src;
     document.body.appendChild(element);
}
// Add a script element as a child of the body
function downloadJSAtOnload() {
	
	
	 
		loadScript("<?php bloginfo('stylesheet_directory'); ?>/scripts/menu.js");		
 
}
 // Check for browser support of event handling capability
 if (window.addEventListener)
     window.addEventListener("load", downloadJSAtOnload, false);
	 else if (window.attachEvent)
     window.attachEvent("onload", downloadJSAtOnload);
 else window.onload = downloadJSAtOnload; 
 (function() {
      function getScript(url,success){
        var script=document.createElement('script');
        script.src=url;
        var head=document.getElementsByTagName('head')[0],
            done=false;
        script.onload=script.onreadystatechange = function(){
          if ( !done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete') ) {
            done=true;
            success();
            script.onload = script.onreadystatechange = null;
            head.removeChild(script);
          }
        };
        head.appendChild(script);
      }
	   getScript('http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js',function(){
        });
    })();
</script>
<?php
}

// Auto Resize Image

function aq_resize( $url, $width, $height = null, $crop = null, $single = true ) {

//validate inputs
if(!$url OR !$width ) return false;

//define upload path & dir
$upload_info = wp_upload_dir();
$upload_dir = $upload_info['basedir'];
$upload_url = $upload_info['baseurl'];

//check if $img_url is local
if(strpos( $url, $upload_url ) === false) return false;

//define path of image
$rel_path = str_replace( $upload_url, '', $url);
$img_path = $upload_dir . $rel_path;

//check if img path exists, and is an image indeed
if( !file_exists($img_path) OR !getimagesize($img_path) ) return false;

//get image info
$info = pathinfo($img_path);
$ext = $info['extension'];
list($orig_w,$orig_h) = getimagesize($img_path);

//get image size after cropping
$dims = image_resize_dimensions($orig_w, $orig_h, $width, $height, $crop);
$dst_w = $dims[4];
$dst_h = $dims[5];

//use this to check if cropped image already exists, so we can return that instead
$suffix = "{$dst_w}x{$dst_h}";
$dst_rel_path = str_replace( '.'.$ext, '', $rel_path);
$destfilename = "{$upload_dir}{$dst_rel_path}-{$suffix}.{$ext}";

if(!$dst_h) {
//can't resize, so return original url
$img_url = $url;
$dst_w = $orig_w;
$dst_h = $orig_h;
}
//else check if cache exists
elseif(file_exists($destfilename) && getimagesize($destfilename)) {
$img_url = "{$upload_url}{$dst_rel_path}-{$suffix}.{$ext}";
}
//else, we resize the image and return the new resized image url
else {

// Note: This pre-3.5 fallback check will edited out in subsequent version
if(function_exists('wp_get_image_editor')) {

$editor = wp_get_image_editor($img_path);

if ( is_wp_error( $editor ) || is_wp_error( $editor->resize( $width, $height, $crop ) ) )
return false;

$resized_file = $editor->save();

if(!is_wp_error($resized_file)) {
$resized_rel_path = str_replace( $upload_dir, '', $resized_file['path']);
$img_url = $upload_url . $resized_rel_path;
} else {
return false;
}

} else {

$resized_img_path = image_resize( $img_path, $width, $height, $crop ); // Fallback foo
if(!is_wp_error($resized_img_path)) {
$resized_rel_path = str_replace( $upload_dir, '', $resized_img_path);
$img_url = $upload_url . $resized_rel_path;
} else {
return false;
}

}

}

//return the output
if($single) {
//str return
$image = $img_url;
} else {
//array return
$image = array (
0 => $img_url,
1 => $dst_w,
2 => $dst_h
);
}

return $image;
}

function catch_that_image() {
        global $post, $posts;
        $first_img = '';
        ob_start();
        ob_end_clean();
        $output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
        if(count($matches [1]))$first_img = $matches [1] [0];
        return $first_img;
}


function new_excerpt_length($length) {
    return 40;
}
add_filter('excerpt_length', 'new_excerpt_length');

function string_limit_words($string, $word_limit)
{
  $words = explode(' ', $string, ($word_limit + 1));
  if(count($words) > $word_limit)
  array_pop($words);
  return implode(' ', $words);
}   

function custom_pagination($numpages = '', $pagerange = '', $paged='') {

  if (empty($pagerange)) {
    $pagerange = 2;
  }

  /**
   * This first part of our function is a fallback
   * for custom pagination inside a regular loop that
   * uses the global $paged and global $wp_query variables.
   * 
   * It's good because we can now override default pagination
   * in our theme, and use this function in default quries
   * and custom queries.
   */
  global $paged;
  if (empty($paged)) {
    $paged = 1;
  }
  if ($numpages == '') {
    global $wp_query;
    $numpages = $wp_query->max_num_pages;
    if(!$numpages) {
        $numpages = 1;
    }
  }

  /** 
   * We construct the pagination arguments to enter into our paginate_links
   * function. 
   */
  $pagination_args = array(
    'base'            => get_pagenum_link(1) . '%_%',
    'format'          => 'page/%#%',
    'total'           => $numpages,
    'current'         => $paged,
    'show_all'        => False,
    'end_size'        => 1,
    'mid_size'        => $pagerange,
    'prev_next'       => True,
    'prev_text'       => __('&laquo;'),
    'next_text'       => __('&raquo;'),
    'type'            => 'plain',
    'add_args'        => false,
    'add_fragment'    => ''
  );

  $paginate_links = paginate_links($pagination_args);

  if ($paginate_links) {
    echo "<nav class='custom-pagination'>";
      echo "<span class='page-numbers page-num'>Page " . $paged . " of " . $numpages . "</span> ";
      echo $paginate_links;
    echo "</nav>";
  }

}



//Last Updated Post Widget Starts Here
class gl_last_update_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_last_update_widget', 

__('M&G - Last Updated Post', 'gl_last_update_widget_domain'), 

array( 'description' => __( 'Displays Last Updated Post', 'gl_last_update_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );

echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];

?>

<div class="last_updated sidebar_content">
		<?php
			
			// Query Arguments
			$lastupdated_args = array(
			'orderby' => 'modified',
			);
			//Loop to display 5 recently updated posts
			$lastupdated_loop = new WP_Query( $lastupdated_args );
			$counter = 1;
			echo '<ul>';
			while( $lastupdated_loop->have_posts() && $counter <= $instance[ 'post_count' ] ) : $lastupdated_loop->the_post();
			echo '<li>';
			
			
echo"<div class='trend_img'>";
if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
 echo "<div class='featured_viedo_image featured_image'>";
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true);echo "</div>";	
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video
			
 // Defaults
        $f_img_width6 = 111;
        $f_img_height6 = 100;

		// Auto feature image defaults
		$thumb = get_post_thumbnail_id(); 
		$img_url = wp_get_attachment_url( $thumb,'full' ); 
		$image = aq_resize( $img_url,$f_img_width6,$f_img_height6, true );
		// Catch the Image defaults
        $catch_img_url = catch_that_image( $thumb,'full' );
        $catch_image = aq_resize( $catch_img_url, $f_img_width6, $f_img_height6, true );
        // Default Image
		if(has_post_thumbnail())
		echo
		"<div class=\"featured_image\">\n".
		"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img class='grayscale' src=\"" . $image . "\" width=\"" . $f_img_width6 . "\" height=\"" . $f_img_height6 . "\" alt=\"" . get_the_title() . "\"><div class='thumb_hover'></div></a>\n".
		"</div>\n";
		elseif (catch_that_image()){ 
		echo
		"<div class=\"featured_image\">\n".
		"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img class='grayscale' src=\"" . $catch_image . "\" width=\"" . $f_img_width6 . "\" height=\"" . $f_img_height6 . "\" alt=\"" . get_the_title() . "\"></a>\n".
		"</div>\n"; 
		}
}
}		
		/*featured image ends here*/

echo "</div>".
'<h3 class="last_title"><a href="' . get_permalink( $lastupdated_loop->post->ID ) . '"> ' .get_the_title( $lastupdated_loop->post->ID ) . '</a> <span>( '. get_the_modified_date() .')</span></h3> '.
'</li>';
			$counter++;
			endwhile; 
			echo '</ul>';
			wp_reset_postdata(); 

		?>
	</div>


<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Last Updated Posts', 'gl_last_update_widget_domain' );
}

 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '4', 'gl_last_update_widget_domain' );
}

?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>
<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
return $instance;
}
} 

//Last Updated Post Widget Ends Here

// Popular Widget Starts Here

class gl_popular_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_popular_widget', 

__('M&G - Popular Post', 'gl_popular_widget_domain'), 

array( 'description' => __( 'Displays Popular Post', 'gl_popular_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );

echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];

?>

<div class="popular_post sidebar_widget_bg sidebar_widget">
	
	<div class='popular_post_cnt sidebar_content'>
		<?php
			query_posts('post_type=post&posts_per_page='. $post_count .' &orderby=comment_count&order=DESC');
			while (have_posts()): the_post(); 
		?>
			<div class='popular_post_section border_line entry_cnt'>
				<div class='popular_img'>
					<?php
					if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
 echo "<div class='featured_viedo_image'>";
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true); echo "</div>";	
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video
						  $f_img_width2 = $instance['width_size'];
							$f_img_height2 =$instance['height_size'];
							$default_img =  'Feature_image'; 
						// Auto feature image defaults
						$thumb = get_post_thumbnail_id(); 
						$img_url = wp_get_attachment_url( $thumb,'full' ); 
						$image = aq_resize( $img_url, $f_img_width2, $f_img_height2, true );
						// Catch the Image defaults
						$catch_img_url = catch_that_image( $thumb,'full' );
						$catch_image = aq_resize( $catch_img_url, $f_img_width2, $f_img_height2, true );
						if(has_post_thumbnail())
						echo
						"<div class=\"featured_image\">\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img class='grayscale ' src=\"" . $image . "\" width=\"" . $f_img_width2 . "\" height=\"" . $f_img_height2 . "\" alt=\"" . get_the_title() . "\"></a><div class='thumb_hover'><a class=\"link\" href=\"" . get_permalink() . "\"></a></div>\n".
						"</div>\n";
						elseif (catch_that_image()){ 
						echo
						"<div class=\"featured_image\">\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img class='grayscale' src=\"" . $catch_image . "\" width=\"" . $f_img_width2 . "\" height=\"" . $f_img_height2 . "\" alt=\"" . get_the_title() . "\"></a><div class='thumb_hover'><a class=\"link\" href=\"" . get_permalink() . "\"></a></div>\n".
						"</div>\n";  
						} 
						}
						}
					?>
				</div>
				<div class="popular_cnt">
					<h3><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a></h3>
				
				<div class='pop_byline'>
				<span><?php the_time('M jS, Y'); ?></span>
				</div>
				</div>
			</div>
		<?php
			endwhile;
		?>
	</div>
</div>

<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Popular Posts', 'gl_popular_widget_domain' );
}

 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '4', 'gl_popular_widget_domain' );
}

 if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '111', 'gl_popular_widget_domain' );
}

 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '100', 'gl_popular_widget_domain' );
}

?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>
<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';
return $instance;
}
}


// Random Widget Starts Here

class gl_random_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_random_widget', 

__('M&G - Random Post', 'gl_random_widget_domain'), 

array( 'description' => __( 'Displays Random Post', 'gl_random_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );

echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];

?>
<div class="random_post sidebar_widget_bg sidebar_widget">

	<div class='random_post_cnt sidebar_content'>
		<?php
			query_posts('post_type=post&posts_per_page='. $post_count .' &orderby=rand&order=DESC');
			while (have_posts()): the_post(); 
		?>
			<div class='random'>
				<div class='random_img'>
					<?php
					if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
 echo "<div class='featured_viedo_image featured_image'>";
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true);echo "</div>";	
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video
			
					// Defaults
						 $f_img_width4 = $instance['width_size'];
							$f_img_height4 =$instance['height_size'];
						// Auto feature image defaults
						$thumb = get_post_thumbnail_id(); 
						$img_url = wp_get_attachment_url( $thumb,'full' ); 
						$image = aq_resize( $img_url, $f_img_width4, $f_img_height4, true );
						// Catch the Image defaults
						$catch_img_url = catch_that_image( $thumb,'full' );
						$catch_image = aq_resize( $catch_img_url, $f_img_width4, $f_img_height4, true );
						if(has_post_thumbnail())
						echo
						"<div class=\"featured_image\">\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img class='grayscale' src=\"" . $image . "\" width=\"" . $f_img_width4 . "\" height=\"" . $f_img_height4 . "\" alt=\"" . get_the_title() . "\"></a><div class='thumb_hover'><a class=\"link\" href=\"" . get_permalink() . "\"></a></div>\n".
						"</div>\n";
						elseif (catch_that_image()){ 
						echo
						"<div class=\"featured_image\">\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img class='grayscale' src=\"" . $catch_image . "\" width=\"" . $f_img_width4 . "\" height=\"" . $f_img_height4 . "\" alt=\"" . get_the_title() . "\"></a><div class='thumb_hover'><a class=\"link\" href=\"" . get_permalink() . "\"></a></div>\n".
						"</div>\n";  
						} 
						}
						}
					?>
					<div class='ran_cat'>
					<?php
							$category = get_the_category(); 
							?>
							<h4><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></h4>
					</div>
				</div>
				<div class="random_cnt">
				
					<h3><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a></h3>
				<p>
							<?php
							$excerpt=get_the_excerpt();
							echo string_limit_words($excerpt,23);
							?>
							</p>
				</div>
			</div>
		<?php
			endwhile;
		?>
	</div>
</div>

<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Random Posts', 'gl_random_widget_domain' );
}

 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '4', 'gl_random_widget_domain' );
}

 if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '111', 'gl_random_widget_domain' );
}

 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '100', 'gl_random_widget_domain' );
}

?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>
<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';
return $instance;
}
}



// About Us Widget Starts Here

class gl_aboutus_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_aboutus_widget', 

__('M&G - About Us ', 'gl_aboutus_widget_domain'), 

array( 'description' => __( 'Displays About Us Content', 'gl_aboutus_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$sb_aboutus_title = apply_filters( 'sb_aboutus_title', $instance['sb_aboutus_title'] );
$about_us_img = apply_filters( 'about_us_img', $instance['about_us_img'] );
$sb_aboutus_cnt = apply_filters( 'sb_aboutus_cnt', $instance['sb_aboutus_cnt'] );
$sb_aboutus_read = apply_filters( 'sb_aboutus_read', $instance['sb_aboutus_read'] );
$sb_aboutus_read_link = apply_filters( 'sb_aboutus_read_link', $instance['sb_aboutus_read_link'] );

echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];


?>

<div class="sidebar_aboutus sidebar_widget_bg sidebar_widget">
	<div class="aboutus_cnt">
	
			<div class="aboutus_cnt_title_img">
			<a href='<?php  echo $instance['sb_aboutus_read_link'];?>'><img class='grayscale' alt="<?php  echo (genesism_get_option('sb_aboutus_title'));?>" src='<?php  echo $instance['about_us_img'];?>'/>
			<span class="effect-line"></span>
			</a>
			</div>
			<div class="aboutus_cnt_title_para">
			<h3><?php  echo $instance['sb_aboutus_title'];?></h3>
				<div class="aboutus_cnt_main">
			<p><?php  echo $instance['sb_aboutus_cnt'];?></p>
			<a class="custom read_more_btn" href="<?php  echo $instance['sb_aboutus_read_link'];?>"><span><?php  echo $instance['sb_aboutus_read'];?>
			</span>
			</a>
			</div>
			</div>
		</div>
	
</div>
<?php
echo $args['after_widget'];
}
		
public function form( $instance ) {

if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'About Me', 'gl_random_widget_domain' );
}


if ( isset( $instance[ 'sb_aboutus_title' ] ) ) {
$sb_aboutus_title = $instance[ 'sb_aboutus_title' ];
}
else {
$sb_aboutus_title = __( 'Emily smith', 'gl_aboutus_widget_domain' );
}

 if ( isset( $instance[ 'about_us_img' ] ) ) {
$about_us_img = $instance[ 'about_us_img' ];
}
else {
$about_us_img = __( ' ', 'gl_aboutus_widget_domain' );
}

 if ( isset( $instance[ 'sb_aboutus_cnt' ] ) ) {
$sb_aboutus_cnt = $instance[ 'sb_aboutus_cnt' ];
}
else {
$sb_aboutus_cnt = __( 'About Us Content', 'gl_aboutus_widget_domain' );
}

 if ( isset( $instance[ 'sb_aboutus_read' ] ) ) {
$sb_aboutus_read = $instance[ 'sb_aboutus_read' ];
}
else {
$sb_aboutus_read = __( 'Read More', 'gl_aboutus_widget_domain' );
}

 if ( isset( $instance[ 'sb_aboutus_read_link' ] ) ) {
$sb_aboutus_read_link = $instance[ 'sb_aboutus_read_link' ];
}
else {
$sb_aboutus_read_link = __( '', 'gl_aboutus_widget_domain' );
}

?>

<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'sb_aboutus_title' ); ?>"><?php _e( 'About Us Name:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'sb_aboutus_title' ); ?>" name="<?php echo $this->get_field_name( 'sb_aboutus_title' ); ?>" type="text" value="<?php echo esc_attr( $sb_aboutus_title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'about_us_img' ); ?>"><?php _e( 'About Us Image URL Link:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'about_us_img' ); ?>" name="<?php echo $this->get_field_name( 'about_us_img' ); ?>" type="text" value="<?php echo esc_attr( $about_us_img ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'sb_aboutus_cnt' ); ?>"><?php _e( 'About Us Content:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'sb_aboutus_cnt' ); ?>" name="<?php echo $this->get_field_name( 'sb_aboutus_cnt' ); ?>" type="text" value="<?php echo esc_attr( $sb_aboutus_cnt ); ?>"/>
</p>
<p>
<label for="<?php echo $this->get_field_id( 'sb_aboutus_read' ); ?>"><?php _e( 'About Us Readmore Text:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'sb_aboutus_read' ); ?>" name="<?php echo $this->get_field_name( 'sb_aboutus_read' ); ?>" type="text" value="<?php echo esc_attr( $sb_aboutus_read ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'sb_aboutus_read_link' ); ?>"><?php _e( 'About Us Readmore Text URL Link:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'sb_aboutus_read_link' ); ?>" name="<?php echo $this->get_field_name( 'sb_aboutus_read_link' ); ?>" type="text" value="<?php echo esc_attr( $sb_aboutus_read_link ); ?>" />
</p>
<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['sb_aboutus_title'] = ( ! empty( $new_instance['sb_aboutus_title'] ) ) ? strip_tags( $new_instance['sb_aboutus_title'] ) : '';
$instance['about_us_img'] = ( ! empty( $new_instance['about_us_img'] ) ) ? strip_tags( $new_instance['about_us_img'] ) : '';
$instance['sb_aboutus_cnt'] = ( ! empty( $new_instance['sb_aboutus_cnt'] ) ) ? strip_tags( $new_instance['sb_aboutus_cnt'] ) : '';
$instance['sb_aboutus_read'] = ( ! empty( $new_instance['sb_aboutus_read'] ) ) ? strip_tags( $new_instance['sb_aboutus_read'] ) : '';
$instance['sb_aboutus_read_link'] = ( ! empty( $new_instance['sb_aboutus_read_link'] ) ) ? strip_tags( $new_instance['sb_aboutus_read_link'] ) : '';
return $instance;
}
}
// About us post widget ends here



//Single Page Related Post Widget starts Here


class gl_related_post_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_related_post_widget', 

__('M&G - Single Related Post', 'gl_related_post_widget_domain'), 

array( 'description' => __( 'Displays Single Related Post', 'gl_related_post_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$related_title = apply_filters( 'related_title', $instance['related_title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );


echo $args['before_widget'];
if ( ! empty( $title ) )
//echo $args['before_title'] . $title . $args['after_title'];

?>

<div class="thesis_related single_page_cnt">
<?php
global $post;

	if ( is_single() ) {
		$tags = get_the_tags($post->ID);
			if ($tags) {
			$tag_ids = array();
			foreach($tags as $individual_tag) $tag_ids[] = $individual_tag->term_id;
			$args=array(
			'tag__in' => $tag_ids,
			'post__not_in' => array($post->ID),
			'showposts'=>$instance[ 'post_count' ],  // Number of related posts that will be shown.
			'caller_get_posts'=>1
			);
	$my_query = new wp_query($args);
			if( $my_query->have_posts() ) {
	echo	'<div id="relatedposts">'.
				'<div class="single_title">'.
					'<h3>'. $related_title .'</h3>'.
				
				'</div>'.
			'<div class="related_section">';
		while ($my_query->have_posts()) {
			$my_query->the_post();
			$i++;
			$class = ( $i % 3) ? 'related_post_section' : 'related_post_section last';
	 ?>
			<div class="<?php echo $class; ?>">
							<div class="related_img">
								<?php
// show the image thumb if there is one, and the post does not have a video
						  $f_img_width8 = $instance['width_size'];
							$f_img_height8 =$instance['height_size'];
							$default_img =  'Feature_image'; 
						// Auto feature image defaults
						$thumb = get_post_thumbnail_id(); 
						$img_url = wp_get_attachment_url( $thumb,'full' ); 
						$image = aq_resize( $img_url, $f_img_width8, $f_img_height8, true );
						// Catch the Image defaults
						$catch_img_url = catch_that_image( $thumb,'full' );
						$catch_image = aq_resize( $catch_img_url, $f_img_width8, $f_img_height8, true );
						if(has_post_thumbnail())
						echo
						"<div class=\"featured_image\">\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img class='grayscale' src=\"" . $image . "\" width=\"" . $f_img_width8 . "\" height=\"" . $f_img_height8 . "\" alt=\"" . get_the_title() . "\"></a><div class='img_hover'><a class=\"link\" href=\"" . get_permalink() . "\"></a></div>\n".
						"</div>\n";
						elseif (catch_that_image()){ 
						echo
						"<div class=\"featured_image\">\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img class='grayscale' src=\"" . $catch_image . "\" width=\"" . $f_img_width8 . "\" height=\"" . $f_img_height8 . "\" alt=\"" . get_the_title() . "\"></a><div class='img_hover'><a class=\"link\" href=\"" . get_permalink() . "\"></a></div>\n".
						"</div>\n";  
						}
												
					?>
							</div>

							<div class="related_post_cnt">
									<?php echo "<h3><a href='". get_permalink() ."'>".get_the_title()."";
									echo "</a></h3>";?>
									<span class='date'><?php the_time('M jS, Y') ?></span>
							
							</div>
					</div>
	<?php
			}
			echo "</div>";
			echo "</div>";
			}
		}
	$post = $backup;
			wp_reset_query();
			?>
			<div class="clear"></div>
			<?php
			 }
		
?>
</div>
<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {
if ( isset( $instance[ 'related_title' ] ) ) {
$related_title = $instance[ 'related_title' ];
}
else {
$related_title = __( 'Related Post', 'gl_related_post_widget_domain' );
}

 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '6', 'gl_related_post_widget_domain' );
}

if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '252', 'gl_related_post_widget_domain' );
}

 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '225', 'gl_related_post_widget_domain' );
}


?>
<p>
<label for="<?php echo $this->get_field_id( 'related_title' ); ?>"><?php _e( 'Post Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'related_title' ); ?>" name="<?php echo $this->get_field_name( 'related_title' ); ?>" type="text" value="<?php echo esc_attr( $related_title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Left Latest News Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Left Latest News  Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>
<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['related_title'] = ( ! empty( $new_instance['related_title'] ) ) ? strip_tags( $new_instance['related_title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';

return $instance;
}
}

//Single Page Related Post Widget Ends Here

// Editor Picks Widget Starts Here

class gl_editor_picks_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_editor_picks_widget', 

__('M&G - Editor Picks Post', 'gl_editor_picks_widget_domain'), 

array( 'description' => __( 'Displays Editor Picks Post', 'gl_editor_picks_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );
$post_id1 = apply_filters( 'post_id1', $instance['post_id1'] );
$post_id2 = apply_filters( 'post_id2', $instance['post_id2'] );
$read_more = apply_filters( 'read_more', $instance['read_more'] );
echo $args['before_widget'];
if ( ! empty( $title ) )
//echo $args['before_title'] . $title . $args['after_title'];

?>
<div class="topeditor_picks_section">


<div class="top_editor_picks_inner wrap">
<div class='top_editor_header'>
<h2><?php echo $instance['title']; ?></h2>
</div>

<div class="top_editor_picks_right">
<div class="editors_picks_content">

<?php

query_posts('p='. $post_id1 .'&posts_per_page=1');
while (have_posts()): the_post(); 
?>
<?php
echo "<div class='editor_news_sec'>";

echo"<div class='edit_img'>";
if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true);
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video
			
 // Defaults
         $f_img_width = $instance['width_size'];
        $f_img_height = $instance['height_size'];
        $default_img =  'Feature_image'; 

		// Auto feature image defaults
		$thumb = get_post_thumbnail_id(); 
		$img_url = wp_get_attachment_url( $thumb,'full' ); 
		$image = aq_resize( $img_url,$f_img_width,$f_img_height, true );
		// Catch the Image defaults
        $catch_img_url = catch_that_image( $thumb,'full' );
        $catch_image = aq_resize( $catch_img_url, $f_img_width, $f_img_height, true );
        // Default Image
        $default_image = aq_resize( $default_img, $f_img_width, $f_img_height, true );
		if(has_post_thumbnail())
		echo
		"<div class=\"featured_image\">\n".
		"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img class='grayscale ' src=\"" . $image . "\" width=\"" . $f_img_width . "\" height=\"" . $f_img_height . "\" alt=\"" . get_the_title() . "\"><div class='thumb_hover'></div></a>\n".
		"</div>\n";
		elseif (catch_that_image()){ 
		echo
		"<div class=\"featured_image\">\n".
		"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img class='grayscale ' src=\"" . $catch_image . "\" width=\"" . $f_img_width . "\" height=\"" . $f_img_height . "\" alt=\"" . get_the_title() . "\"></a>\n".
		"</div>\n"; 
		}
}
}		
		/*featured image ends here*/

echo "</div>";

echo "<div class='editor_cont'>";
?>

<?php
echo"<div class='blog_title'><h4><a href='". get_permalink() ."'>". get_the_title() ."".
"</a></h4></div>";
?>
<div class="entry_excerpt">
							<p>
							<?php
							$excerpt=get_the_excerpt();
							echo string_limit_words($excerpt,23);
							?>
							</p>
							</div><?php
echo"<div class='permalink readmore'><a href='". get_permalink() ."'>". $read_more ."</a></div>";


echo "</div>";
echo "</div>";

?>

<?php
endwhile;
wp_reset_query();
?>
</div>

<div class="editors_picks_content">

<?php

query_posts('p='. $post_id2 .'&posts_per_page=1');
while (have_posts()): the_post(); 
?>
<?php
echo "<div class='editor_news_sec'>";

echo"<div class='edit_img'>";
if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true);
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video
			
 // Defaults
         $f_img_width = $instance['width_size'];
        $f_img_height = $instance['height_size'];
        $default_img =  'Feature_image'; 

		// Auto feature image defaults
		$thumb = get_post_thumbnail_id(); 
		$img_url = wp_get_attachment_url( $thumb,'full' ); 
		$image = aq_resize( $img_url,$f_img_width,$f_img_height, true );
		// Catch the Image defaults
        $catch_img_url = catch_that_image( $thumb,'full' );
        $catch_image = aq_resize( $catch_img_url, $f_img_width, $f_img_height, true );
        // Default Image
        $default_image = aq_resize( $default_img, $f_img_width, $f_img_height, true );
		if(has_post_thumbnail())
		echo
		"<div class=\"featured_image\">\n".
		"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img class='grayscale ' src=\"" . $image . "\" width=\"" . $f_img_width . "\" height=\"" . $f_img_height . "\" alt=\"" . get_the_title() . "\"><div class='thumb_hover'></div></a>\n".
		"</div>\n";
		elseif (catch_that_image()){ 
		echo
		"<div class=\"featured_image\">\n".
		"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img class='grayscale ' src=\"" . $catch_image . "\" width=\"" . $f_img_width . "\" height=\"" . $f_img_height . "\" alt=\"" . get_the_title() . "\"></a>\n".
		"</div>\n"; 
		}
}
}		
		/*featured image ends here*/

echo "</div>";

echo "<div class='editor_cont'>";
?>

<?php
echo"<div class='blog_title'><h4><a href='". get_permalink() ."'>". get_the_title() ."".
"</a></h4></div>";?>
<div class="entry_excerpt">
							<p>
							<?php
							$excerpt=get_the_excerpt();
							echo string_limit_words($excerpt,23);
							?>
							</p>
							</div><?php
echo"<div class='permalink readmore'><a href='". get_permalink() ."'>". $read_more ."</a></div>";
echo "</div>";
echo "</div>";

?>



<?php
endwhile;
wp_reset_query();
?>
</div>

</div>

</div>

</div>

<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {

if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Editor Picks', 'gl_editor_picks_widget_domain' );
}


if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '300', 'gl_editor_picks_widget_domain' );
}

 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '303', 'gl_editor_picks_widget_domain' );
}


 if ( isset( $instance[ 'post_id1' ] ) ) {
$post_id1 = $instance[ 'post_id1' ];
}
else {
$post_id1 = __( '55', 'gl_editor_picks_widget_domain' );
}

 if ( isset( $instance[ 'post_id2' ] ) ) {
$post_id2 = $instance[ 'post_id2' ];
}
else {
$post_id2 = __( '45', 'gl_editor_picks_widget_domain' );
}

 if ( isset( $instance[ 'read_more' ] ) ) {
$read_more = $instance[ 'read_more' ];
}
else {
$read_more = __( 'Read More', 'gl_editor_picks_widget_domain' );
}
?>

<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'post_id1' ); ?>"><?php _e( 'Editor Picks Post ID One:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_id1' ); ?>" name="<?php echo $this->get_field_name( 'post_id1' ); ?>" type="text" value="<?php echo esc_attr( $post_id1 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'post_id2' ); ?>"><?php _e( 'Editor Picks Post ID Two:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_id2' ); ?>" name="<?php echo $this->get_field_name( 'post_id2' ); ?>" type="text" value="<?php echo esc_attr( $post_id2 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'read_more' ); ?>"><?php _e( 'Read More Text:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'read_more' ); ?>" name="<?php echo $this->get_field_name( 'read_more' ); ?>" type="text" value="<?php echo esc_attr( $read_more ); ?>" />
</p>

<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_id1'] = ( ! empty( $new_instance['post_id1'] ) ) ? strip_tags( $new_instance['post_id1'] ) : '';
$instance['post_id2'] = ( ! empty( $new_instance['post_id2'] ) ) ? strip_tags( $new_instance['post_id2'] ) : '';
$instance['read_more'] = ( ! empty( $new_instance['read_more'] ) ) ? strip_tags( $new_instance['read_more'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';

return $instance;
}
}


// Editor Picks Widget Ends Here

// Trending Post Widget Starts Here

class gl_trending_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_trending_widget', 

__('M&G - Trending Post  Post', 'gl_trending_widget_domain'), 

array( 'description' => __( 'Displays Trending Post  Post', 'gl_trending_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );

echo $args['before_widget'];
if ( ! empty( $title ) )
//echo $args['before_title'] . $title . $args['after_title'];

?>
<div class="trending_post">

	<div class="trending_post_inner wrap">
	<div class="trnd_heading">
		<h3><?php echo $instance['title']; ?></h3>
	</div>
	<div class="trending_post_section">
		<ul>
			<?php
				global $query_string;
				query_posts( array( 'posts_per_page'=> $instance['post_count'] , 'post_type' => 'post', 'orderby' => 'comment_count','order' => 'desc', 'paged' => get_query_var('paged')) );
				if(have_posts()) : 
				while(have_posts()) : the_post();
			?>
				<li class="trend_cont">
				<?php 

echo"<div class='trend_img'>";
if(get_post_meta(get_the_ID(), "_related-video", true) != ''){
 echo "<div class='featured_viedo_image featured_image'>";
// show the video embed code if there is one
echo get_post_meta(get_the_ID(), "_related-video", true); echo "</div>";		
}else{
if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) {
// show the image thumb if there is one, and the post does not have a video
			
 // Defaults
        $f_img_width5 = $instance['width_size'];
        $f_img_height5 = $instance['height_size'];

		// Auto feature image defaults
		$thumb = get_post_thumbnail_id(); 
		$img_url = wp_get_attachment_url( $thumb,'full' ); 
		$image = aq_resize( $img_url,$f_img_width5,$f_img_height5, true );
		// Catch the Image defaults
        $catch_img_url = catch_that_image( $thumb,'full' );
        $catch_image = aq_resize( $catch_img_url, $f_img_width5, $f_img_height5, true );
        // Default Image
		if(has_post_thumbnail())
		echo
		"<div class=\"featured_image\">\n".
		"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img  class='grayscale' src=\"" . $image . "\" width=\"" . $f_img_width5 . "\" height=\"" . $f_img_height5 . "\" alt=\"" . get_the_title() . "\"><div class='thumb_hover'></div></a>\n".
		"</div>\n";
		elseif (catch_that_image()){ 
		echo
		"<div class=\"featured_image\">\n".
		"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img class='grayscale' src=\"" . $catch_image . "\" width=\"" . $f_img_width5 . "\" height=\"" . $f_img_height5 . "\" alt=\"" . get_the_title() . "\"></a>\n".
		"</div>\n"; 
		}
}
}		
		/*featured image ends here*/

echo "</div>";

echo"<div class='trend_btm'>";
?>

<?php
echo "<h3><a href='". get_permalink() ."'>".
get_the_title() ."".
"</a></h3>";?>
<div class="entry_excerpt">
							<p>
							<?php
							$excerpt=get_the_excerpt();
							echo string_limit_words($excerpt,23);
							?>
							</p>
							</div>

<?php
echo "</div>";
?>
				</li>
			<?php 
				endwhile;
				endif;
			?>
		</ul>
	</div>
	</div>

</div>

<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {

if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Trending Post', 'gl_trending_widget_domain' );
}


if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '360', 'gl_trending_widget_domain' );
}

 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '250', 'gl_trending_widget_domain' );
}


 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '4', 'gl_trending_widget_domain' );
}

?>

<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>


<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>


<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';

return $instance;
}
}


// Trending Post Widget Ends Here


// Register and load the widget
function gl_load_widget() {
	register_widget( 'gl_last_update_widget' );
	register_widget( 'gl_popular_widget' );
	register_widget( 'gl_random_widget' );
	register_widget( 'gl_aboutus_widget' );
	register_widget( 'gl_related_post_widget' );
	register_widget( 'gl_editor_picks_widget' );
	register_widget( 'gl_trending_widget' );
}
add_action( 'widgets_init', 'gl_load_widget' );
