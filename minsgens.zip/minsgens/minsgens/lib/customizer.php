<?php

function minsgens_customize_register( $wp_customize ) {
 /*******************************************
Color scheme
********************************************/
 
// add the section to contain the settings
$wp_customize->add_section( 'textcolors' , array(
    'title' =>  'Color Scheme',
) );

// Body Background Color
$txtcolors[] = array(
    'slug'=>'body_bg_color', 
    'default' => '#fff',
    'label' => 'Background Color'
);

//Bottom Header Background
$txtcolors[] = array(
    'slug'=>'btm_header_bg_clr', 
    'default' => '#f2f2f2',
    'label' => 'Bottom Header Background Color '
);
 
 // Search Box BG color 
$txtcolors[] = array(
    'slug'=>'search_bg', 
    'default' => '#d9d9d9',
    'label' => 'Search Box BG color '
);

// Body Text Color
$txtcolors[] = array(
    'slug'=>'body_txt_color', 
    'default' => '#555',
    'label' => 'Body Text Color'
);


// Header Text Color
$txtcolors[] = array(
    'slug'=>'header_text_color', 
    'default' => '#212121',
    'label' => 'Header Text Color'
);


// link color
$txtcolors[] = array(
    'slug'=>'link_color', 
    'default' => '#9b9b9b',
    'label' => 'Link Color'
);


// Sidebar header Background

$txtcolors[] = array(
    'slug'=>'sidebar_hdr_bg', 
    'default' => '#111',
    'label' => 'Sidebar Header BG Color'
);

// Text Color

$txtcolors[] = array(
    'slug'=>'txt_color', 
    'default' => '#fff',
    'label' => 'Text Color'
);

 
// Border color 
$txtcolors[] = array(
    'slug'=>'border_color', 
    'default' => '#E3E3E3',
    'label' => 'Border Color'
);

 


// add the settings and controls for each color
foreach( $txtcolors as $txtcolor ) {
 
    // SETTINGS
    $wp_customize->add_setting(
        $txtcolor['slug'], array(
            'default' => $txtcolor['default'],
            'type' => 'option', 
            'capability' => 
            'edit_theme_options'
        )
    );
    // CONTROLS
    $wp_customize->add_control(
        new WP_Customize_Color_Control(
            $wp_customize,
            $txtcolor['slug'], 
            array('label' => $txtcolor['label'], 
            'section' => 'textcolors',
            'settings' => $txtcolor['slug'])
        )
    );
}
}
add_action( 'customize_register', 'minsgens_customize_register' );