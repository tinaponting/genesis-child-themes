<?php

/**
 * This function registers the default values for genesis theme settings
 */
 
function genesism_theme_settings_defaults() {
$defaults = array( // define our defaults
'style' => 'default',
'custom' => 0,
'shortcodes-css' => 1,
'top_menu' => 1,
'center_header' => 1,
'center_header_logo_img' => 'http://minsandgens.genesislovers.com/wp-content/uploads/2016/10/logo.png',
'btm_menu' => 1,
'btm_header_search' => 1,
'search_text' => 'search...',
'top_optin' => 1,
'optin_url4' => '#',
'name_text4' => 'Enter your name',
'email_text4' => 'Enter your email',
'submit_text4' => 'submit',
'hdr_optin_title' => 'HOW TO MAKE THEM STOP AND STARE.',
'hdr_optin_para' => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet…',
'top_optin_bg' => 'http://minsandgens.genesislovers.com/wp-content/uploads/2016/10/hands-people-woman-meeting-large.jpg',
'read_more' => 1,
'read_text' => 'Keep Reading',
'blog_social_share' => 1,
'single_social_share' => 1,
'single_share_title' => 'Social Share',
'postadcheck' => 1,
'float' => 'right',
'postad' => '<img alt="Post advertisement" src="http://minsandgens.genesislovers.com/wp-content/uploads/2016/10/banner300x250.png"/>',
'landing_content_optin' => 1,
'optin_url1' => '#',
'name_text1' => 'Enter Your  Name',
'email_text1' => 'Enter Your Email',
'submit_text1' => 'Join our Team',
'land_optin_title' => 'Sign-up on our weekly plan to receive',
'land_optin_para' => 'Non sunt dicta ridiculus numquam sociis leo ',
'top_left_title' => 'Start off the new year on the right foot.',
'top_left_para' => 'Studies have shown that those who participate in group fitness are more dedicated and get better results.',
'top_read_txt' => 'Readmore',
'land_optin_bg' => 'http://minsandgens.genesislovers.com/wp-content/uploads/2016/10/bg1.jpeg',
'landing_feature' => 1,
'landing_feature_title' => 'Contrary to popular belief, Lorem Ipsum',
'landing_feature_para' => 'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur',
'land_ftr1_img' => 'http://minsandgens.genesislovers.com/wp-content/uploads/2016/10/feat3.jpg',
'ftr1_title' => 'Strength Training',
'feature1_para' => 'All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.',
'viewmore_txt1' => 'View more',
'land_ftr2_img' => 'http://minsandgens.genesislovers.com/wp-content/uploads/2016/10/feat2.jpg',
'ftr2_title' => 'Teach you perfect',
'feature2_para' => 'All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.',
'viewmore_txt2' => 'View more',
'land_ftr3_img' => 'http://minsandgens.genesislovers.com/wp-content/uploads/2016/10/feat1.jpg',
'ftr3_title' => 'Combining a Rang',
'feature3_para' => 'All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.',
'viewmore_txt3' => 'View more',

'footer1' => 1,

'f_img_width'=>'740',
'f_img_height'=>'370',

		'footer_text' => 'Copyright &copy;'.date('Y') .  ' <a href="'. get_bloginfo('url') .'">' . get_bloginfo('name') . '</a>'
	
	);
	
	return apply_filters('genesism_theme_settings_defaults', $defaults);

}



function genesism_theme_settings_boxes() {
	global $_genesism_theme_settings_pagehook;
	
	if (function_exists('add_screen_option')) { add_screen_option('layout_columns', array('max' => 2, 'default' => 2) ); }

add_meta_box('genesism-theme-settings-version', __('Theme Information', 'genesism'), 'genesism_theme_settings_info_box', $_genesism_theme_settings_pagehook, 'normal');	
 }
  
 function genesism_theme_settings_info_box() { 
?>

<p class="bolder"><strong><?php echo CHILD_THEME_NAME; ?></strong> by <a href="http://genesislovers.com">genesislovers.com</a></p>
<p><strong>
  <?php _e('Version:', 'genesism'); ?>
  </strong> <?php echo CHILD_THEME_VERSION; ?> <strong>
   </p>
<p><span class="description">
  <?php _e('For support, please visit <a href="http://genesislovers.com/contactus/">http://genesislovers.com/contactus/</a>', 'genesism'); ?>
  </span></p>

<div id="tabs">

	<ul>
		<li><a href="#tabs-1"><?php _e("Top Header Menu Section", 'genesism'); ?></a></li>
		<li><a href="#tabs-2"><?php _e("Top Header Social Follow", 'genesism'); ?></a></li>
		<li><a href="#tabs-3"><?php _e("Header Logo Section", 'genesism'); ?></a></li>
		<li><a href="#tabs-4"><?php _e("Bottom Menu", 'genesism'); ?></a></li>
		<li><a href="#tabs-5"><?php _e("Header Search", 'genesism'); ?></a></li>
		
		<li><a href="#tabs-6"><?php _e("Top Optin Section", 'genesism'); ?></a></li>
				
		<li><a href="#tabs-7"><?php _e("Blog Read More Section", 'genesism'); ?></a></li>
		<li><a href="#tabs-8"><?php _e("Home Post Social Share Box", 'genesism'); ?></a></li>
			
		<li><a href="#tabs-9"><?php _e("Single Page Social Share", 'genesism'); ?></a></li>
			
		<li><a href="#tabs-10"><?php _e("Single Post Advertisement", 'genesism'); ?></a></li>
		
		<li><a href="#tabs-11"><?php _e("Landing Content Optin Box", 'genesism'); ?></a></li>
		<li><a href="#tabs-12"><?php _e("Landing Feature Box", 'genesism'); ?></a></li>
		
		<li><a href="#tabs-13"><?php _e("Footer Social Follow", 'genesism'); ?></a></li>
		<li><a href="#tabs-14"><?php _e("Footer Text section", 'genesism'); ?></a></li>
		
		<li><a href="#tabs-15"><?php _e("Custom CSS", 'genesism'); ?></a></li>
	
		
	</ul>
	
	
	<div id="tabs-1">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[top_menu]" id="<?php echo MINSGENS_SETTINGS_FIELD; ?>[top_menu]" value="1" <?php checked(1, genesism_get_option('top_menu')); ?> />
				<label for="<?php echo MINSGENS_SETTINGS_FIELD; ?>[top_menu]">
				<?php _e("Enable Top Header Menu", 'genesism'); ?>
				</label>
			</li>			
		</ul>
	</div>
	
	
	<div id="tabs-2">
		<ul>
			
			
			
			
			<li class="second_list">
				<label>Paste your RSS URL Link</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[rss_text2]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('rss_text2') ); ?></textarea> 
			</li>
			
			
			<li class="second_list">
				<label>Paste your Facebook URL Link</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[facebook_text2]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('facebook_text2') ); ?></textarea> 
			</li>
			
			
			<li class="second_list"><label>Paste your Twitter URL Link</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[twitter_text2]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('twitter_text2') ); ?></textarea> 
			</li>
			
			
			<li class="second_list"><label>Paste your Googleplus URL Link</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[googleplus_text2]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('googleplus_text2') ); ?></textarea> 
			</li>
			
			
			<li class="second_list"><label>Paste your Pinterest URL Link</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[pinterest_text2]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('pinterest_text2') ); ?></textarea>
			</li>
			
			
			
			<li class="second_list"><label>Paste your Instagram URL Link</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[instagram_text2]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('instagram_text2') ); ?></textarea>
			</li>
			
			
			
			<li class="second_list"><label>Paste your Youtube URL Link</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[youtube_text2]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('youtube_text2') ); ?></textarea>
			</li>
			
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[header_social]" id="<?php echo MINSGENS_SETTINGS_FIELD; ?>[header_social]" value="1" <?php checked(1, genesism_get_option('header_social')); ?> />
				<label for="<?php echo MINSGENS_SETTINGS_FIELD; ?>[header_social]">
				<?php _e("Disable Header Social Follow Icon", 'genesism'); ?>
				</label>
			</li>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[rsscheck2]" id="<?php echo MINSGENS_SETTINGS_FIELD; ?>[rsscheck2]" value="1" <?php checked(1, genesism_get_option('rsscheck2')); ?> />
				<label for="<?php echo MINSGENS_SETTINGS_FIELD; ?>[rsscheck2]">
				<?php _e("Disable Rss icon", 'genesism'); ?>
				</label>
			</li>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[fbcheck2]" id="<?php echo MINSGENS_SETTINGS_FIELD; ?>[fbcheck2]" value="1" <?php checked(1, genesism_get_option('fbcheck2')); ?> />
				<label for="<?php echo MINSGENS_SETTINGS_FIELD; ?>[fbcheck2]">
				<?php _e("Disable Facebook icon", 'genesism'); ?>
				</label>
			</li>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[twittercheck2]" id="<?php echo MINSGENS_SETTINGS_FIELD; ?>[twittercheck2]" value="1" <?php checked(1, genesism_get_option('twittercheck2')); ?> />
				<label for="<?php echo MINSGENS_SETTINGS_FIELD; ?>[twittercheck2]">
				<?php _e("Disable Twitter icon", 'genesism'); ?>
				</label>
			</li>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[googlepluscheck2]" id="<?php echo MINSGENS_SETTINGS_FIELD; ?>[googlepluscheck2]" value="1" <?php checked(1, genesism_get_option('googlepluscheck2')); ?> />
				<label for="<?php echo MINSGENS_SETTINGS_FIELD; ?>[googlepluscheck2]">
				<?php _e("Disable Googleplus icon", 'genesism'); ?>
				</label>
			</li>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[pinterestcheck2]" id="<?php echo MINSGENS_SETTINGS_FIELD; ?>[pinterestcheck2]" value="1" <?php checked(1, genesism_get_option('pinterestcheck2')); ?> />
				<label for="<?php echo MINSGENS_SETTINGS_FIELD; ?>[pinterestcheck2]">
				<?php _e("Disable Pinterest icon", 'genesism'); ?>
				</label>
			</li>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[instagramcheck2]" id="<?php echo MINSGENS_SETTINGS_FIELD; ?>[instagramcheck2]" value="1" <?php checked(1, genesism_get_option('instagramcheck2')); ?> />
				<label for="<?php echo MINSGENS_SETTINGS_FIELD; ?>[instagramcheck2]">
				<?php _e("Disable Instagram icon", 'genesism'); ?>
				</label>
			</li>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[youtubecheck2]" id="<?php echo MINSGENS_SETTINGS_FIELD; ?>[youtubecheck2]" value="1" <?php checked(1, genesism_get_option('youtubecheck2')); ?> />
				<label for="<?php echo MINSGENS_SETTINGS_FIELD; ?>[youtubecheck2]">
				<?php _e("Disable Youtube icon", 'genesism'); ?>
				</label>
			</li>
			
		</ul>
	</div>
	
	
	
	<div id="tabs-3">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[center_header]" id="<?php echo MINSGENS_SETTINGS_FIELD; ?>[center_header]" value="1" <?php checked(1, genesism_get_option('center_header')); ?> />
				<label for="<?php echo MINSGENS_SETTINGS_FIELD; ?>[center_header]">
				<?php _e("Enable Header Logo Section", 'genesism'); ?>
				</label>
			</li>
			<li class="second_list">
				<label>Enter the Header Logo Image Url Link here</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[center_header_logo_img]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('center_header_logo_img') ); ?></textarea>
			</li>
			
			
		</ul>
	</div>
	
		
	<div id="tabs-4">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[btm_menu]" id="<?php echo MINSGENS_SETTINGS_FIELD; ?>[btm_menu]" value="1" <?php checked(1, genesism_get_option('btm_menu')); ?> />
				<label for="<?php echo MINSGENS_SETTINGS_FIELD; ?>[btm_menu]">
				<?php _e("Enable Bottom Header Menu Section", 'genesism'); ?>
				</label>
			</li>
		</ul>
	</div>
	
	<div id="tabs-5">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[btm_header_search]" id="<?php echo MINSGENS_SETTINGS_FIELD; ?>[btm_header_search]" value="1" <?php checked(1, genesism_get_option('btm_header_search')); ?> />
				<label for="<?php echo MINSGENS_SETTINGS_FIELD; ?>[btm_header_search]">
				<?php _e("Enable Bottom Header Search Box", 'genesism'); ?>
				</label>
			</li>
			<li class="second_list">
				<label>Enter the Search Placeholder text here</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[search_text]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('search_text') ); ?></textarea>
			</li>
			
		</ul>
	</div>
	
	
	<div id="tabs-6">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[top_optin]" id="<?php echo MINSGENS_SETTINGS_FIELD; ?>[top_optin]" value="1" <?php checked(1, genesism_get_option('top_optin')); ?> />
				<label for="<?php echo MINSGENS_SETTINGS_FIELD; ?>[top_optin]">
				<?php _e("Enable Top Optin Section", 'genesism'); ?>
				</label>
			</li>
			
			<li class="second_list">
				<label>Paste your Optin Code and Press Tab Button</label>
				<textarea id="optin_code4" name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[optin_code4]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_code4') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form name</label>
				<textarea id="optin_name4" name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[optin_name4]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('optin_name4') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form Email</label>
				<textarea id="optin_email4" name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[optin_email4]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('optin_email4') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form action url</label>
				<textarea id="optin_url4" name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[optin_url4]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_url4') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Hidden fields</label>
				<textarea id="optin_hidden4" name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[optin_hidden4]" rows="10" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_hidden4') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Enter your Name Place holder text here</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[name_text4]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('name_text4') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Enter your Email Place holder text here</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[email_text4]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('email_text4') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Change your Subscribe me button text</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[submit_text4]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('submit_text4') ); ?></textarea>
			</li>
						
			<li class="second_list">
				<label>Change the Top Optin Title Text here</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[hdr_optin_title]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('hdr_optin_title') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Change the Top Optin Header Para here</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[hdr_optin_para]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('hdr_optin_para') ); ?></textarea>
			</li>
					
			<li class="second_list">
				<label>Change the Optin Background Image url link here</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[top_optin_bg]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('top_optin_bg') ); ?></textarea>
			</li>	
				
			

<script type="text/javascript">
var $j = jQuery.noConflict();
$j(document).ready(function(){
$j("#optin_code4").blur(function(){
var txt=$j(this).val();
if(txt=="")
{
$j("#optin_url4").val("");
$j("#optin_hidden4").val("");
$j("#optin_name4").val("");
$j("#optin_email4").val("");
return false;
}
var pos1=0;
var pos2=0;
var i=1;
var hidden="";
while(1)
{
pos1=txt.indexOf("<input",pos1);
if(pos1<0) break;
pos2=txt.indexOf(">",pos1+1);
var text=txt.substr(pos1,pos2-pos1);
pp=text.indexOf('type="hidden"');
pp1=text.indexOf('type="submit"');
if(pp>0)
{
hidden+=text+">";
}
if(pp<0 && pp1<0){
pp=text.indexOf('name="');
pp=pp+6;
pp1=text.indexOf('"',pp+1);
var tt=text.substr(pp,pp1-pp);
if(i==1) $j("#optin_name4").val(tt);
else $j("#optin_email4").val(tt);
i++;
}
pos1=pos2+1;
}
pos1=txt.indexOf("<form",0);
pos2=txt.indexOf(">",pos1+1);
text=txt.substr(pos1,pos2-pos1);
pp=text.indexOf('action="');
pp=pp+8;
pp1=text.indexOf('"',pp+1);
var tt=text.substr(pp,pp1-pp);
$j("#optin_url4").val(tt);
$j("#optin_hidden4").val(hidden);
});
});
</script> 
			
			
		</ul>
	</div>
	
	
	
	
	<div id="tabs-7">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[read_more]" id="<?php echo MINSGENS_SETTINGS_FIELD; ?>[read_more]" value="1" <?php checked(1, genesism_get_option('read_more')); ?> />
				<label for="<?php echo MINSGENS_SETTINGS_FIELD; ?>[read_more]">
				<?php _e("Enable Blog Read More Section", 'genesism'); ?>
				</label>
			</li>
			<li class="second_list">
				<label>Enter the Read More Text here</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[read_text]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('read_text') ); ?></textarea>
			</li>
		</ul>
	</div>
	
	
	
	<div id="tabs-8">
		<ul>
		<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[blog_social_share]" id="<?php echo MINSGENS_SETTINGS_FIELD; ?>[blog_social_share]" value="1" <?php checked(1, genesism_get_option('blog_social_share')); ?> />
				<label for="<?php echo MINSGENS_SETTINGS_FIELD; ?>[blog_social_share]">
				<?php _e("Enable Home Post Social Section", 'genesism'); ?>
				</label>
			</li>
			
			
	</div>
	
	
		
	<div id="tabs-9">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[single_social_share]" id="<?php echo MINSGENS_SETTINGS_FIELD; ?>[single_social_share]" value="1" <?php checked(1, genesism_get_option('single_social_share')); ?> />
				<label for="<?php echo MINSGENS_SETTINGS_FIELD; ?>[single_social_share]">
				<?php _e("Enable Single Page Social Share Section", 'genesism'); ?>
				</label>
			</li>
			
			<li class="second_list">
				<label>Change the Single Page Social Share Header Text here</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[single_share_title]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('single_share_title') ); ?></textarea>
			</li>
			
		</ul>
	</div>
	
	
		
	<div id="tabs-10">
		<ul>
			<li class="first_list chkbox">
			  <input type="checkbox" name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[postadcheck]" id="<?php echo MINSGENS_SETTINGS_FIELD; ?>[postadcheck]" value="1" <?php checked(1, genesism_get_option('postadcheck')); ?> />
				<label for="<?php echo MINSGENS_SETTINGS_FIELD; ?>[postadcheck]">
				<?php _e("Enable Single Page Post Advertisement section", 'genesism'); ?>
			  </label>
			</li>
			<li class="second_list">
				<label>Enter the ad position ... left or right...</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[float]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('float') ); ?></textarea> 
			</li>
			<li class="second_list">
				<label>Enter the Post advertisement image url</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[postad]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('postad') ); ?></textarea> 
			 </li>
		</ul>
	</div>
	
	<div id="tabs-11">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[landing_content_optin]" id="<?php echo MINSGENS_SETTINGS_FIELD; ?>[landing_content_optin]" value="1" <?php checked(1, genesism_get_option('landing_content_optin')); ?> />
				<label for="<?php echo MINSGENS_SETTINGS_FIELD; ?>[landing_content_optin]">
				<?php _e("Enable Landing Page Optin Section", 'genesism'); ?>
				</label>
			</li>
			
			<li class="second_list">
				<label>Paste your Optin Code and Press Tab Button</label>
				<textarea id="optin_code1" name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[optin_code1]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_code1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form name</label>
				<textarea id="optin_name1" name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[optin_name1]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('optin_name1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form Email</label>
				<textarea id="optin_email1" name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[optin_email1]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('optin_email1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form action url</label>
				<textarea id="optin_url1" name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[optin_url1]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_url1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Hidden fields</label>
				<textarea id="optin_hidden1" name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[optin_hidden1]" rows="10" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_hidden1') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Enter your Name Place holder text here</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[name_text1]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('name_text1') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Enter your Email Place holder text here</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[email_text1]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('email_text1') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Change your Subscribe me button text</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[submit_text1]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('submit_text1') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Enter the Optin Header Text here</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[land_optin_title]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('land_optin_title') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Enter the Optin Para Text here</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[land_optin_para]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('land_optin_para') ); ?></textarea>
			</li>
			
			
			<li class="second_list">
				<label>Change the Landing Page Optin Left Header here</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[top_left_title]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('top_left_title') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Change the Landing Page Optin Left Para here</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[top_left_para]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('top_left_para') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Change the Landing Page Left Read More Text here</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[top_read_txt]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('top_read_txt') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Change the Landing Page Optin Left Read More url link here</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[top_read_link]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('top_read_link') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Change the Landing Page Optin Background Image url link here</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[land_optin_bg]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('land_optin_bg') ); ?></textarea>
			</li>	
				
			

<script type="text/javascript">
var $j = jQuery.noConflict();
$j(document).ready(function(){
$j("#optin_code1").blur(function(){
var txt=$j(this).val();
if(txt=="")
{
$j("#optin_url1").val("");
$j("#optin_hidden1").val("");
$j("#optin_name1").val("");
$j("#optin_email1").val("");
return false;
}
var pos1=0;
var pos2=0;
var i=1;
var hidden="";
while(1)
{
pos1=txt.indexOf("<input",pos1);
if(pos1<0) break;
pos2=txt.indexOf(">",pos1+1);
var text=txt.substr(pos1,pos2-pos1);
pp=text.indexOf('type="hidden"');
pp1=text.indexOf('type="submit"');
if(pp>0)
{
hidden+=text+">";
}
if(pp<0 && pp1<0){
pp=text.indexOf('name="');
pp=pp+6;
pp1=text.indexOf('"',pp+1);
var tt=text.substr(pp,pp1-pp);
if(i==1) $j("#optin_name1").val(tt);
else $j("#optin_email1").val(tt);
i++;
}
pos1=pos2+1;
}
pos1=txt.indexOf("<form",0);
pos2=txt.indexOf(">",pos1+1);
text=txt.substr(pos1,pos2-pos1);
pp=text.indexOf('action="');
pp=pp+8;
pp1=text.indexOf('"',pp+1);
var tt=text.substr(pp,pp1-pp);
$j("#optin_url1").val(tt);
$j("#optin_hidden1").val(hidden);
});
});
</script> 
			
			
		</ul>
	</div>
	
	<div id="tabs-12">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[landing_feature]" id="<?php echo MINSGENS_SETTINGS_FIELD; ?>[landing_feature]" value="1" <?php checked(1, genesism_get_option('landing_feature')); ?> />
				<label for="<?php echo MINSGENS_SETTINGS_FIELD; ?>[landing_feature]">
				<?php _e("Enable Landing Feature Section", 'genesism'); ?>
				</label>
			</li>
			
			<li class="second_list">
				<label>Change the Landing Feature Header Text here</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[landing_feature_title]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('landing_feature_title') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Feature Content Text here</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[landing_feature_para]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_para') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Change the Landing Feature One Image URL Link here</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[land_ftr1_img]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('land_ftr1_img') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Change the Landing Feature One Title Text here</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[ftr1_title]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('ftr1_title') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Feature One View more Link here</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[ftr1_link]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('ftr1_link') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Feature One Para Text here</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[feature1_para]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('feature1_para') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Change the Landing Features One Read More Text here</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[viewmore_txt1]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('viewmore_txt1') ); ?></textarea>
			</li>
			
			
			<li class="second_list">
				<label>Change the Landing Feature Two Image URL Link here</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[land_ftr2_img]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('land_ftr2_img') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Change the Landing Feature Two Title Text here</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[ftr2_title]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('ftr2_title') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Feature Two View more Link here</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[ftr2_link]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('ftr2_link') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Feature Two Para Text here</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[feature2_para]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('feature2_para') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Change the Landing Features Two Read More Text here</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[viewmore_txt2]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('viewmore_txt2') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Change the Landing Feature Three Image URL Link here</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[land_ftr3_img]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('land_ftr3_img') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Change the Landing Feature Three Title Text here</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[ftr3_title]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('ftr3_title') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Feature Three View more Link here</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[ftr3_link]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('ftr3_link') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Feature Three Para Text here</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[feature3_para]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('feature3_para') ); ?></textarea>
			</li>
						
			<li class="second_list">
				<label>Change the Landing Features Three Read More Text here</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[viewmore_txt3]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('viewmore_txt3') ); ?></textarea>
			</li>
			
		</ul>
	</div>
	
	
	<div id="tabs-13">	   
		<ul>
			
			
			<li class="second_list">
				<label>Paste your Facebook URL Link</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[facebook_text1]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('facebook_text1') ); ?></textarea> 
			</li>
			
			
			
			<li class="second_list"><label>Paste your Twitter URL Link</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[twitter_text1]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('twitter_text1') ); ?></textarea> 
			</li>
			
			
			
			<li class="second_list"><label>Paste your Googleplus URL Link</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[googleplus_text1]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('googleplus_text1') ); ?></textarea> 
			</li>
			
			
									
			<li class="second_list"><label>Paste your Instagram URL Link</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[instagram_text1]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('instagram_text1') ); ?></textarea>
			</li>
			
			
			
			<li class="second_list"><label>Paste your Youtube URL Link</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[youtube_text1]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('youtube_text1') ); ?></textarea>
			</li>
			
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[footer_social_follow_box]" id="<?php echo MINSGENS_SETTINGS_FIELD; ?>[footer_social_follow_box]" value="1" <?php checked(1, genesism_get_option('footer_social_follow_box')); ?> />
				<label for="<?php echo MINSGENS_SETTINGS_FIELD; ?>[footer_social_follow_box]">
				<?php _e("Disable Footer Social Follow Icons", 'genesism'); ?>
				</label>
			</li>
			
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[fbcheck1]" id="<?php echo MINSGENS_SETTINGS_FIELD; ?>[fbcheck1]" value="1" <?php checked(1, genesism_get_option('fbcheck1')); ?> />
				<label for="<?php echo MINSGENS_SETTINGS_FIELD; ?>[fbcheck1]">
				<?php _e("Disable Facebook icon", 'genesism'); ?>
				</label>
			</li>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[twittercheck1]" id="<?php echo MINSGENS_SETTINGS_FIELD; ?>[twittercheck1]" value="1" <?php checked(1, genesism_get_option('twittercheck1')); ?> />
				<label for="<?php echo MINSGENS_SETTINGS_FIELD; ?>[twittercheck1]">
				<?php _e("Disable Twitter icon", 'genesism'); ?>
				</label>
			</li>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[googlepluscheck1]" id="<?php echo MINSGENS_SETTINGS_FIELD; ?>[googlepluscheck1]" value="1" <?php checked(1, genesism_get_option('googlepluscheck1')); ?> />
				<label for="<?php echo MINSGENS_SETTINGS_FIELD; ?>[googlepluscheck1]">
				<?php _e("Disable Googleplus icon", 'genesism'); ?>
				</label>
			</li>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[instagramcheck1]" id="<?php echo MINSGENS_SETTINGS_FIELD; ?>[instagramcheck1]" value="1" <?php checked(1, genesism_get_option('instagramcheck1')); ?> />
				<label for="<?php echo MINSGENS_SETTINGS_FIELD; ?>[instagramcheck1]">
				<?php _e("Disable Instagram icon", 'genesism'); ?>
				</label>
			</li>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[youtubecheck1]" id="<?php echo MINSGENS_SETTINGS_FIELD; ?>[youtubecheck1]" value="1" <?php checked(1, genesism_get_option('youtubecheck1')); ?> />
				<label for="<?php echo MINSGENS_SETTINGS_FIELD; ?>[youtubecheck1]">
				<?php _e("Disable Youtube icon", 'genesism'); ?>
				</label>
			</li>
			
		</ul>
	</div>	
	
	<div id="tabs-14">	   
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[footer1]" id="<?php echo MINSGENS_SETTINGS_FIELD; ?>[footer1]" value="1" <?php checked(1, genesism_get_option('footer1')); ?> />
				<label for="<?php echo MINSGENS_SETTINGS_FIELD; ?>[footer1]">
				<?php _e("Enable Footer text", 'genesism'); ?>
				</label>
			</li>
			<li class="second_list"><label>Use custom footer text?</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[footer_text]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('footer_text') ); ?></textarea> 
			</li>
		</ul>
	</div>	
	
	
	
	<div id="tabs-15">
		<ul>
		<li class="second_list">
				<label>Enter the Custom CSS here</label>
				<textarea name="<?php echo MINSGENS_SETTINGS_FIELD; ?>[custom_css]" rows="25" cols="70"><?php echo htmlspecialchars( genesism_get_option('custom_css') ); ?></textarea>
		</li>			
		</ul>
	</div>

		
	
		
</div>  
  
<?php
}
 
 

	