<?php
/**
 * This file adds the blog page to the theme
 *
 * @package      bloom
 * @license      GPL-2.0+
 */

/*
Template Name: Blog
*/



genesis();