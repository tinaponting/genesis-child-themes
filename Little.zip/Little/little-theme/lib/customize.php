<?php
/**
 * Customizer Additions
 *
 * @package      little
 * @author       Minimadesign
 * @license      GPL-2.0+
 */
 
/**
 * Get default primary color for Customizer.
 *
 * Abstracted here since at least two functions use it.
 *
 * @since 1.0.0
 *
 * @return string Hex color code for primary color.
 */

function little_customizer_get_default_primary_color() {
    return '#f9f3f1';
}

function little_customizer_get_default_accent_color() {
    return '#242424';
}

function little_customizer_get_default_highlight_color() {
    return '#212420';
}

function little_customizer_get_default_fix_color() {
    return '#242424';
}



add_action( 'customize_register', 'little_customizer_register' );
/**
 * Register settings and controls with the Customizer.
 *
 * @since 1.0.0
 * 
 * @param WP_Customize_Manager $wp_customize Customizer object.
 */
function little_customizer_register() {

    global $wp_customize;



    
    $wp_customize->add_setting(
        'little_primary_color',
        array(
            'default' => little_customizer_get_default_primary_color(),
        )
    );

    $wp_customize->add_control(
        new WP_Customize_Color_Control(
            $wp_customize,
            'little_primary_color',
            array(
                'description' => __( 'Change the background color of navigation bar and buttons.', 'little' ),
                'label'    => __( 'Primary Color', 'little' ),
                'section'  => 'colors',
                'settings' => 'little_primary_color',
            )
        )
    );
    




    $wp_customize->add_setting(
        'little_accent_color',
        array(
            'default' => little_customizer_get_default_accent_color(),
        )
    );

    $wp_customize->add_control(
        new WP_Customize_Color_Control(
            $wp_customize,
            'little_accent_color',
            array(
                'description' => __( 'Change the border color of buttons.', 'little' ),
                'label'    => __( 'Border Color', 'little' ),
                'section'  => 'colors',
                'settings' => 'little_accent_color',
            )
        )
    );



    $wp_customize->add_setting(
        'little_highlight_color',
        array(
            'default' => little_customizer_get_default_highlight_color(),
        )
    );

    $wp_customize->add_control(
        new WP_Customize_Color_Control(
            $wp_customize,
            'little_highlight_color',
            array(
                'description' => __( 'Change the color of links in your posts.', 'little' ),
                'label'    => __( 'Link Color', 'little' ),
                'section'  => 'colors',
                'settings' => 'little_highlight_color',
            )
        )
    );



    $wp_customize->add_setting(
        'little_fix_color',
        array(
            'default' => little_customizer_get_default_fix_color(),
        )
    );

    $wp_customize->add_control(
        new WP_Customize_Color_Control(
            $wp_customize,
            'little_fix_color',
            array(
                'description' => __( 'If your Primary Color is a dark color, change this value to #FFFFFF.', 'little' ),
                'label'    => __( 'Black Text Swap', 'little' ),
                'section'  => 'colors',
                'settings' => 'little_fix_color',
            )
        )
    );



}




add_action( 'wp_enqueue_scripts', 'little_css' );
/**
* Checks the settings for the accent color, highlight color, and header
* If any of these value are set the appropriate CSS is output
*
* @since 1.0.0
*/
function little_css() {

    $handle  = defined( 'CHILD_THEME_NAME' ) && CHILD_THEME_NAME ? sanitize_title_with_dashes( CHILD_THEME_NAME ) : 'child-theme';

    $color = get_theme_mod( 'little_primary_color', little_customizer_get_default_primary_color() );
    $color_accent = get_theme_mod( 'little_accent_color', little_customizer_get_default_accent_color() );
    $color_highlight = get_theme_mod( 'little_highlight_color', little_customizer_get_default_highlight_color() );
    $color_fix = get_theme_mod( 'little_fix_color', little_customizer_get_default_fix_color() );

    $css = '';

        
    $css .= ( little_customizer_get_default_primary_color() !== $color ) ? sprintf( '
        
.nav-primary,
button:hover,
input:hover[type="button"],
input:hover[type="reset"],
input:hover[type="submit"],
.button.clear:hover,
.button:hover,
.widget .button:hover,
.widget .button.clear:hover,
.footer-widgets button:hover,
.footer-widgets input:hover[type="button"],
.footer-widgets input:hover[type="reset"],
.footer-widgets input:hover[type="submit"],
.footer-widgets .widget .button:hover,
.sidebar .widget-title,
.after-entry .enews-widget,
.sidebar .enews-widget input[type="submit"],
.nf-form-layout,
.pagination-next a:hover, .pagination-previous a:hover,
.archive-pagination li a:hover,
.comment-reply,
.creds,
.category-page .more-from-category a,
a.more-link:hover,
.above-header .enews-widget input[type="submit"],
.below-header .enews-widget input[type="submit"],
button.menu-toggle {
        background-color: %1$s !important;
}

button:hover,
input:hover[type="button"],
input:hover[type="reset"],
input:hover[type="submit"],
.button.clear:hover,
.button:hover,
.widget .button:hover,
.widget .button.clear:hover,
.footer-widgets button:hover,
.footer-widgets input:hover[type="button"],
.footer-widgets input:hover[type="reset"],
.footer-widgets input:hover[type="submit"],
.footer-widgets .widget .button:hover,
.pagination-next a:hover, .pagination-previous a:hover,
.archive-pagination li a:hover,
.category-page .more-from-category a,
a.more-link:hover {
    border-color: %1$s !important;
}
        
        ', $color ) : '';




    $css .= ( little_customizer_get_default_accent_color() !== $color_accent ) ? sprintf( '

input:focus,
textarea:focus,
button,
input[type="button"],
input[type="reset"],
input[type="submit"],
.button,
.widget .button,
.nf-form-content input[type=button],
.nf-form-content input[type=button]:hover,
.pagination-next a, .pagination-previous a,
.category-page .more-from-category a:hover,
a.more-link { 
    border-color: %1$s !important;
}
        
        ', $color_accent ) : '';


        
    $css .= ( little_customizer_get_default_accent_color() !== $color_highlight ) ? sprintf( '

.entry-title a:hover,
a:hover,
.entry-footer .entry-meta a:hover,
.genesis-nav-menu .sub-menu a:hover,
.entry-content a,
.social i:hover,
.creds a:hover,
.footer-widgets a:hover,
.genesis-nav-menu a:hover {
    color: %1$s !important;
}

a.more-link, .archive-pagination li a:hover { color: #242424 !important; }
        
        ', $color_highlight ) : '';



    $css .= ( little_customizer_get_default_fix_color() !== $color_fix ) ? sprintf( '

.nav-primary a,
button,
input[type="button"],
input[type="reset"],
input[type="submit"],
.button,
.widget .button,
.sidebar .enews-widget input[type="submit"]:hover,
.nf-form-content input[type=button]:hover,
.nav-primary a,
.creds,
.creds a,
.footer-widgets a,
.footer-widgets .widget-title,
.footer-logo,
.category-page .more-from-category a,
a.more-link:hover,
button.menu-toggle,
.archive-pagination li a:hover,
.sidebar .widget-title,
.nf-field-label {
        color: %1$s !important;
}
        
        ', $color_fix ) : '';


        
        if (
little_customizer_get_default_primary_color() !== $color ||

little_customizer_get_default_accent_color() !== $color_accent ||

little_customizer_get_default_highlight_color() !== $color_highlight ||

little_customizer_get_default_fix_color() !== $color_fix

 )  
 {

        $css .= '
        }
        ';
    }

    if( $css ){
        wp_add_inline_style( $handle, $css );
    }

}