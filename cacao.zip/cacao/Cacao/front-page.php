<?php
/**
 * This file adds the Home Page to the Cacao Child Theme.
 *
 * @author Candiesnpixels
 * @package Cacao
 * @subpackage Customizations
 */

add_action( 'genesis_meta', 'cacao_home_genesis_meta' );
/**
 * Add widget support for homepage. If no widgets active, display the default loop.
 *
 */
function cacao_home_genesis_meta() {

	if ( is_active_sidebar( 'home-section-1' ) || is_active_sidebar( 'home-section-2' ) || is_active_sidebar( 'home-section-3' ) || is_active_sidebar( 'home-section-4' )) {

		//* Force full width content layout
		add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );

		// Add cacao-home body class
		add_filter( 'body_class', 'cacao_body_class' );

		// Remove the default Genesis loop
		remove_action( 'genesis_loop', 'genesis_do_loop' );

		// Add homepage widgets
		add_action( 'genesis_loop', 'cacao_homepage_widgets' );
		
		// Add Enews Before Footer Widget 
		add_action ('widgets_init','genesischild_footerwidgetheader');
		
		//* Add featured-section body class
		if ( is_active_sidebar( 'home-section-1' ) ) {
		
		//* Add image-section-start body class
			add_filter( 'body_class', 'cacao_featured_body_class' );
			function cacao_featured_body_class( $classes ) {

				$classes[] = 'featured-section';				
				return $classes;
				
			}
			
	    }		

	}
}

function cacao_body_class( $classes ) {

	$classes[] = 'cacao-home';
	return $classes;
	
}

function cacao_homepage_widgets() {
	
	genesis_widget_area( 'home-section-1', array(
		'before' => '<div class="home-odd home-section-1 widget-area"><div class="wrap">',
		'after'  => '</div></div>',
	) );

	genesis_widget_area( 'home-section-2', array(
		'before' => '<div class="home-even home-section-2 widget-area"><div class="wrap">',
		'after'  => '</div></div>',
	) );

	genesis_widget_area( 'home-section-3', array(
		'before' => '<div class="home-odd home-section-3 widget-area"><div class="wrap">',
		'after'  => '</div></div>',
	) );

	genesis_widget_area( 'home-section-4', array(
		'before' => '<div class="home-even home-section-4 widget-area"><div class="wrap">',
		'after'  => '</div></div>',
	) );
	
	

}



genesis();
