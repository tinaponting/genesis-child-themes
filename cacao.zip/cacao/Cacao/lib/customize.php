<?php

/**
 * Customizer additions.
 * @package cacao   
 * @license GPL2-0+
 */

/**
 * Get default accent color for Customizer.
 *
 * Abstracted here since at least two functions use it.
 *
 * @since 1.0.0
 *
 * @return string Hex color code for accent color.
 */
function cacao_customizer_get_default_accent_color() {
	return '#2f2f2f';
}

add_action( 'customize_register', 'cacao_customizer_register' );
/**
 * Register settings and controls with the Customizer.
 *
 * @since 4.1
 * 
 * @param WP_Customize_Manager $wp_customize Customizer object.
 */
function cacao_customizer_register() {

	/**
	 * Customize Background Image Control Class
	 *
	 * @package WordPress
	 * @subpackage Customize
	 * @since 3.4.0
	 */
	class Child_cacao_Image_Control extends WP_Customize_Image_Control {

		/**
		 * Constructor.
		 *
		 * If $args['settings'] is not defined, use the $id as the setting ID.
		 *
		 * @since 3.4.0
		 * @uses WP_Customize_Upload_Control::__construct()
		 *
		 * @param WP_Customize_Manager $manager
		 * @param string $id
		 * @param array $args
		 */
		
           function cacao_customizer_setup ($wp_customize) {
			   
           
           $images[] = array(
               'label'      => __( 'Upload a image', 'cacao' ),
               'section'    => 'home-section-1',
               'settings'   => 'your_setting_id',
               'context'    => 'your_setting_context' 
           );
		   
		   
		   
		   
       
  
			if ( $this->setting->default )
				$this->add_tab( 'default',  __( 'Default', 'cacao' ),  array( $this, 'tab_default_background' ) );

			// Early priority to occur before $this->manager->prepare_controls();
			add_action( 'customize_controls_init', array( $this, 'prepare_control' ), 5 );
		}

		/**
		 * @since 3.4.0
		 * @uses WP_Customize_Image_Control::print_tab_image()
		 */
		public function tab_default_background() {
			$this->print_tab_image( $this->setting->default );
		}

	}

	global $wp_customize;

	$images = apply_filters( 'cacao_images', array( '1', '3' ) );

	$wp_customize->add_section( 'cacao-settings', array(
		'description' => __( 'Use the included default images or personalize your site by uploading your own images.<br /><br />The default images are <strong>1349 pixels wide and 654 pixels tall</strong>.', 'cacao' ),
		'title'    => __( 'Home Page Background Images', 'cacao' ),
		'priority' => 35,
	) );
	

	foreach( $images as $image ){

		$wp_customize->add_setting( $image .'-cacao-image', array(
			'default'  => sprintf( '%s/images/bg-%s.jpg', get_stylesheet_directory_uri(), $image ),
			'type'     => 'option',
		) );

		$wp_customize->add_control( new Child_cacao_Image_Control( $wp_customize, $image .'-studio-image', array(
			'label'    => sprintf( __( 'Featured Section %s Image:', 'cacao' ), $image ),
			'section'  => 'cacao-settings',
			'settings' => $image .'-cacao-image',
			'priority' => $image+1,
		) ) );
		
	}
	
	$colors[] = array(
        'slug'      => 'cnp_navsecondary',
        'default'   => '#ede1e5',
        'label'     => 'Nav Background'
    );

   $colors[] = array(
        'slug'      => 'cnp_link',
        'default'   => '#da9c25',
        'label'     => 'Link'
    );
	
	$colors[] = array(
        'slug'      => 'cnp_sitetitlecolor',
        'default'   => '#da9c25',
        'label'     => 'Site Title Color'
    );
	
	$colors[] = array(
        'slug'      => 'cnp_sitedescriptioncolor',
        'default'   => '#d2a8b2',
        'label'     => 'Site Description Color'
    );
	
	$colors[] = array(
        'slug'      => 'cnp_secondarysidebarbackground',
        'default'   => '#dae6e4',
        'label'     => 'Secondary Sidebar Background Color'
    );
	
	$colors[] = array(
        'slug'      => 'cnp_primarysidebarbackground',
        'default'   => '#ede1e5',
        'label'     => 'Primary Sidebar Background Color'
    );
	
	$colors[] = array(
        'slug'      => 'cnp_sidebarcolor',
        'default'   => '#da9c25',
        'label'     => 'Sidebar Text Color'
    );
	
    
    $colors[] = array(
        'slug'      => 'cnp_footer_text',
        'default'   => '#333333',
        'label'     => 'Footer Text'
    );
	
	$colors[] = array(
        'slug'      => 'cnp_footerwidgets',
        'default'   => '#da9c25',
        'label'     => 'Footer Widgets Background'
    );
	
	$colors[] = array(
        'slug'      => 'cnp_footerwidgetscolor',
        'default'   => '#dae6e4',
        'label'     => 'Footer Widgets Color'
    );
	 
	$colors[] = array(
        'slug'      => 'cnp_button',
        'default'   => '#dae6e4',
        'label'     => 'Button Background'
    );
	
	$colors[] = array(
        'slug'      => 'cnp_homesectionbutton',
        'default'   => '#eecf65',
        'label'     => 'Home Section Button Color'
    );
	
	$colors[] = array(
        'slug'      => 'cnp_homesectionbackground',
        'default'   => '#d2a8b2',
        'label'     => 'Home Section 2 Background Color'
    );
	
	$colors[] = array(
        'slug'      => 'cnp_enewsbutton',
        'default'   => '#dae6e4',
        'label'     => 'Enews Button Background'
    );
	
	$colors[] = array(
        'slug'      => 'cnp_enewsbackground',
        'default'   => '#eecf65',
        'label'     => 'Enews Background'
    );
	
	$colors[] = array(
        'slug'      => 'cnp_enewstitle',
        'default'   => '#777777',
        'label'     => 'Enews Widget Title'
    );
	
	$colors[] = array(
        'slug'      => 'cnp_instagrambackground',
        'default'   => '#dae6e4',
        'label'     => 'Instagram Widget Background Color'
    );
	

    foreach( $colors as $color ) {

        // SETTINGS
        $wp_customize->add_setting(
            $color['slug'], array(
                'default' => $color['default'],
                'sanitize_callback' => 'sanitize_hex_color',
            )
        );

        // CONTROLS
        $wp_customize->add_control(
            new WP_Customize_Color_Control(
                $wp_customize,
                $color['slug'],
                array(
                    'label' => $color['label'],
                    'section' => 'colors',
                    'settings' => $color['slug']
                )
            )
        );
    }

}



function cnp_customizer_css() {


    $link = get_theme_mod('cnp_link');
    $sitetitlecolor = get_theme_mod('cnp_sitetitlecolor');
    $sitedescriptioncolor = get_theme_mod('cnp_sitedescriptioncolor');
	$navsecondary = get_theme_mod('cnp_navsecondary');
    $footerText = get_theme_mod('cnp_footer_text');
	$footerwidgets = get_theme_mod ('cnp_footerwidgets');
	$footerwidgetscolor = get_theme_mod ('cnp_footerwidgetscolor');
	$button = get_theme_mod('cnp_button');
	$enewsbutton = get_theme_mod('cnp_enewsbutton');
	$enewsbackground = get_theme_mod('cnp_enewsbackground');
	$enewstitle = get_theme_mod ('cnp_enewstitle');
	$instagrambackground = get_theme_mod ('cnp_instagrambackground');
	$secondarysidebarbackground = get_theme_mod ('cnp_secondarysidebarbackground');
	$primarysidebarbackground = get_theme_mod ('cnp_primarysidebarbackground');
	$sidebarcolor = get_theme_mod ('cnp_sidebarcolor');
	$homesectionbutton = get_theme_mod ('cnp_homesectionbutton');
	$homesectionbackground = get_theme_mod ('cnp_homesectionbackground');


?><style type="text/css">

.site-title a {
	color: <?php echo $sitetitlecolor; ?>;
}

.site-description{
	color: <?php echo $sitedescriptioncolor; ?>;
}

.nav-primary {
    background: <?php echo $navsecondary; ?>;  
}

.home-section-1 .button,
.home-section-2 .button,
.home-section-3 .button,
.home-section-4 .button {
	background-color: <?php echo $homesectionbutton; ?>; 
}

.home-section-2 .widget_text .widget-title {
	background-color: <?php echo $homesectionbackground; ?>;
}

button,
		input[type="button"],
		input[type="reset"],
		input[type="submit"] {
			background-color: <?php echo $button; ?>; 
		}
		
.enews-widget input[type="submit"],
.sidebar .enews-widget input[type="submit"] {
			background: <?php echo $enewsbutton; ?>;
		}
		
.enews-widget,
.sidebar .widget.enews-widget {
	background: <?php echo $enewsbackground; ?>;
}		
 
.enews-widget .widget-title	{
	color: <?php echo $enewstitle; ?>;
}

a,
.genesis-nav-menu > li a,
.genesis-nav-menu .current-menu-item > a,
.genesis-nav-menu .sub-menu > li a,
.archive-pagination li a {
    color: <?php echo $link; ?>;
}

a:hover,
.genesis-nav-menu > li a:hover,
.genesis-nav-menu .current-menu-item > a:hover,
.genesis-nav-menu .sub-menu > li a:hover,
.genesis-nav-menu .sub-menu .current-menu-item > a:hover,
.archive-pagination li a:hover {
    color: <?php echo $linkHover; ?>;
}

a:visited {
    color: <?php echo $linkVisited; ?>;
}

.genesis-nav-menu > li a:hover,
.genesis-nav-menu .current-menu-item > a:hover,
.genesis-nav-menu .sub-menu > li a:hover,
.genesis-nav-menu .sub-menu .current-menu-item > a:hover,
.archive-pagination li a:hover {
    color: <?php echo $headerNavHover; ?>;
}

.sidebar-primary {
	background-color: <?php echo $primarysidebarbackground; ?>;
}

.sidebar-secondary {
	background-color: <?php echo $secondarysidebarbackground; ?>;
}

.sidebar .widget {
	color: <?php echo $sidebarcolor; ?>; 
}

.footer-widgets {
	background-color: <?php echo $footerwidgets; ?>;
}

.footer-widgets {
	color: <?php echo $footerwidgetscolor; ?>;
}

.instagram {
	background-color: <?php echo $instagrambackground; ?>;
}

.site-footer {
    color: <?php echo $footerText; ?>;
}

</style>
<?php
}
add_action( 'wp_head', 'cnp_customizer_css' );