<?php
/*
Template Name: SalesPage
*/

add_action( 'genesis_meta', 'cacao_salespage_genesis_meta' );
/**
 * Add widget support for this template. If no widgets are active, display the default Genesis loop.
 *
 */

 
function cacao_salespage_genesis_meta() {

	if ( is_active_sidebar( 'salespage-one' ) || is_active_sidebar( 'salespage-two' ) || is_active_sidebar( 'salespage-three') || is_active_sidebar( 'salespage-four' )) {

		//* Force full width content layout
		add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );

		// Add cacao-home body class
		add_filter( 'body_class', 'cacao_body_class' );

		// Remove the default Genesis loop
		remove_action( 'genesis_loop', 'genesis_do_loop' );

		// Add salespage widgets
		add_action( 'genesis_loop', 'cacao_salespage_widgets' );
		
		//* Remove site header elements
remove_action( 'genesis_header', 'genesis_header_markup_open', 5 );
remove_action( 'genesis_header', 'genesis_do_header' );
remove_action( 'genesis_header', 'genesis_header_markup_close', 15 );

//* Remove primary/secondary navigation menus
remove_theme_support( 'genesis-menus' );

//* Remove navigation
remove_action( 'genesis_header', 'genesis_do_nav', 12 );
remove_action( 'genesis_header', 'genesis_do_subnav', 7);
remove_action ( 'genesis_footer', 'genesis_do_subnav', 7 );

//* Remove breadcrumbs
remove_action( 'genesis_before_loop', 'genesis_do_breadcrumbs' );

remove_action( 'genesis_before_footer', 'sp_instagram_feed_widget' );

//* Remove site footer widgets
remove_action( 'genesis_before_footer', 'genesis_footer_widget_areas' );
remove_action( 'genesis_before_footer', 'instagram_feed_widget' );

//* Remove site footer elements
remove_action( 'genesis_footer', 'genesis_footer_markup_open', 5 );
remove_action( 'genesis_footer', 'genesis_do_footer' );
remove_action( 'genesis_footer', 'genesis_footer_markup_close', 15 );
remove_action('genesis_entry_footer', 'my_after_entry_widget' );
		

	}
}

function cacao_body_class( $classes ) {

	$classes[] = 'cacao-salespage';
	return $classes;
	
}
function cacao_salespage_widgets() {
	
	genesis_widget_area( 'salespage-one', array(
		'before' => '<div class="salespage-one widget-area"><div class="wrap">',
		'after'  => '</div></div>',
	) );

	genesis_widget_area( 'salespage-two', array(
		'before' => '<div class="salespage-two widget-area"><div class="wrap">',
		'after'  => '</div></div>',
	) );

	genesis_widget_area( 'salespage-three', array(
		'before' => '<div class="salespage-three widget-area"><div class="wrap">',
		'after'  => '</div></div>',
	) );
	
	genesis_widget_area( 'salespage-four', array(
		'before' => '<div class="salespage-four widget-area"><div class="wrap">',
		'after'  => '</div></div>',
	) );
	
	genesis_widget_area( 'salespage-five', array(
		'before' => '<div class="salespage-five widget-area"><div class="wrap">',
		'after'  => '</div></div>',
	) );
	
	genesis_widget_area( 'salespage-six', array(
		'before' => '<div class="salespage-six widget-area"><div class="wrap">',
		'after'  => '</div></div>',
	) );
	
}
 
genesis();