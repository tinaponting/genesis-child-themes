jQuery(document).ready(function($) {
	$("body").backstretch([BackStretchImg.src],{duration:3000,fade:750});
});