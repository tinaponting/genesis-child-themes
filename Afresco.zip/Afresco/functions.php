<?php
//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );

//* Child theme (do not remove)
define( 'CHILD_THEME_NAME', 'Alfresco' );

//* Enqueue Lato Google font
add_action( 'wp_enqueue_scripts', 'genesis_sample_google_fonts' );
function genesis_sample_google_fonts() {
	wp_enqueue_style( 'google-font-lato', '//fonts.googleapis.com/css?family=Lato:300,700', array(), CHILD_THEME_VERSION );
        wp_enqueue_style( 'google-font-overlock-sc', '//fonts.googleapis.com/css?family=Overlock+SC:400', array(), CHILD_THEME_VERSION );
}

//* Add HTML5 markup structure
add_theme_support( 'html5' );

//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Add support for custom background
add_theme_support( 'custom-background' );

//* Add support for 3-column footer widgets
add_theme_support( 'genesis-footer-widgets', 3 );

/** Reposition the sub navigation */
remove_action( 'genesis_after_header', 'genesis_do_subnav' );
add_action( 'genesis_before', 'genesis_do_subnav' );

genesis_register_sidebar( array(
    'id'    => 'welcome-text',
    'name'    => __( 'Welcome Text', 'genesis' ),
    'description'    => __( 'Add Custom Text After Header.', 'executive' ),
) );
 
add_action( 'genesis_before_content_sidebar_wrap', 'custom_text', 15 );
function custom_text() {
if ( is_home() && is_active_sidebar('welcome-text')) {
   genesis_widget_area( 'welcome-text', array(
       'before' => '<div class="welcome-text widget-area">',
   ) );
 
    }
}
genesis_register_sidebar( array(
	'id'			=> 'home-top',
	'name'			=> __( 'Home Top', 'alfresco' ),
	'description'	=> __( 'This is the home top section.', 'alfresco' ),
) );
genesis_register_sidebar( array(
	'id'			=> 'home-middle-left',
	'name'			=> __( 'Home Middle Left', 'alfresco' ),
	'description'	=> __( 'This is the home middle left section.', 'alfresco' ),
) );
genesis_register_sidebar( array(
	'id'			=> 'home-middle-right',
	'name'			=> __( 'Home Middle Right', 'alfresco' ),
	'description'	=> __( 'This is the home middle right section.', 'alfresco' ),
) );
genesis_register_sidebar( array(
	'id'			=> 'home-bottom',
	'name'			=> __( 'Home Bottom', 'alfresco' ),
	'description'	=> __( 'This is the home bottom section.', 'alfresco' ),
) );

/** Add new image sizes */
add_image_size('home-top', 700, 250, TRUE);
add_image_size( 'home-middle-left', 300, 150, TRUE );
add_image_size('home-bottom', 150, 150, TRUE);


/** Add support for structural wraps */
add_theme_support( 'genesis-structural-wraps', array( 'header', 'nav', 'subnav', 'inner', 'footer-widgets', 'footer' ) );


genesis_register_sidebar( array(
	'id'          => 'nav-social-menu',
	'name'        => __( 'Nav Social Menu', 'alfresco' ),
	'description' => __( 'This is the nav social menu section.', 'alfresco' ),
) );
 
add_filter( 'genesis_nav_items', 'sws_social_icons', 10, 2 );
add_filter( 'wp_nav_menu_items', 'sws_social_icons', 10, 2 );
 
function sws_social_icons($menu, $args) {
	$args = (array)$args;
	if ( 'primary' !== $args['theme_location'] )
		return $menu;
	ob_start();
	genesis_widget_area('nav-social-menu');
	$social = ob_get_clean();
	return $menu . $social;
}