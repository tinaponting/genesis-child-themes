<?php
/**
 * This file control Romo Theme styles
 *
 * @package     Romo
 * @author      aprakasa
 * @license     GPL-2.0+
 * @link        http://prakasa.me/go/romo
 */

/** Exit if accessed directly */
if ( ! defined( "ABSPATH" ) ) exit;

add_action( 'wp_enqueue_scripts', 'romo_enqueue_styles', 5 );
/**
 * This function control styles registration and style enqueue
 *
 * @since 1.0
 */
function romo_enqueue_styles(){
    $browser        = $_SERVER['HTTP_USER_AGENT'];
    $browser        = substr( "$browser", 25, 8 );
    $lightbox_en    = get_option( 'woocommerce_enable_lightbox' ) == 'yes' ? true : false;
    /** Enqueue Google Webfonts */
    romo_enqueue_google_webfonts();
    /** Romo Style */
    wp_enqueue_style( "romo" );
    /** WooCommerce Styles */
    if ( class_exists( 'WooCommerce' ) ) {
        wp_enqueue_style( 'romo-woocommerce' );
        if ( $lightbox_en && ( is_product() || ( ! empty( $post->post_content ) && strstr( $post->post_content, '[product_page' ) ) ) ) {
            wp_enqueue_style( 'romo-prettyphoto' );
        }
    }
    /** Romo Plugins */
    if (class_exists( 'GFForms' ) ||
        class_exists( 'FluidVideoEmbed' ) ||
        class_exists( 'Genesis_Latest_Tweets' ) ||
        class_exists( 'BJGK_Genesis_eNews_Extended' ) ||
        function_exists( 'wpcf7_enqueue_styles' ) ||
        is_page_template( 'masonry.php' ) ||
        ( is_singular() && has_shortcode( get_post_field( 'post_content', get_the_ID() ), 'slideshow' ) ) )
            wp_enqueue_style( "romo-plugins" );
    /** Portfolio Style */
    if ( is_post_type_archive( 'portfolio_item' ) || is_singular( 'portfolio_item' ) || is_tax( 'portfolio' ) )
        wp_enqueue_style( 'romo-plugins' );
    /** AQPB Style */
    if ( class_exists( 'AQ_Page_Builder' ) ) {
        if ( is_singular() && has_shortcode( get_post_field( 'post_content', get_the_ID() ), 'template' ) )
            wp_enqueue_style( 'romo-aqpb' );
        if ( class_exists( 'Custom_Content_Portfolio' ) && is_singular() && has_shortcode( get_post_field( 'post_content', get_the_ID() ), 'template' ) ) {
            wp_enqueue_style( 'romo-plugins' );
        }
    }
    if ( class_exists( 'bbPress' ) ) {
        wp_enqueue_style( 'romo-bbpress' );
    }
    wp_enqueue_style( 'romo-ie8' );
}

/**
 * This function control google fonts enqueue
 *
 * @since 1.0
 */
function romo_enqueue_google_webfonts(){
    $browser = $_SERVER['HTTP_USER_AGENT'];
    $browser = substr( "$browser", 25, 8 );
    $heading 	= romo_get_option( 'heading_font' );
    $bodyfont 	= romo_get_option( 'body_font' );
    if ( ! empty( $heading ) ) {        
        $gheading = str_replace(" ", "+", $heading );
        $gheading_id = strtolower( str_replace(" ", "-", $heading ) );
        if ( in_array( $heading, romo_get_google_webfonts() ) ) {
            if ( $browser == "MSIE 7.0" || $browser == "MSIE 8.0" ) {
                wp_enqueue_style( "$gheading_id-400", "//fonts.googleapis.com/css?family=$gheading:400", array(), CHILD_THEME_VERSION, "all" );
                wp_enqueue_style( "$gheading_id-400italic", "//fonts.googleapis.com/css?family=$gheading:400italic", array(), CHILD_THEME_VERSION, "all" );
                wp_enqueue_style( "$gheading_id-700", "//fonts.googleapis.com/css?family=$gheading:700", array(), CHILD_THEME_VERSION, "all" );
                wp_enqueue_style( "$gheading_id-700italic", "//fonts.googleapis.com/css?family=$gheading:700italic", array(), CHILD_THEME_VERSION, "all" );
                wp_enqueue_style( "$gheading_id-subset", "//fonts.googleapis.com/css?family=$gheading&subset=latin,latin-ext,greek,greek-ext,cyrillic,cyrillic-ext,vietnamese,khmer", array(), CHILD_THEME_VERSION, "all" );
            } else {
                wp_enqueue_style( "$gheading_id", "//fonts.googleapis.com/css?family=$gheading:400,400italic,700,700italic&subset=latin,latin-ext,greek,greek-ext,cyrillic,cyrillic-ext,vietnamese,khmer", array(), CHILD_THEME_VERSION, "all" );
            }
        }
    }
    if ( ! empty( $bodyfont ) ) {
        if( $heading == $bodyfont )
            return;
        $gbodyfont = str_replace(" ", "+", $bodyfont );
        $gbodyfont_id = strtolower( str_replace(" ", "-", $bodyfont ) );
        if ( in_array( $bodyfont, romo_get_google_webfonts() ) ) {
            if ( $browser == "MSIE 7.0" || $browser == "MSIE 8.0" ) {
                wp_enqueue_style( "$gbodyfont_id-400", "//fonts.googleapis.com/css?family=$gbodyfont:400", array(), CHILD_THEME_VERSION, "all" );
                wp_enqueue_style( "$gbodyfont_id-400italic", "//fonts.googleapis.com/css?family=$gbodyfont:400italic", array(), CHILD_THEME_VERSION, "all" );
                wp_enqueue_style( "$gbodyfont_id-700", "//fonts.googleapis.com/css?family=$gbodyfont:700", array(), CHILD_THEME_VERSION, "all" );
                wp_enqueue_style( "$gbodyfont_id-700italic", "//fonts.googleapis.com/css?family=$gbodyfont:700italic", array(), CHILD_THEME_VERSION, "all" );
                wp_enqueue_style( "$gbodyfont_id-subset", "//fonts.googleapis.com/css?family=$gbodyfont&subset=latin,latin-ext,greek,greek-ext,cyrillic,cyrillic-ext,vietnamese,khmer", array(), CHILD_THEME_VERSION, "all" );
            } else {
                wp_enqueue_style( "$gbodyfont_id", "//fonts.googleapis.com/css?family=$gbodyfont:400,400italic,700,700italic&subset=latin,latin-ext,greek,greek-ext,cyrillic,cyrillic-ext,vietnamese,khmer", array(), CHILD_THEME_VERSION, "all" );
            }
        }
    }
}

/**
 * Callback function for custom-background
 *
 * @since   1.0
 */
function romo_custom_background_cb() {
    if ( function_exists( 'jetpack_photon_url' ) ) {
        $background = jetpack_photon_url( get_background_image() );
    } else {
        $background = get_background_image();
    }
    $color = get_background_color();
    if ( ! $background && ! $color )
        return;
    $style = $color ? "background-color: #$color;" : '';
    if ( $background ) {
        $image = " background-image: url('$background');";
        $repeat = get_theme_mod( 'background_repeat', 'repeat' );
        if ( ! in_array( $repeat, array( 'no-repeat', 'repeat-x', 'repeat-y', 'repeat' ) ) )
            $repeat = 'repeat';
        $repeat = " background-repeat: $repeat;";
        $position = get_theme_mod( 'background_position_x', 'left' );
        if ( ! in_array( $position, array( 'center', 'right', 'left' ) ) )
            $position = 'left';
        $position = " background-position: top $position;";
        $attachment = get_theme_mod( 'background_attachment', 'scroll' );
        if ( ! in_array( $attachment, array( 'fixed', 'scroll' ) ) )
            $attachment = 'scroll';
        $attachment = " background-attachment: $attachment;";
        $style .= $image . $repeat . $position . $attachment;
    }
    return trim( $style );
}


add_action( 'wp_head', 'romo_print_inline_styles', 8 );
/**
 * This function control custom styles
 *
 * @since 1.0
 * @todo cleanup code
 */
function romo_print_inline_styles(){
    $browser = $_SERVER['HTTP_USER_AGENT'];
    $browser = substr( "$browser", 25, 8);

    if ( function_exists( 'jetpack_photon_url' ) ) {
        $logo_img   = jetpack_photon_url( romo_get_option( 'image_logo' ) );
    } else {
        $logo_img   = romo_get_option( 'image_logo' );
    }    
    $logo_width     = romo_get_option( 'image_logo_width' );
    $logo_height    = romo_get_option( 'image_logo_height' );

    $css= '';
    if ( romo_get_option( 'website_style' ) == 'boxed-layout' ) {
       $css .= 'body.custom-background{'. romo_custom_background_cb() .'}';
   }

    if ( ! empty( $logo_img ) ) {
        $css .=
        '.image-logo .site-title a { 
            background-image: url('. esc_url( $logo_img ) .');
            width: '. (int)$logo_width  .'px;
            height: '. (int)$logo_height .'px;
            max-width: 100%;
        }';
    }

    if ( romo_get_option( 'heading_font' ) ) {
        $aqpb_heading_font = ( class_exists( 'AQ_Page_Builder') ) ? ', .aq-block-romo_callout_block .large-text' : '';
        $css .= '
            h1, h2, h3, h4 ,h5, h5, h6,
            .site-title
            '. $aqpb_heading_font .' {
                font-family:"'. romo_get_option( 'heading_font' ) .'", sans-serif;
                font-weight:'. romo_get_option( 'heading_weight' ) .';
            }
        ';
    }

    if ( romo_get_option( 'body_font' ) ) {
        $css .= '
            body,
            .site-description,
            .genesis-nav-menu {
                font-family:"'. romo_get_option( 'body_font' ) .'", sans-serif;
            }
        ';
    }

    if ( romo_get_option( 'heading_one' ) ) {
        $css .=' h1 { font-size: '. (int)romo_get_option( 'heading_one' ) .'px } ';
    }

    if ( romo_get_option( 'heading_two' ) ) {
        $css .=' h2 { font-size: '. (int)romo_get_option( 'heading_two' ) .'px } ';
    }

    if ( romo_get_option( 'heading_three' ) ) {
        $css .=' h3 { font-size: '. (int)romo_get_option( 'heading_three' ) .'px } ';
    }

    if ( romo_get_option( 'heading_four' ) ) {
        $css .=' h4 { font-size: '. (int)romo_get_option( 'heading_four' ) .'px } ';
    }

    if ( romo_get_option( 'heading_five' ) ) {
        $css .=' h5 { font-size: '. (int)romo_get_option( 'heading_five' ) .'px } ';
    }

    if ( romo_get_option( 'heading_six' ) ) {
        $css .=' h6 { font-size: '. (int)romo_get_option( 'heading_six' ) .'px } ';
    }

    if ( romo_get_option( 'body_font_size' ) ) {
        $css .=' body { font-size: '. (int)romo_get_option( 'body_font_size' ) .'px } ';
    }

    if ( romo_get_option( 'widget_size' ) ) {
        $aqpb_widget_size = ( class_exists( 'AQ_Page_Builder') ) ? ', h4.aq-block-title' : '';
        $css .=' h4.widget-title '. $aqpb_widget_size .' { font-size: '. (int)romo_get_option( 'widget_size' ) .'px } ';
    }

    if ( romo_get_option( 'button_color' ) ) {
        $css .= '
            button,
            input[type="button"],
            input[type="reset"],
            input[type="submit"],
            .button,
            .entry-content .button,
            .pagination li a:hover,
            .pagination li.active a,
            .bbp-pagination-links a:hover,
            .bbp-pagination-links .current,
            .widget_tag_cloud a,
            .widget_product_tag_cloud a { background-color: '. romo_get_option( 'button_color' ) .' }

            .pagination li a:hover,
            .pagination li.active a { border-color: '. romo_get_option( 'button_color' ) .' }
        ';
    }

    if ( romo_get_option( 'hyperlink_color' ) ) {
        $css .= '
            a,
            .widget_display_stats dt { color: '. romo_get_option( 'hyperlink_color' ) .' }
            .genesis-nav-menu .menu-item:hover > .sub-menu a:hover,
            .enews-widget input[type="submit"],
            .featuredpage a.more-link,
            a.portfolio-widget-link:before,
            .no-thumbnail:before,
            .portfolio-thumbnail:before,
            .portfolio-filter li a.active,
            .widget_tag_cloud a:hover,
            .widget_product_tag_cloud a:hover { background-color: '. romo_get_option( 'hyperlink_color' ) .' }

            .portfolio-filter li a.active { border-color: '. romo_get_option( 'hyperlink_color' ) .' }
        ';
    }

    if ( romo_get_option( 'hover_color' ) ) {
        $css .= '
            a:hover { color: '. romo_get_option( 'hover_color' ) .' }
            button:hover,
            input:hover[type="button"],
            input:hover[type="reset"],
            input:hover[type="submit"],
            .button:hover,
            .entry-content .button:hover,
            .enews-widget input[type="submit"]:hover,
            .featuredpage a.more-link:hover,
            .portfolio-filter li a:hover,
            .client-prev:hover,
            .client-next:hover  { background-color: '. romo_get_option( 'hover_color' ) .' }

            .portfolio-filter li a:hover,
            .client-prev:hover,
            .client-next:hover { border-color: '. romo_get_option( 'hover_color' ) .' }
        ';
    }

    if ( class_exists( 'Genesis_Widget_Toggle' ) ) {
        $css .= '.site-container{padding-top: 5px}';
    }

    if ( ! empty( $css ) ) {
       echo "<!-- Custom Style -->\n<style type='text/css'>". romo_minify( $css ) ."</style>\n";
    }
}