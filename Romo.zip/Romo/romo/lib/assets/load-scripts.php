<?php
/**
 * This file control Romo Theme Scripts
 *
 * @package     Romo
 * @author      aprakasa
 * @license     GPL-2.0+
 * @link        http://prakasa.me/go/romo
 */

/** Exit if accessed directly */
if ( ! defined( "ABSPATH" ) ) exit;

add_action( 'wp_enqueue_scripts', 'romo_enqueue_scripts', 5 );
/**
 * This function control scripts loader
 *
 * @since 	1.0
 */
function romo_enqueue_scripts(){
	if ( is_post_type_archive( 'portfolio_item' ) || is_tax( 'portfolio' ) )
		wp_enqueue_script( 'jquery-isotope' );
	if ( is_post_type_archive( 'portfolio_item' ) || is_tax( 'portfolio' ) || is_singular( 'portfolio_item' ) )
		wp_enqueue_script( 'jquery-magnific-popup' );
	if ( is_singular() && has_shortcode( get_post_field( 'post_content', get_the_ID() ), 'slideshow' ) || is_page_template( 'homepage.php' ) ) {
		wp_enqueue_script( 'jquery-flexslider' );
		wp_enqueue_script( 'jquery-magnific-popup' );
	}
	if ( is_page_template( 'masonry.php' ) ) {
		wp_enqueue_script( 'jquery-isotope' );
		wp_enqueue_script( 'jquery-infinitescroll' );
	}
	wp_enqueue_script( 'romo' );
	wp_localize_script( "jquery", "Romo_l10n", array(
		"select_page"	=> __( 'Menu', 'romo' ),
		"no_post"		=> __( 'No more posts to load.', 'romo' ),
		'img_loading'	=> ROMO_ASSETS_URI . 'images/loading.gif',
		'post_loading'	=> __( 'Loading next posts ...', 'romo' ),
		'view_map'		=> __( 'View on Google Map', 'romo' ) ) );
}

remove_action( 'wp_head', 'genesis_html5_ie_fix' );
add_action( 'wp_head', 'romo_html5_ie_fix', 9 );
/**
 * Replace genesis_html5_ie_fix() with romo_html5_ie_fix().
 *
 * @since 1.0.0
 */
function romo_html5_ie_fix() {
	if ( ! genesis_html5() )
		return;	
		$output = '<!--[if lt IE 9]><script src="//cdnjs.cloudflare.com/ajax/libs/html5shiv/3.6.2/html5shiv.min.js"></script><![endif]-->' . "\n";
		$output .= '<!--[if lt IE 9]><script src="//cdnjs.cloudflare.com/ajax/libs/respond.js/1.2.0/respond.min.js"></script><![endif]-->' . "\n";
		$output .= '<!--[if lt IE 9]><script src="//cdnjs.cloudflare.com/ajax/libs/selectivizr/1.0.2/selectivizr-min.js"></script><![endif]-->' . "\n";
	echo $output;
}