<?php
/**
 * This file control Romo child theme Scripts and style registration
 * Some assets might not licensed under GPL
 *
 * @package 	Romo
 * @author   	aprakasa
 * @license  	GPL-2.0+
 * @link     	http://prakasa.me/go/romo
 */

/** Exit if accessed directly */
if ( ! defined( "ABSPATH" ) ) exit;

/**
 * Helper function is load library from cdn or not
 *
 * @since 	1.0
 * @return 	bool
 */
function is_scripts_cdn(){
	return (bool) genesis_get_option( "scripts_cdn", ROMO_SETTINGS );
}

add_action( "init", "romo_register_scripts_and_styles", 5 );
/**
 * This function control script and style registration
 *
 * @since 	1.0
 */
function romo_register_scripts_and_styles(){

	global $wp_styles, $wp_scripts;
	
	/** -- Styles registration ----------------------------------------------------------------------- */

    /** Load Fontawesome v3.2.1 */
    wp_register_style( "fontawesome", ( ! is_scripts_cdn() ) ? ROMO_ASSETS_URI . "css/font-awesome.min.css" : "//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.min.css", array(), "3.2.1", "all" );
    wp_register_style( "fontawesome-ie7", ( ! is_scripts_cdn() ) ? ROMO_ASSETS_URI . "css/font-awesome-ie7.min.css" : "//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome-ie7.min.css", array(), "3.2.1", "all" );
	/** Romo Main Styles */
    wp_register_style( "romo", ROMO_URI . "style.css", array( "fontawesome", "fontawesome-ie7" ), CHILD_THEME_VERSION, "all" );
    /** Custom plugins style */
    wp_register_style( "romo-plugins", ROMO_ASSETS_URI . "css/plugins.css", array( "romo" ), CHILD_THEME_VERSION, "all" );
    wp_register_style( "romo-aqpb", ROMO_ASSETS_URI . "css/aqpb.css", array( "romo", "romo-plugins" ), CHILD_THEME_VERSION, "all" );
    wp_register_style( "romo-bbpress", ROMO_ASSETS_URI . "css/bbpress.css", array( "romo", "romo-plugins" ), CHILD_THEME_VERSION, "all" );
    wp_register_style( "romo-woocommerce", ROMO_ASSETS_URI . "css/woocommerce.css", array( "romo", "romo-plugins" ), CHILD_THEME_VERSION, "all" );
    wp_register_style( "romo-prettyphoto", ROMO_ASSETS_URI . "css/pretty-photo.css", array( "romo", "romo-plugins", "romo-woocommerce" ), CHILD_THEME_VERSION, "all" );
    wp_register_style( "romo-ie8", ROMO_ASSETS_URI . "css/ie8.css", array(), CHILD_THEME_VERSION, "all" );
    /** Select2 */
	wp_register_style( "select2", ( ! is_scripts_cdn() ) ? ROMO_ASSETS_URI . "css/select2.min.css" : "//cdnjs.cloudflare.com/ajax/libs/select2/3.4.1/select2.min.css", array(), "3.4.1", "all" );
 	/** Dependency */
	$wp_styles->add_data( 'fontawesome-ie7', 'conditional', 'lt IE 8' );
	$wp_styles->add_data( 'romo-ie8', 'conditional', 'lt IE 9' );
	
	/** Scripts registration ----------------------------------------------------------------------- */
	
	/** html5shiv */
	wp_register_script( "html5shiv", ( ! is_scripts_cdn() ) ? ROMO_ASSETS_URI . "js/html5shiv.min.js" : "//cdnjs.cloudflare.com/ajax/libs/html5shiv/3.6.2/html5shiv.js", array(), "3.6.2", false );	
	/** selectivizr*/
	wp_register_script( "selectivizr", ( ! is_scripts_cdn() ) ? ROMO_ASSETS_URI . "js/selectivizr-min.js" : "//cdnjs.cloudflare.com/ajax/libs/selectivizr/1.0.2/selectivizr-min.js", array( "jquery" ), "1.0.2", false );	
	/** Respond Js*/
	wp_register_script( "respond", ( ! is_scripts_cdn() ) ? ROMO_ASSETS_URI . "js/respond.min.js" : "//cdnjs.cloudflare.com/ajax/libs/respond.js/1.2.0/respond.js", array( "jquery" ), "1.2.0", false );
	/** Select2*/
	wp_register_script( "select2", ( ! is_scripts_cdn() ) ? ROMO_ASSETS_URI . "js/select2.min.js" : "//cdnjs.cloudflare.com/ajax/libs/select2/3.4.1/select2.min.js", array( "jquery" ), "3.4.1", true );
	/** Isotope */
	wp_register_script( "jquery-isotope", ( ! is_scripts_cdn() ) ? ROMO_ASSETS_URI . "js/jquery.isotope.min.js" : "//cdnjs.cloudflare.com/ajax/libs/jquery.isotope/1.5.25/jquery.isotope.min.js", array( "jquery" ), "1.5.25", true );	
	/** Infinitescroll */
	wp_register_script( "jquery-infinitescroll", ( ! is_scripts_cdn() ) ? ROMO_ASSETS_URI . "js/jquery.infinitescroll.min.js" : "//cdnjs.cloudflare.com/ajax/libs/jquery-infinitescroll/2.0b2.110713/jquery.infinitescroll.min.js", array( "jquery" ), "2.0b2.110713", true );
	/** Mousewheel*/
	wp_register_script( "jquery-mousewheel", ( ! is_scripts_cdn() ) ? ROMO_ASSETS_URI . "js/jquery.mousewheel.min.js" : "//cdnjs.cloudflare.com/ajax/libs/jquery-mousewheel/3.1.3/jquery.mousewheel.min.js", array( "jquery" ), "3.1.3", true );	
	/** Touchswipe*/
	wp_register_script( "jquery-touchswipe", ( ! is_scripts_cdn() ) ? ROMO_ASSETS_URI . "js/jquery.touchswipe.min.js" : "//cdnjs.cloudflare.com/ajax/libs/jquery.touchswipe/1.6.4/jquery.touchSwipe.min.js", array( "jquery" ), "1.6.4", true );	
	/** Caroufredsel*/
	wp_register_script( "jquery-caroufredsel",  ( ! is_scripts_cdn() ) ? ROMO_ASSETS_URI . "js/jquery.carouFredSel-6.2.1-packed.js" : "//cdnjs.cloudflare.com/ajax/libs/jquery.caroufredsel/6.2.1/jquery.carouFredSel.packed.js", array( "jquery" ), "6.2.1", true );	
	/** magnific popup*/
	wp_register_script( "jquery-magnific-popup",  ( ! is_scripts_cdn() ) ? ROMO_ASSETS_URI . "js/jquery.magnific-popup.min.js" : "//cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/0.8.9/jquery.magnific-popup.min.js", array( "jquery" ), "0.8.9", true );
	/** FitVids*/
	wp_register_script( "jquery-placeholder",  ( ! is_scripts_cdn() ) ? ROMO_ASSETS_URI . "js/jquery.placeholder.min.js" : "//cdnjs.cloudflare.com/ajax/libs/jquery-placeholder/2.0.7/jquery.placeholder.min.js", array( "jquery" ), "2.0.7", true );
	/** Flexslider */
	wp_register_script( "jquery-flexslider", ( ! is_scripts_cdn() ) ? ROMO_ASSETS_URI . "js/jquery.flexslider-min.js" : "//cdnjs.cloudflare.com/ajax/libs/flexslider/2.1/jquery.flexslider-min.js", array( "jquery" ), "2.2.0", true );
	/** jQuery mobilemenu */
	wp_register_script( "jquery-mobilemenu", ROMO_ASSETS_URI . "js/jquery.mobilemenu.min.js", array( "jquery" ), "1.0", true );
	/** Global Romo Scripts*/
	wp_register_script( "romo", ROMO_ASSETS_URI . "js/romo.js", array( "jquery", "jquery-mobilemenu", "jquery-placeholder" ), CHILD_THEME_VERSION, true );
	/** Google Maps API */
	wp_register_script( "google-maps-api", "//maps.google.com/maps/api/js?sensor=false" );
	/**
	 * Im doing it wrong
	 * @see 	http://core.trac.wordpress.org/ticket/10891
	 */
	//$wp_scripts->add_data( 'html5shiv', 'conditional', 'lt IE 9' );
	//$wp_scripts->add_data( 'selectivizr', 'conditional', 'lt IE 9' );
	//$wp_scripts->add_data( 'respond', 'conditional', 'lt IE 9' );

}