<?php
/**
 * Initializes Romo child theme by doing some basic things like defining constants
 * and loading all components from the /lib directory.
 * @package 	Romo
 */
/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;
class Romo_Init {

	/** Constructor */
	function __construct() {
		add_action( 'genesis_init', array( $this, 'constants' ), 15 );
		add_action( 'genesis_setup', array( $this, 'load_translation' ) );
		add_action( 'genesis_setup', array( $this, 'theme_supports' ) );
		add_action( 'genesis_setup', array( $this, 'load_functions' ) );
		add_action( 'genesis_setup', array( $this, 'load_plugins' ) );
		add_action( 'genesis_setup', array( $this, 'load_assets' ) );
	}

	/**
	 * This function defines Romo child theme constants
	 */
	function constants() {
		$romo = wp_get_theme();
		/** Define Theme Info Constants */
		define( 'ROMO_DEVELOPMENT', true );
		define( 'CHILD_THEME_NAME', $romo->Name );
		define( 'CHILD_DEVELOPER_NAME', $romo->{'Author Name'} );
		define( 'CHILD_DEVELOPER_URI', $romo->{'Author URI'} );
		define( 'CHILD_THEME_URI', $romo->get('ThemeURI') );
		define( 'CHILD_THEME_VERSION', $romo->Version );
		/** REMEMBER TO CHANGE THIS WHEN THE THEME IS UPDATED */
		define( 'ROMO_RELEASE_DATE', date_i18n( 'F j, Y', '1380050700' ) );
		/** Define Romo Settings fields */
		define( 'ROMO_SETTINGS', $romo->get('TextDomain') . '-settings' );
		/** Define Directory Location Constants */
		define( 'ROMO_DIR', trailingslashit( get_stylesheet_directory() ) );
		define( 'ROMO_LIB_DIR', ROMO_DIR . trailingslashit( 'lib' ) );
		define( 'ROMO_ADMIN_DIR', ROMO_LIB_DIR . trailingslashit( 'admin' ) );
		define( 'ROMO_ASSETS_DIR', ROMO_LIB_DIR. trailingslashit( 'assets' ) );
		define( 'ROMO_BLOCKS_DIR', ROMO_LIB_DIR . trailingslashit( 'blocks' ) );
		define( 'ROMO_CLASSES_DIR', ROMO_LIB_DIR . trailingslashit( 'classes' ) );
		define( 'ROMO_FUNCTIONS_DIR', ROMO_LIB_DIR . trailingslashit( 'functions' ) );
		define( 'ROMO_PLUGINS_DIR', ROMO_LIB_DIR . trailingslashit( 'plugins' ) );
		define( 'ROMO_WIDGETS_DIR', ROMO_LIB_DIR . trailingslashit( 'widgets' ) );
		/** Define URL Location Constants */
		define( 'ROMO_URI', trailingslashit( get_stylesheet_directory_uri() ) );
		define( 'ROMO_LIB_URI', ROMO_URI . trailingslashit( 'lib' ) );		
		define( 'ROMO_ADMIN_URI', ROMO_LIB_URI . trailingslashit( 'admin' ) );
		define( 'ROMO_ASSETS_URI', ROMO_LIB_URI. trailingslashit( 'assets' ) );
		define( 'ROMO_BLOCKS_URI', ROMO_LIB_URI . trailingslashit( 'blocks' ) );
		define( 'ROMO_CLASSES_URI', ROMO_LIB_URI . trailingslashit( 'classes' ) );
		define( 'ROMO_FUNCTIONS_URI', ROMO_LIB_URI . trailingslashit( 'functions' ) );
		define( 'ROMO_PLUGINS_URI', ROMO_LIB_URI . trailingslashit( 'plugins' ) );
		define( 'ROMO_WIDGETS_URI', ROMO_LIB_URI . trailingslashit( 'widgets' ) );
	}

	/**
	 * This function load translation files for Romo child theme
	 */
	function load_translation() {
		load_child_theme_textdomain( 'romo', ROMO_DIR . 'languages' );
	}

	/**
	 * This function defines Romo child theme support
	 */
	function theme_supports() {
		/** Enable WordPress $content_width and oEmbed support */
		if ( ! isset( $GLOBALS['content_width'] ) ) 
			$GLOBALS['content_width'] = 1170;
		/** Editor Styles */
		add_editor_style( ROMO_ASSETS_URI . 'css/font-awesome.min.css' );
		add_editor_style( ROMO_ASSETS_URI . 'css/editor-style.css' );
		/** Custom image size */
		add_image_size( 'romo-thumbnail', 64, 64, true );
		add_image_size( 'romo-square', 370, 370, true );
		add_image_size( 'romo-big-square', 720, 720, true );
		add_image_size( 'romo-small-featured', 370, 9999, false );
		add_image_size( 'romo-featured', 770, 480, true );
		add_image_size( 'romo-slider', 1260, 9999, false );
		/** Add Genesis HTML5 theme support */
		add_theme_support( 'html5' );
		/** Add Genesis Responsive Viewport support */
		add_theme_support( 'genesis-responsive-viewport' );
		/** Add Genesis Menus support */
		add_theme_support(
			'genesis-menus', 
			array(
				'header_social'=> __( 'Header Social', 'romo' ),
				'header'=> __( 'Header Menu', 'romo' ),
				'primary'=> __( 'Primary Navigation Menu', 'genesis' ),
				'secondary'=> __( 'Secondary Navigation Menu', 'genesis' ),
				'footer_social'=> __( 'Footer Social', 'romo' ),
				'footer'=> __( 'Footer Navigation Menu', 'romo' ) ) );
		/** Genesis Footer Widgets #4 */
		add_theme_support( 'genesis-footer-widgets', 4 );
		/** genesis-structural-wrap */
		add_theme_support( 'genesis-structural-wraps',
			array( 
				'header',
				'menu-primary',
				'menu-secondary',
				'breadcrumb',
				'inner',
				'footer-widgets',
				'menu-footer',
				'footer' ) );
		/** WordPress Custom Background */
		add_theme_support( 'custom-background',
			array(
			    'default-color'=> 'eaeaea',
			    'background-attachment'=> 'scroll', 
				'wp-head-callback'=> 'romo_custom_background_cb' ) );
		/** Unregister Genesis layouts */
		genesis_unregister_layout( 'content-sidebar-sidebar' );
		genesis_unregister_layout( 'sidebar-sidebar-content' );
		genesis_unregister_layout( 'sidebar-content-sidebar' );
		/** WooCommerce theme support */
		add_theme_support( 'woocommerce' );
		/** Genesis Connect Woocommerce theme support*/
		add_theme_support( 'genesis-connect-woocommerce' );
	}

	/**
	 * This function load functions files for Romo child theme
	 */
	function load_functions() {
		/** Load romo theme functions */
		include( ROMO_FUNCTIONS_DIR . 'theme-functions.php' );
		/** Load romo theme tweaks */
		include( ROMO_FUNCTIONS_DIR . 'theme-tweaks.php' );
		/** Load genesis tweaks */
		include( ROMO_FUNCTIONS_DIR . 'genesis-tweaks.php' );
		/** Load widgets init */
		include( ROMO_WIDGETS_DIR . 'widgets-init.php' );
	}

	/**
	 * This function load plugin tweaks files for Romo child theme
	 */
	function load_plugins() {
		/** Load plugin conditional */
		include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
		/** Load TGM plugin activation class */
		include_once( ROMO_CLASSES_DIR . 'class-tgm-plugin-activation.php' );
		/** Load plugins requirement and recommendation */
		include( ROMO_PLUGINS_DIR . 'theme-plugins.php' );
		/** Load Options Framework */
		if ( function_exists( 'optionsframework_init' ) ) {
			/** Load options framework tweaks */
			include_once ( ROMO_ADMIN_DIR . 'admin.php' );
			/** Load admin help tab */
			include_once ( ROMO_ADMIN_DIR . 'admin-help.php' );
			/** Load options */
			include_once ( ROMO_DIR . 'options.php' );
			/** Load custom metabox */
			include_once ( ROMO_ADMIN_DIR . 'metabox.php' );
			/** Load romo customizer */
			include_once ( ROMO_ADMIN_DIR . 'customizer.php' );
		}
		/** Load general plugins tweaks */
		include( ROMO_PLUGINS_DIR . 'plugins-tweaks.php' );
		/** Load custom AQPB modules */
		if ( class_exists( 'AQ_Page_Builder') )
			include( ROMO_BLOCKS_DIR . 'blocks-init.php' );
		/** Load CCP tweaks */
		if ( class_exists( 'Custom_Content_Portfolio') )
			include( ROMO_PLUGINS_DIR . 'ccp-tweaks.php' );
		/** Load WooCommerce Tweaks */
		if ( class_exists( 'WooCommerce') )
			include( ROMO_PLUGINS_DIR . 'woocommerce-tweaks.php' );
		/** Load bbPress tweaks */
		if ( class_exists( 'bbPress') )
			include( ROMO_PLUGINS_DIR . 'bbpress-tweaks.php' );
	}

	/**

	 */
	function load_assets() {
		/** Load Romo Assets */
		include( ROMO_ASSETS_DIR . 'load-assets.php' );
		/** Load Romo Styles */
		include( ROMO_ASSETS_DIR . 'load-styles.php' );
		/** Load Romo Scripts */
		include( ROMO_ASSETS_DIR . 'load-scripts.php' );
	}} /** EOF Romo_Init() */
$_romo_init = new Romo_Init();