<?php
/**
 * This file controls all part of WooCommerce Tweaks
 * @package 	Romo
 */
/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;
add_action( 'admin_notices', 'romo_gcwc_notification' );
/** 
 * Make it sure to install 'Genesis Connect for WooCommerce' if using WooCommerce plugin
 */
function romo_gcwc_notification(){
	if ( class_exists( 'Woocommerce' ) && is_plugin_active( 'genesis-connect-woocommerce/genesis-connect-woocommerce.php' ) ) {
    	return;
	} elseif ( class_exists( 'Woocommerce' ) && is_plugin_inactive( 'genesis-connect-woocommerce/genesis-connect-woocommerce.php' ) ) {
		echo '<div class="updated"><p>'.sprintf( __( 'One more step to make %s compatible with %s. Please <b>install</b> and <b>activate</b> %s plugin.', 'romo' ),
										CHILD_THEME_NAME, 
										'WooCommerce',
										'<a href="http://wordpress.org/extend/plugins/genesis-connect-woocommerce/" target="_blank">Genesis Connect for WooCommerce</a>' ).'</p></div>';
	}}
add_filter( 'genesis_attr_content', 'romo_shop_attributes', 20 );
/**
 * Function to filter genesis_attr_content
 */
function romo_shop_attributes( $attributes ) {if ( is_post_type_archive( 'product' ) )$attributes['itemscope'] = 'itemscope';$attributes['itemtype'] = '';return $attributes;
}
/* Disable default Woocommerce CSS */
define( 'WOOCOMMERCE_USE_CSS', false );
remove_action( 'woocommerce_after_shop_loop', 'woocommerce_pagination', 10 );
add_action( 'woocommerce_after_shop_loop', 'genesis_posts_nav', 10 );
add_action( 'wp_enqueue_scripts', 'replace_woocommerce_prettyPhoto_css', 99 );
function replace_woocommerce_prettyPhoto_css(){wp_dequeue_style( 'woocommerce_prettyPhoto_css' );
}

add_action( 'genesis_header', 'ayo_woocommerce_meta' );
/** 
 * Function to show shop meta
 */
function ayo_woocommerce_meta() {	
	global $woocommerce;
	if ( genesis_get_option( 'shop_header_meta', ROMO_SETTINGS ) ) {
		?>
			<ul class="romo-wc-meta">
				<li class="romo-wc-user"><?php echo romo_user_login(); ?></li>
				<li><i class="icon-shopping-cart"></i><?php woocommerce_cart_link();?></li>
			</ul>
		<?php
	}}

/** 
 * WooCommerce User login
 */
function romo_user_login(){
	global $woocommerce, $current_user;
    get_currentuserinfo();
	$output ='';
	if ( is_user_logged_in() ) {
		$output .='<i class="icon-user"></i><a class="romo-user-login" href="'. esc_url( get_permalink( get_option('woocommerce_myaccount_page_id') ) ) .'" title="'. __( 'My Account', 'romo' ).'">'. __( 'Howdy, ', 'romo' ) . $current_user->display_name .'</a>';
	} else{
		$output .='<i class="icon-lock"></i><a class="romo-user-account" href="'. esc_url( get_permalink( get_option('woocommerce_myaccount_page_id') ) ).'" title="'. __( 'Customer login','romo').'">'.__( 'Customer login', 'romo' ).'</a>';
	}
	return $output;
}
add_filter( 'add_to_cart_fragments', 'header_add_to_cart_fragment' );
/** 
 * echo woocommerce cart fragment
 */
function header_add_to_cart_fragment( $fragments ) {
	global $woocommerce;
	ob_start();
	woocommerce_cart_link();
	$fragments['a.cart-parent'] = ob_get_clean();
	return $fragments;
}
/** 
 * Function to show shop meta
 */
function woocommerce_cart_link() {
	global $woocommerce;
	?>
	<a class="cart-parent" href="<?php echo $woocommerce->cart->get_cart_url(); ?>" title="<?php _e('View your shopping cart', 'romo'); ?>">
		<span>
		<?php
		echo $woocommerce->cart->get_cart_total();
		echo ' &ndash; <span class="contents">' . sprintf( _n( '%d item', '%d items', $woocommerce->cart->get_cart_contents_count(), 'romo'), $woocommerce->cart->get_cart_contents_count() ) . '</span>';
		?>
		</span>
	</a>
	<?php
}
add_action( 'woocommerce_before_shop_loop_item_title', 'romo_get_product_crossfade_image', 10 );
function romo_get_product_crossfade_image(){
	global $post, $product, $woocommerce;
	$attachment_ids = $product->get_gallery_attachment_ids();
	if ( ! $attachment_ids )return;
	$output = '<div class="cross-fade-wrap">';
	$loop = 0;
	foreach ( $attachment_ids as $attachment_id ) {
		$loop++;
		$img = wp_get_attachment_image_src( $attachment_id, 'shop_catalog' );
		$output .= '<img src="'. $img[0] .'" class="cross-fade" alt="'. get_the_title( $attachment_id ) .'" />';
	
		if ($loop == 1) break;
	}
	$output .= '</div>';	
	echo $output;
}
if ( genesis_get_option( 'products_loop', ROMO_SETTINGS ) ) {add_filter( 'loop_shop_per_page', create_function( '$cols', 'return '. genesis_get_option( 'products_loop', ROMO_SETTINGS ). ';') );
}
add_filter( 'loop_shop_columns', 'ayo_shop_columns' );
function ayo_shop_columns() {if ( genesis_site_layout() == 'full-width-content' ) {return 4;} else {return 3;
}}
remove_action( 'woocommerce_after_shop_loop', 'woocommerce_pagination', 10 );
add_action( 'woocommerce_after_shop_loop', 'genesis_posts_nav', 10 );

/** 
 * Change number of related products per row based on layout
 */
function woocommerce_output_related_products() {
	if ( genesis_site_layout() == 'full-width-content' ) {woocommerce_related_products( 4, 4 ); } else{woocommerce_related_products( 3, 3 ); 
	}}
remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_upsell_display', 15 );
add_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_upsells', 15 );
/** 
 * Change number of upsells products per row based on layout
 */ 
if ( ! function_exists( 'woocommerce_output_upsells' ) ) {
	function woocommerce_output_upsells() {
		if ( genesis_site_layout() == 'full-width-content' ) {woocommerce_upsell_display( -1, 4 );} else{woocommerce_upsell_display( -1, 3 );
		}}}
global $pagenow;
if ( is_admin() && isset( $_GET['activated'] ) && $pagenow == 'themes.php' ) {
	add_action( 'init', 'romo_woocommerce_image_size', 1 );
}
/** 
 * Change default WooCommerce images size
 */
function romo_woocommerce_image_size() {
	update_option( 'woocommerce_catalog_image_width', '380' ); 
	update_option( 'woocommerce_catalog_image_height', '380' );
	update_option( 'woocommerce_single_image_width', '620' ); 
	update_option( 'woocommerce_single_image_height', '620' ); 
	update_option( 'woocommerce_thumbnail_image_width', '180' );
	update_option( 'woocommerce_thumbnail_image_height', '180' );
	update_option( 'woocommerce_thumbnail_image_crop', 1 );
	update_option( 'woocommerce_single_image_crop', 0 ); 
	update_option( 'woocommerce_catalog_image_crop', 1 );
}
/** Make woocommerce widget tag cloud consistent */
add_filter( 'woocommerce_product_tag_cloud_widget_args', 'romo_widget_tag_cloud_args' );