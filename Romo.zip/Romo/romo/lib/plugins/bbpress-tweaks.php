<?php
/**
 * This file controls all part of bbPress Tweaks
 * @package 	Romo
 */
/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;
add_action( 'admin_notices', 'romo_bbpress_notification' );
/** 
 * Make it sure to install 'Genesis Connect for WooCommerce' if using WooCommerce plugin
 */
function romo_bbpress_notification(){
	if ( class_exists( 'bbPress' ) && is_plugin_active( 'bbpress-genesis-extend/init.php' ) ) {
    	return;
	} elseif ( class_exists( 'bbPress' ) && is_plugin_inactive( 'bbpress-genesis-extend/init.php' ) ) {
		echo '<div class="updated"><p>'. sprintf( __( 'One more step to make %s compatible with %s. Please <b>install</b> and <b>activate</b> %s plugin.', 'romo' ), 
											CHILD_THEME_NAME,
											'bbPress',
											'<a href="http://wordpress.org/extend/plugins/bbpress-genesis-extend/" target="_blank">bbPress Genesis Extend</a>' ) .'</p></div>';
	}}

/** Remove bbp_title() and use Default Genesis title */
remove_filter( 'wp_title', 'bbp_title', 10, 3 );

/** Add support for Post Type Archive Settings */
add_post_type_support( bbp_get_forum_post_type(), array( 'genesis-cpt-archives-settings' ) );
add_action( 'genesis_meta', 'romo_bbp_loop' );
/** 
 * bbPress Content Stucture
 */
function romo_bbp_loop(){
	if ( is_bbpress() ) {
		remove_action( 'genesis_before_loop', 'romo_do_breadcrumb' );
		remove_action( 'genesis_before_content', 'genesis_do_breadcrumbs' );
		add_action( 'genesis_before_content', 'bbp_breadcrumb' );
		if ( is_post_type_archive( bbp_get_forum_post_type() ) )
			remove_action( 'genesis_entry_header', 'genesis_do_post_title' );
		remove_action( 'genesis_after_entry', 'genesis_do_author_box_single', 8 );
	}}

/** remove forum and single topic summaries at the top of the page */
add_filter( 'bbp_get_single_forum_description', '__return_false' );
add_filter( 'bbp_get_single_topic_description', '__return_false' );
add_action( 'bbp_enqueue_scripts', 'ayo_bbpress_styles', 99 ); 
/** 
 * Remove bbPress default stylesheet and replace with romo stylesheet
 */
function ayo_bbpress_styles(){
    wp_dequeue_style( array( 'bbp-child-bbpress', 'bbp-parent-bbpress', 'bbp-default-bbpress', 'bbpress-genesis-extend' ) );
    wp_enqueue_style( 'romo-bbpress' );
}
add_filter( 'bbp_before_get_breadcrumb_parse_args', 'romo_custom_forum_breadcrumb', 999 );
/** 
 * bbPress breadcrumb tweaks
 */
function romo_custom_forum_breadcrumb( $args ) {
	$args['before'] = '<div class="breadcrumb">';
	$args['after'] 	= '</div>';return $args;
}
add_filter( 'genesis_attr_content', 'romo_attr_forum_content', 20 );
/**
 * Function to filter genesis_attr_content
 */
function romo_attr_forum_content( $attributes ) {
	if (is_post_type_archive( array( bbp_get_forum_post_type(), bbp_get_topic_post_type() ) ) ||
		is_singular( array( bbp_get_forum_post_type(), bbp_get_topic_post_type() ) ) ) {
	    $attributes['itemscope'] = 'itemscope';
	    $attributes['itemtype'] = '';}return $attributes;
}
add_filter( 'genesis_attr_entry', 'romo_attr_forum_entry', 20 );
/**
 * Function to filter genesis_attr_content
 */
function romo_attr_forum_entry( $attributes ) {
	if (is_post_type_archive( array( bbp_get_forum_post_type(), bbp_get_topic_post_type() ) ) ||
		is_singular( array( bbp_get_forum_post_type(), bbp_get_topic_post_type() ) ) ) {
		$attributes['itemscope'] = 'itemscope';
		$attributes['itemtype'] = 'http://schema.org/Article';}return $attributes;
}