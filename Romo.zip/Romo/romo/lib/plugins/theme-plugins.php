<?php
/**
 * This file controls Romo child theme plugins requirement and recommendation
 * @package 	Romo
 */
/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;

add_action( 'tgmpa_register', 'romo_theme_plugins' );
/**
 * This function controls Romo child theme plugins requirement and recommendation
 */
function romo_theme_plugins() {
	$plugins = array(
		array(
			'name'=> 'Options Framework',
			'slug'=> 'options-framework',
			'required'=> true,
			'force_deactivation'=> true,
		),
		array(
			'name'=> 'WordPress SEO',
			'slug'=> 'wordpress-seo',
			'required'=> false,
		),
		array(
			'name'=> 'Fluid Video Embeds',
			'slug'=> 'fluid-video-embeds',
			'required'=> false,
		),
		array(
			'name'=> 'Custom Content Portfolio',
			'slug'=> 'custom-content-portfolio',
			'required'=> false,
		),
		array(
			'name'=> 'WordPress Post Type Archive Links',
			'slug'=> 'post-type-archive-links',
			'required'=> false,
		),
		array(
			'name'=> 'Genesis Simple Sidebar',
			'slug'=> 'genesis-simple-sidebars',
			'required'=> false,
		),
		array(
			'name'=> 'Genesis Simple Menus',
			'slug'=> 'genesis-simple-menus',
			'required'=> false,
		),
		array(
			'name'=> 'Genesis Latest Tweets',
			'slug'=> 'genesis-latest-tweets',
			'required'=> false,
		),
		array(
			'name'=> 'Genesis eNews Extended',
			'slug'=> 'genesis-enews-extended',
			'force_activation'=> false,
		),
		array(
			'name'=> 'Genesis Widget Toggle',
			'slug'=> 'genesis-widget-toggle',
			'required'=> false,
		),
		array(
			'name'=> 'Contact Form 7',
			'slug'=> 'contact-form-7',
			'required'=> false,
		),
		array(
			'name'=> 'Aqua Page Builder',
			'slug'=> 'aqua-page-builder',
			'required'=> false,
		),
		array(
			'name'=> 'WooCommerce - excelling eCommerce',
			'slug'=> 'woocommerce',
			'required'=> false,
		),
		array(
			'name'=> 'Genesis Connect for WooCommerce',
			'slug'=> 'genesis-connect-woocommerce',
			'required'=> false,
		),
		array(
			'name'=> 'bbPress',
			'slug'=> 'bbpress',
			'required'=> false,
		),
		array(
			'name'=> 'bbPress Genesis Extend',
			'slug'=> 'bbpress-genesis-extend',
			'required'=> false,
		),);

	/**
	 * Array of configuration settings. Amend each line as needed.
	 */
	$config = array(
		'domain'=> 'romo', 
		'default_path'=> '',               
		'parent_menu_slug'=> 'themes.php', 				
		'parent_url_slug'=> 'themes.php', 		
		'menu'=> 'install-required-plugins', 
		'has_notices'=> true,                     
		'is_automatic'=> false,					
		'message'=> '',						
		'strings'=> array(
			'page_title'=> __( 'Install Required Plugins', 'romo' ),
			'menu_title'=> __( 'Install Plugins', 'romo' ),
			'installing'=> __( 'Installing Plugin: %s', 'romo' ), 
			'oops'=> __( 'Something went wrong with the plugin API.', 'romo' ),
			'notice_can_install_required'=> _n_noop( 'This theme requires the following plugin: %1$s.', 'This theme requires the following plugins: %1$s.' ),
			'notice_can_install_recommended'=> _n_noop( 'This theme recommends the following plugin: %1$s.', 'This theme recommends the following plugins: %1$s.' ),
			'notice_cannot_install'=> _n_noop( 'Sorry, but you do not have the correct permissions to install the %s plugin. Contact the administrator of this site for help on getting the plugin installed.', 'Sorry, but you do not have the correct permissions to install the %s plugins. Contact the administrator of this site for help on getting the plugins installed.' ),
			'notice_can_activate_required'=> _n_noop( 'The following required plugin is currently inactive: %1$s.', 'The following required plugins are currently inactive: %1$s.' ), 
			'notice_can_activate_recommended'=> _n_noop( 'The following recommended plugin is currently inactive: %1$s.', 'The following recommended plugins are currently inactive: %1$s.' ), 
			'notice_cannot_activate'=> _n_noop( 'Sorry, but you do not have the correct permissions to activate the %s plugin. Contact the administrator of this site for help on getting the plugin activated.', 'Sorry, but you do not have the correct permissions to activate the %s plugins. Contact the administrator of this site for help on getting the plugins activated.' ), 
			'notice_ask_to_update'=> _n_noop( 'The following plugin needs to be updated to its latest version to ensure maximum compatibility with this theme: %1$s.', 'The following plugins need to be updated to their latest version to ensure maximum compatibility with this theme: %1$s.' ), 
			'notice_cannot_update'=> _n_noop( 'Sorry, but you do not have the correct permissions to update the %s plugin. Contact the administrator of this site for help on getting the plugin updated.', 'Sorry, but you do not have the correct permissions to update the %s plugins. Contact the administrator of this site for help on getting the plugins updated.' ), 
			'install_link'=> _n_noop( 'Begin installing plugin', 'Begin installing plugins' ),
			'activate_link'=> _n_noop( 'Activate installed plugin', 'Activate installed plugins' ),
			'return'=> __( 'Return to Required Plugins Installer', 'romo' ),
			'plugin_activated'=> __( 'Plugin activated successfully.', 'romo' ),
			'complete'=> __( 'All plugins installed and activated successfully. %s', 'romo' ), 
			'nag_type'=> 'updated' 
		));
	tgmpa( $plugins, $config );
}