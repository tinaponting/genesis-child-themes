<?php
/**
 * This file controls plugins tweaks
 * @package 	Romo
 */
/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;
if ( ! function_exists( 'romo_require_plugin' ) ) :
/**
 * Helper function if some feature require plugin
 */
function romo_require_plugin( $slug, $name ) { return sprintf( __( 'Please install and activate %s%s%s plugin if want to use this feature.', 'romo' ), '<a href="//wordpress.org/extend/plugins/'. esc_attr( $slug ) .'" target="_blank">', esc_attr( $name ), '</a>' );
}
endif;

add_filter( 'wpseo_opengraph_type', 'romo_opengraph_type', 10, 1 );
/**
 * Force front page opengraph type into website if using canvas template
 */
function romo_opengraph_type( $type ) {if ( is_front_page() && is_page_template( 'canvas.php' ) ) {return 'website';} else {return 'article';
}}
add_action( 'wp_enqueue_scripts', 'romo_deregister_scripts' );
/**
 * Unregister default Contact Form 7 Sylesheet plugin
 */
function romo_deregister_scripts(){if ( function_exists( 'wpcf7_enqueue_styles' ) )wp_dequeue_style( 'contact-form-7' );
}
add_action( 'wp_enqueue_scripts', 'unregister_gwt_script', 999 );
function unregister_gwt_script(){
    if ( class_exists( 'Genesis_Widget_Toggle' ) ) {wp_deregister_script( 'gwt-script' );
    }}
add_action( 'init', 'romo_unregister_plugin_scripts', 15 );
/** 
 * Remove default script and style from some plugin
 */
function romo_unregister_plugin_scripts() {
    if ( class_exists( 'AQ_Page_Builder' ) ) {
        wp_dequeue_style( 'aqpb-view-css' );
        wp_dequeue_script( 'aqpb-view-js' );
    }
    if ( class_exists( 'FluidVideoEmbed' ) ) {global $fve;remove_action( 'wp_head', array( $fve, 'add_head_css' ) );
    }}
if( function_exists( 'jetpack_photon_url' ) ) {
    add_filter( 'jetpack_photon_url', 'jetpack_photon_url', 10, 3 );
}