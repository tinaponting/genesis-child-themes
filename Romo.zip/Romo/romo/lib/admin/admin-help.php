<?php
/**
 * This file give additional information for theme
 * 
 * Require Options Framework plugin
 *
 * @package 	Romo
 * @author   	aprakasa
 * @license  	GPL-2.0+
 * @link     	http://prakasa.me/go/romo
 */

/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;

add_action( 'load-genesis_page_romo-settings', 'romo_load_help_tab' );
/**
 * This function control options framework help tab
 *
 * @since 1.0
 */
function romo_load_help_tab() {
    
    $screen = get_current_screen();
    $of_page = 'genesis_page_romo-settings';

    if ( $screen->id != $of_page )
        return;

	$tab1_help =
		'<h3>' . __( 'General Settings' , 'romo' ) . '</h3>' .
		'<p>'. __( 'Descriptions coming soon!', 'romo' ) .'</p>';
		
	$tab2_help =
		'<h3>' . __( 'Colors Settings' , 'romo' ) . '</h3>'.
		'<p>'. __( 'Descriptions coming soon!', 'romo' ) .'</p>';
		
	$tab3_help =
		'<h3>' . __( 'Font Settings' , 'romo' ) . '</h3>'.
		'<p>'. __( 'Descriptions coming soon!', 'romo' ) .'</p>';

	$tab4_help =
		'<h3>' . __( 'Portfolio Settings' , 'romo' ) . '</h3>'.
		'<p>'. __( 'Descriptions coming soon!', 'romo' ) .'</p>';

	$tab5_help =
		'<h3>' . __( 'Misc Settings' , 'romo' ) . '</h3>'.
		'<p>'. __( 'Descriptions coming soon!', 'romo' ) .'</p>';

	$screen->add_help_tab(
	array(
		'id'		=> $of_page . '-tab1',
		'title'		=> __( 'General' , 'romo' ),
		'content'	=> $tab1_help,
	));

	$screen->add_help_tab(
		array(
			'id'		=> $of_page . '-tab2',
			'title'		=> __( 'Style' , 'romo' ),
			'content'	=> $tab2_help,
		));
		
	$screen->add_help_tab(
		array(
			'id'		=> $of_page . '-tab3',
			'title'		=> __( 'Fonts' , 'romo' ),
			'content'	=> $tab3_help,
		));

	$screen->add_help_tab(
		array(
			'id'		=> $of_page . '-tab4',
			'title'		=> __( 'Portfolio' , 'romo' ),
			'content'	=> $tab4_help,
		));

	$screen->add_help_tab(
		array(
			'id'		=> $of_page . '-tab5',
			'title'		=> __( 'Misc' , 'romo' ),
			'content'	=> $tab5_help,
		));
		
	// Add Sidebar
	$screen->set_help_sidebar(
		'<p>' .sprintf( __( '%s ver.%s was released at %s by %s. ', 'romo' ),
			'<strong><a href="'. esc_url( CHILD_THEME_URI ).'" target="_blank" title="'. CHILD_THEME_NAME .'">' . CHILD_THEME_NAME . '</a></strong>',
			'<strong>' . CHILD_THEME_VERSION . '</strong>',
			'<strong>' . ROMO_RELEASE_DATE . '</strong>',
			'<strong><a href="'. esc_url( CHILD_DEVELOPER_URI ) .'" target="_blank" title="'. CHILD_DEVELOPER_NAME .'">'. CHILD_DEVELOPER_NAME .'</a></strong>' ).
		'</p>'.
		
		'<p><strong>' . __( 'Helpful link:', 'romo' ) . '</strong></p>' .
		'<p><strong><a href="//docs.prakasa.me/romo/">'. __( 'Theme Documentation', 'romo' ) .'</a></strong></p>'
	);

}