<?php
/**
 * Tweaks some function that are already exist from Genesis core
 * @package 	Romo
 */
/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;
add_action( 'genesis_admin_before_metaboxes', 'romo_remove_genesis_theme_metaboxes' );
/**
 * Remove selected Genesis metaboxes from the Settings pages.
 */
function romo_remove_genesis_theme_metaboxes( $hook ) {
	remove_meta_box( 'genesis-theme-settings-header', $hook, 'main' );
	remove_meta_box( 'genesis-cpt-archives-layout-settings', $hook, 'main' );
}
if ( is_front_page() && is_page_template( 'canvas.php' ) ) {
	// add_filter( 'genesis_seo_title', 'romo_seo_title', 10, 3 );
}
/**
 * Wrap canvas page title into <H1> if set as front page.
 */
function romo_seo_title( $title, $inside, $wrap ){
	$inside = sprintf( '<a href="%s" title="%s">%s</a>', trailingslashit( home_url() ), esc_attr( get_bloginfo( 'name' ) ), get_bloginfo( 'name' ) );
	$wrap = ( is_home() || is_front_page() && is_page_template( 'canvas.php' ) ) && 'title' === genesis_get_seo_option( 'home_h1_on' )? 'h1' : 'p';
	$wrap = ( is_home() || is_front_page() && is_page_template( 'canvas.php' ) ) && ! genesis_get_seo_option( 'home_h1_on' )? 'h1' : $wrap;
	$wrap = genesis_html5() && genesis_get_seo_option( 'semantic_headings' ) ? 'h1' : $wrap;
	$title  = genesis_html5() ? sprintf( "<{$wrap} %s>", genesis_attr( 'site-title' ) ) : sprintf( '<%s id="title">%s</%s>', $wrap, $inside, $wrap );
	$title .= genesis_html5() ? "{$inside}</{$wrap}>" : '';
	echo apply_filters( 'romo_seo_title', $title, $inside, $wrap );
}
add_action( 'wp_head', 'romo_load_favicon', 5 );
/**
 * Branding Meta.
 */
function romo_load_favicon() {
	$output = '';
	if ( romo_get_option( 'old_favicon' ) )
		$output .= '<link rel="icon" href="'. esc_url( romo_get_option( 'old_favicon' ) ) .'">'."\n";
	if ( romo_get_option( 'favicon_image' ) )
		$output .= '<link rel="icon" href="'. esc_url( romo_get_option( 'favicon_image' ) ) .'">'."\n";
	if ( romo_get_option( 'apple_touch_144' ) )
		$output .= '<link rel="apple-touch-icon" sizes="144x144" href="'. esc_url( romo_get_option( 'apple_touch_144' ) ) .'">';
	if ( romo_get_option( 'apple_touch_114' ) )
		$output .= '<link rel="apple-touch-icon" sizes="114x114" href="'. esc_url( romo_get_option( 'apple_touch_114' ) ) .'">';
	if ( romo_get_option( 'apple_touch_72' ) )
		$output .= '<link rel="apple-touch-icon" sizes="72x72" href="'. esc_url( romo_get_option( 'apple_touch_72' ) ) .'">';
	if ( romo_get_option( 'apple_touch_57' ) )
		$output .= '<link rel="apple-touch-icon" href="'. esc_url( romo_get_option( 'apple_touch_57' ) ) .'">';
	if ( romo_get_option( 'apple_touch_144') )
		$output .= '<meta name="msapplication-TileImage" content="'. esc_url( romo_get_option( 'apple_touch_144' ) ) .'">';
	if ( romo_get_option( 'apple_touch_144' ) && romo_get_option( 'primary_color') )
		$output .= '<meta name="msapplication-TileColor" content="'. romo_get_option( 'primary_color' ) .'">'."\n";
	echo $output;
}
remove_action( 'genesis_before_loop', 'genesis_do_breadcrumbs' );
add_action( 'genesis_before_content', 'genesis_do_breadcrumbs' );
add_filter( 'genesis_breadcrumb_args', 'romo_breadcrumb_args' );
/**
 * Function to filter Genesis Breadcrumb
 */
function romo_breadcrumb_args( $args ) {
	$args['home']                    = __( 'Home', 'romo' );
	$args['sep']                     = '&nbsp; / &nbsp;';
	$args['list_sep']                = ', '; // Genesis 1.5 and later
	$args['prefix']                  = '<div class="breadcrumb">';
	$args['suffix']                  = '</div>';
	$args['heirarchial_attachments'] = true; 
	$args['heirarchial_categories']  = true;
	$args['display']                 = true;
	$args['labels']['prefix']        = ' ';
	$args['labels']['author']        = ' ';
	$args['labels']['category']      = ' '; 
	$args['labels']['tag']           = ' ';
	$args['labels']['date']          = ' ';
	$args['labels']['search']        = ' ';
	$args['labels']['tax']           = ' ';
	$args['labels']['post_type']     = ' ';
	$args['labels']['404']           = ' '; 
	return $args;
}
add_action( 'genesis_header', 'romo_do_nav' );
/**
 * Echo the "Header Navigation" menu.
 */
function romo_do_nav() {
	if ( ! genesis_nav_menu_supported( 'header' ) )return;	
	if ( has_nav_menu( 'header' ) ) {
		$class = 'menu genesis-nav-menu menu-header';
		if ( genesis_superfish_enabled() )$class .= ' js-superfish';
		$args = array(
			'theme_location' => 'header',
			'container'      => '',
			'menu_class'     => $class,
			'echo'           => 0,
		);
		$nav = wp_nav_menu( $args );
		if ( ! $nav )
			return;
		$nav_markup_open = genesis_markup( array(
			'html5'   => '<nav %s>',
			'xhtml'   => '<div id="nav">',
			'context' => 'nav-header',
			'echo'    => false ) );
		$nav_markup_open .= genesis_structural_wrap( 'menu-header', 'open', 0 );
		$nav_markup_close  = genesis_structural_wrap( 'menu-header', 'close', 0 );
		$nav_markup_close .= genesis_html5() ? '</nav>' : '</div>';
		$nav_output = $nav_markup_open . $nav . $nav_markup_close;
		echo apply_filters( 'romo_do_nav', $nav_output, $nav, $args );
	}}
add_action( 'genesis_before_header', 'romo_header_info' );
/**
 * Custom hook for header info
 */
function romo_header_info() {
	$email 		= romo_get_option( 'email_address' );
	$phone 		= romo_get_option( 'phone_number' );
	$output = '';
	if ( $email || $phone || has_nav_menu( 'header_social' ) ) {
		$output .= '<aside class="header-info">';
			$output .= '<div class="wrap">';
			if ( $email || $phone ) {
				if ( is_email( $email ) || $phone ) {
					$output .= '<div class="header-info-contact" itemscope="itemscope" itemtype="http://schema.org/ContactPoint">';
					if ( is_email( $email ) )
						$output .= '<span itemprop="telephone"><a href="mailto:'. antispambot( $email ) .'" class="email-address"><i class="icon-envelope"></i>'. antispambot( $email ) .'</a></span>';
					if ( $phone )
						$output .= '<span itemprop="email"><a href="tel:'. $phone .'" class="phone-number"><i class="icon-phone-sign icon-large"></i>'. $phone .'</a></span>';
					$output .= '</div>';
				}}
			if ( has_nav_menu( 'header_social' ) ) {
				$output .= wp_nav_menu( array(
							'theme_location'  	=> 'header_social',
							'container'       	=> 'div',
							'container_id'    	=> '',
							'container_class' 	=> 'header-social',
							'menu_id'         	=> '',
							'menu_class'      	=> 'social-profiles',
							'depth'           	=> 1,
							'link_before'     	=> '<span class="screen-reader-text">',
							'link_after'      	=> '</span>',
							'fallback_cb'     	=> '',
							'echo'           	=> 0, ) );
			}
			$output .= '</div>';
		$output .= '</aside>';
	}
	echo $output;
}
add_action( 'genesis_footer', 'romo_footer_social', 5 );
/**
 * Echo the "Footer Social" menu.
 */
function romo_footer_social() {
	if ( has_nav_menu( 'footer_social' ) )
		echo wp_nav_menu( array(
			'theme_location'  	=> 'footer_social',
			'container'       	=> 'div',
			'container_id'    	=> '',
			'container_class' 	=> 'footer-social',
			'menu_id'         	=> '',
			'menu_class'      	=> 'social-profiles',
			'depth'           	=> 1,
			'link_before'     	=> '<span class="screen-reader-text">',
			'link_after'      	=> '</span>',
			'fallback_cb'     	=> '',
			'echo'           	=> 0, ) );
}
add_action( 'genesis_footer', 'romo_do_footer_nav', 8 );
/**
 * Echo the "Header Navigation" menu.
 */
function romo_do_footer_nav() {
	if ( ! genesis_nav_menu_supported( 'footer' ) )
		return;	
	if ( has_nav_menu( 'footer' ) ) {
		$class = 'menu genesis-nav-menu menu-footer';
		$args = array(
			'theme_location' => 'footer',
			'container'      => '',
			'depth'          => 1,
			'menu_class'     => $class,
			'echo'           => 0,
		);
		$nav = wp_nav_menu( $args );
		if ( ! $nav )
			return;
		$nav_markup_open = genesis_markup( array(
			'html5'   => '<nav %s>',
			'xhtml'   => '<div id="nav">',
			'context' => 'nav-footer',
			'echo'    => false ) );
		$nav_markup_open .= genesis_structural_wrap( 'menu-footer', 'open', 0 );
		$nav_markup_close  = genesis_structural_wrap( 'menu-footer', 'close', 0 );
		$nav_markup_close .= genesis_html5() ? '</nav>' : '</div>';
		$nav_output = $nav_markup_open . $nav . $nav_markup_close;
		echo apply_filters( 'romo_do_footer_nav', $nav_output, $nav, $args );
	}}
if ( romo_get_option( 'footer_text' ) ) {
	add_filter( 'genesis_footer_creds_text', 'romo_footer_text' );
}
function romo_footer_text( $creds_text ) {
	$creds_text = romo_get_option( 'footer_text' );
	return $creds_text;
}
add_action( 'genesis_footer', 'romo_footer_widget' );
function romo_footer_widget(){
	if ( is_active_sidebar( 'romo-footer-widget' ) ) {
		dynamic_sidebar( 'romo-footer-widget' );
	}}