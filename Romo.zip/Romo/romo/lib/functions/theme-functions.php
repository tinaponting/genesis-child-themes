<?php
/**
 * This file controls all part of misc helper functions that can be reused as need it
 * @package 	Romo
 */
/** Exit if accessed directly */
if ( ! defined( "ABSPATH" ) ) exit;
function romo_strip_autoformat( $text ) {
	$no_br = preg_replace("/<br.?\/>/is", "", $text);
	$no_p = preg_replace("/<p>/is", "", $no_br);
	return preg_replace("/<\/p>/is", "\n", $no_p);
}
if ( ! function_exists( 'romo_get_option' ) ) :
	/** 
	 * Get options value
	 * Set value to false since we want to sync with it with theme customizer
	 */
	function romo_get_option( $key, $use_cache = false ) {
		return genesis_get_option( $key, ROMO_SETTINGS, $use_cache );
	}	
endif;
if ( ! function_exists( 'romo_get_number' ) ) {
	/** 
	 * This file contain numbers in an array
	 */
	function romo_get_number() {
		$number = range( 0, 120 );
		$number = array_map( 'absint', $number );
		return $number;
	}}/** EOF romo_get_number() */
if ( ! function_exists( 'romo_get_published_posts' ) ) {
	/**
	 * Returns published post type into an array
	 * @return array()
	 */
	function romo_get_published_posts( $name, $placeholder = '' ) {
		$post_type 	= array();
		$titles 	= get_posts( array( 
			'post_type'=> $name, 
			'posts_per_page'=> -1,
			'orderby'=> 'menu_order',
			'order'=> 'ASC',
			'post_status'=> 'publish' ) );
		$placeholder = ( ! empty( $placeholder ) ) ? $placeholder : '';
		$post_type[''] = $placeholder;
		foreach ( $titles as $title ) :
			$post_type[$title->ID] = $title->post_title;
		endforeach;
		return $post_type;
	}}/** EOF romo_get_published_posts() */
if ( ! function_exists( 'romo_product_cats' ) ) {
	
	function romo_product_cats(){
		$product_cats = array();
		$cat_terms = get_terms( 'product_cat', array( 'hide_empty' => 0 , 'orderby' => 'ASC' ) );
		$product_cats[''] = '';
		foreach ( $cat_terms as $cat_term ) :
			$product_cats[$cat_term->term_id] = $cat_term->name;
		endforeach;
		return $product_cats;
	}}
if ( ! function_exists( 'romo_minify' ) ) {
	/**
	 * Quick and dirty way to mostly minify CSS.
	 * @param 		string $css CSS to minify
	 * @return 		string Minified CSS
	 */
	function romo_minify( $css ) {
		// Normalize whitespace
		$css = preg_replace( '/\s+/', ' ', $css );
		// Remove comment blocks, everything between /* and */, unless
		// preserved with /*! ... */
		$css = preg_replace( '/\/\*[^\!](.*?)\*\//', '', $css );
		// Remove space after , : ; { }
		$css = preg_replace( '/(,|:|;|\{|}) /', '$1', $css );
		// Remove space before , ; { }
		$css = preg_replace( '/ (,|;|\{|})/', '$1', $css );
		// Strips leading 0 on decimal values (converts 0.5px into .5px)
		$css = preg_replace( '/(:| )0\.([0-9]+)(%|em|ex|px|in|cm|mm|pt|pc)/i', '${1}.${2}${3}', $css );
		// Strips units if value is 0 (converts 0px to 0)
		$css = preg_replace( '/(:| )(\.?)0(%|em|ex|px|in|cm|mm|pt|pc)/i', '${1}0', $css );
		// Converts all zeros value into short-hand
		$css = preg_replace( '/0 0 0 0/', '0', $css );
		// Shortern 6-character hex color codes to 3-character where possible
		$css = preg_replace( '/#([a-f0-9])\\1([a-f0-9])\\2([a-f0-9])\\3/i', '#\1\2\3', $css );
		return trim( $css );
	}} /** EOF romo_minify() */
if( ! function_exists( 'is_login_page' ) ) {
	/**
	 * Conditional tag for WordPress login page
	 * @return 	bool
	 */
	function is_login_page() {
	    return (bool) in_array( $GLOBALS['pagenow'], array( 'wp-login.php', 'wp-register.php' ) );	    
	}} /** EOF is_login_page() */

/**
 * Get Attachment ID from URI
 */
function romo_get_attachment_id_from_url( $attachment_url = '' ) {
	global $wpdb;
	$attachment_id = false;
	if ( '' == $attachment_url )return;
	$upload_dir_paths = wp_upload_dir();
	if ( false !== strpos( $attachment_url, $upload_dir_paths['baseurl'] ) ) {
		$attachment_url = preg_replace( '/-\d+x\d+(?=\.(jpg|jpeg|png|gif)$)/i', '', $attachment_url );
		$attachment_url = str_replace( $upload_dir_paths['baseurl'] . '/', '', $attachment_url );
		$attachment_id = $wpdb->get_var( $wpdb->prepare( "SELECT wposts.ID FROM $wpdb->posts wposts, $wpdb->postmeta wpostmeta WHERE wposts.ID = wpostmeta.post_id AND wpostmeta.meta_key = '_wp_attached_file' AND wpostmeta.meta_value = '%s' AND wposts.post_type = 'attachment'", $attachment_url ) );
 
	}
	return $attachment_id;
}/** EOF romo_get_attachment_id_from_url() */

if ( ! function_exists( 'has_shortcode' ) ) {
	/**
	 * Whether a registered shortcode exists named $tag
	 * @global array $shortcode_tags
	 * @param string $tag
	 * @return boolean
	 */
	function shortcode_exists( $tag ) {
		global $shortcode_tags;
		return array_key_exists( $tag, $shortcode_tags );
	}
	/**
	 * Whether the passed content contains the specified shortcode
	 * @global array $shortcode_tags
	 * @param string $tag
	 * @return boolean
	 */
	function has_shortcode( $content, $tag ) {
		if ( shortcode_exists( $tag ) ) {
			preg_match_all( '/' . get_shortcode_regex() . '/s', $content, $matches, PREG_SET_ORDER );
			if ( empty( $matches ) )return false;
			foreach ( $matches as $shortcode ) {if ( $tag === $shortcode[2] )return true;}}return false;
	}}/** EOF has_shortcode() */
if ( ! function_exists( 'romo_get_fontawesome' ) ) :
/**
 * This function is an array for listing fontawesome classes
 */
function romo_get_fontawesome() {
	if( false === ( $icons  = get_transient( 'romo_get_fontawesome' ) ) ){	
		$pattern = '/\.(icon-(?:\w+(?:-)?)+):before\s*{\s*content/';
		$subject = file_get_contents( ROMO_ASSETS_URI . 'css/font-awesome.min.css' );
		preg_match_all( $pattern, $subject, $matches, PREG_SET_ORDER );
		$icons = array();
		$icons[''] = '';
		foreach( $matches as $match ) {$icons[ str_replace( 'icon-', '', $match[1] ) ] = str_replace( 'icon-', '', $match[1] );
		}
		asort( $icons );
		set_transient( 'romo_get_fontawesome', $icons, 60 * 60 * 24 );}return $icons;
}
endif;/** EOF romo_get_fontawesome() */
if ( ! function_exists( 'romo_get_websafe_fonts' ) ) :
/**
 * Organize web safe fonts into an array
 */
function romo_get_websafe_fonts(){
	$romo_get_websafe_fonts = array(
		'Arial'=> 'Arial',
		'Arial Black'=> 'Arial Black',
		'Comic Sans MS'=> 'Comic Sans MS',
		'Courier New'=> 'Courier New',
		'Georgia'=> 'Georgia',
		'Impact'=> 'Impact',
		'Lucida Console'=> 'Lucida Console',
		'Lucida Sans Unicode'=> 'Lucida Sans Unicode',
		'Palatino Linotype'=> 'Palatino Linotype',
		'Tahoma'=> 'Tahoma',
		'Times New Roman'=> 'Times New Roman',
		'Trebuchet MS'=> 'Trebuchet MS',
		'Verdana'=> 'Verdana',
	);
	asort( $romo_get_websafe_fonts );
	return apply_filters( 'romo_get_websafe_fonts', $romo_get_websafe_fonts);
}
endif; /** EOF romo_get_websafe_fonts() */
if ( ! function_exists( 'romo_get_google_webfonts' ) ) :
/** 
 * Organize All Google webfonts into an array
 */
function romo_get_google_webfonts() {
	if( false === ( $gfonts  = get_transient( 'romo_get_google_webfonts' ) ) ){
		$get_fonts = file_get_contents( ROMO_ASSETS_URI . 'font/webfonts.json' );
		$get_fonts = json_decode( $get_fonts, true );
		$items = $get_fonts['items'];
		$gfonts = array();
		if ( is_array( $items ) ) {
			foreach ( $items as $item ) {
				$gfonts[$item['family']] = $item['family'];
			}}
		asort( $gfonts );
		set_transient( 'romo_get_google_webfonts', $gfonts, 60 * 60 * 24 );}return $gfonts;
}
endif; /** EOF romo_get_google_webfonts() */
if ( ! function_exists( 'romo_get_webfonts' ) ) :
/** 
 * Marge all web safe font and google fonts into an array
 */
function romo_get_webfonts(){
	$romo_get_webfonts = array_merge( romo_get_websafe_fonts(), romo_get_google_webfonts() );
	return apply_filters( 'romo_get_webfonts', $romo_get_webfonts );
}
endif; /** EOF romo_get_webfonts() */

add_action( 'update_option', 'romo_development_true' );
function romo_development_true() {
	if ( ! defined( 'ROMO_DEVELOPMENT' ) )return;
	delete_transient( 'romo_get_fontawesome' );
	delete_transient( 'romo_get_google_webfonts' );
}