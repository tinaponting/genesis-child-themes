<?php
/**
 * Initial all widgets functions and tweaks
 * @package 	Romo
 */
/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;

/** Load widgets init */
include( ROMO_WIDGETS_DIR . 'romo-organization-info.php' );
if ( class_exists( 'Custom_Content_Portfolio') )include( ROMO_WIDGETS_DIR . 'romo-recent-portfolio.php' );
add_action( 'widgets_init', 'romo_widgets_init' );
/** 
 * Unregister sidebar area
 */
function romo_widgets_init(){
	global $wp_embed;
	add_filter( 'widget_text', 'do_shortcode', 8 );
	add_filter( 'widget_text', array( $wp_embed, 'run_shortcode'), 8 );
	add_filter( 'widget_text', array( $wp_embed, 'autoembed'), 8 );

	/** Unregister Genesis Sidebars */
	unregister_sidebar( 'header-right' );
	unregister_sidebar( 'sidebar-alt' );

	/** Register footer widget areas*/
	genesis_register_sidebar( array(
		'id'=> 'romo-footer-widget',
		'name'=> __( 'Footer widget', 'ayoshop' ),
		'description'=> __( 'This widget will show below copyright text at footer area.', 'romo' ),
	));
	
	/** Register Romo Custom Widget */
	register_widget( 'Romo_Organization_Widget' );
	if ( class_exists( 'Custom_Content_Portfolio') )
		register_widget( 'Romo_Recent_Portfolio' );
}
add_filter( 'widget_tag_cloud_args', 'romo_widget_tag_cloud_args' );
/** 
 * Widget Tag clound font size
 */
function romo_widget_tag_cloud_args( $args ) {
	$args['largest'] = 12;
	$args['smallest'] = 12;
	$args['unit'] = 'px';
	return $args;	
}