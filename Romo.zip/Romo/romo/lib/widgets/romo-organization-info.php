<?php
/**
 * Widget to display Organization detail.
 * @package 	Romo
 */
/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;
class Romo_Organization_Widget extends WP_Widget {

	/**
	 * Default widget values.
	 * @var array
	 */
	protected $defaults;

	/**
	 * Default widget values.
	 * @var array
	 */
	protected $organization;

	/**
	 * Constructor method.
	 * Set some global values and create widget.
	 */
	function __construct() {

		/**
		 * Default widget option values.
		 */
		$this->defaults = array(
			'title'=> '',
			'type'=> '',
			'name'=> '',
			'url'=> '',
			'desc'=> '',
			'address'=> '',
			'po_box'=> '',
			'city'=> '',
			'state'=> '',
			'pcode'=> '',
			'country'=> '',
		);

		/**
		 * Default widget option values.
		 */
		$this->organization = array(
			'General'=> 'Organization',
			'Corporation'=> 'Corporation',
			'Education'=> 'EducationalOrganization',
			'Government'=> 'GovernmentOrganization',
			'Local Business'=> 'LocalBusiness',
			'NGO'=> 'NGO',
			'Performing Group'=> 'PerformingGroup',
			'Sports Team'=> 'SportsTeam',
		);
		$widget_ops = array(
			'classname'=> 'romo-organization-widget',
			'description'=> __( 'Displays information of your organization with microformat markup.', 'romo' ),
		);
		$control_ops = array(
			'id_base'=> 'romo-organization-widget',
			'width'=> 400,
			//'height'=> 200,
		);
		parent::__construct( 'romo-organization-widget', __( 'Romo - Organization Info', 'romo' ), $widget_ops, $control_ops );
	}

	/**
	 * Widget Form.
	 * Outputs the widget form that allows users to control the output of the widget.
	 */
	function form( $instance ) {
		$instance = wp_parse_args( (array) $instance, $this->defaults );
		?>
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title', 'romo' ); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $instance['title'] ); ?>" />
		</p>
	
		<p>
			<label for="<?php echo $this->get_field_id( 'type' ); ?>"><?php _e( 'Organization Type', 'romo' ); ?>:</label>
			<select id="<?php echo $this->get_field_id( 'type' ); ?>" name="<?php echo $this->get_field_name( 'type' ); ?>">
				<?php
				foreach ( $this->organization as $types => $type ) {printf( '<option value="%s" %s>%s</option>', $type, selected( $type, $instance['type'], 0 ), $types );
				}
				?>
			</select>
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'name' ); ?>"><?php _e( 'Organization name', 'romo' ); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'name' ); ?>" name="<?php echo $this->get_field_name( 'name' ); ?>" type="text" value="<?php echo esc_attr( $instance['name'] ); ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'url' ); ?>"><?php _e( 'Organization url', 'romo' ); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'url' ); ?>" name="<?php echo $this->get_field_name( 'url' ); ?>" type="text" value="<?php echo esc_attr( $instance['url'] ); ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'desc' ); ?>"><?php _e( 'Description', 'romo' ); ?></label>
			<textarea class="widefat" rows="8" cols="20" id="<?php echo $this->get_field_id( 'desc' ); ?>" name="<?php echo $this->get_field_name('desc'); ?>"><?php echo esc_textarea( $instance['desc'] ); ?></textarea>
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'address' ); ?>"><?php _e( 'Address', 'romo' ); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'address' ); ?>" name="<?php echo $this->get_field_name( 'address' ); ?>" type="text" value="<?php echo esc_attr( $instance['address'] ); ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'po_box' ); ?>"><?php _e( 'PO BOX', 'romo' ); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'po_box' ); ?>" name="<?php echo $this->get_field_name( 'po_box' ); ?>" type="text" value="<?php echo esc_attr( $instance['po_box'] ); ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'city' ); ?>"><?php _e( 'City', 'romo' ); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'city' ); ?>" name="<?php echo $this->get_field_name( 'city' ); ?>" type="text" value="<?php echo esc_attr( $instance['city'] ); ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'state' ); ?>"><?php _e( 'State/Region', 'romo' ); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'state' ); ?>" name="<?php echo $this->get_field_name( 'state' ); ?>" type="text" value="<?php echo esc_attr( $instance['state'] ); ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'pcode' ); ?>"><?php _e( 'Postal Code', 'romo' ); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'pcode' ); ?>" name="<?php echo $this->get_field_name( 'pcode' ); ?>" type="text" value="<?php echo esc_attr( $instance['pcode'] ); ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'country' ); ?>"><?php _e( 'Country', 'romo' ); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'country' ); ?>" name="<?php echo $this->get_field_name( 'country' ); ?>" type="text" value="<?php echo esc_attr( $instance['country'] ); ?>" />
		</p>
		<p class="description"><?php echo sprintf( __( 'All the informations will be markup by using %s guidelines.', 'romo' ), '<a href="http://schema.org/Organization">Schema.org - Organization</a>' ); ?></p>
		<?php
	}

	/**
	 * Form validation and sanitization.
	 * Runs when you save the widget form. Allows you to validate or sanitize widget options before they are saved.
	 */
	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = strip_tags( $new_instance['title'] );
		$instance['type'] = strip_tags( $new_instance['type'] );
		$instance['name'] = strip_tags( $new_instance['name'] );
		$instance['url'] = esc_url( $new_instance['url'] );
		$instance['desc'] = esc_textarea( $new_instance['desc'] );
		$instance['address'] = esc_textarea( $new_instance['address'] );
		$instance['po_box'] = (int) $new_instance['po_box'];
		$instance['city'] = esc_attr( ucwords( $new_instance['city'] ) );
		$instance['state'] = esc_attr( $new_instance['po_box'] );
		$instance['country'] = esc_attr( ucwords( $new_instance['country'] ) );return $instance;
	}

	/**
	 * Widget Output.
	 * Outputs the actual widget on the front-end based on the widget options the user selected.
	 */
	function widget( $args, $instance ) {
		extract( $args );
		$instance = wp_parse_args( (array) $instance, $this->defaults );
		echo $before_widget;
		if ( ! empty( $instance['title'] ) )
			echo $before_title . apply_filters( 'widget_title', $instance['title'], $instance, $this->id_base ) . $after_title;
		$output = '<div class="organization" itemscope itemtype="http://schema.org/'. $instance['type'] .'">';
			if ( ! empty( $instance['name'] ) && ! empty( $instance['url'] ) ) {
				$output .= '<p class="organization-name" itemprop="name"><strong><a itemprop="url" href="'. esc_url( $instance['url'] ) .'">'. esc_attr( $instance['name'] ) .'</a></strong></p>';
			} elseif ( ! empty( $instance['name'] ) ) {
				$output .= '<div itemprop="name"><p><strong>'. esc_attr( $instance['name'] ) .'</strong></p></div>';
			}
			if ( ! empty( $instance['desc'] ) )
				$output .= '<div class="organization-description" itemprop="description">'. wpautop( esc_textarea( $instance['desc'] ) ) .'</div>';
			$output .= '<div class="romo-address" itemprop="address" itemscope itemtype="http://schema.org/PostalAddress">';
				if ( ! empty( $instance['address'] ) )
					$output .= '<span itemprop="streetAddress">'. esc_textarea( $instance['address'] ) .'</span>';
				if ( ! empty( $instance['po_box'] ) )
					$output .= '<span class="pobox" itemprop="postOfficeBoxNumber">'. (int) $instance['po_box'] .'</span>';
				if ( ! empty( $instance['city'] ) )
					$output .= '<span itemprop="addressLocality">'. esc_attr( $instance['city'] ) .'</span>';
				if ( ! empty( $instance['region'] ) )
					$output .= '<span itemprop="addressRegion">'. esc_attr( $instance['region'] ) .'</span>';
				if ( ! empty( $instance['pcode'] ) )
					$output .= '<span itemprop="postalCode">'. (int) $instance['pcode'] .'</span>';
				if ( ! empty( $instance['country'] ) )
					$output .= '<span itemprop="addressCountry">'. esc_attr( ucwords( $instance['country'] ) ) .'</span>';
			$output .= '</div>';
		$output .= '</div><!--- .end-organization/'. $instance['type'] .' -->';
		echo $output;
		echo $after_widget;
	}}