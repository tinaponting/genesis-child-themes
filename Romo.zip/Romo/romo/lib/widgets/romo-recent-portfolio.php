<?php
/**
 * Recent Portfolio
 * @package 	Romo
 */
/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Romo Featured Portfolio widget class.
 */
class Romo_Recent_Portfolio extends WP_Widget {

	/**
	 * Holds widget settings defaults,
	 * populated in constructor.
	 * @var array
	 */
	protected $defaults;

	/**
	 * Constructor.
	 * Set the default widget options and create widget.
	 */
	function __construct() {

		$this->defaults = array(
			'title'=> '',
			'portfolio_num'=> 6,
			'display'=> 'thumbnail',
			'effect'=> 'slide',
		);
		$widget_ops = array(
			'classname'=> 'romo-recent-portfolio',
			'description'=> __( 'Displays Recent portfolio slideshow', 'romo' ),
		);
		$control_ops = array(
			'id_base'=> 'romo-recent-portfolio',
			//'width'=> 505,
			//'height'=> 350,
		);
		parent::__construct( 'romo-recent-portfolio', __( 'Romo - Recent Portfolio', 'romo' ), $widget_ops, $control_ops );
		
	}

	/**
	 * Widget Form.
	 * Outputs the widget form that allows users to control the output of the widget.
	 */
	function form( $instance ) {
		$instance = wp_parse_args( (array) $instance, $this->defaults );
		?>
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title', 'romo' ); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $instance['title'] ); ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'portfolio_num' ); ?>"><?php _e( 'Number of Portfolio to Show', 'Romo' ); ?>:</label>
			<input type="text" id="<?php echo $this->get_field_id( 'portfolio_num' ); ?>" name="<?php echo $this->get_field_name( 'portfolio_num' ); ?>" value="<?php echo esc_attr( $instance['portfolio_num'] ); ?>" size="2" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'display' ); ?>"><?php _e( 'Display portfolio as', 'romo' ); ?>:</label>
			<select id="<?php echo $this->get_field_id( 'display' ); ?>" name="<?php echo $this->get_field_name( 'display' ); ?>">
				<option value="thumbnail" <?php selected( 'thumbnail', $instance['display'] ); ?>><?php _e( 'Thumbnail', 'romo' ); ?></option>
				<option value="slideshow" <?php selected( 'slideshow', $instance['display'] ); ?>><?php _e( 'Slideshow', 'romo' ); ?></option>
			</select>
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'effect' ); ?>"><?php _e( 'Slideshow effect', 'romo' ); ?>:</label>
			<select id="<?php echo $this->get_field_id( 'effect' ); ?>" name="<?php echo $this->get_field_name( 'effect' ); ?>">
				<option value="fade" <?php selected( 'fade', $instance['effect'] ); ?>><?php _e( 'Fade', 'romo' ); ?></option>
				<option value="slide" <?php selected( 'slide', $instance['effect'] ); ?>><?php _e( 'Slide', 'romo' ); ?></option>
			</select>
		</p>
		<?php
	}

	/**
	 * Form validation and sanitization.
	 */
	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = strip_tags( $new_instance['title'] );
		$instance['portfolio_num'] = (int)$new_instance['portfolio_num'];
		$instance['display'] = $new_instance['display'];
		$instance['effect'] = strip_tags( $new_instance['effect'] );return $instance;
	}

	/**
	 * Widget Output.
	 * Outputs the actual widget on the front-end based on the widget options the user selected.
	 */
	function widget( $args, $instance ) {
		global $wp_query, $_genesis_displayed_ids;
		extract( $args );
		$instance = wp_parse_args( (array) $instance, $this->defaults );
		wp_enqueue_script( 'jquery-flexslider' );
		echo $before_widget;
		if ( ! empty( $instance['title'] ) )
			echo $before_title . apply_filters( 'widget_title', $instance['title'], $instance, $this->id_base ) . $after_title;
		if ( $instance['display'] == 'slideshow' ) {
			$output = '<div id="romo-slider-'. rand( 1, 100 ) .'" class="romo-flexslider attachment-slideshow" data-effect="'. esc_attr( $instance['effect'] ) .'">';
				$output .= '<ul class="romo-slides cf">';
		} else {$output = '<div class="portfolio-grid">';$output .= '<ul class="cf">';
		}
			$wp_query = new WP_Query( array(
				'post_type'=> 'portfolio_item',
				'showposts'=> $instance['portfolio_num'],
				'no_found_rows'=> true,
	    		'update_post_term_cache'=> false,
	    		'update_post_meta_cache'=> false ) );
				if ( have_posts() ) :
					while ( have_posts() ) : the_post();
					if ( $instance['display'] == 'slideshow' ) {
						$img = genesis_get_image( array( 'format' => 'url', 'size' => 'romo-featured' ) );
						$placeholder = ROMO_ASSETS_URI .'images/portfolio.png';
				    	$placeholder = ( function_exists( 'jetpack_photon_url' ) ) ? jetpack_photon_url( $placeholder ) : $placeholder;
					} else {
						$img = genesis_get_image( array( 'format' => 'url', 'size' => 'romo-square' ) );
						$placeholder = ROMO_ASSETS_URI .'images/portfolio-thumbnail.png';
						$placeholder = ( function_exists( 'jetpack_photon_url' ) ) ? jetpack_photon_url( $placeholder ) : $placeholder;
					}
					$output .= '<li>';
						$output .= '<a class="portfolio-widget-link" href="'. get_permalink() .'" title="'. get_the_title() .'">';
						if ( has_post_thumbnail() || genesis_get_image_id() ) {
							$output .= '<img src="'. esc_url( $img ) .'" alt="'. get_the_title() .'" title="'. get_the_title() .'" />';
						} else {
							$output .= '<img src="'. $placeholder .'" alt="'. get_the_title() .'" title="'. get_the_title() .'" />';
						}
						$output .= '</a>';
					$output .=	'</li>';
					endwhile;
				endif;
			$output .= '</ul>';
		$output .= '</div>';
		echo $output;
		wp_reset_query();
		echo $after_widget;	
	}}