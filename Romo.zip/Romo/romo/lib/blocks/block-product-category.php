<?php
/**
 * This file control Product Category Block
 *
 * @package 	Romo
 * @author   	aprakasa
 * @license  	GPL-2.0+
 * @link     	http://prakasa.me/go/romo
 */

/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;

if( ! class_exists( 'Romo_Product_Category' ) ) :

class Romo_Product_Category extends AQ_Block {
	
	//set and create block
	function __construct() {
		$block_options = array(
			'name' 		=> __( 'Product Category', 'romo' ),
			'size' 		=> 'span4',
		);
		
		//create the block
		parent::__construct( 'Romo_Product_Category', $block_options );
	}
	
	function form($instance) {
		
		$defaults = array(
			'category'		=> '',
		);
		$instance = wp_parse_args($instance, $defaults);
		extract($instance);
		
		?>
		<div class="description">
            <label for="<?php echo $this->get_field_id( 'category' ) ?>"><?php _e( 'Product Category', 'romo' );?></label>
            <?php echo aq_field_select( 'category', $block_id, romo_product_cats(), $category ) ?>
		</div>

		<div class="description">
			<p><?php _e( 'This block will display product category title, thumbnail and link.', 'romo' );?></p>
		</div>

		<?php
	}
	
	function block($instance) {
		extract($instance);
		if ( ! class_exists( 'woocommerce' ) )
			return;
		if ( empty( $category ) )
			return;

		$thumbnail_id 	= get_woocommerce_term_meta( $category, 'thumbnail_id', true );
		$cat_desc		= get_woocommerce_term_meta( $category, 'description', true );
		$image 			= wp_get_attachment_image_src( $thumbnail_id, 'romo-featured' );
		$terms 			= get_term( $category, 'product_cat' );
		$placeholder 	= ROMO_ASSETS_URI .'images/portfolio.png';
		$placeholder 	= ( function_exists( 'jetpack_photon_url' ) ) ? jetpack_photon_url( $placeholder ) : $placeholder;

		$output = '<div class="product-category-wrap">';
			$output .= '<a class="product-cat-overlay" href="'. get_term_link( $terms ) .'" title="'. $terms->name .'">';
				if ( !empty( $image[0] ) ) {
					$output .= '<img src="'. $image[0] .'" alt="'. $terms->name .'" />';
				} else {
					$output .= '<img src="'. $placeholder .'" alt="'. $terms->name .'" />';
				}
				$output .= '<span class="category-title">'. $terms->name . '</span>';
			$output .= '</a>';
		$output .= '</div>';

		echo $output;
	}

 	/* block header */
 	function before_block($instance) {
 		extract($instance);
 		$column_class = $first ? 'aq-first' : ''; 		
 		echo '<section id="aq-block-'.$template_id.'-'.$number.'" class="aq-block block-col-'. $id_base .' aq-block-'.$id_base.' aq_'.$size.' '.$column_class.' cf">';
 	}

 	/* block footer */
 	function after_block($instance) {
 		extract($instance);
 		echo '</section>';
 	}
	
}

aq_register_block( 'Romo_Product_Category' );

endif;