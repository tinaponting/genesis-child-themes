<?php
/**
 * This file control custom text action with button
 *
 * @package 	Romo
 * @author   	RomoThemes
 * @license  	GPL-2.0+
 * @link     	http://prakasa.me/go/romo
 */

/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;

if( ! class_exists( 'Romo_Callout_Block' ) ) :

class Romo_Callout_Block extends AQ_Block {

	function __construct() {
		$block_options = array(
			'name' 		=> __( 'Callout', 'romo' ),
			'size' 		=> 'span12',
			'resizable' => 0,
		);		
		parent::__construct( 'Romo_Callout_Block', $block_options );
	}

 	function form( $instance ) {
		$defaults = array(
			'headline'		=> '',
			'subheadline' 	=> '',
			'btn_text'		=> '',
			'btn_link'		=> '',
			'btn_target'	=> '',
			'btn_icon'		=> '',
			'icon_position'	=> 'right',
			'btn_color'		=> '#E74C3C',
		);

		$instance = wp_parse_args( $instance, $defaults );
		extract( $instance );

		$position = array(
			'left' => 'Left',
			'right' => 'Right' );
		$target = array(
			'_self' 	=> __( 'Same Tab/Window', 'romo' ),
			'_blank'	=> __( 'New Tab/Window', 'romo' ) );

		?>

		<p class="description">
			<label for="<?php echo $this->get_field_id( 'headline' ) ?>"><?php _e( 'Main Headline (big text)', 'romo' );?></label>
			<?php echo aq_field_input( 'headline', $block_id, $headline ) ?>			
		</p>

		<p class="description">
			<label for="<?php echo $this->get_field_id( 'subheadline' ) ?>"><?php _e( 'Sub Headline (small text)', 'romo' );?></label>
			<?php echo aq_field_textarea( 'subheadline', $block_id, $subheadline ) ?>			
		</p>

		<p class="description half">
			<label for="<?php echo $this->get_field_id('btn_text') ?>"><?php _e( 'Button Text', 'romo' );?> *<?php _e( 'Optional', 'romo' );?></label>
			<?php echo aq_field_input( 'btn_text', $block_id, $btn_text ) ?>			
		</p>

		<p class="description half last">
			<label for="<?php echo $this->get_field_id('btn_link') ?>"><?php _e( 'Button Link', 'romo' );?> *<?php _e( 'Optional', 'romo' );?></label>
			<?php echo aq_field_input( 'btn_link', $block_id, $btn_link ) ?>			
		</p>

		<p class="description half">
			<label for="<?php echo $this->get_field_id( 'btn_icon' ) ?>"><?php _e( 'Button Icon', 'romo' );?> *<?php _e( 'Optional', 'romo' );?></label>				
			<?php echo aq_field_select( 'btn_icon', $block_id, romo_get_fontawesome(), $btn_icon ) ?>
		</p>

		<p class="description half last">
			<label for="<?php echo $this->get_field_id( 'btn_target' ) ?>"><?php _e( 'Button link target.', 'romo' );?></label>
			<?php echo aq_field_select( 'btn_target', $block_id, $target, $btn_target ) ?>
		</p>

		<p class="description half">
			<label for="<?php echo $this->get_field_id( 'icon_position' ) ?>"><?php _e( 'Icon position', 'romo' );?> *<?php _e( 'Optional', 'romo' );?></label>				
			<?php echo aq_field_select( 'icon_position', $block_id, $position, $icon_position ) ?>
		</p>

		<div class="description half last">
			<label for="<?php echo $this->get_field_id( 'btn_color' ) ?>"><?php _e( 'Button color', 'romo' );?></label>
			<?php echo aq_field_color_picker( 'btn_color', $block_id, $btn_color ); ?>
		</div>

		<?php

	}

	function block( $instance ) {
		extract( $instance );
		$icon_left 	= ( ! empty( $btn_icon ) && $icon_position == 'left' ) ? '<span class="icon-'. $btn_icon .' icon-large in-left"></span>' : '';
		$icon_right = ( ! empty( $btn_icon ) && $icon_position == 'right' ) ? '<span class="icon-'. $btn_icon .' icon-large in-right"></span>' : '';
		$output = '';
		if ( ! empty( $headline ) )
			$output .= '<p class="large-text">'. htmlspecialchars_decode( esc_attr( $headline ) ) .'</p>';
		if ( ! empty( $subheadline ) )
			$output .= '<p class="small-text">'. htmlspecialchars_decode( esc_attr( $subheadline ) ) .'</p>';
		if ( ! empty( $btn_text ) && ! empty( $btn_link ) ) {
			$output .= '<a href="'. esc_url( $btn_link ) .'" target="'. $btn_target .'" class="callout-button" style="background-color:'. $btn_color .'">'. $icon_left .'<span class="button-text">'. esc_attr( $btn_text ) .'</span>'. $icon_right .'</a>';
		}
		echo $output;	
	}

 	/* block header */
 	function before_block($instance) {
 		extract($instance);
 		$column_class = $first ? 'aq-first' : ''; 		
 		echo '<section id="aq-block-'.$template_id.'-'.$number.'" class="aq-block aq-block-'.$id_base.' aq_'.$size.' '.$column_class.' cf">';
 	}

 	/* block footer */
 	function after_block($instance) {
 		extract($instance);
 		echo '</section>';
 	}

}

aq_register_block( 'Romo_Callout_Block' );

endif;