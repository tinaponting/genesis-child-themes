<?php
/**
 * This file control Soliloquy slider block
 *
 * @package 	Romo
 * @author   	aprakasa
 * @license  	GPL-2.0+
 * @link     	http://prakasa.me/go/romo
 */

/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;

if( ! class_exists( 'Romo_Soliloquy_Block') ) :

class Romo_Soliloquy_Block extends AQ_Block {

	function __construct() {
		$block_options = array(
			'name' => 'Soliloquy Slider',
			'size' => 'span12',
		);		
		parent::__construct( 'Romo_Soliloquy_Block', $block_options );
	}
	
	function form( $instance ) {

		$defaults = array(
			'slider' 	=> '',
		);

		$instance = wp_parse_args( $instance, $defaults );
		extract( $instance );
		
		$sliders = romo_get_published_posts( 'soliloquy', __( 'Select slider:', 'romo' ) );
		
		if( empty( $sliders ) ) {
			echo __( 'You currently do not have any slider. Please create slider.', 'romo' );
			return false;
		}

		?>
		<div class="description">
			<label for="<?php echo $this->get_field_id( 'slider' ) ?>"><?php _e( 'Choose slider', 'romo' );?></label>
			<?php echo aq_field_select( 'slider', $block_id, $sliders, $slider ); ?>
		</div>
		<?php
	}
	
	function block($instance) {
		extract( $instance );
		if( ! class_exists( 'Tgmsp' ) && ! class_exists( 'Tgmsp_Lite' ) )
			return;
		if( ! empty( $slider ) )
			echo soliloquy_slider( $slider );
	}

 	/* block header */
 	function before_block($instance) {
 		extract($instance);
 		$column_class = $first ? 'aq-first' : ''; 		
 		echo '<section id="aq-block-'.$template_id.'-'.$number.'" class="aq-block aq-block-'.$id_base.' aq_'.$size.' '.$column_class.' cf">';
 	}

 	/* block footer */
 	function after_block($instance) {
 		extract($instance);
 		echo '</section>';
 	}
 	
}

aq_register_block( 'Romo_Soliloquy_Block' );

endif;