<?php
/**
 * Open wrapper/container
 *
 * @package 	Romo
 * @author   	aprakasa
 * @license  	GPL-2.0+
 * @link     	http://prakasa.me/go/romo
 */

/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;

if( ! class_exists( 'Romo_Open_Container_Block') ) :

class Romo_Open_Container_Block extends AQ_Block {

	function __construct() {
		$block_options = array(
			'name' 		=> 'Container (open)',
			'size' 		=> 'span12',
			'resizable' => 0,
		);		
		parent::__construct( 'Romo_Open_Container_Block', $block_options );
	}
	
	function form( $instance ){
		$defaults = array (
			'background'			=> '',
			'color'					=> '',
			'padding_top'			=> '',
			'padding_bottom'		=> '',
			'margin_bottom'			=> '',
			'bg_img'				=> '',
			'bg_option'				=> '',
		);

		$instance = wp_parse_args( $instance, $defaults );
		extract( $instance );
		
		$background 		= isset( $background ) ? $background : '';
		$color 				= isset( $color ) ? $color : '';
		$padding_top 		= isset( $padding_top ) ? (int)$padding_top : '';
		$padding_bottom 	= isset( $padding_bottom ) ? (int)$padding_bottom : '';
		$margin_bottom 		= isset( $margin_bottom ) ? (int)$margin_bottom : '';
		$bg_img 			= isset( $bg_img ) ? $bg_img : '';
		$bg_option 			= isset( $bg_option ) ? $bg_option : '';

		$bg_opt = array(
			'cover' 		=> 'cover',
			'tile'			=> 'tile',
			'align-left'	=> 'align left',
			'align-center'	=> 'align center',
			'align-right'	=> 'align right'
		);
		
		?>

		<div class="description">
			<label for="<?php echo $this->get_field_id( 'bg_img' ) ?>"><?php _e( 'Background Image', 'romo' );?></label>
			<?php echo aq_field_upload( 'bg_img', $block_id, $bg_img ); ?>
			<?php if( ! empty( $bg_img ) ) : ?>
			<div class="description screenshot">
				<img src="<?php echo $bg_img ?>" />
			</div>
			<?php endif; ?>
		</div>

		<div class="clear"></div>

		<div class="description half">
	        <div class="description">
	            <label for="<?php echo $this->get_field_id( 'bg_option' ) ?>"><?php _e( 'Background Sytle', 'romo' );?></label>               
	            <?php echo aq_field_select( 'bg_option', $block_id, $bg_opt, $bg_option ) ?>
	        </div>
			<div class="description third">
				<label for="<?php echo $this->get_field_id( 'padding_top' ) ?>"><?php _e( 'Padding top', 'romo' );?></label><br />
				<?php echo aq_field_input( 'padding_top', $block_id, $padding_top, $size = 'min', $type = 'number' ) ?>px
			</div>

			<div class="description third">
				<label for="<?php echo $this->get_field_id( 'padding_bottom' ) ?>"><?php _e( 'Padding Bottom', 'romo' );?></label><br />
				<?php echo aq_field_input( 'padding_bottom', $block_id, $padding_bottom, $size = 'min', $type = 'number' ) ?>px
			</div>

			<div class="description third last">
				<label for="<?php echo $this->get_field_id( 'margin_bottom' ) ?>"><?php _e( 'Margin Bottom', 'romo' );?></label><br />
				<?php echo aq_field_input( 'margin_bottom', $block_id, $margin_bottom, $size = 'min', $type = 'number' ) ?>px
			</div>
		</div>

		<div class="description half last">
			<div class="description">
				<label for="<?php echo $this->get_field_id( 'background' ) ?>"><?php _e( 'Background color', 'romo' );?></label>
				<?php echo aq_field_color_picker( 'background', $block_id, $background ); ?>
			</div>

			<div class="description">
				<label for="<?php echo $this->get_field_id( 'color' ) ?>"><?php _e( 'Text color', 'romo' );?></label>
				<?php echo aq_field_color_picker( 'color', $block_id, $color ); ?>
			</div>
		</div>

		<?php
	}
	
	function block( $instance ) {
		extract( $instance );
		$bg_option 		= ( ! empty ( $bg_img ) && ! empty( $bg_option ) ) ? ' '. $bg_option : '';
		$css = $this->css( $instance );
		//echo '<style type="text/css">'. $css .'</style>';
		echo '<div '. $css .'id="aq-block-'. $template_id .'-'. $number .'" class="template-wrap cf'. $bg_option .'"><div class="container">';
	}

	function css( $instance ) {
		$defaults = array (
			'background'			=> '',
			'color'					=> '',
			'padding_top'			=> '',
			'padding_bottom'		=> '',
			'margin_bottom'			=> '',
			'bg_img'				=> '',
		);

		$instance = wp_parse_args( $instance, $defaults );
		extract( $instance );

		$background 	= ( ! empty ( $background ) ) ? 'background-color:'. $background  .';': '';
		$color 			= ( ! empty ( $color ) ) ? 'color:'. $color .';' : '';
		$link_color 	= ( ! empty ( $link_color ) ) ? 'color:'. $link_color .';' : '';
		$hover_color 	= ( ! empty ( $hover_color ) ) ? 'color:'. $hover_color .';' : '';

		$padding_top 	= ( ! empty( $padding_top ) ) ? 'padding-top:'. (int)$padding_top .'px;': '';
		$padding_bottom = ( ! empty( $padding_bottom ) ) ? 'padding-bottom:'. (int)$padding_bottom .'px;': '';
		$margin_bottom 	= ( ! empty( $margin_bottom ) ) ? 'margin-bottom:'. (int)$margin_bottom .'px;': '';
		$bg_option 		= ( ! empty( $bg_option ) ) ? ' '. $bg_option : '';
		if ( function_exists( 'jetpack_photon_url' ) ) {
			$bg_img = ( ! empty ( $bg_img ) ) ? 'background-image:url('. jetpack_photon_url( esc_url( $bg_img ) ) .');': '';
		} else {
			$bg_img = ( ! empty ( $bg_img ) ) ? 'background-image:url('. esc_url( $bg_img ) .');': '';
		}
		
		
		/** Not a good practice -_- need more research */
		$style = ( 
			! empty( $background ) || 
			! empty( $color ) || 
			! empty( $padding_top ) ||
			! empty( $margin_bottom ) ||
			! empty( $padding_bottom ) ) ||
			! empty( $bg_img ) ? 
				sprintf( '%s%s%s%s%s%s', $background, $color, $padding_top, $padding_bottom, $margin_bottom, $bg_img ) : '';
		
		if ( ! empty( $style ) ) {			
			$output = 'style="'. $style .'" ';			
			return  $output;
		}

	}

	function before_block( $instance ) {
		extract( $instance );
		return;
	}

	function after_block( $instance ) {
		extract( $instance );
		return;
	}
 	
}

aq_register_block( 'Romo_Open_Container_Block' );

endif;