<?php
/**
 * This file control Google Maps class
 *
 * @package 	Romo
 * @author   	aprakasa
 * @license  	GPL-2.0+
 * @link     	http://prakasa.me/go/romo
 */

/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;

if( ! class_exists( 'Romo_Gmaps_Block' ) ) :
/**
 * This file control custom text block class
 *
 * @author   	SyamilMJ
 * @link     	http://aquagraphite.come/cuvette
 */
class Romo_Gmaps_Block extends AQ_Block {

	function __construct() {
		$block_options = array(
			'name' => __( 'Google Map', 'romo' ),
			'size' => 'span6',
		);
		
		parent::__construct( 'Romo_Gmaps_Block', $block_options );
	}

 	function form( $instance ) {

		$defaults = array(
			'title'			=> '',
			'icon'			=> '',
			'map_title'		=> '',
			'address' 		=> '',
			'coordinates' 	=> '',
			'height' 		=> '300',
			'zoom' 			=> 8,
		);

		$instance = wp_parse_args( $instance, $defaults );
		extract( $instance );

		?>

		<div class="description half">
			<label for="<?php echo $this->get_field_id( 'title' ) ?>"><?php _e( 'Title', 'romo' );?></label>	
			<?php echo aq_field_input( 'title', $block_id, $title ) ?>			
		</div>

		<div class="description half last is-fontawesome">
			<label for="<?php echo $this->get_field_id( 'icon' ) ?>"><?php _e( 'Icon', 'romo' );?> *<?php _e( 'Optional', 'romo' );?></label>				
			<?php echo aq_field_select( 'icon', $block_id, romo_get_fontawesome(), $icon ) ?>
		</div>

		<div class="description half">
			<label for="<?php echo $this->get_field_id( 'map_title' ) ?>"><?php _e( 'Map Info Title', 'romo' );?></label>	
			<?php echo aq_field_input( 'map_title', $block_id, $map_title ) ?>			
		</div>

		<div class="description half last">
			<label for="<?php echo $this->get_field_id( 'coordinates' ) ?>"><?php _e( 'Coordinates', 'romo' );?> *<?php _e( 'Optional', 'romo' );?> e.g. "3.82497,103.32390"</label>				
			<?php echo aq_field_input( 'coordinates', $block_id, $coordinates ) ?>
		</div>

		<div class="description">
			<label for="<?php echo $this->get_field_id( 'address' ) ?>"><?php _e( 'Address', 'romo' );?></label>				
			<?php echo aq_field_input( 'address', $block_id, $address ) ?>
		</div>

		<div class="description half">
			<label for="<?php echo $this->get_field_id( 'height' ) ?>"><?php _e( 'Height', 'romo' );?></label>				
			<?php echo aq_field_input( 'height', $block_id, $height, 'min', 'number' ) ?> px
		</div>

		<div class="description half last">
			<label for="<?php echo $this->get_field_id( 'zoom' ) ?>"><?php _e( 'Zoom', 'romo' );?></label>				
			<?php echo aq_field_input( 'zoom', $block_id, $zoom, 'min', 'number' ) ?> 
		</div>


		<?php

	}

	function block( $instance ) {
		extract( $instance );
		wp_enqueue_script( 'google-maps-api' );
		$icon = ( ! empty( $icon ) ) ? '<i class="icon-'. $icon .'"></i>' : '';
		$output = ( ! empty( $title ) ) ? '<h4 class="widget-title"><span>'. $icon . strip_tags( $title ) .'</span></h4>' : '';	
		if( ! $address ) {
			_e( 'Address was not specified', 'romo' );
			return false;
		}		
		if( ! $coordinates ) {
			$coordinates = $this->get_map_coordinates( $address );
			if( is_array( $coordinates ) ) {
				$coordinates = $coordinates['lat'] .','. $coordinates['lng'];
			} else {
				echo $coordinates;
				return false;
			}
		}		
		$output .= '<div id="map_canvas_'. rand( 1, 100 ) .'" class="googlemap">';
			$output .= ( ! empty( $map_title ) ) ? '<input class="title" type="hidden" value="'. $map_title .'" />' : '';
			$output .= '<input class="location" type="hidden" value="'. $address .'" />';
			$output .= '<input class="coordinates" type="hidden" value="'. $coordinates .'" />';
			$output .= '<input class="zoom" type="hidden" value="'. $zoom .'" />';
			$output .= '<div class="map_canvas" style="height:'. $height .'px;"></div>';
		$output .= '</div>';
		echo $output;
	}

	/**
	 * Retrieve coordinates for an address
	 *
	 * Coordinates are cached using transients and a hash of the address
	 * @since 		0.1
	 * @link 		http://pippinsplugins.com/simple-google-maps-short-code
	 * @version 	1.0.2
	 * @access      private
	 * @return      void
	*/
	function get_map_coordinates( $address, $force_refresh = false ) {
		
	    $address_hash = md5( $address );

	    $coordinates = get_transient( $address_hash );

	    if ( $force_refresh || $coordinates === false ) {

	    	$args       = array( 'address' => urlencode( $address ), 'sensor' => 'false' );
	    	$url        = add_query_arg( $args, 'http://maps.googleapis.com/maps/api/geocode/json' );
	     	$response 	= wp_remote_get( $url );

	     	if( is_wp_error( $response ) )
	     		return;

	     	$data = wp_remote_retrieve_body( $response );

	     	if( is_wp_error( $data ) )
	     		return;

			if ( $response['response']['code'] == 200 ) {

				$data = json_decode( $data );

				if ( $data->status === 'OK' ) {

				  	$coordinates = $data->results[0]->geometry->location;

				  	$cache_value['lat'] 	= $coordinates->lat;
				  	$cache_value['lng'] 	= $coordinates->lng;
				  	$cache_value['address'] = (string) $data->results[0]->formatted_address;

				  	// cache coordinates for 3 months
				  	set_transient( $address_hash, $cache_value, 3600*24*30*3 );
				  	$data = $cache_value;

				} elseif ( $data->status === 'ZERO_RESULTS' ) {
				  	return __( 'No location found for the entered address.', 'romo' );
				} elseif( $data->status === 'INVALID_REQUEST' ) {
				   	return __( 'Invalid request. Did you enter an address?', 'romo' );
				} else {
					return __( 'Something went wrong while retrieving your map, please ensure you have entered the short code correctly.', 'romo' );
				}

			} else {
			 	return __( 'Unable to contact Google API service.', 'romo' );
			}

	    } else {
	       // return cached results
	       $data = $coordinates;
	    }

	    return $data;
	}

 	/* block header */
 	function before_block($instance) {
 		extract($instance);
 		$column_class = $first ? 'aq-first' : ''; 		
 		echo '<section id="aq-block-'.$template_id.'-'.$number.'" class="aq-block aq-block-'.$id_base.' aq_'.$size.' '.$column_class.' cf">';
 	}

 	/* block footer */
 	function after_block($instance) {
 		extract($instance);
 		echo '</section>';
 	}

}

aq_register_block( 'Romo_Gmaps_Block' );

endif;