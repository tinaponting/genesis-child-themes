<?php
/**
 * This file control custom text block class
 *
 * @package 	Romo
 * @author   	aprakasa
 * @license  	GPL-2.0+
 * @link     	http://prakasa.me/go/romo
 */

/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;

if( ! class_exists( 'Romo_Oembed_Block' ) ) :

class Romo_Oembed_Block extends AQ_Block {

	function __construct() {
		$block_options = array(
			'name' => __( 'oEmbed', 'romo' ),
			'size' => 'span6',
		);		
		parent::__construct( 'Romo_Oembed_Block', $block_options );
	}

 	function form( $instance ) {

		$defaults = array(
			'title'		=> '',
			'icon' 		=> '',
			'oembed'	=> '',
		);

		$instance = wp_parse_args( $instance, $defaults );
		extract( $instance );

		?>

		<div class="description half">
			<label for="<?php echo $this->get_field_id('title') ?>"><?php _e( 'Title', 'romo' );?></label>	
			<?php echo aq_field_input('title', $block_id, $title) ?>			
		</div>

		<div class="description half last">
			<label for="<?php echo $this->get_field_id( 'icon' ) ?>"><?php _e( 'Icon', 'romo' );?> *<?php _e( 'Optional', 'romo' );?></label>				
			<?php echo aq_field_select( 'icon', $block_id, romo_get_fontawesome(), $icon ) ?>
		</div>

		<div class="description">
			<label for="<?php echo $this->get_field_id( 'oembed' ) ?>"><?php _e( 'oEmbed URL', 'romo' );?></label>	
			<?php echo aq_field_input( 'oembed', $block_id, $oembed ) ?>
			<p class="description"><?php echo sprintf( __( 'Supported embed file can be found at %sWordPress Documentation%s.', 'romo' ), '<a target="_blank" href="http://codex.wordpress.org/Embeds#Okay.2C_So_What_Sites_Can_I_Embed_From.3F">', '</a>' );?></p>
		</div>

		<?php

	}

	function block( $instance ) {
		extract( $instance );
        $icon = ( ! empty( $icon ) ) ? '<i class="icon-'. $icon .'"></i>' : '';
        $embed = apply_filters( 'romo_block_oembed', empty( $oembed ) ? '' : $oembed );

        $output = ( ! empty( $title ) ) ? '<h4 class="widget-title"><span>'. $icon . strip_tags( $title ) .'</span></h4>' : '';
    	$output .= $embed;
		echo $output;
	}

 	/* block header */
 	function before_block( $instance ) {
 		extract($instance);
 		$column_class = $first ? 'aq-first' : ''; 		
 		echo '<section id="aq-block-'.$template_id.'-'.$number.'" class="aq-block aq-block-'.$id_base.' aq_'.$size.' '.$column_class.' cf">';
 	}

 	/* block footer */
 	function after_block($instance) {
 		extract($instance);
 		echo '</section>';
 	}

}

aq_register_block( 'Romo_Oembed_Block' );

endif;