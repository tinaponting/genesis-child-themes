<?php
/**
 * Genesis Breadcrumb
 *
 * @package 	Romo
 * @author   	aprakasa
 * @license  	GPL-2.0+
 * @link     	http://prakasa.me/go/romo
 */

/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;

if( ! class_exists( 'Romo_Breadcrumb_Block') ) :

class Romo_Breadcrumb_Block extends AQ_Block {

	function __construct() {
		$block_options = array(
			'name' 		=> 'Breadcrumb',
			'size' 		=> 'span12',
			'resizable' => 0,
		);		
		parent::__construct( 'Romo_Breadcrumb_Block', $block_options );		
	}
	
	function form( $instance ){
		extract( $instance );		
		?>
		<p class="description">
			<?php _e( 'By default, canvas tempalate didnt display breadcrumb. You can use this block to display Genesis breadcrumb', 'romo' ); ?>
		</p>
		<?php
	}
	
	function block($instance) {
		extract( $instance );
		genesis_do_breadcrumbs();
	}


	function before_block($instance) {
		extract($instance);
		return;
	}

	function after_block($instance) {
 		extract($instance);
 		return;
	}
 	
}

aq_register_block( 'Romo_Breadcrumb_Block' );

endif;