<?php
/**
 * This file control Portfolio Block Class
 *
 * @package 	Romo
 * @author   	aprakasa
 * @license  	GPL-2.0+
 * @link     	http://prakasa.me/go/romo
 */

/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;

if( ! class_exists( 'Romo_Portfolio_Block') ) :

class Romo_Portfolio_Block extends AQ_Block {

	function __construct() {

		$block_options = array(
			'name' 		=> __( 'Portfolio', 'romo' ),
			'size' 		=> 'span12',
			'resizable'	=> 0
		);
		
		parent::__construct( 'Romo_Portfolio_Block', $block_options );

	}

	function form( $instance ){
		$defaults = array (
			'title'			=> '',
			'icon'			=> '',
			'portfolio_num' => '8',
			'column'		=> 'span3',
			'filter'		=> false,
			'portfolio_text'=> 'See more portfolio &rarr;',
		);

		$instance = wp_parse_args( $instance, $defaults );
		extract( $instance );

		$columns = array(
			'span6' => __( 'Two columns', 'romo' ),
			'span4'	=> __( 'Three columns', 'romo' ),
			'span3'	=> __( 'Four columns', 'romo' ),
		);

		?>
		<div class="description half">
			<label for="<?php echo $this->get_field_id( 'title' ) ?>"><?php _e( 'Title', 'romo' );?></label>	
			<?php echo aq_field_input('title', $block_id, $title) ?>			
		</div>

		<div class="description half last">
			<label for="<?php echo $this->get_field_id( 'icon' ) ?>"><?php _e( 'Icon', 'romo' );?> *<?php _e( 'Optional', 'romo' );?></label>				
			<?php echo aq_field_select( 'icon', $block_id, romo_get_fontawesome(), $icon ) ?>
		</div>

        <div class="description half">
            <label for="<?php echo $this->get_field_id( 'column' ) ?>"><?php _e( 'Portfolio Column', 'romo' );?></label>               
            <?php echo aq_field_select( 'column', $block_id, $columns, $column ) ?>
        </div>

        <div class="description half last">
            <label for="<?php echo $this->get_field_id( 'portfolio_num' ) ?>"><?php _e( 'Number of Portfolio to Show', 'Romo' );?></label>               
            <?php echo aq_field_select( 'portfolio_num', $block_id, romo_get_number(), $portfolio_num ) ?>
        </div>

		<div class="description half">
			<label for="<?php echo $this->get_field_id( 'portfolio_text' ) ?>"><?php _e( 'Text link for portfolio archive', 'romo' );?></label>	
			<?php echo aq_field_input('portfolio_text', $block_id, $portfolio_text) ?>			
		</div>

		<div class="description half last">
			<?php echo aq_field_checkbox( 'filter', $block_id, $filter ) ?>&nbsp;&nbsp;
			<label for="<?php echo $this->get_field_id( 'filter' ) ?>"><?php _e( 'Display portfolio filter.', 'romo' );?></label>
		</div>

		<?php
	}

	function block( $instance ) {
		global $wp_query;

		extract( $instance );

		wp_enqueue_script( 'jquery-isotope' );

        $icon = ( ! empty( $icon ) ) ? '<i class="icon-'. $icon .'"></i>' : '';
        $output = ( ! empty( $title ) ) ? '<h4 class="widget-title"><span>'. $icon . strip_tags( $title ) .'</span></h4>' : '';

        if ( ! empty( $filter ) ) {
		    $terms = get_terms( 'portfolio', array( 'hide_empty' => '1' ) );
		    $output .= '<div class="portfolio-filter">';
		        $output .= '<ul>';
		            $output .= '<li><a href="#" data-filter="*" class="active">'. __( 'All', 'romo' ) .'</a></li>';
		        foreach ( $terms as $term ) : 
		            $output .= '<li><a href="#" data-filter=".portfolio-'. $term->slug .'"><span>'. $term->name .'</span></a></li>';
		        endforeach;
		        $output .= '</ul>';
		    $output .= '</div>';
        }

        $output .= '<div class="isotope-container">';

		$wp_query 	= new WP_Query( array(
			'post_type'					=> 'portfolio_item',
			'showposts'					=> $portfolio_num,
			'no_found_rows' 			=> true,
    		'update_post_term_cache' 	=> false,
    		'update_post_meta_cache' 	=> false ) );

			if ( have_posts() ) : 
				while ( have_posts() ) : the_post();
					$featured  	= genesis_get_image( array( 'format' => 'url', 'size' => 'romo-featured' ) );
				    $images    	= genesis_get_image( array( 'format' => 'url', 'size' => 'large' ) );
				    $post_class = array_diff( get_post_class(), array( 'span6', 'span4', 'span3' ) );

				    $placeholder = ROMO_ASSETS_URI .'images/portfolio.png';
				    $placeholder = ( function_exists( 'jetpack_photon_url' ) ) ? jetpack_photon_url( $placeholder ) : $placeholder;

					$output .= '<article class="widget-portfolio '. implode( ' ', $post_class ) .' '. $column .'">';
				    if ( has_post_thumbnail() || genesis_get_image_id() ) {
				        $output .= '<div class="portfolio-thumbnail">';
				            $output .= '<img src="'. esc_url( $featured ) .'" alt="'. get_the_title() .'"/>';
				            $output .= '<a href="'. get_permalink() .'" class="portfolio-link" title="'. get_the_title() .'"></a>';
				        $output .= '</div>';
				    } else {
				        $output .= '<div class="no-thumbnail">';
				            $output .= '<img src="'. $placeholder .'" alt="'. get_the_title() .'" />';
				            $output .= '<a href="'. get_permalink() .'" class="portfolio-link" title="'. get_the_title() .'"></a>';
				        $output .= '</div>';
				    }
					$output .= '</article>';
				endwhile;
			endif;

			$output .= '</div>';

	    if ( ! empty( $portfolio_text ) )
			$output .= '<a class="more-portfolio" href="'. get_post_type_archive_link( 'portfolio_item' ) .'">'. esc_attr( $portfolio_text ) .'</a>';

		echo $output;

		wp_reset_query();

	}

 	/* block header */
 	function before_block($instance) {
 		extract($instance);
 		$column_class = $first ? 'aq-first' : ''; 		
 		echo '<section id="aq-block-'.$template_id.'-'.$number.'" class="aq-block aq-block-'.$id_base.' aq_'.$size.' '.$column_class.' cf">';
 	}

 	/* block footer */
 	function after_block($instance) {
 		extract($instance); 		
 		echo '</section>';
 	}

}

aq_register_block( 'Romo_Portfolio_Block' );

endif;