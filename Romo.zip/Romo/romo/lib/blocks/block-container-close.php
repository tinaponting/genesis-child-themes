<?php
/**
 * Close wrapper/container
 *
 * @package 	Romo
 * @author   	aprakasa
 * @license  	GPL-2.0+
 * @link     	http://prakasa.me/go/romo
 */

/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;

if( ! class_exists( 'Romo_Close_Container_Block') ) :

class Romo_Close_Container_Block extends AQ_Block {

	function __construct() {
		$block_options = array(
			'name' 		=> 'Container (close)',
			'size' 		=> 'span12',
			'resizable' => 0,
		);		
		parent::__construct( 'Romo_Close_Container_Block', $block_options );		
	}
	
	function form( $instance ){
		extract( $instance );		
		?>
		<p class="description">
			<?php _e( 'There is no settings in here. Just make it sure to add this block if you use container (open).', 'romo' ); ?>
		</p>
		<?php
	}
	
	function block($instance) {
		extract( $instance );
		echo "</div>\n</div>";
	}


	function before_block($instance) {
		extract($instance);
		return;
	}

	function after_block($instance) {
 		extract($instance);
 		return;
	}
 	
}

aq_register_block( 'Romo_Close_Container_Block' );

endif;