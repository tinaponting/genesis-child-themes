<?php
/**
 * This file control Featured Products Block
 *
 * @package 	Romo
 * @author   	aprakasa
 * @license  	GPL-2.0+
 * @link     	http://prakasa.me/go/romo
 */

/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;

if( ! class_exists( 'Romo_Featured_Products' ) ) :

class Romo_Featured_Products extends AQ_Block {
	
	//set and create block
	function __construct() {
		$block_options = array(
			'name' 		=> __( 'Featured Product', 'romo' ),
			'size' 		=> 'span12',
		);		
		parent::__construct( 'Romo_Featured_Products', $block_options );
	}
	
	function form($instance) {		
		$defaults = array(
			'title' 		=> 'Featured Products',
			'icon'			=> '',
			'products' 		=> '4',
			'columns'		=> '4',
			'item_order'	=> 'DESC',
			'item_orderby'	=> 'date',
		);
		$instance = wp_parse_args($instance, $defaults);
		extract($instance);
		if( ! class_exists( 'WooCommerce' ) ) {
			echo sprintf( __( 'Sorry, you cannot use this block until you install and activate %s plugin.', 'romo' ), '<a href="http://wordpress.org/extend/plugins/woocommerce/">WooCommerce</a>');
			return false;
		}
        $product_col = array(
            '1'	=> __( '1 column', 'romo' ),
            '2' => __( '2 columns', 'romo' ),
            '3' => __( '3 columns', 'romo' ),
            '4' => __( '4 columns', 'romo' ),
            '6' => __( '6 columns', 'romo' ) );
        $product_order = array(
    		'ASC' 	=> __( 'Ascending', 'romo' ),
			'DESC' 	=> __( 'Descending', 'romo' ) );
        $product_orderby = array(
			'title'	=> __( 'Title', 'romo' ),
			'date'	=> __( 'Date', 'romo' ),
			'rand'	=> __( 'Random', 'romo' ) );		
		?>
		<div class="description half">
			<label for="<?php echo $this->get_field_id('title') ?>"><?php _e( 'Title', 'romo' );?></label>	
			<?php echo aq_field_input('title', $block_id, $title) ?>			
		</div>

		<div class="description half last is-fontawesome">
			<label for="<?php echo $this->get_field_id( 'icon' ) ?>"><?php _e( 'Icon', 'romo' );?> *<?php _e( 'Optional', 'romo' );?></label>				
			<?php echo aq_field_select( 'icon', $block_id, romo_get_fontawesome(), $icon ) ?>
		</div>

		<div class="description fourth">
	        <label for="<?php echo $this->get_field_id( 'products' ) ?>"><?php _e( 'Poducts to show', 'romo' );?>:</label>
            <?php echo aq_field_select( 'products', $block_id, romo_get_number(), $products ) ?>
		</div>

		<div class="description fourth">
	        <label for="<?php echo $this->get_field_id( 'columns' ) ?>"><?php _e( 'Columns', 'romo' );?>:</label>
            <?php echo aq_field_select( 'columns', $block_id, $product_col, $columns ) ?>
		</div>

		<div class="description fourth">
	        <label for="<?php echo $this->get_field_id( 'item_order' ) ?>"><?php _e( 'Order', 'romo' );?>:</label>
            <?php echo aq_field_select( 'item_order', $block_id, $product_order, $item_order ) ?>
		</div>

		<div class="description fourth last">
	        <label for="<?php echo $this->get_field_id( 'item_orderby' ) ?>"><?php _e( 'Order by', 'romo' );?>:</label>
            <?php echo aq_field_select( 'item_orderby', $block_id, $product_orderby, $item_orderby ) ?>
		</div>
		<?php
	}
	
	function block($instance) {
		extract($instance);
		if ( ! class_exists( 'woocommerce' ) )
			return;
        $output = '';
        $icon = ( ! empty( $icon ) ) ? '<i class="icon-'. $icon .' icon-large"></i>' : '';
        $output .= ( ! empty( $title ) ) ? '<h4 class="widget-title">'. $icon .'<span>'. strip_tags( $title ) .'</span></h4>' : '';
		if ( $products )
			$output .= do_shortcode('[featured_products per_page="'. $products .'" columns="'. $columns .'" order="'. $item_order .'" orderby="'. $item_orderby .'"]');
		echo $output;
	}

 	/* block header */
 	function before_block($instance) {
 		extract($instance);
 		$column_class = $first ? 'aq-first' : ''; 		
 		echo '<section id="aq-block-'.$template_id.'-'.$number.'" class="aq-block block-col-'. $columns .' aq-block-'.$id_base.' aq_'.$size.' '.$column_class.' cf">';
 	}

 	/* block footer */
 	function after_block($instance) {
 		extract($instance);
 		echo '</section>';
 	}
	
}

aq_register_block( 'Romo_Featured_Products' );

endif;