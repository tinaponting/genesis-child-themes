<?php
/**
 * This file control Featured Block Class
 *
 * @package 	Romo
 * @author   	aprakasa
 * @license  	GPL-2.0+
 * @link     	http://prakasa.me/go/romo
 */

/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;

if( ! class_exists( 'Romo_Recent_Posts') ) :

class Romo_Recent_Posts extends AQ_Block {

	function __construct() {

		$block_options = array(
			'name' 	=> __( 'Recent Posts', 'romo' ),
			'size' 	=> 'span4',
		);
		
		parent::__construct( 'Romo_Recent_Posts', $block_options );

	}
	
	function form( $instance ){

		$defaults = array (
			'title'			=> '',
			'icon'			=> '',
			'post_number'	=> '',
		);

		$instance = wp_parse_args( $instance, $defaults );
		extract( $instance );

	?>

		<p class="description half">
			<label for="<?php echo $this->get_field_id( 'title' ) ?>"><?php _e( 'Title', 'romo' );?></label>	
			<?php echo aq_field_input('title', $block_id, $title) ?>			
		</p>

		<p class="description">
			<label for="<?php echo $this->get_field_id( 'icon' ) ?>"><?php _e( 'Icon', 'romo' );?> *<?php _e( 'Optional', 'romo' );?></label>				
			<?php echo aq_field_select( 'icon', $block_id, romo_get_fontawesome(), $icon ) ?>
		</p>

		<div class="description">
			<label for="<?php echo $this->get_field_id( 'post_number' ) ?>"><?php _e( 'Number of post to show', 'romo' );?> : </label>
			<?php echo aq_field_input( 'post_number', $block_id, $post_number, $size = 'min', $type = 'number' ) ?>
		</div>

	<?php
		
	}
	
	function block( $instance ) {
		global $wp_query;

		extract( $instance );

        $icon = ( ! empty( $icon ) ) ? '<i class="icon-'. $icon .'"></i>' : '';
        $output = ( ! empty( $title ) ) ? '<h4 class="widget-title"><span>'. $icon . strip_tags( $title ) .'</span></h4>' : '';

		if ( empty( $post_number ) )
			return;
		$wp_query 	= new WP_Query( array(
			'showposts'					=> $post_number,
			'no_found_rows' 			=> true,
    		'update_post_term_cache' 	=> false,
    		'update_post_meta_cache' 	=> false ) );

		if ( have_posts() ) : 
			while ( have_posts() ) : the_post();
				$img = genesis_get_image( array( 
						'format' 	=> 'url',
						'size' 		=> 'romo-thumbnail' ) );
				$output .= '<article class="recent-posts cf" itemscope="itemscope" itemtype="http://schema.org/BlogPosting">';
					if ( ! empty( $img ) )
						$output .= sprintf( '<a class="alignleft" href="%1$s"><img src="%2$s" alt="%3$s" title="%3$s" /></a>', get_permalink(), $img, get_the_title() );
					$output .= '<header class="entry-header">';
						$output .= '<h2 class="entry-title">';
							$output .= '<a href="'. get_permalink().'" title="'. get_the_title() .'">'. get_the_title() .'</a>';
						$output .= '</h2>';
						$output .= '<p class="entry-meta">';
							$output .= do_shortcode( '[post_date] ' . __( 'by', 'genesis' ) . ' [post_author_posts_link] [post_comments] [post_edit]' );
						$output .= '</p>';
					$output .= '</header>';
				$output .= '</article>';
			endwhile;
		endif;
		echo $output;
		wp_reset_query();
	}

 	/* block header */
 	function before_block($instance) {
 		extract($instance);
 		$column_class = $first ? 'aq-first' : ''; 		
 		echo '<section id="aq-block-'.$template_id.'-'.$number.'" class="aq-block aq-block-'.$id_base.' aq_'.$size.' '.$column_class.' cf">';
 	}

 	/* block footer */
 	function after_block($instance) {
 		extract($instance); 		
 		echo '</section>';
 	}
 	
}

aq_register_block( 'Romo_Recent_Posts' );

endif;