<?php
/**
 * This file control custom text action with button
 *
 * @package 	Romo
 * @author   	aprakasa
 * @license  	GPL-2.0+
 * @link     	http://prakasa.me/go/romo
 */

/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;

if( ! class_exists( 'Romo_Tabs_Block' ) ) :

class Romo_Tabs_Block extends AQ_Block {

    function __construct() {
        $block_options = array(
            'name' => 'Tabs &amp; Toggles',
            'size' => 'span6',
        );
        parent::__construct( 'Romo_Tabs_Block', $block_options );
        add_action( 'wp_ajax_aq_block_tabs_add_new', array( $this, 'add_tab' ) );            
    }
    
    function form( $instance ) {
    
        $defaults = array(
            'title' => '',
            'icon'  => '',
            'tabs'  => array(
                1   => array(
                    'title'     => 'My New Tab',
                    'icon'      => '',
                    'content'   => 'My tab contents',
                )
            ),
            'type'  => 'tab',
        );
        
        $instance = wp_parse_args( $instance, $defaults );
        extract( $instance );
        
        $tab_types = array(
            'tab'           => 'Tabs',
            'toggle'        => 'Toggles',
            'accordion'     => 'Accordion',
        );
        
        ?>
        <div class="description half">
            <label for="<?php echo $this->get_field_id( 'title' ) ?>"><?php _e( 'Title', 'romo' );?> *<?php _e( 'Optional', 'romo' );?></label>
            <?php echo aq_field_input( 'title', $block_id, $title ) ?>
        </div>
		<div class="description half last is-fontawesome">
			<label for="<?php echo $this->get_field_id( 'icon' ) ?>"><?php _e( 'Icon', 'romo' );?> *<?php _e( 'Optional', 'romo' );?></label>				
			<?php echo aq_field_select( 'icon', $block_id, romo_get_fontawesome(), $icon ) ?>
		</div>
        <div class="clear"></div>
        <div class="description cf">
            <ul id="aq-sortable-list-<?php echo $block_id ?>" class="aq-sortable-list" rel="<?php echo $block_id ?>">
                <?php
                $tabs = is_array( $tabs) ? $tabs : $defaults['tabs'];
                $count = 1;
                foreach( $tabs as $tab ) {        
                    $this->tabs( $tab, $count );
                    $count++;
                }
                ?>
            </ul>
            <a href="#" rel="tabs" class="aq-sortable-add-new button"><?php _e( 'Add New', 'romo' );?></a>
        </div>
        <div class="description">
            <label for="<?php echo $this->get_field_id( 'type' ) ?>"><?php _e( 'Tabs Style', 'romo' );?></label>
            <?php echo aq_field_select( 'type', $block_id, $tab_types, $type ) ?>
        </div>
        <?php
    }
    
    function tabs( $tab = array(), $count = 0 ) {

        $defaults = array (
            'title'     => '',
            'icon'      => '',
            'content'   => ''
        );

        $tab = wp_parse_args( $tab, $defaults );
                
        ?>
        <li id="<?php echo $this->get_field_id( 'tab' ) ?>-sortable-item-<?php echo $count ?>" class="sortable-item" rel="<?php echo $count ?>">
                
            <div class="sortable-head cf">
                <div class="sortable-title">
                    <strong><?php echo $tab['title'] ?></strong>
                </div>
                <div class="sortable-handle">
                    <a href="#">Open / Close</a>
                </div>
            </div>
                
            <div class="sortable-body">

                <p class="tab-desc description">
                    <label for="<?php echo $this->get_field_id( 'tabs' ) ?>-<?php echo $count ?>-title"><?php _e( 'Title', 'romo' );?></label>
                    <input type="text" id="<?php echo $this->get_field_id('tabs') ?>-<?php echo $count ?>-title" class="input-full" name="<?php echo $this->get_field_name('tabs') ?>[<?php echo $count ?>][title]" value="<?php echo $tab['title'] ?>" />
                </p>

                <p class="tab-desc description">
                    <label for="<?php echo $this->get_field_id( 'tabs' ) ?>-<?php echo $count ?>-icon"><?php _e( 'Icon', 'romo' );?></label>
                    <select id="<?php echo $this->get_field_id( 'tabs' ) ?>-<?php echo $count ?>-icon" name="<?php echo $this->get_field_name('tabs') ?>[<?php echo $count ?>][icon]">
                        <?php
                        foreach ( romo_get_fontawesome() as $fonts => $font ) {
                           printf( '<option value="%s" %s>%s</option>', $fonts, selected( $font, $tab['icon'], 1), $font );
                        }
                        ?>
                    </select>
                </p>

                <p class="tab-desc description">
                    <label for="<?php echo $this->get_field_id( 'tabs' ) ?>-<?php echo $count ?>-content"><?php _e( 'Content', 'romo' );?></label>
                    <textarea id="<?php echo $this->get_field_id( 'tabs' ) ?>-<?php echo $count ?>-content" class="textarea-full" name="<?php echo $this->get_field_name('tabs') ?>[<?php echo $count ?>][content]" rows="5"><?php echo $tab['content'] ?></textarea>
                </p>

                <p class="tab-desc description"><a href="#" class="sortable-delete"><?php _e( 'Delete', 'romo' );?></a></p>

            </div>
                
        </li>
        <?php
    }
    
    function block( $instance ) {

        extract( $instance );

        $output = '';

        $icon = ( ! empty( $icon ) ) ? '<i class="icon-'. $icon .' icon-large"></i>' : '';
        $output .= ( ! empty( $title ) ) ? '<h4 class="aq-block-title">'. $icon .'<span>'. strip_tags( $title ) .'</span></h4>' : '';

        if( $type == 'tab' ) {

            wp_enqueue_script( 'jquery-ui-tabs' );
            $output .= '<div id="aq_block_tabs_'. rand( 1, 100 ) .'" class="aq_block_tabs">';
                $output .= '<div class="aq-tab-inner">';
                    $output .= '<ul class="aq-nav cf">';                
                    $i = 1;
                    foreach( $tabs as $tab ){
                        $use_icon = ( !empty( $tab['icon'] ) ) ? '<i class="icon-'. $tab['icon'] .'"></i>' : '';
                        $tab_selected = $i == 1 ? 'ui-tab-active' : '';
                        $output .= '<li class="'.$tab_selected.'"><a href="#aq-tab-'. sanitize_title( $tab['title'] ) . $i .'">'.$use_icon.' ' . $tab['title'] . '</a></li>';
                        $i++;
                    }                
                    $output .= '</ul>';
                    
                    $i = 1;
                    foreach( $tabs as $tab ) {
                        $tab_content = apply_filters( 'romo_tab_content', htmlspecialchars_decode( $tab['content'] ) );
                        $tabs_hide = $i == 1 ? '' : '';                        
                        $output .= '<div id="aq-tab-'. sanitize_title( $tab['title'] ) . $i .'" class="aq-tab '.$tabs_hide.'">';
                        $output .= wpautop( $tab_content );
                        $output .= '</div>';
                        $i++;
                    }
                
                $output .= '</div>';
            $output .= '</div>';
                
        } elseif ( $type == 'toggle' ) {

            $count = count($tabs);
            $i = 1;                
            $output .= '<div id="aq_block_toggles_wrapper_'.rand( 1,100 ).'" class="aq_block_toggles_wrapper">';            
            foreach( $tabs as $tab ){
                $tab_content = apply_filters( 'romo_tab_content', htmlspecialchars_decode( $tab['content'] ) );
                $child = '';
                if($i == 1) $child = 'first-child';
                if($i == $count) $child = 'last-child';
                $i++;
                $use_icon = ( !empty( $tab['icon'] ) ) ? '<i class="icon-'. $tab['icon'] .' icon-large"></i>' : '';
                $output  .= '<div class="aq_block_toggle '. $child .'">';
                    $output .= '<h4 class="tab-head">'.$use_icon.'<span>'. $tab['title'] .'</span></h4>';
                    $output .= '<div class="arrow"><i class="icon-chevron-down"></i></div>';
                    $output .= '<div class="tab-body hide cf">';
                    $output .= wpautop( $tab_content );
                    $output .= '</div>';
                $output .= '</div>';
            }            
            $output .= '</div>';

        } elseif ( $type == 'accordion' ) {
                
            $count = count($tabs);
            $i = 1;                
            $output .= '<div id="aq_block_accordion_wrapper_'.rand( 1,100 ).'" class="aq_block_accordion_wrapper">';                
            foreach( $tabs as $tab ){
                $tab_content = apply_filters( 'romo_tab_content', htmlspecialchars_decode( $tab['content'] ) );
                $open = $i == 1 ? 'open' : 'hide';                    
                $child = '';
                if($i == 1) $child = 'first-child';
                if($i == $count) $child = 'last-child';
                $i++;
                $use_icon = ( !empty( $tab['icon'] ) ) ? '<i class="icon-'. $tab['icon'] .' icon-large"></i>' : '';

                $output  .= '<div class="aq_block_accordion '. $child .'">';
                    $output .= '<h4 class="tab-head">'. $use_icon .'<span>'. $tab['title'] .'</span></h4>';
                    $output .= '<div class="arrow"><i class="icon-chevron-down"></i></div>';
                    $output .= '<div class="tab-body '. $open .' cf">';
                    $output .= wpautop( $tab_content );
                    $output .= '</div>';
                $output .= '</div>';
            }                
            $output .= '</div>';
            
        }

        echo $output;

    }
    
    /* AJAX add tab */
    function add_tab() {
        $nonce = $_POST['security'];    
        if ( ! wp_verify_nonce( $nonce, 'aqpb-settings-page-nonce' ) ) die('-1');
        
        $count = isset( $_POST['count'] ) ? absint( $_POST['count'] ) : false;
        $this->block_id = isset($_POST['block_id']) ? $_POST['block_id'] : 'aq-block-9999';
        
        //default key/value for the tab
        $tab = array(
            'title'     => 'New Tab',
            'icon'      => '',
            'content'   => ''
        );
        
        if($count) {
            $this->tabs( $tab, $count );
        } else {
            die(-1);
        }
        
        die();
    }
    
    function update( $new_instance, $old_instance ) {
        $new_instance = aq_recursive_sanitize( $new_instance );
        return $new_instance;
    }

    /* block header */
    function before_block($instance) {
        extract($instance);
        $column_class = $first ? 'aq-first' : '';       
        echo '<section id="aq-block-'.$template_id.'-'.$number.'" class="aq-block aq-block-'.$id_base.' aq_'.$size.' '.$column_class.' cf">';
    }

    /* block footer */
    function after_block($instance) {
        extract($instance);
        echo '</section>';
    }

}

aq_register_block( 'Romo_Tabs_Block' );

endif;