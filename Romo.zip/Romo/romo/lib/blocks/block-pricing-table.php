<?php
/**
 * This file control pricing table block class
 *
 * @package 	Romo
 * @author   	aprakasa
 * @license  	GPL-2.0+
 * @link     	http://prakasa.me/go/romo
 */

/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;

if( ! class_exists( 'Romo_Pricing_Block' ) ) :

class Romo_Pricing_Block extends AQ_Block {

	function __construct() {
		$block_options = array(
			'name' => __( 'Pricing Table', 'romo' ),
			'size' => 'span4',
		);
		
		parent::__construct( 'Romo_Pricing_Block', $block_options );
	}

 	function form( $instance ) {

		$defaults = array(
			'title'			=> '',
			'sub_title'		=> '',
			'price'			=> '$9.99',
			'duration'		=> '/month',
			'features'		=> 'One line per Features',
			'header_bg' 	=> '#eaeaea',
			'header_text'	=> '#444444',
			'btn_text'		=> 'Register Now',
			'btn_icon'		=> '',
			'btn_link'		=> '',
			'btn_target'	=> '',
			'icon_position'	=> 'right',
			'btn_color' 	=> '#E74C3C',
		);

		$instance = wp_parse_args( $instance, $defaults );
		extract( $instance );

		$position = array(
			'left' => __( 'Left', 'romo' ),
			'right' => __( 'Right', 'romo' ) );
		$target = array(
			'_self' 	=> __( 'Same Tab/Window', 'romo' ),
			'_blank'	=> __( 'New Tab/Window', 'romo' ) );

		?>

		<div class="description half">
			<label for="<?php echo $this->get_field_id( 'title' ) ?>"><?php _e( 'Title', 'romo' );?></label>	
			<?php echo aq_field_input( 'title', $block_id, $title ) ?>			
		</div>

		<div class="description half last">
			<label for="<?php echo $this->get_field_id( 'sub_title' ) ?>"><?php _e( 'Sub Title', 'romo' );?></label>	
			<?php echo aq_field_input( 'sub_title', $block_id, $sub_title ) ?>			
		</div>

		<div class="description half">
			<label for="<?php echo $this->get_field_id( 'price' ) ?>"><?php _e( 'Price', 'romo' );?></label>	
			<?php echo aq_field_input( 'price', $block_id, $price ) ?>			
		</div>

		<div class="description half last">
			<label for="<?php echo $this->get_field_id( 'duration' ) ?>"><?php _e( 'Per', 'romo' );?></label>	
			<?php echo aq_field_input( 'duration', $block_id, $duration ) ?>			
		</div>

		<div class="description third last">
			<label for="<?php echo $this->get_field_id( 'header_text' ) ?>"><?php _e( 'Header text color', 'romo' );?></label>
			<?php echo aq_field_color_picker( 'header_text', $block_id, $header_text ); ?>
		</div>

		<div class="description third last">
			<label for="<?php echo $this->get_field_id( 'header_bg' ) ?>"><?php _e( 'Header color', 'romo' );?></label>
			<?php echo aq_field_color_picker( 'header_bg', $block_id, $header_bg ); ?>
		</div>

		<div class="description">
			<label for="<?php echo $this->get_field_id( 'features' ) ?>"><?php _e( 'Features', 'romo' );?></label>
			<?php echo aq_field_textarea( 'features', $block_id, $features ) ?>			
		</div>

		<p class="description half">
			<label for="<?php echo $this->get_field_id('btn_text') ?>"><?php _e( 'Button Text', 'romo' );?></label>
			<?php echo aq_field_input( 'btn_text', $block_id, $btn_text ) ?>			
		</p>

		<p class="description half last">
			<label for="<?php echo $this->get_field_id('btn_link') ?>"><?php _e( 'Button Link', 'romo' );?></label>
			<?php echo aq_field_input( 'btn_link', $block_id, $btn_link ) ?>			
		</p>

		<p class="description half">
			<label for="<?php echo $this->get_field_id( 'btn_icon' ) ?>"><?php _e( 'Button Icon', 'romo' );?></label>				
			<?php echo aq_field_select( 'btn_icon', $block_id, romo_get_fontawesome(), $btn_icon ) ?>
		</p>

		<p class="description half last">
			<label for="<?php echo $this->get_field_id( 'btn_target' ) ?>"><?php _e( 'Button link target.', 'romo' );?></label>
			<?php echo aq_field_select( 'btn_target', $block_id, $target, $btn_target ) ?>
		</p>

		<p class="description half">
			<label for="<?php echo $this->get_field_id( 'icon_position' ) ?>"><?php _e( 'Icon position', 'romo' );?> *<?php _e( 'Optional', 'romo' );?></label>				
			<?php echo aq_field_select( 'icon_position', $block_id, $position, $icon_position ) ?>
		</p>

		<div class="description half last">
			<label for="<?php echo $this->get_field_id( 'btn_color' ) ?>"><?php _e( 'Button color', 'romo' );?></label>
			<?php echo aq_field_color_picker( 'btn_color', $block_id, $btn_color ); ?>
		</div>

		<?php

	}

	function block( $instance ) {
		extract( $instance );

		$output = '';

		$output .= '<div class="romo-pricing-table">';
			$output .= '<div class="romo-pricing-header" style="background-color:'. $header_bg .';color:'. $header_text .'">';
				$duration = ( ! empty( $duration ) ) ? ' <span>'. trim( $duration ) .'</span>' : '';
				if ( ! empty( $title ) )
					$output .= '<h4 class="pricing-title"><span>' . esc_attr( $title ) . '</span></h4>';
				if ( ! empty( $sub_title ) )
					$output .= '<p class="sub-title">' . esc_attr( $sub_title ) . '</p>';
				if ( ! empty( $price ) )
					$output .= '<p class="pricing-plan">' . esc_attr( $price ) . $duration .'</p>';
			$output .= '</div>';

			$output .= '<div class="romo-pricing-body">';
				$features = ( ! empty( $features ) ) ? explode( "\n", trim( $features ) ) : array();
				if ( ! empty( $features ) ) {
					$output .= '<ul>';
						$i= 0;
						foreach ( $features as $feature ) {
							$i++;
							$class = ( $i % 2 == 0 ) ? ' class="even"' : ' class="odd"';
							$output .= '<li'. $class .'>'. do_shortcode( htmlspecialchars_decode( romo_strip_autoformat( $feature ) ) ) .'</li>';
						}
					$output .= '</ul>';
				}

			$output .= '</div>';
			$output .= '<div class="romo-pricing-footer">';
				if ( ! empty( $btn_text ) && ! empty( $btn_link ) ) {
					$icon_left 	= ( ! empty( $btn_icon ) && $icon_position == 'left' ) ? '<span class="icon-'. $btn_icon .' icon-large in-left"></span>' : '';
					$icon_right = ( ! empty( $btn_icon ) && $icon_position == 'right' ) ? '<span class="icon-'. $btn_icon .' icon-large in-right"></span>' : '';
					$output .= '<a href="'. esc_url( $btn_link ) .'" target="'. $btn_target .'" class="callout-button" style="background-color:'. $btn_color .'">'. $icon_left .'<span class="button-text">'. esc_attr( $btn_text ) .'</span>'. $icon_right .'</a>';	
				}
			$output .= '</div>';

		$output .= '</div>';

		echo $output;	
	}

 	/* block header */
 	function before_block($instance) {
 		extract($instance);
 		$column_class = $first ? 'aq-first' : ''; 		
 		echo '<section id="aq-block-'.$template_id.'-'.$number.'" class="aq-block aq-block-'.$id_base.' aq_'.$size.' '.$column_class.' cf">';
 	}

 	/* block footer */
 	function after_block($instance) {
 		extract($instance);
 		echo '</section>';
 	}

}

aq_register_block( 'Romo_Pricing_Block' );

endif;