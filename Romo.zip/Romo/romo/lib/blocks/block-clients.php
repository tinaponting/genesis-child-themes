<?php
/**
 * This file control client list
 *
 * @package     Romo
 * @author      aprakasa
 * @license     GPL-2.0+
 * @link        http://prakasa.me/go/romo
 */

/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;

if( ! class_exists( 'Romo_Clients_Block') ) :

class Romo_Clients_Block extends AQ_Block {

	function __construct() {
		$block_options = array(
			'name'       => __( 'Clients list', 'romo' ),
			'size'       => 'span12',
            'resizable'  => 0,
		);
		
		parent::__construct( 'Romo_Clients_Block', $block_options );
		/** AJAX */
		add_action( 'wp_ajax_aq_block_clients_add_new', array( $this, 'add_client' ) );
	}

 	function form( $instance ) {

        $defaults = array(
            'title' 	=> '',
            'icon'      => '',
            'clients' 	=> array(
				1  => array(
				    'company_name'	=> 'Client/Company Name',
				    'company_logo' 	=> '',
				    'company_link'	=> '',
				)
            ),
            'columns'  => '',
        );

        $instance = wp_parse_args( $instance, $defaults );
        extract( $instance );
        ?>

        <div class="description half">
            <label for="<?php echo $this->get_field_id( 'title' ) ?>"><?php _e( 'Title', 'romo' );?> *<?php _e( 'Optional', 'romo' );?></label>
            <?php echo aq_field_input( 'title', $block_id, $title ) ?>
        </div>

        <div class="description half last">
            <label for="<?php echo $this->get_field_id( 'icon' ) ?>"><?php _e( 'Icon', 'romo' );?> *<?php _e( 'Optional', 'romo' );?></label>               
            <?php echo aq_field_select( 'icon', $block_id, romo_get_fontawesome(), $icon ) ?>            
        </div>
        <div class="clear"></div>
        <div class="description cf">
            <ul id="aq-sortable-list-<?php echo $block_id ?>" class="aq-sortable-list" rel="<?php echo $block_id ?>">
                <?php
                $clients = is_array( $clients) ? $clients : $defaults['clients'];
                $count = 1;
                foreach( $clients as $client ) {        
                    $this->clients( $client, $count );
                    $count++;
                }
                ?>
            </ul>
            <a href="#" rel="clients" class="aq-sortable-add-new button"><?php _e( 'Add Client', 'romo' );?></a>
        </div>

        <?php
 	}

 	function clients( $client = array(), $count = 0 ) {

        $defaults = array (
		    'company_name'	=> 'Client/Company Name',
		    'company_logo' 	=> '',
		    'company_link'	=> '',
        );

 		$client = wp_parse_args( $client, $defaults );
 		?>
		<li id="<?php echo $this->get_field_id( 'tab' ) ?>-sortable-item-<?php echo $count ?>" class="sortable-item" rel="<?php echo $count ?>">
            <div class="sortable-head cf">
                <div class="sortable-title">
                    <strong><?php echo $client['company_name'] ?></strong>
                </div>
                <div class="sortable-handle">
                    <a href="#">Open / Close</a>
                </div>
            </div>
            <div class="sortable-body">
                <div class="tab-desc description">
                    <label for="<?php echo $this->get_field_id( 'clients' ) ?>-<?php echo $count ?>-company_name"><?php _e( 'Company Name', 'romo' );?></label>
                    <input type="text" id="<?php echo $this->get_field_id('clients') ?>-<?php echo $count ?>-company_name" class="input-full" name="<?php echo $this->get_field_name( 'clients' ) ?>[<?php echo $count ?>][company_name]" value="<?php echo $client['company_name'] ?>" />
                </div>

                <div class="description">
                    <label for="<?php echo $this->get_field_id('clients') ?>-<?php echo $count ?>-company_logo"><?php _e( 'Client Logo', 'romo'  );?></label>
                    <input type="text" id="<?php echo $this->get_field_id('clients') ?>-<?php echo $count ?>-company_logo" class="input-full input-upload" value="<?php echo $client['company_logo'] ?>" name="<?php echo $this->get_field_name('clients') ?>[<?php echo $count ?>][company_logo]">
                    <a href="#" class="aq_upload_button button" rel="image"><?php _e( 'Upload', 'romo' );?></a>
                </div>

                <div class="tab-desc description">
                    <label for="<?php echo $this->get_field_id( 'clients' ) ?>-<?php echo $count ?>-company_link"><?php _e( 'Company Link', 'romo' );?></label>
                    <input type="text" id="<?php echo $this->get_field_id('clients') ?>-<?php echo $count ?>-company_link" class="input-full" name="<?php echo $this->get_field_name( 'clients' ) ?>[<?php echo $count ?>][company_link]" value="<?php echo $client['company_link'] ?>" />
                </div>

                <div class="tab-desc description"><a href="#" class="sortable-delete"><?php _e( 'Delete', 'romo' );?></a></p>

            </div>
		</li>
 		<?php
 	}

	function block( $instance ) {

		extract( $instance );
        
        wp_enqueue_script( "jquery-touchswipe" );
        wp_enqueue_script( "jquery-caroufredsel" );

        $output = '';
        
        $icon = ( !empty( $icon ) ) ? '<i class="icon-'. $icon .'"></i>' : '';
        $output .= ( ! empty( $title ) ) ? '<h4 class="widget-title"><span>'. $icon . strip_tags( $title ) .'</span></h4>' : '';

        if ( $clients ) {
            $rand = rand( 1, 100 );
            $output .= '<div id="romo-clients-'.$rand.'" class="romo-clients-list cf">';
                $output .= '<ul class="clients-carousel">';

                foreach ( $clients as $client ) {
                    $image_id = romo_get_attachment_id_from_url( $client['company_logo'] );
                    $get_image = wp_get_attachment_image_src( $image_id, 'romo-small-featured' );
                    $get_image_logo = ( $image_id ) ? $get_image[0] : $client['company_logo'];
                    if ( $client['company_name'] && $client['company_logo'] && $client['company_link'] ) {
                        $output .= '<li>';
                            $output .= '<a class="clients-overlay" href="'. esc_url( $client['company_link'] ) .'" target="_blank" title="'. esc_attr( $client['company_name'] ) .'">';
                            $output .= '<img src="'. $get_image_logo .'" alt="'. esc_attr( $client['company_name'] ) .'" />';
                            $output .= '</a>';
                        $output .= '</li>';
                    } elseif ( $client['company_name'] && $client['company_logo'] ) {
                        $output .= '<li>';
                            $output .= '<img src="'. $get_image_logo .'" alt="'. esc_attr( $client['company_name'] ) .'" />';
                        $output .= '</li>';
                    }
                }

                $output .= '</ul>';
                $output .= '<a id="client-prev-'. $rand .'" class="client-prev" href="#"><i class="icon-chevron-left"></i></a>';
                $output .= '<a id="client-next-'. $rand .'" class="client-next" href="#"><i class="icon-chevron-right"></i></a>';
            $output .= '</div>';
        }       

        echo $output;

	}

    /** AJAX add client */
    function add_client() {
        $nonce = $_POST['security'];    
        if ( ! wp_verify_nonce( $nonce, 'aqpb-settings-page-nonce' ) ) die('-1');        
        $count = isset( $_POST['count'] ) ? absint( $_POST['count'] ) : false;
        $this->block_id = isset($_POST['block_id']) ? $_POST['block_id'] : 'aq-block-9999';        
        /** default key/value for the tab */
        $client = array(
		    'company_name'	=> 'Client/Company Name',
		    'company_logo' 	=> '',
		    'company_link'	=> '',
        );

        if($count) {
            $this->clients( $client, $count );
        } else {
            die(-1);
        }

        die();
    }
    
    function update( $new_instance, $old_instance ) {
        $new_instance = aq_recursive_sanitize( $new_instance );
        return $new_instance;
    }

    /* block header */
    function before_block($instance) {
        extract($instance);
        $column_class = $first ? 'aq-first' : '';        
        echo '<section id="aq-block-'.$template_id.'-'.$number.'" class="aq-block aq-block-'.$id_base.' aq_'.$size.' '.$column_class.' cf">';
    }

    /* block footer */
    function after_block($instance) {
        extract($instance);
        echo '</section>';
    }

}

aq_register_block( 'Romo_Clients_Block' );

endif;