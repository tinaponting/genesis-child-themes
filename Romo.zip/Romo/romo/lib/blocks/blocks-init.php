<?php
/**
 * Initializes Aqua Page Builder custom modules
 *
 * @package 	Romo
 * @author   	aprakasa
 * @license  	GPL-2.0+
 * @link     	http://prakasa.me/go/romo
 */

/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;

global $wp_version;

$version = '3.5.2';
/** Unregister default blocks  */
aq_unregister_block( 'AQ_Alert_Block' );
aq_unregister_block( 'AQ_Tabs_Block' );
aq_unregister_block( 'AQ_Text_Block' );
/** Load all blocks  */
include_once ( ROMO_BLOCKS_DIR . 'block-text.php' );
include_once ( ROMO_BLOCKS_DIR . 'block-container-open.php' );
include_once ( ROMO_BLOCKS_DIR . 'block-container-close.php' );
include_once ( ROMO_BLOCKS_DIR . 'block-breadcrumb.php' );
include_once ( ROMO_BLOCKS_DIR . 'block-callout.php' );
include_once ( ROMO_BLOCKS_DIR . 'block-clients.php' );
include_once ( ROMO_BLOCKS_DIR . 'block-featured-page.php' );
include_once ( ROMO_BLOCKS_DIR . 'block-recent-posts.php' );
include_once ( ROMO_BLOCKS_DIR . 'block-slider.php' );
include_once ( ROMO_BLOCKS_DIR . 'block-tabs.php' );
include_once ( ROMO_BLOCKS_DIR . 'block-image.php' );
include_once ( ROMO_BLOCKS_DIR . 'block-oembed.php' );
include_once ( ROMO_BLOCKS_DIR . 'block-gmaps.php' );
include_once ( ROMO_BLOCKS_DIR . 'block-pricing-table.php' );
/** For WordPress 3.6+ */
if ( version_compare( $wp_version, '3.5.2', '>' ) ) {
	include_once ( ROMO_BLOCKS_DIR . 'block-audio.php' );
	include_once ( ROMO_BLOCKS_DIR . 'block-video.php' );
}
/** require CCP plugin */
if ( class_exists( 'Custom_Content_Portfolio' ) ) {
	include_once ( ROMO_BLOCKS_DIR . 'block-portfolio.php' );
}
/** require WooCommerce plugin */
if ( class_exists( 'WooCommerce' ) ) {
	include_once ( ROMO_BLOCKS_DIR . 'block-recent-products.php' );
	include_once ( ROMO_BLOCKS_DIR . 'block-featured-products.php' );
	include_once ( ROMO_BLOCKS_DIR . 'block-product-category.php' );
}
/** WordPress repo plugins */
if ( defined( 'WPCF7_VERSION' ) )
	include_once ( ROMO_BLOCKS_DIR . 'block-cf7.php' );
/** Premium Slider Plugins */
if ( class_exists( 'Tgmsp' ) || class_exists( 'Tgmsp_Lite' ) )
	include_once ( ROMO_BLOCKS_DIR . 'block-soliloquy.php' );
if ( class_exists( 'RevSlider' ) )
	include_once ( ROMO_BLOCKS_DIR . 'block-revslider.php' );
if ( function_exists( 'layerslider' ) )
	include_once ( ROMO_BLOCKS_DIR . 'block-layerslider.php' );

add_action( 'init', 'block_filter' );
/**
 * Filter oembed block and text block for shortcode and autoembed
 *
 * @since 1.0
 */
function block_filter() {
	global $wp_embed;	
	add_filter( 'romo_block_oembed', 'do_shortcode' );
	add_filter( 'romo_block_oembed', array( $wp_embed, 'run_shortcode' ), 8 );
	add_filter( 'romo_block_oembed', array( $wp_embed, 'autoembed'), 8 );
	add_filter( 'romo_block_text', 'do_shortcode' );
	add_filter( 'romo_block_text', array( $wp_embed, 'run_shortcode' ), 8 );
	add_filter( 'romo_block_text', array( $wp_embed, 'autoembed'), 8 );
	add_filter( 'romo_tab_content', 'do_shortcode' );
	add_filter( 'romo_tab_content', array( $wp_embed, 'run_shortcode' ), 8 );
	add_filter( 'romo_tab_content', array( $wp_embed, 'autoembed'), 8 );
}