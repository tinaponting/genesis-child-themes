<?php
/**
 * This file control Contact Form 7 builder class
 *
 * @package 	Romo
 * @author   	aprakasa
 * @license  	GPL-2.0+
 * @link     	http://prakasa.me/go/romo
 */

/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;

if( ! class_exists( 'Romo_Cform7_Block') ) :

class Romo_Cform7_Block extends AQ_Block {

	function __construct() {
		$block_options = array(
			'name' 	=> 'Contact Form 7',
			'size' 	=> 'span6',
		);		
		parent::__construct( 'Romo_Cform7_Block', $block_options );
	}
	
	function form( $instance ){

		$defaults = array (
			'title'		=> '',
			'icon'		=> '',
			'form_id' 	=> 0,
		);

		$instance = wp_parse_args( $instance, $defaults );
		extract( $instance );
		$contact_form = romo_get_published_posts( 'wpcf7_contact_form', __( 'Select contact form', 'romo' ) );		
		if( empty( $contact_form ) ) {
			echo __( 'You currently do not have any contact form. Please create a contact form before setting up this block', 'romo' );
			return false;
		}
		
		?>

		<p class="description">
			<label for="<?php echo $this->get_field_id( 'title' ) ?>"><?php _e( 'Title', 'romo' );?></label>
			<?php echo aq_field_input('title', $block_id, $title) ?>
		</p>

		<p class="description half">
			<label for="<?php echo $this->get_field_id( 'icon' ) ?>"><?php _e( 'Icon', 'romo' );?> *<?php _e( 'Optional', 'romo' );?></label>				
			<?php echo aq_field_select( 'icon', $block_id, romo_get_fontawesome(), $icon ) ?>
		</p>

		<p class="description half last">
			<label for="<?php echo $this->get_field_id( 'form_id' ) ?>"><?php _e( 'Select contact form', 'romo' );?></label>
			<?php echo aq_field_select( 'form_id', $block_id, $contact_form, $form_id ); ?>
		</p>

		<?php
	}
	
	function block( $instance ) {
		extract( $instance );
		if ( ! defined( 'WPCF7_VERSION' ) )
			return;
		$icon = ( !empty( $icon ) ) ? '<i class="icon-'. $icon .'"></i>' : '';
		if( ! empty( $title ) ) echo '<h4 class="widget-title"><span>'. $icon . strip_tags( $title ) .'</span></h4>';
		echo do_shortcode('[contact-form-7 id="'. $form_id .'" title="'. $title .'"]');
	}

 	/* block header */
 	function before_block($instance) {
 		extract($instance);
 		$column_class = $first ? 'aq-first' : ''; 		
 		echo '<section id="aq-block-'.$template_id.'-'.$number.'" class="aq-block aq-block-'.$id_base.' aq_'.$size.' '.$column_class.' cf">';
 	}

 	/* block footer */
 	function after_block($instance) {
 		extract($instance);
 		echo '</section>';
 	}
 	
}

aq_register_block( 'Romo_Cform7_Block' );

endif;