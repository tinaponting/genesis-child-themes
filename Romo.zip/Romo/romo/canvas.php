<?php
/**
 * Canvas template file.
 * Template Name: Canvas
 * @package 	Romo
 */
/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;get_header();while ( have_posts() ) : the_post();the_content();endwhile;get_footer();