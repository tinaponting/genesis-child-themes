<?php
/**
 * Main function file
 * @package 	Romo
 */
/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;

/** Load Romo child theme library */
require_once( get_stylesheet_directory() . '/lib/init.php' );