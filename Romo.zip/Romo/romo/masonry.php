<?php
/**
 * Masonry template file.
 * Template Name: Blog - Masonry
 * @package 	Romo
 */
/** Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) exit;

add_action( 'genesis_meta', 'romo_blog_masonry' );
/**
 * Custom loop for masonry blog
 */
function romo_blog_masonry(){
	add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );
	remove_action( 'genesis_loop', 'genesis_do_loop' );
	add_action( 'genesis_loop', 'romo_masonry_loop' );
	remove_action( 'genesis_entry_content', 'genesis_do_post_image', 8 );
	add_action( 'genesis_entry_header', 'genesis_do_post_image', 8 );
	remove_action( 'genesis_loop_else', 'genesis_do_noposts' );
	add_action( 'genesis_before_loop', 'romo_masonry_open_container', 15 );
	add_action( 'genesis_after_endwhile', 'romo_masonry_close_container', 5 );
}
function romo_masonry_open_container() {
	echo '<div class="masonry-container">';
}
function romo_masonry_close_container(){
	echo '</div>';
}
function romo_masonry_loop() {
	if ( is_page_template( 'masonry.php' ) ) {
		$include = genesis_get_option( 'blog_cat' );
		$exclude = genesis_get_option( 'blog_cat_exclude' ) ? explode( ',', str_replace( ' ', '', genesis_get_option( 'blog_cat_exclude' ) ) ) : '';
		$paged   = get_query_var( 'paged' ) ? get_query_var( 'paged' ) : 1;		
		$query_args = wp_parse_args(
			genesis_get_custom_field( 'query_args' ),
			array(
				'cat'=> $include,
				'category__not_in'=> $exclude,
				'showposts'=> genesis_get_option( 'blog_cat_num' ),
				'paged'=> $paged,
			)
		);
		genesis_custom_loop( $query_args );
	} else {genesis_standard_loop();
	}}
genesis();