<?php
/**
 * This file adds the portfolio taxonomy template to the bloom theme
 *
 * @subpackage Customizations
 */
 
//* Add portfolio body class to the head
add_filter( 'body_class', 'bloom_body_class' );
function bloom_body_class( $classes ) {
   
   $classes[] = 'bloom-portfolio';
   return $classes;
   
}
 
//* Force full width content layout
add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );

//* Remove page elements
remove_action( 'genesis_entry_header', 'genesis_post_info' );
remove_action( 'genesis_before_loop', 'genesis_do_breadcrumbs' );
remove_action( 'genesis_entry_content', 'genesis_do_post_content' );
remove_action( 'genesis_entry_content', 'genesis_do_post_image', 8 );
remove_action( 'genesis_entry_footer', 'genesis_post_meta' );

//* Add the featured image before post title
add_action( 'genesis_entry_header', 'bloom_portfolio', 1 );
function bloom_portfolio() {

    if ( $image = genesis_get_image( 'format=url&size=portfolio' ) ) {
        printf( '<div class="portfolio-featured-image"><a href="%s" rel="bookmark"><img src="%s" alt="%s" /></a></div>', get_permalink(), $image, the_title_attribute( 'echo=0' ) );

    }

}

genesis();