<?php
/**
 * This file adds the custom portfolio single post template to the bloom theme
 *
 * @subpackage Customizations
 */
 

//* Add link back to portfolio page
add_action( 'genesis_after_entry', 'portfolio_link');
function portfolio_link() {
?>
<div class="portfolio-back-button"><a href="<?php echo get_site_url(); ?>/portfolio">Back to Portfolio</a></div>
<?php
}

//* Force full width content layout
add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );

//* Remove page elements
remove_action( 'genesis_entry_header', 'genesis_post_info', 5 );
remove_action( 'genesis_before_loop', 'genesis_do_breadcrumbs' );
remove_action( 'genesis_after_entry', 'genesis_do_author_box_single', 8 );
remove_action( 'genesis_entry_footer', 'genesis_post_meta' );
remove_action( 'genesis_entry_footer', 'child_related_posts' );


genesis();