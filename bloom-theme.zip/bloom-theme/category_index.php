<?php
/**
 * This file adds the Category Index Page to the bloom Theme
 *
 * @package bloom
 * @subpackage Customizations
 */
 
/*
Template Name: Category Index
*/

add_action( 'genesis_meta', 'bloom_category_genesis_meta' );
/**
 * Add widget support for category index. If no widgets active, display the default loop.
 *
 */
function bloom_category_genesis_meta() {

    if ( is_active_sidebar( 'category-page' )) {

        remove_action( 'genesis_loop', 'genesis_do_loop' );
        add_action( 'genesis_loop', 'bloom_category_sections' );
        add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_content_sidebar' );

    }
    
}

function bloom_category_sections() {

    genesis_widget_area( 'category-page', array(
        'before' => '<div class="category-page widget-area">',
        'after'  => '</div>',
    ) );
    
}

genesis();