<?php
//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );

//* Set Localization (do not remove)
load_child_theme_textdomain( 'bloom', apply_filters( 'child_theme_textdomain', get_stylesheet_directory() . '/languages', 'bloom' ) );

//* Add WordPress theme customizer color support
require_once( get_stylesheet_directory() . '/lib/customize.php' );

//* Child theme (do not remove)
define( 'CHILD_THEME_NAME', 'bloom' );
define( 'CHILD_THEME_URL', 'https://minimadesign.co' );
define( 'CHILD_THEME_VERSION', '1.0.0' );

//* Enqueue scripts and styles
add_action( 'wp_enqueue_scripts', 'bloom_enqueue_scripts_styles' );
function bloom_enqueue_scripts_styles() {

    wp_enqueue_script( 'bloom-global', get_bloginfo( 'stylesheet_directory' ) . '/js/global.js', array( 'jquery' ), '1.0.0' );
    wp_enqueue_style( 'bloom-ionicons', '//code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css', array(), CHILD_THEME_VERSION );
    wp_enqueue_style( 'dashicons' );
    wp_enqueue_style( 'bloom-google-fonts', '//fonts.googleapis.com/css?family=Source+Serif+Pro:300,400,700|Karla:400,400i,700', array(), CHILD_THEME_VERSION );
    
    if ( class_exists( 'woocommerce' ) ) {
        wp_enqueue_style( 'custom-stylesheet', CHILD_URL . '/woo/bloom-woocommerce.css', array() );
    }
}

//* Add HTML5 markup structure
add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption' ) );

//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

// Register responsive menu script
add_action( 'wp_enqueue_scripts', 'bloom_responsive_menu' );
function bloom_responsive_menu() {

    wp_enqueue_script( 'bloom-responsive-menu', get_stylesheet_directory_uri() . '/js/responsive-menu.js', array( 'jquery' ), '1.0.0', true );
 
}

//* Add new image sizes
add_image_size( 'blog-image', 700, 9999, FALSE );
add_image_size( 'home-featured', 1040, 9999, FALSE );
add_image_size( 'category-page', 330, 500, TRUE );
add_image_size( 'category-index', 320, 320, TRUE );
add_image_size( 'portfolio', 400, 400, true );


function remove_admin_login_header() {
    remove_action('wp_head', '_admin_bar_bump_cb');
}
add_action('get_header', 'remove_admin_login_header');



//* Automatic titles on archive pages
function bloom_default_term_title( $value, $term_id, $meta_key, $single ) {
    if( ( is_category() || is_tag() || is_tax() ) && 'headline' == $meta_key && ! is_admin() ) {
    
        // Grab the current value, be sure to remove and re-add the hook to avoid infinite loops
        remove_action( 'get_term_metadata', 'bloom_default_term_title', 10 );
        $value = get_term_meta( $term_id, 'headline', true );
        add_action( 'get_term_metadata', 'bloom_default_term_title', 10, 4 );
        // Use term name if empty
        if( empty( $value ) ) {
            $term = get_term_by( 'term_taxonomy_id', $term_id );
            $value = $term->name;
        }
    
    }
    return $value;      
}
add_filter( 'get_term_metadata', 'bloom_default_term_title', 10, 4 );


//* Set number of posts on category archive pages
function bloom_category_post_count($query)
{
    if ($query->is_main_query() && $query->is_category() && !is_admin())
        $query->set('posts_per_page', 6);
}
 
add_action('pre_get_posts', 'bloom_category_post_count');


//* Modify Genesis Read More Link
add_filter( 'excerpt_more', 'bloom_read_more_link' );
add_filter( 'get_the_content_more_link', 'bloom_read_more_link' );
add_filter( 'the_content_more_link', 'bloom_read_more_link' );
/**
 * Modify the Genesis read more link.
 *
 * @since  1.0.0
 *
 * @param  string $more
 * @return string Modified read more text.
 */
function bloom_read_more_link() {
    return '...</p><p><a class="more-link" href="' . get_permalink() . '">' . __( 'Read More', 'bloom' ) . '</a></p>';
}

//* Unregister the header right widget area
unregister_sidebar( 'header-right' );

//* Reposition header
remove_action( 'genesis_header', 'genesis_header_markup_open', 5 );
remove_action( 'genesis_header', 'genesis_do_header' );
remove_action( 'genesis_header', 'genesis_header_markup_close', 10 ) ;

add_action( 'genesis_before', 'genesis_header_markup_open', 5 );
add_action( 'genesis_before', 'genesis_do_header' );
add_action( 'genesis_before', 'genesis_header_markup_close', 10 );

//* Reposition the secondary navigation menu
remove_action( 'genesis_after_header', 'genesis_do_subnav' );
add_action( 'genesis_before', 'genesis_do_subnav', 12 );

//* Reposition the primary navigation menu
remove_action( 'genesis_after_header', 'genesis_do_nav' );
add_action( 'genesis_before', 'genesis_do_nav', 1 );

//* Remove output of primary navigation right extras
remove_filter( 'genesis_nav_items', 'genesis_nav_right', 10, 2 );
remove_filter( 'wp_nav_menu_items', 'genesis_nav_right', 10, 2 );

//* Unregister layout settings
genesis_unregister_layout( 'content-sidebar-sidebar' );
genesis_unregister_layout( 'sidebar-content-sidebar' );
genesis_unregister_layout( 'sidebar-sidebar-content' );

//* Unregister secondary sidebar
unregister_sidebar( 'sidebar-alt' );

//* Remove title all single pages
add_action( 'get_header', 'remove_titles_all_single_pages' );
function remove_titles_all_single_pages() {
    if ( is_singular('page') ) {
        remove_action( 'genesis_entry_header', 'genesis_do_post_title' );
    }
}


//* Add support for custom header
add_theme_support( 'custom-header', array(
    'flex-height'     => true,
    'width'           => 900,
    'height'          => 300,
    'header-selector' => '.site-title a',
    'header-text'     => false,
) );

//* Add support for structural wraps
add_theme_support( 'genesis-structural-wraps', array(
    'header',
    'nav',
    'subnav',
    'footer-widgets',
    'footer',
) );

//* Above Header widget area
add_action( 'genesis_before', 'bloom_above_header', 1 );
function bloom_above_header() {
    if( is_active_sidebar('above-header') ) {
        genesis_widget_area( 'above-header', array(
            'before'    => '<div class="above-header wrap widget-area">',
            'after'     => '</div>',
        ) );
    }
}



//* Below Header widget area
add_action( 'genesis_after_header', 'bloom_below_header' );
function bloom_below_header() {
    if( is_home() && !is_paged()  && is_active_sidebar('below-header') ) {
        genesis_widget_area( 'below-header', array(
            'before'    => '<div class="below-header wrap widget-area">',
            'after'     => '</div>',
        ) );
    }
}

//* Modify the size of the Gravatar in the author box
add_filter( 'genesis_author_box_gravatar_size', 'bloom_author_box_gravatar' );
function bloom_author_box_gravatar( $size ) {

    return 176;

}

//* Modify the size of the Gravatar in the entry comments
add_filter( 'genesis_comment_list_args', 'bloom_comments_gravatar' );
function bloom_comments_gravatar( $args ) {

    $args['avatar_size'] = 120;

    return $args;

}

//* Remove comment form allowed tags
add_filter( 'comment_form_defaults', 'bloom_remove_comment_form_allowed_tags' );
function bloom_remove_comment_form_allowed_tags( $defaults ) {

    $defaults['comment_field'] = '<p class="comment-form-comment"><label for="comment">' . _x( 'Comment', 'noun', 'bloom' ) . '</label> <textarea id="comment" name="comment" cols="45" rows="8" aria-required="true"></textarea></p>';
    $defaults['comment_notes_after'] = '';

    return $defaults;

}

//* Customize search form input button text
add_filter( 'genesis_search_button_text', 'bloom_search_button_text' );
function bloom_search_button_text( $text ) {
    return esc_attr( 'Go' );
}

//* Customize search form input box text
add_filter( 'genesis_search_text', 'sp_search_text' );
function sp_search_text( $text ) {
    return esc_attr( 'Looking for...' );
}


//* Genesis Previous/Next Post Post Navigation
add_action( 'genesis_before_comments', 'bloom_prev_next_post_nav' );

function bloom_prev_next_post_nav() {

    if ( is_single() ) {

        echo '<div class="prev-next-navigation">';
        previous_post_link( '<div class="previous">%link</div>', '%title' );
        next_post_link( '<div class="next">%link</div>', '%title' );
        echo '</div><!-- .prev-next-navigation -->';
    }
}

//* Add support for after entry widget
add_theme_support( 'genesis-after-entry-widget-area' );

//* Add Theme Support for WooCommerce
add_theme_support( 'genesis-connect-woocommerce' );

//* Remove Add to Cart on Archives
add_action( 'woocommerce_after_shop_loop_item', 'bloom_remove_add_to_cart_buttons', 1 );
function bloom_remove_add_to_cart_buttons() {

    remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart' );
}

//* Remove Related Products
remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20 );

//* Force full width layout on WooCommerce pages
function bloom_woo_full_layout() {
 if( is_page ( array( 'shop', 'cart', 'checkout' )) || 'product' == get_post_type() ) {
 return 'full-width-content';
 }
}
add_filter( 'genesis_site_layout', 'bloom_woo_full_layout' );


//* Display 12 products per page
add_filter( 'loop_shop_per_page', create_function( '$cols', 'return 12;' ), 20 );


//* Customize the entry meta in the entry header
add_filter( 'genesis_post_info', 'bloom_post_info_filter' );
function bloom_post_info_filter( $post_info ) {

    $post_info = '[post_date]';

    return $post_info;

}




//* Customize the entry meta in the entry footer
add_filter( 'genesis_post_meta', 'bloom_post_meta_filter' );
function bloom_post_meta_filter( $post_meta ) {

    $post_meta = ' [post_categories before=" &middot; "]  [post_tags before=" &middot; Tagged: "] [post_edit]';

    return $post_meta;

}

//* Add shop the post custom field
add_action( 'genesis_after_entry', 'shop_post_widget', 1 );
function shop_post_widget() {
if(is_page() || is_front_page() || is_single() ) {
genesis_custom_field('shop_post');
}
}

//* Register widget areas
genesis_register_sidebar( array(
    'id'            => 'above-header',
    'name'          => 'Above Header',
    'description'   => 'This is a widget area that appears above your header. You could add a newsletter signup, advertisement banner, or anything you want here.'
) );
genesis_register_sidebar( array(
    'id'            => 'below-header',
    'name'          => 'Below Header',
    'description'   => 'This is a widget area that appears between your header and blog posts. You could add an image slider, newsletter signup, or anything you want here.'
) );

genesis_register_sidebar( array(
    'id'          => 'category-page',
    'name'        => __( 'Category Index Page', 'bloom' ),
    'description' => __( 'This is the area for the Category Index.', 'bloom' ),
) );
genesis_register_sidebar( array(
    'id'            => 'bloom-instagram',
    'name'          => __( 'Instagram Footer Area', 'bloom' ),
    'description'   => __( 'This is the full-width footer area for the Instagram widget.', 'bloom' ),
) );
genesis_register_sidebar( array(
	'id'          => 'bloom-footer',
	'name'        => __('Footer Widgets', 'genesis' ),
	'description' => __('This is the footer flexible widget area section.', 'genesis'),
) );

genesis_register_sidebar( array(
	'id'          => 'instagram-widget',
	'name'        => __('Instagram Widget', 'genesis' ),
	'description' => __('Add here your Instagram code.', 'genesis'),
) );


//* Add Page Widget Area to Content - HTML5 only
add_action( 'genesis_entry_footer', 'custom_instagram_menu_add_page_content' );
function custom_instagram_menu_add_page_content() {
	if ( is_page_template( 'instagram_landing.php' ) ) {
	genesis_widget_area ('instagram-landing-page-widget', array(
        'before' => '<div class="instagram-landing-page-widget"><div class="wrap">',
        'after' => '</div></div>',
	) );
	}
}

//* Register Instagram Landing Page Widget Area
genesis_register_sidebar( array(
	'id'		=> 'instagram-landing-page-widget',
	'name'		=> __( 'Instagram Menu', 'bloom' ),
	'description'	=> __( 'This is the widget area for your custom Instagram Menu.', 'bloom' ),
) );


//* Edit width of tiled portfolio
if ( ! isset( $content_width ) )
    $content_width = 1100;

//* Create Portfolio Taxonomy
add_action( 'init', 'bloom_portfolio_taxonomy' );
function bloom_portfolio_taxonomy() {

    register_taxonomy( 'portfolio-type', 'portfolio',
        array(
            'labels' => array(
                'name'          => _x( 'Types', 'taxonomy general name', 'bloom' ),
                'add_new_item'  => __( 'Add New Portfolio Type', 'bloom' ),
                'new_item_name' => __( 'New Portfolio Type', 'bloom' ),
            ),
            'exclude_from_search' => true,
            'has_archive'         => true,
            'hierarchical'        => true,
            'rewrite'             => array( 'slug' => 'portfolio-type', 'with_front' => false ),
            'show_ui'             => true,
            'show_tagcloud'       => false,
        )
    );

}

//* Create portfolio custom post type
add_action( 'init', 'bloom_portfolio_post_type' );
function bloom_portfolio_post_type() {

    register_post_type( 'portfolio',
        array(
            'labels' => array(
                'name'          => __( 'Portfolio', 'bloom' ),
                'singular_name' => __( 'Portfolio', 'bloom' ),
            ),
            'has_archive'  => true,
            'hierarchical' => true,
            'menu_icon'    => 'dashicons-screenoptions',
            'public'       => true,
            'rewrite'      => array( 'slug' => 'portfolio', 'with_front' => false ),
            'supports'     => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'trackbacks', 'custom-fields', 'revisions', 'page-attributes', 'genesis-seo', 'genesis-cpt-archives-settings' ),
            'taxonomies'   => array( 'portfolio-type' ),

        )
    );
    
}

//* Add Portfolio Type Taxonomy to columns
add_filter( 'manage_taxonomies_for_portfolio_columns', 'bloom_portfolio_columns' );
function bloom_portfolio_columns( $taxonomies ) {

    $taxonomies[] = 'portfolio-type';
    return $taxonomies;

}

//* Change number of Portfolio posts per page
add_action( 'pre_get_posts', 'portfolio_posts_per_page' );
function portfolio_posts_per_page( $query ) {
    if( $query->is_main_query() && is_post_type_archive( $portfolio )  && ! is_admin() ) {
        $query->set( 'posts_per_page', '21' );
    }
}


//Add portfolio navigation.

add_action( 'genesis_after_entry', 'bloom_prev_next_post_nav_cpt' );
function bloom_prev_next_post_nav_cpt() {
 if ( ! is_singular( array( 'portfolio' ) ) )
 return;
 genesis_markup( array(
 'html5' => '<div %s>',
 'xhtml' => '<div class="navigation">',
 'context' => 'adjacent-entry-pagination',
 ) );
 echo '<div class="pagination-previous alignleft">';
previous_post_link( '%link', __( 'OLDER', 'genesis' ) );
 echo '</div>';
 echo '<div class="pagination-next alignright">';
 next_post_link('%link', __( 'NEWER', 'genesis' ) );
 echo '</div>';
 echo '</div>';
}

//* Start code Flexible Footer Area ---------//

//* Customize the footer credits
add_filter( 'genesis_footer_creds_text', 'bloom_footer_creds_text' );
function bloom_footer_creds_text() {

    $copyright = '<div class="creditline"><h6><a href="'.esc_url( home_url() ).'">' .get_bloginfo('name'). '</a> &copy; ' . date('Y') .' <span>-</span> ' . __('DESIGNED BY', 'genesis') . ' <a href="https://minimadesign.co" target="_blank">Minimadesign</a></h6></div>';
	return $copyright;
}

// Position the footer widget area.
function bloom_footer_widget() {
	
	genesis_widget_area( 'bloom-footer', array(
		'before' => '<div class="bloom-footer-widgets"><div class="wrap"><div class="flexible-widgets widget-area' . bloom_widget_area_class( 'bloom-footer' ) . '">',
		'after'  => '</div></div></div>',
	));

	genesis_widget_area( 'instagram-widget', array(
		'before' => '<div class="instagram-widget">',
		'after'  => '</div>',
	));


}

add_action( 'genesis_before_footer','bloom_footer_widget' );


// Code to Display Footer Block
add_action( 'genesis_before_footer', 'the_footer', 17 );
function the_footer() {

  ?><div id="bloom-footer">
   <?php
  
}

// Code to Display End of Footer Block
add_action( 'genesis_after_footer', 'the_footer_end' );
function the_footer_end() {

  ?></div>
   <?php
}



/* Display Featured Image after post title */
function display_featured_image() {
if ( ! is_singular( 'post' ) ) return;
the_post_thumbnail('post-image');
}
add_action( 'genesis_entry_content', 'display_featured_image', 8 );

// Related Posts --------------//
add_action( 'genesis_before_comments', 'child_related_posts' );

function child_related_posts() {

if ( is_single ( ) ) {

global $post;

$count = 0;
$postIDs = array( $post->ID );
$related = '';
$tags = wp_get_post_tags( $post->ID );
$cats = wp_get_post_categories( $post->ID );

if ( $tags ) {

foreach ( $tags as $tag ) {

$tagID[] = $tag->term_id;

}

$args = array(
'tag__in' => $tagID,
'post__not_in' => $postIDs,
'showposts' => 4,
'ignore_sticky_posts' => 1,
'tax_query' => array(
array(
'taxonomy' => 'post_format',
'field' => 'slug',
'terms' => array(
'post-format-link',
'post-format-status',
'post-format-aside',
'post-format-quote'
),
'operator' => 'NOT IN'
)
)
);

$tag_query = new WP_Query( $args );

if ( $tag_query->have_posts() ) {

while ( $tag_query->have_posts() ) {

$tag_query->the_post();

$img = genesis_get_image() ? genesis_get_image( array( 'size' => 'square-entry-image' ) ) : '<img src="' . get_stylesheet_directory_uri() . '/images/related.png" alt="' . get_the_title() . '" />';

$related .= '<li><a href="' . get_permalink() . '" rel="bookmark" title="Permanent Link to' . get_the_title() . '">' . $img . get_the_title() . '</a></li>';

$postIDs[] = $post->ID;

$count++;
}
}
}

if ( $count <= 3 ) {

$catIDs = array( );

foreach ( $cats as $cat ) {

if ( 2 == $cat )
continue;
$catIDs[] = $cat;

}

$showposts = 4 - $count;

$args = array(
'category__in' => $catIDs,
'post__not_in' => $postIDs,
'showposts' => $showposts,
'ignore_sticky_posts' => 1,
'orderby' => 'rand',
'tax_query' => array(
array(
'taxonomy' => 'post_format',
'field' => 'slug',
'terms' => array(
'post-format-link',
'post-format-status',
'post-format-aside',
'post-format-quote' ),
'operator' => 'NOT IN'
)
)
);

$cat_query = new WP_Query( $args );

if ( $cat_query->have_posts() ) {

while ( $cat_query->have_posts() ) {

$cat_query->the_post();

$img = genesis_get_image() ? genesis_get_image( array( 'size' => 'square-entry-image' ) ) : '<img src="' . get_stylesheet_directory_uri() . '/images/related.png" alt="' . get_the_title() . '" />';

$related .= '<li><a href="' . get_permalink() . '" rel="bookmark" title="Permanent Link to' . get_the_title() . '">' . $img . get_the_title() . '</a></li>';
}
}
}

if ( $related ) {

printf( '<div class="related-posts"><h3 class="related-title">You might also like...</h3><ul class="related-list">%s</ul></div>', $related );

}

wp_reset_query();

}
}


 //Used to add classes to widget areas so widgets can be displayed one, two, three or four per row
 //
function count_widgets( $sidebar_id ) {
	global $_wp_sidebars_widgets;
	if ( empty( $_wp_sidebars_widgets ) ) :
		$_wp_sidebars_widgets = get_option( 'sidebars_widgets', array() );
	endif;
	
	$sidebars_widgets_count = $_wp_sidebars_widgets;
	
	if ( isset( $sidebars_widgets_count[ $sidebar_id ] ) ) :
		$widget_count = count( $sidebars_widgets_count[ $sidebar_id ] );
		$widget_classes = 'widget-count-' . count( $sidebars_widgets_count[ $sidebar_id ] );
		if ( $widget_count % 4 == 0 || $widget_count > 6 ) :
			$widget_classes .= ' per-row-4';
		elseif ( $widget_count >= 3 ) :
			$widget_classes .= ' per-row-3';
		elseif ( 2 == $widget_count ) :
			$widget_classes .= ' per-row-2';
		endif; 
		return $widget_classes;
	endif;
}
 

//* Setup widget counts
function bloom_count_widgets( $id ) {

	global $sidebars_widgets;

	if ( isset( $sidebars_widgets[ $id ] ) ) {
		return count( $sidebars_widgets[ $id ] );
	}

}

function bloom_widget_area_class( $id ) {

	$count = bloom_count_widgets( $id );

	$class = '';

	if( $count == 1 ) {
		$class .= ' widget-full';
	} elseif( $count % 3 == 1 ) {
		$class .= ' widget-thirds';
	} elseif( $count % 4 == 1 ) {
		$class .= ' widget-fourths';
	} elseif( $count % 6 == 1 ) {
		$class .= ' widget-uneven';
	} elseif( $count % 2 == 0 ) {
		$class .= ' widget-halves uneven';
	} else {	
		$class .= ' widget-halves';
	}

	return $class;

}


