<?php
/**
 * This file adds the Landing template.
 *
 * @package bloom
 * @subpackage Customizations
 */

/*
Template Name: Landing
*/

//* Add custom body class to the head
add_filter( 'body_class', 'bloom_add_body_class' );
function bloom_add_body_class( $classes ) {

   $classes[] = 'bloom-landing';
   return $classes;
   
}
// Remove Skip Links.
remove_action ( 'genesis_before_header', 'genesis_skip_links', 5 );

// Dequeue Skip Links Script.
add_action( 'wp_enqueue_scripts', 'genesis_sample_dequeue_skip_links' );
function genesis_sample_dequeue_skip_links() {
	wp_dequeue_script( 'skip-links' );
}

remove_action( 'genesis_before', 'genesis_header_markup_open', 5 );
remove_action( 'genesis_before', 'genesis_do_header' );
remove_action( 'genesis_before', 'genesis_header_markup_close', 10 );  


//* Force full width content layout
add_filter( 'genesis_site_layout', '__genesis_return_full_width_content' );

//* Remove navigation
remove_action( 'genesis_before_header', 'genesis_do_nav' );
remove_action( 'genesis_after_header', 'genesis_do_subnav' );

// Remove navigation.
remove_theme_support( 'genesis-menus' );



//* Force full width content layout
add_filter( 'genesis_site_layout', '__genesis_return_full_width_content' );


//* Remove breadcrumbs
remove_action( 'genesis_before_loop', 'genesis_do_breadcrumbs' );

//* Remove site footer elements
remove_action( 'genesis_before_footer','bloom_footer_widget' );

//* Remove the entry title (requires HTML5 theme support)
remove_action( 'genesis_entry_header', 'genesis_do_post_title' );

//* Run the Genesis loop
genesis();
