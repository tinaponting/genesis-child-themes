<?php
/*
Template Name: V1 ONLY - Portfolio Page
*/
/**
 * Template used for portfolio content pages
 * 
 * @package Coastal
 * @author Station Seven <hello@stnsvn.com> 
 * @copyright Copyright (c) 2015, Station Seven
 * 
 */ 

genesis();
	