<?php
/*
Template Name: V1 ONLY - Home Page Section
*/
/**
 * Template used for home page sections
 *
 * @package Coastal
 * @author Station Seven <hello@stnsvn.com> 
 * @copyright Copyright (c) 2015, Station Seven
 * 
 */ 

genesis();
