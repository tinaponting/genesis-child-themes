<?php
/*
Template Name: Content Page
*/
/**
 * Template used for content pages
 * 
 * @package Coastal
 * @author Station Seven <hello@stnsvn.com> 
 * @copyright Copyright (c) 2015, Station Seven
 * 
 */ 

genesis();
