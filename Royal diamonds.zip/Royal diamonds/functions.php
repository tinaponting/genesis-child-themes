<?php
//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );

//* Setup Theme
include_once( get_stylesheet_directory() . '/lib/theme-defaults.php' );

//* Set Localization (do not remove)
load_child_theme_textdomain( 'royal', apply_filters( 'child_theme_textdomain', get_stylesheet_directory() . '/languages', 'royal' ) );


//* Child theme (do not remove)
define( 'CHILD_THEME_NAME', __( 'Royal Diamonds Theme', 'royal' ) );

//* Add HTML5 markup structure
add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption' ) );

//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Enqueue Scripts
add_action( 'wp_enqueue_scripts', 'royal_load_scripts' );
function royal_load_scripts() {
	
	wp_enqueue_script( 'royal-responsive-menu', get_bloginfo( 'stylesheet_directory' ) . '/js/responsive-menu.js', array( 'jquery' ), '1.0.0' );
	
	wp_enqueue_style( 'dashicons' );
	
	wp_enqueue_style( 'google-fonts', '//fonts.googleapis.com/css?family=Quicksand', array(), CHILD_THEME_VERSION );
}

//* Add new image sizes
add_image_size( 'home-large', 634, 360, TRUE );
add_image_size( 'home-small', 266, 160, TRUE );

//* woocommerce
add_theme_support( 'genesis-connect-woocommerce' );

//* WooCommerce NUMBER OF PRODICTS TO DISPLAY ON SHOP PAGE
add_filter('loop_shop_per_page', create_function('$cols', 'return 32;'));

//* Demo Color Options
add_filter('body_class', 'string_body_class');
function string_body_class( $classes ) {
	if ( isset( $_GET['color'] ) ) :
		$classes[] = 'royal-pro-' . sanitize_html_class( $_GET['color'] );
	endif;

	return $classes;
}

//* Remove Widgets
function remove_some_widgets(){

     // Unregsiter some of the TwentyTen sidebars
     unregister_sidebar( 'header-right' );
     unregister_sidebar( 'home-top' );
     unregister_sidebar( 'home-middle' );
     unregister_sidebar( 'home-bottom-left' );
     unregister_sidebar( 'home-bottom-right' );
     unregister_sidebar( 'sidebar-alt' );
}
add_action( 'widgets_init', 'remove_some_widgets', 11 );

//* Unregister Layouts
genesis_unregister_layout( 'content-sidebar-sidebar' ); 
genesis_unregister_layout( 'sidebar-sidebar-content' ); 
genesis_unregister_layout( 'sidebar-content-sidebar' );

//* Remove Nav Extras
add_action( 'genesis_theme_settings_metaboxes', 'child_remove_metaboxes' );
	function child_remove_metaboxes( $_genesis_theme_settings ) {
   	remove_meta_box( 'genesis-theme-settings-nav', $_genesis_theme_settings, 'main' );
}

//* Customize the credits
add_filter( 'genesis_footer_creds_text', 'sp_footer_creds_text' );
function sp_footer_creds_text() {
	echo '<div class="creds"><p>';
	echo ' Made by pride <a href="http://exempel.se" title="Studio Mommy">MY Own Design</a> ';
	echo 'Copyright &copy; ';
	echo date('Y');
	echo '</p></div>';
}


//* Customize the post info function
add_filter( 'genesis_post_info', 'post_info_filter' );
function post_info_filter($post_info) {
	$post_info = '[post_date] [post_edit]';
	return $post_info;
}

//* Remove the post info function
remove_action( 'genesis_before_post_content', 'genesis_post_info' );


//* Customize the post meta function
add_filter( 'genesis_post_meta', 'post_meta_filter' );
function post_meta_filter($post_meta) {
	$post_meta = '[post_comments] [post_edit] <br /> [post_categories before="Filed Under: "][post_tags before="Tagged: "]';
	return $post_meta;
}

//* Add support for custom background
add_theme_support( 'custom-background', array(
	'default-color' => 'ffffff',
) );

//* Add support for custom header
add_theme_support( 'custom-header', array(
	'header_image'    => '',
	'header-selector' => '.site-title a',
	'header-text'     => false,
) );

//* Add support for additional color style options
add_theme_support( 'genesis-style-selector', array(
	'royal-pro-blue'    => __( 'royal Pro Blue', 'royal' ),
	'royal-pro-green'   => __( 'royal Pro Green', 'royal' ),
	'royal-pro-tan' => __( 'royal Pro Tan', 'royal' ),
	'royal-pro-purple'  => __( 'royal Pro Purple', 'royal' ),
	'royal-pro-gray'     => __( 'royal Pro Gray', 'royal' ),
) );

//* Unregister secondary navigation menu
add_theme_support( 'genesis-menus', array( 'primary' => __( 'Primary Navigation Menu', 'genesis' ) ) );

//* Modify the size of the Gravatar in the author box
add_filter( 'genesis_author_box_gravatar_size', 'royal_author_box_gravatar' );
function royal_author_box_gravatar( $size ) {

	return 96;
		
}

//* Modify the size of the Gravatar in the entry comments
add_filter( 'genesis_comment_list_args', 'royal_comments_gravatar' );
function royal_comments_gravatar( $args ) {

	$args['avatar_size'] = 60;
	return $args;
	
}

//* Remove comment form allowed tags
add_filter( 'comment_form_defaults', 'royal_remove_comment_form_allowed_tags' );
function royal_remove_comment_form_allowed_tags( $defaults ) {
	
	$defaults['comment_notes_after'] = '';
	return $defaults;

}

//* Add support for 3-column footer widgets
add_theme_support( 'genesis-footer-widgets', 3 );


//* Register widget areas
genesis_register_sidebar( array(
	'id'          => 'home-top',
	'name'        => __( 'Home - Top', 'royal' ),
	'description' => __( 'This is the top section of the homepage.', 'royal' ),
) );
genesis_register_sidebar( array(
	'id'          => 'home-middle',
	'name'        => __( 'Home - Middle', 'royal' ),
	'description' => __( 'This is the middle section of the homepage.', 'royal' ),
) );
genesis_register_sidebar( array(
	'id'          => 'home-bottom-left',
	'name'        => __( 'Home - Bottom Left', 'royal' ),
	'description' => __( 'This is the bottom left section of the homepage.', 'royal' ),
) );
genesis_register_sidebar( array(
	'id'          => 'home-bottom-right',
	'name'        => __( 'Home - Bottom Right', 'royal' ),
	'description' => __( 'This is the bottom right section of the homepage.', 'royal' ),
) );