<?php
/**
 * This file adds the custom filterable gallery to the Rowan theme
 *
 * @author 17thAvenue
 * @package Rowan
 * @subpackage Customizations
 */

# Force full width content
add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );

wp_enqueue_script('isotope', get_stylesheet_directory_uri() . '/lib/js/jquery.isotope.min.js', array('jquery'), '1.5.25', true);
wp_enqueue_script('isotope_init', get_stylesheet_directory_uri() . '/lib/js/isotope_init.js', array('isotope'), '', true);
wp_enqueue_script('isotope_pkgd', get_stylesheet_directory_uri() . '/lib/js/isotope.pkgd.min.js', array('jquery'), '', true);

//* Add custom body class
add_filter( 'body_class', 'filterable_gallery_add_body_class' );

//* Filterable Gallery custom body class
function filterable_gallery_add_body_class( $classes ) {
    $classes[] = 'filterable-gallery-page';
        return $classes;
}

remove_action( 'genesis_loop', 'genesis_do_loop' );
add_action( 'genesis_loop', 'filterable_gallery_do_loop' );

/**
 * Outputs a custom loop
 *
 * @global mixed $paged current page number if paginated
 * @return void
 */
function filterable_gallery_do_loop() { ?>

    <header id="page-heading" class="entry-header">
        <?php $terms = get_terms( 'gallery-type' ); ?>
        <?php if( $terms[0] ) { ?>
            <ul id="gallery-cats" class="filter clearfix">
                <li><a href="#" class="active" data-filter="*"><span><?php _e('All', 'genesis'); ?></span></a></li>
                <?php foreach ($terms as $term ) : ?>
                    <li><a href="#" data-filter=".<?php echo $term->slug; ?>"><span><?php echo $term->name; ?></span></a></li>
                <?php endforeach; ?>
            </ul><!-- /gallery-cats -->
        <?php } ?>
    </header><!-- /page-heading -->

    <div class="entry-content" itemprop="text">
         <?php if( have_posts() ) { ?>
            <div id="gallery-wrap" class="clearfix filterable-gallery">
                <div class="gallery-content">
                    <?php $wpex_count=0; ?>
                    <?php while( have_posts() ) : the_post() ?>
                        <?php $wpex_count++; ?>
                        <?php $terms = get_the_terms( get_the_ID(), 'gallery-type' ); ?>
                        <?php if ( has_post_thumbnail($post->ID) ) { ?>
                            <article class="gallery-item col-<?php echo $wpex_count; ?> <?php if( $terms ) foreach ( $terms as $term ) { echo $term->slug .' '; }; ?>">
                                <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php echo genesis_get_image( array( size => 'gallery' ) ); ?>
                                <div class="gallery-title"><h3><?php the_title(); ?></h3></div><!-- gallery-title --></a>
                            </article>
                        <?php } ?>
                    <?php endwhile; ?>
                </div><!-- /gallery-content -->
            </div><!-- /gallery-wrap -->
        <?php } ?>
        <?php wp_reset_postdata(); ?>
    </div><!-- /entry-content -->

<?php }

genesis();