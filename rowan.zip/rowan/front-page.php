<?php
/**
 * This file adds the Home Page to the Rowan Theme.
 *
 * @author 17thAvenue
 * @package Rowan
 * @subpackage Customizations
 */
 
add_action( 'genesis_meta', 'rowan_home_genesis_meta' );
/**
 * Add widget support for homepage. If no widgets active, display the default loop.
 *
 * @since  1.0.0
 */
function rowan_home_genesis_meta() {

	if ( is_active_sidebar( 'home-top' ) || is_active_sidebar( 'home-middle-left' ) || is_active_sidebar( 'home-bottom' ) ) {

		remove_action( 'genesis_loop', 'genesis_do_loop' );

		add_action( 'genesis_loop', 'rowan_homepage_widgets' );
		add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );
		add_filter( 'body_class', 'rowan_add_home_body_class' );
	
	}
}

//* Display content for the home sections
function rowan_homepage_widgets() {

	echo '<div class="home-top">';

		genesis_widget_area( 'home-top', array(
			'before' => '<div class="home-top-slider widget-area">',
			'after'  => '</div>',
		) );

	echo '</div>';

	echo '<div class="home-middle">';

		genesis_widget_area( 'home-middle-left', array(
			'before' => '<div class="home-middle-left one-third first widget-area">',
			'after'  => '</div>',
		) );
		
		genesis_widget_area( 'home-middle-center', array(
			'before' => '<div class="home-middle-center one-third widget-area">',
			'after'  => '</div>',
		) );
		
		genesis_widget_area( 'home-middle-right', array(
			'before' => '<div class="home-middle-right one-third widget-area">',
			'after'  => '</div>',
		) );

	echo '</div>';
	
	echo '<div class="home-bottom">';

		genesis_widget_area( 'home-bottom', array(
			'before' => '<div class="home-bottom widget-area">',
			'after'  => '</div>',
		) );

	echo '</div>';

}

//* Add body class to home page		
function rowan_add_home_body_class( $classes ) {

	$classes[] = 'rowan-home';
	return $classes;
	
}

genesis();