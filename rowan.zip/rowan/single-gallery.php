<?php
/**
 * This file adds the custom gallery single post template to the Rowan theme.
 *
 * @author 17thAvenue
 * @package Rowan
 * @subpackage Customizations
 */

//* Add link back to gallery page
add_action( 'genesis_after_entry', 'gallery_link');
function gallery_link() {
?>
<div class="gallery-back-button"><a href="<?php echo get_site_url(); ?>/gallery">Back to Gallery</a></div>
<?php
}

//* Force full width content layout
add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );

//* Remove page elements
remove_action( 'genesis_entry_header', 'genesis_post_info', 5 );
remove_action( 'genesis_before_loop', 'genesis_do_breadcrumbs' );
remove_action( 'genesis_post_info', 'post_info_filter' );
remove_action( 'genesis_entry_header', 'genesis_post_info', 12 );
remove_action( 'genesis_entry_header', 'genesis_do_post_title' );
remove_action( 'genesis_entry_footer', 'genesis_entry_footer_markup_open', 5 );
remove_action( 'genesis_entry_footer', 'genesis_entry_footer_markup_close', 15 );
remove_action( 'genesis_entry_footer', 'genesis_post_meta' );
remove_action( 'genesis_entry_footer', 'share_buttons', 2 );

genesis();