( function( window, $, undefined ) {
'use strict';
$( 'nav' ).before( '<button class="menutoggle" role="button" aria-pressed="false"></button>' ); 
$( 'nav .sub-menu' ).before( '<button class="submenutoggle" role="button" aria-pressed="false"></button>' ); 
$( '.menutoggle, .submenutoggle' ).on( 'click', function() {
var $this = $( this );
$this.attr( 'aria-pressed', function( index, value ) {return 'false' === value ? 'true' : 'false';
});
$this.toggleClass( 'activated' );
$this.next( 'nav, .sub-menu' ).slideToggle( 'fast' );
});
})( this, jQuery );