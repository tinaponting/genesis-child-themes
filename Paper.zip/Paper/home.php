<?php		
remove_action( 'genesis_loop', 'genesis_do_loop' );
add_action( 'genesis_loop', 'child_grid_loop_helper' );
/** Add support for Genesis Grid Loop **/
function child_grid_loop_helper() {
    if ( function_exists( 'genesis_grid_loop' ) ) {
        genesis_grid_loop( array(
            'features' => 1,
            'feature_image_size' => 1,
            'feature_image_class' => 'align none post-image',
            'feature_content_limit' => 350,
			'grid_image_size' => 'grid',
            'grid_image_class' => 'aligncenter post-image',
            'grid_content_limit' => 350,
            'more' => __( '[Continue reading...]', 'genesis' ),
            'posts_per_page' => 10,
        ) );
    } else {
        genesis_standard_loop();
    }
}

/** Remove the post meta function for front page only **/
remove_action( 'genesis_after_post_content', 'genesis_post_meta' );

/** Add Masonry Scripts **/
add_filter('genesis_footer_scripts', 'masonry_scripts');
function masonry_scripts() { 
	wp_enqueue_script('masonry', CHILD_URL.'/js/jquery.masonry.min.js', array('jquery'), '2.1.05', TRUE);
	?>
	<script type="text/javascript" charset="utf-8">
		jQuery(window).load(function() {
		  jQuery('#content').masonry({
			// options
			itemSelector : '.hentry',
			isAnimated: true,
			columnWidth : 1
		  });
		});
	/script>
	<?php
}

genesis();