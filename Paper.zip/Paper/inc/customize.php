<?php
/**
 * Paper Design Design
 * @package Paper
 */
function cnp_customizer_setup($wp_customize) {
    $colors[] = array(
        'slug'      => 'cnp_link',
        'default'   => '#000',
        'label'     => 'Link'
    );
	
	$colors [] = array (
	    'slug'      => 'cnp_entrytitle',
        'default'   => '#fc0',
        'label'     => 'post title'
	);
	
	$colors [] = array (
	   'slug'      => 'cnp_sidebar',
        'default'   => '#fc0',
        'label'     => 'Sidebar'
	);
	
	$colors [] = array (
	   'slug'      => 'cnp_morelink',
        'default'   => '#fc0',
        'label'     => 'More Link'
	);
	
	$colors[] = array(
        'slug'      => 'cnp_footerwidgets',
        'default'   => '#f9f9f9',
        'label'     => 'Footer Widgets Background'
    );
	 
	 $colors[] = array(
        'slug'      => 'cnp_button',
        'default'   => '#ffffff',
        'label'     => 'Button Background'
    );
	

    foreach( $colors as $color ) {

        // SETTINGS
        $wp_customize->add_setting(
            $color['slug'], array(
                'default' => $color['default'],
                'sanitize_callback' => 'sanitize_hex_color',
            )
        );

        // CONTROLS
        $wp_customize->add_control(
            new WP_Customize_Color_Control(
                $wp_customize,
                $color['slug'],
                array(
                    'label' => $color['label'],
                    'section' => 'colors',
                    'settings' => $color['slug']
                )
            )
        );
    }

}

add_action('customize_register', 'cnp_customizer_setup');


function cnp_customizer_css() {


    $link = get_theme_mod('cnp_link');
	$navsecondary = get_theme_mod('cnp_navsecondary');
    $footerText = get_theme_mod('cnp_footer_text');
	$footerwidgets = get_theme_mod ('cnp_footerwidgets');
	$button = get_theme_mod('cnp_button');
	$entrytitle = get_theme_mod ('cnp_entrytitle');
	$sidebar = get_theme_mod ('cnp_sidebar');
	$morelink = get_theme_mod ('cnp_morelink');


?><style type="text/css">

button,
		input[type="button"],
		input[type="reset"],
		input[type="submit"] {
			background-color: <?php echo $button; ?>; 
		}
		
.entry-title a {
	color: <?php echo $entrytitle; ?>;
}	

.sidebar {
	background-color: <?php echo $sidebar; ?>;
}	

.more-link {
	background-color: <?php echo $morelink; ?>;
}

a,
.genesis-nav-menu > li a,
.genesis-nav-menu .current-menu-item > a,
.genesis-nav-menu .sub-menu > li a,
.archive-pagination li a {
    color: <?php echo $link; ?>;
}

a:hover,
.genesis-nav-menu > li a:hover,
.genesis-nav-menu .current-menu-item > a:hover,
.genesis-nav-menu .sub-menu > li a:hover,
.genesis-nav-menu .sub-menu .current-menu-item > a:hover,
.archive-pagination li a:hover {
    color: <?php echo $linkHover; ?>;
}

a:visited {
    color: <?php echo $linkVisited; ?>;
}

.genesis-nav-menu > li a:hover,
.genesis-nav-menu .current-menu-item > a:hover,
.genesis-nav-menu .sub-menu > li a:hover,
.genesis-nav-menu .sub-menu .current-menu-item > a:hover,
.archive-pagination li a:hover {
    color: <?php echo $headerNavHover; ?>;
}

.footer-widgets {
	background-color: <?php echo $footerwidgets; ?>;
}

.site-footer {
    color: <?php echo $footerText; ?>;
}

</style>
<?php
}
add_action( 'wp_head', 'cnp_customizer_css' );
