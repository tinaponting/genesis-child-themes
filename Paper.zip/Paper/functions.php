<?php
//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );

//* Child theme (do not remove)
define( 'CHILD_THEME_NAME', __( 'Paper Theme', 'paper' ) );
define( 'CHILD_THEME_VERSION', '1.1' );

//* Add HTML5 markup structure
add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption' ) );

//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

// Adds customizer support
    include_once( get_stylesheet_directory() . '/inc/customize.php' );

// enqueue Dashicons
add_action( 'wp_enqueue_scripts', 'wdm_enqueue_dashicons' );
function wdm_enqueue_dashicons() {
     wp_enqueue_style( 'ss-dashicons-font', get_stylesheet_directory_uri(), array('dashicons'), '1.0' );
}

//* Enqueue Libre+Baskerville Google font
add_action( 'wp_enqueue_scripts', 'sp_load_google_fonts' );
function sp_load_google_fonts() {
	wp_enqueue_style( 'google-font-Libre+Baskerville', '//fonts.googleapis.com/css?family=Libre+Baskerville:400,400i|Nixie+One', array(), CHILD_THEME_VERSION );
}

// Enqueue scripts and styles
add_action( 'wp_enqueue_scripts', 'custom_scripts_styles_mobile_responsive' );
function custom_scripts_styles_mobile_responsive() {

	wp_enqueue_script( 'beautiful-responsive-menu', get_stylesheet_directory_uri() . '/js/responsive-menu.js', array( 'jquery' ), '1.0.0' );
	wp_enqueue_style( 'dashicons' );

}

//* Remove the header right widget area
unregister_sidebar( 'header-right' );

//* Reposition the secondary navigation menu
remove_action( 'genesis_after_header', 'genesis_do_subnav' );
add_action( 'genesis_footer', 'genesis_do_subnav', 7 );

//* Reduce the secondary navigation menu to one level depth
add_filter( 'wp_nav_menu_args', 'studios_secondary_menu_args' );
function studios_secondary_menu_args( $args ){

	if( 'secondary' != $args['theme_location'] )
	return $args;

	$args['depth'] = 1;
	return $args;

}

//* Add support for custom header
add_theme_support( 'custom-header', array(
	'header-selector' => '.site-title a',
	'header-text'     => false,
	'height'          => 120,
	'width'           => 400,
) );

//* Add support for custom background
add_theme_support( 'custom-background', array(
	'default-attachment' => 'fixed',
	'default-color'      => 'ffffff',
	'default-image'      => get_stylesheet_directory_uri() . '/images/bgg.png',
	'default-repeat'     => 'repeat',
	'default-position-x' => 'center',
	
) );

//* Add new image sizes
add_image_size('grid', 500, 500, TRUE);
add_image_size('featured-img',500, 500, TRUE);

/** Unregister site layouts */
genesis_unregister_layout( 'content-sidebar-sidebar' );
genesis_unregister_layout( 'sidebar-sidebar-content' );
genesis_unregister_layout( 'sidebar-content-sidebar' );

//* Unregister secondary sidebar
unregister_sidebar( 'sidebar-alt' );

//* Add support for 2-column footer widgets
add_theme_support( 'genesis-footer-widgets', 2 );

/**
* Auto Complete all WooCommerce orders.
* Add to theme functions.php file
*/
 
add_action( 'woocommerce_thankyou', 'custom_woocommerce_auto_complete_order' );
function custom_woocommerce_auto_complete_order( $order_id ) {
    global $woocommerce;
 
    if ( !$order_id )
        return;
    $order = new WC_Order( $order_id );
    $order->update_status( 'completed' );
}

//* Change the footer text
add_filter('genesis_footer_creds_text', 'sp_footer_creds_filter');
function sp_footer_creds_filter( $creds ) {
	$creds = '[footer_copyright]  <a href="http://exempel.se/"> MY OWN BLOGSITE </a>';
	return $creds;
}


