<?php
//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );

//* Child theme (do not remove)
define( 'CHILD_THEME_NAME', 'Wander' );
if ( ! isset( $content_width ) )$content_width = 1200;

/* THEME SUPPORTS
--------------------------------------------- */
//* Add HTML5 markup structure
add_theme_support( 'html5' );

//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

/* IMAGE SIZES
--------------------------------------------- */
add_image_size( 'featured-large', 600, 350, true );

/* FONTS
--------------------------------------------- */
add_action( 'wp_enqueue_scripts', 'genesis_sample_google_fonts' );
function genesis_sample_google_fonts() {
	wp_enqueue_style( 'font-playfair-display', '//fonts.googleapis.com/css?family=Playfair+Display:400,700,400italic,700italic', array(), CHILD_THEME_VERSION );
	wp_enqueue_style( 'font-open-sans', '//fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,400,300,600,700', array(), CHILD_THEME_VERSION );
	wp_enqueue_style( 'font-noto-serif', '//fonts.googleapis.com/css?family=Noto+Serif:400,700,400italic,700italic', array(), CHILD_THEME_VERSION );
	wp_enqueue_style( 'font-inconsolata', '//fonts.googleapis.com/css?family=Inconsolata', array(), CHILD_THEME_VERSION );
}
/* ENQUEUE SCRIPTS & STYLES
--------------------------------------------- */
add_action( 'wp_enqueue_scripts', 'wander_register_scripts' );
function wander_register_scripts(){
	wp_enqueue_script('wander-js', get_stylesheet_directory_uri() . '/assets/js/custom.js', array( 'jquery' ), array(), true);
	wp_enqueue_script('responsive-menu', get_stylesheet_directory_uri() . '/assets/js/responsive_menu.js', array( 'jquery' ), array(), true);
	wp_enqueue_style('fontawesome', get_stylesheet_directory_uri() . '/assets/css/font-awesome.min.css', array(), CHILD_THEME_VERSION );
	
	$settings_option = unserialize(get_option('wander-setting'));
	$options = (isset($settings_option['wander'])) ? $settings_option['wander'] : array();
	$colors = array('blue','green','red','orange', 'yellow');
	foreach ($colors as $key => $value) {
		wp_register_style( 'wander-color-scheme-' . $value, 
	    get_stylesheet_directory_uri() . '/assets/css/'. $value .'.css',
	    array(), CHILD_THEME_VERSION );
	}
	if(isset($options['color']) && in_array($options['color'], $colors)){wp_enqueue_style( 'wander-color-scheme-' .  $options['color'] );
	}}
/* WP_HEAD HOOKS
--------------------------------------------- */
add_action('wp_head','wander_head');
function wander_head(){
	$settings_option = unserialize(get_option('wander-setting'));
	$options = (isset($settings_option['wander'])) ? $settings_option['wander'] : array();
	if(isset($options['color']) && 'custom' == $options['color']){ ?>
	<style type="text/css">
	<?php if(isset($options['link']) && !empty($options['link'])):?>
	body .site-description, body a {
	  color: <?php echo $options['link'];?>;
	}
	<?php endif;?>
	<?php if(isset($options['hover']) && !empty($options['hover'])):?>
	body a:hover, body .footer-widgets a:hover, body .site-footer a:hover, body .entry-title a:hover {
	  color: <?php echo $options['hover'];?>;
	}
	body .footer-widgets button:hover, body .footer-widgets input[type="button"]:hover, body .footer-widgets input[type="reset"]:hover, body .footer-widgets input[type="submit"]:hover, body .footer-widgets .button:hover, body .footer-widgets .enews-widget input[type="submit"]:hover,
	body .tagcloud a:hover, body button:hover, body input:hover[type="button"], body input:hover[type="reset"], body input:hover[type="submit"], body .button:hover, body .entry-content .button:hover {
	  background-color: <?php echo $options['hover'];?>;
	}
	body .tagcloud a:hover {
	  border-color: <?php echo $options['hover'];?>;
	}
	<?php endif;?>
	</style>
	<?php }
}
/* LAYOUT HOOKS
--------------------------------------------- */
unregister_sidebar( 'header-right' );
add_action('genesis_after_header', 'wander_before_content_sidebar_wrap');
function wander_before_content_sidebar_wrap(){
	if(is_home()){
		get_template_part( 'includes/content', 'postsblock' );
	}}
/* Add Social Icons on Top
------------------------------------------------------------ */
add_action('genesis_before_header', 'wander_before_header');
function wander_before_header(){
	$settings_option = unserialize(get_option('wander-setting'));
	$options = (isset($settings_option['wander'])) ? $settings_option['wander'] : array();
	?>
	<div class="header-right">
		<div class="site-header-search">
			<form method="get" role="form" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
				<input id="search-query" type="text" class="form-control" placeholder="<?php _e('To search type &amp; hit enter','wander');?>" name="s" value="">
			</form>
			<a href="#" title="<?php _e('Search','wander');?>" class="search-toggle" data-toggle="dropdown">
				<span class="fa fa-search"></span>
			</a>
		</div>
		<?php
		if(!empty($options['socials'])){
			echo '<div class="top-social"><ul>';
			foreach ($options['socials'] as $key => $value) {
				if(!empty($value)){
					if(!in_array($key, array('envelope-o'))){echo '<li><a href="'. wander_addhttp($value) .'" target="_blank"><i class="fa fa-'. $key .'"></i></a></li>';
					}else{echo '<li><a href="mailto:'. $value .'"><i class="fa fa-'. $key .'"></i></a></li>';
					}}}
			echo '</ul></div>';
		}
		?>	
		<div class="clear"></div>
	</div>
	<?php
}
/* Add support for 3-column footer widgets
------------------------------------------------------------ */
add_theme_support( 'genesis-footer-widgets', 3 );

/* Entry Header Format
------------------------------------------------------------ */
remove_action( 'genesis_entry_header', 'genesis_post_info', 12);
add_action( 'genesis_entry_header', 'genesis_post_info', 9 );
add_filter( 'genesis_post_info', 'wander_post_info_filter' );
function wander_post_info_filter($post_info) {
	$post_info = '[post_date]';
	return $post_info;
}
add_action( 'genesis_entry_header', 'wander_post_info', 20 );
function wander_post_info(){
	echo '<p class="entry-meta">';
	if(is_single()){
		echo do_shortcode('[post_author_posts_link]');
		echo do_shortcode('[post_categories sep=", " before=""]');
		echo do_shortcode('[post_comments]');}echo '</p>';
}
/* Customize the entry meta in the entry footer (requires HTML5 theme support)
------------------------------------------------------------------------------- */
add_filter( 'genesis_post_meta', 'sp_post_meta_filter' );
function sp_post_meta_filter($post_meta) {
	$post_meta = '[post_tags]';
	return $post_meta;
}
/* Add Read more Link
------------------------------------------------------------ */
add_filter('excerpt_more', 'wander_read_more_link');
add_filter( 'the_content_more_link', 'wander_read_more_link' );
function wander_read_more_link() {
   return '...<div class="post-more-link"><a href="' . get_permalink() . '">'. __('Continue Reading', 'wander') .'</a></div>';
}
/* Add span class to widget headline
------------------------------------------------------------ */
add_filter( 'widget_title', 'wander_widget_title' );
function wander_widget_title( $title ){
  if( $title )
  return sprintf('<span>%s</span>', $title );
}
/* Wrap Count
------------------------------------------------------------ */
add_filter('get_archives_link', 'wander_count_archive');
function wander_count_archive($links) {
	$links = str_replace('</a>&nbsp;(', '</a><span class="post-count">', $links);
	$links = str_replace(')', '</span>', $links);
	return $links;
}
add_filter('wp_list_categories','wander_count_category');
function wander_count_category ($variable) {
$variable = str_replace('(', '<span class="post-count"> ', $variable);
$variable = str_replace(')', ' </span>', $variable);return $variable;
}	
/* ADMIN MENU
--------------------------------------------- */
add_action('admin_menu', 'wander_settings_init', 15);
function wander_settings_init() {
    global $_wander_settings_pagehook;
    $_wander_settings_pagehook = add_submenu_page('genesis', __('Child Theme Settings','wander'), __('Child Theme Settings','wander'), 'manage_options', 'wander', 'wander_settings_admin');
    add_action('load-'.$_wander_settings_pagehook, 'wander_settings_scripts');
    add_action('load-'.$_wander_settings_pagehook, 'wander_settings_boxes');
}
function wander_settings_admin(){
	global $_wander_settings_pagehook;
	$settings_option = unserialize(get_option('wander-setting'));
	if(isset($_POST['wander_action']) && $_POST['wander_action'] == "save_wander_settings_page"){
		update_option('wander-setting', serialize($_POST));
		$settings_option = $_POST;
	}
	?>
	<div id="howto-metaboxes-general" class="wrap">
		<h2><?php _e('Genesis Child Theme Options','wander');?></h2><br /><br />
		<form action="<?php _e( str_replace( '%7E', '~', $_SERVER['REQUEST_URI']) ); ?>" method="post">
			<?php wp_nonce_field('wander-settings-page'); ?>
			<?php wp_nonce_field('closedpostboxes', 'closedpostboxesnonce', false ); ?>
			<?php wp_nonce_field('meta-box-order', 'meta-box-order-nonce', false ); ?>
			<input type="hidden" name="wander_action" value="save_wander_settings_page" />

			<div id="poststuff" class="metabox-holder">
				<div id="side-info-column" class="inner-sidebar">
					<?php do_meta_boxes($_wander_settings_pagehook, 'side', $settings_option); ?>
				</div>
				<div id="post-body" class="has-sidebar">
					<div id="post-body-content" class="has-sidebar-content">
						<?php do_meta_boxes($_wander_settings_pagehook, 'normal', $settings_option); ?>
						<p class="wpp_save_changes_row">
							<input type="submit" value="<?php _e('Save Changes','wander');?>" class="button-primary btn" name="Submit">
						</p>
					</div></div>
				<br class="clear"/>					
			</div>
		</form>
	</div>
	<script type="text/javascript">
		//<![CDATA[
		jQuery(document).ready( function($) {
			// close postboxes that should be closed
			$('.if-js-closed').removeClass('if-js-closed').addClass('closed');
			// postboxes setup
			postboxes.add_postbox_toggles('<?php echo $_wander_settings_pagehook; ?>');
		});
		//]]>
	</script>
	<?php
}
function wander_settings_scripts(){
	wp_enqueue_script('jquery');
	wp_enqueue_script('jquery-ui-core');
	wp_enqueue_script('jquery-ui-sortable');
	wp_enqueue_script('common');
	wp_enqueue_script('wp-lists');
	wp_enqueue_script('postbox');
	wp_enqueue_style( 'wp-color-picker' );
	wp_enqueue_script('wp-color-picker');
	wp_register_style( 'wander-settings', 
	    get_stylesheet_directory_uri() . '/assets/css/admin.css',
	    array(), CHILD_THEME_VERSION );
	wp_enqueue_style( 'wander-settings' );
	wp_enqueue_script('wander-admin', get_stylesheet_directory_uri() . '/assets/js/admin.js', array( 'jquery' ), array(), true);
}
function wander_settings_boxes(){
	global $_wander_settings_pagehook;
	add_meta_box('wander-general-metabox', __('General Settings','wander'), 'wander_general', $_wander_settings_pagehook, 'normal', 'core');
	add_meta_box('wander-social-metabox', __('Social Media','wander'), 'wander_social_media', $_wander_settings_pagehook, 'normal', 'core');
}
function wander_general($settings_options){
	$options = (isset($settings_options['wander'])) ? $settings_options['wander'] : array();
	$categories = get_categories(
						array('hide_empty'=>	1
							));
	$selected = (isset($options['featured']) && !empty($options['featured'])) ? $options['featured'] : 1; 
	$color = (isset($options['color']) && !empty($options['color'])) ? $options['color'] : 'default'; 
	?>
	<table class="form-table">
		<tbody>
			<tr valign="top">
				<th scope="row"><label for="wander_color"><?php _e('Color Scheme','wander');?></label></th>
				<td><select name="wander[color]" class="widefat wander-color-scheme">
					<option value="default" <?php echo ($color == 'default') ? 'selected="selected"' : '';?>><?php _e('Default', 'wander');?></option>
					<option value="blue" <?php echo ($color == 'blue') ? 'selected="selected"' : '';?>><?php _e('Blue', 'wander');?></option>
					<option value="green" <?php echo ($color == 'green') ? 'selected="selected"' : '';?>><?php _e('Green', 'wander');?></option>
					<option value="red" <?php echo ($color == 'red') ? 'selected="selected"' : '';?>><?php _e('Red', 'wander');?></option>
					<option value="orange" <?php echo ($color == 'orange') ? 'selected="selected"' : '';?>><?php _e('Orange', 'wander');?></option>
					<option value="yellow" <?php echo ($color == 'yellow') ? 'selected="selected"' : '';?>><?php _e('Yellow', 'wander');?></option>
					<option value="custom" <?php echo ($color == 'custom') ? 'selected="selected"' : '';?>><?php _e('Custom', 'wander');?></option>
				</select></td>
			</tr>
			<tr valign="top">
				<th scope="row"><label for="wander_featured"><?php _e('Featured Post Category','wander');?></label></th>
				<td><select name="wander[featured]" class="widefat">
					<?php foreach ($categories as $cat) {
						echo '<option value="'. $cat->term_id .'" '. (($selected == $cat->term_id) ? 'selected="selected"' : '') .'>'. $cat->name .'</option>';
					}?>
				</select></td>
			</tr>
		</tbody>
	</table>
	<table class="form-table wander-custom" <?php echo ($color == 'custom') ? 'style="display:table-row;"' : '';?>>
		<tbody>
			<tr valign="top">
				<th scope="row"><label for="wander_link"><?php _e('Link Color','wander');?></label></th>
				<td><input type="text" name="wander[link]" class="wander-colorwell" value="<?php echo (isset($options['link']) && !empty($options['link'])) ? $options['link'] : '';?>" /></td>
			</tr>
		
			<tr valign="top">
				<th scope="row"><label for="wander_hover"><?php _e('Hover Color','wander');?></label></th>
				<td><input type="text" name="wander[hover]" class="wander-colorwell" value="<?php echo (isset($options['hover']) && !empty($options['hover'])) ? $options['hover'] : '';?>"  /></td>
			</tr>
		</tbody>
	</table>
	<p class="wander_save_changes_row">
		<input type="submit" value="<?php _e('Save Changes', 'wander');?>" class="button-primary btn" name="Submit">
	</p>
	<?php
}
function wander_social_media($settings_options){
	$options = (isset($settings_options['wander'])) ? $settings_options['wander'] : array();
	$placeholder = '';
	$socials = array(
					'envelope-o'=> __('Email Address','wander'),
					'facebook'=> __('Facebook', 'wander'),
					'twitter'=> __('Twitter', 'wander'),
					'instagram'=> __('Instagram', 'wander'),
					'reddit'=> __('Reddit', 'wander'),
					'pinterest'=> __('Pinterest', 'wander'),
					'dribbble'=> __('Dribbble', 'wander'),
					'linkedin'=> __('Linkedin', 'wander'),
					'behance'=> __('Behance', 'wander'),
					'skype'=> __('Skype', 'wander'),
					'github'=> __('Github', 'wander'),
					'flickr'=> __('Flickr', 'wander'),
					'vimeo-square'=> __('Vimeo', 'wander'),
					'tumblr'=> __('Tumblr', 'wander'),
					'foursquare'=> __('Four Square', 'wander'),
					// 'qoura'=> __('Qoura', 'wander'),
					'lastfm'=> __('Lastfm', 'wander'),
					// 'rdio'=> __('Rdio', 'wander'),
					'spotify'=> __('Spotify', 'wander'),
					'dropbox'=> __('Dropbox', 'wander'),
					// 'evernote'=> __('Evernote', 'wander'),
					// 'flattr'=> __('Flattr', 'wander'),
					// 'sinaweibo'=> __('Sina Weibo', 'wander'),
					'paypal'=> __('Paypal', 'wander'),
					// 'picasa'=> __('Picasa', 'wander'),
					'soundcloud'=> __('Sound Cloud', 'wander'),
					// 'smashing-magazine'=> __('Smashing Magazine', 'wander'),
					'deviantart'=> __('Deviantart', 'wander'),
					'steam'=> __('Steam', 'wander'),
					'vk'=> __('VKontakte', 'wander'),
					'rss'=> __('RSS', 'wander')
				);
	if(isset($options['socials'])){$_socials = $options['socials'];}else{$_socials = $socials;
	}
	?>
	<table class="wp-list-table widefat">
		<tbody class="ui-sortable wander-table-socials">
			<?php foreach ($_socials as $key => $value) { 
				if(!in_array($key, array('envelope-o'))){
					$value = wander_addhttp($value);
					$placeholder = __('Add Complete '. $socials[ $key ] .' Url', 'wander');
				}
				?>
			<tr class="wander_row">
				<td class="wander_handle">&nbsp;</td>	
				<td><label for="wander_<?php echo $key;?>"><?php echo $socials[ $key ];?></label></td>
				<td><input type="text" name="wander[socials][<?php echo $key;?>]" id="wander_<?php echo $key;?>" value="<?php echo (isset($options['socials'])) ? $value : '';?>" class="widefat" placeholder="<?php echo $placeholder;?>" /></td>
			</tr>
			<?php }?>
		</tbody>
	</table>
	<p class="wander_save_changes_row">
		<input type="submit" value="<?php _e('Save Changes', 'wander');?>" class="button-primary btn" name="Submit">
	</p>
	<script>
		jQuery(document).ready(function($){
			$( ".ui-sortable" ).sortable();
		});
	</script>
	<?php
}
function wander_addhttp($url) {if (!preg_match("~^(?:f|ht)tps?://~i", $url) && !empty($url)) {$url = "http://" . $url;}return $url;
}
?>