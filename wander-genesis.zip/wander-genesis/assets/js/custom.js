/**
* Genesis Child Theme
*/
// Utility
if ( typeof Object.create !== 'function' ) {
	Object.create = function( obj ) {
		function F() {};
		F.prototype = obj;
		return new F();
	};}
(function( $, window, document, undefined ) {
	$('.site-header-search a').on('click',function(e){
		if($('.site-header-search').hasClass('open')){
			$('.site-header-search').removeClass('open');
		}else{$('.site-header-search').addClass('open');
		}
		e.preventDefault();
		e.stopPropagation();
	});
	$(window).resize(function(){
		if(window.innerWidth < 959) {jQuery('.content-sidebar-wrap .content').css({'min-height' : '1px'});}else{custom_border();
		}});
})( jQuery, window, document );
jQuery(window).load(function($){
	if(window.innerWidth > 959) {
		custom_border();
	}});
function custom_border(){
	var content_h = jQuery('.content-sidebar-wrap .content').outerHeight();
	var msidebar_h = jQuery('.content-sidebar-wrap .sidebar-primary').outerHeight();
	var ssidebar_h = jQuery('.content-sidebar-wrap .sidebar-secondary').outerHeight();
	if(msidebar_h > content_h){
		jQuery('.content-sidebar-wrap .content').css({'min-height' : msidebar_h});
	}
	if(ssidebar_h > content_h && ( ssidebar_h > msidebar_h )){jQuery('.content-sidebar-wrap .content').css({'min-height' : ssidebar_h});
	}}