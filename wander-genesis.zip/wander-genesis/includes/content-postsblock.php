<?php
$count = 1;
$settings_option = unserialize(get_option('wander-setting'));
$options = (isset($settings_option['wander'])) ? $settings_option['wander'] : array();
$cat_id = (isset($options['featured']) && !empty($options['featured'])) ? $options['featured'] : 1; 
$args = array(
            'post_type'=> 'post',
            'post_status'=>  'publish',
            'cat'=>	$cat_id,
            'orderby'=> 'date',
            'order'=> 'DESC',
            'posts_per_page'=>	5,
            'ignore_sticky_posts'=> 1
        );
$colors = array(
				'turquoise', 'emerland', 'peter-river', 'amethyst', 'wet-asphalt',
				'green-sea', 'nephritis', 'belize-hole', 'wisteria', 'midnight-blue',
				'sun-flower', 'carrot', 'alizarin', 'pumpkin','pomegranate'
			);
?>
<div class="wander-posts-block">
	<?php
	$query = new WP_Query( $args );
                if ( $query->have_posts() ) :
                	while ( $query->have_posts() ) : $query->the_post();
                		$style = '';
                		if(has_post_thumbnail()){
                			$image = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'featured-large' );
                			$style = 'background-image: url('. $image[0] .')';
                		}
                		$post_categories = wp_get_post_categories( get_the_ID() );
                		if( $count <= 2  ){ ?>
							<div class="one-half">
								<a href="<?php the_permalink();?>">
									<div class="wander-posts-block-inner uicolor-<?php echo $colors[ array_rand($colors) ];?>" <?php if(!empty($style)){ echo 'style="'. $style .'"'; }?>>
										<div class="wander-posts-block-info">
											<span class="entry-meta"><?php echo do_shortcode('[post_date]');?></span>
											<h3><?php the_title();?></h3>
											<?php
											if(!empty($post_categories)){ ?>
												<ul class="post-categories">
													<?php 
														foreach ($post_categories as $post_category) {
															$cat = get_category( $post_category );
															echo '<li>'. $cat->name .'</li>';
														}
													?>
												</ul>
											<?php } ?>										
										</div>
										<span class="overlay"></span>
									</div>
								</a>
							</div>
						<?php
                		}else{ ?>
							<div class="one-third">
								<a href="<?php the_permalink();?>">
									<div class="wander-posts-block-inner uicolor-<?php echo $colors[ array_rand($colors) ];?>" <?php if(!empty($style)){ echo 'style="'. $style .'"'; }?>>
										<div class="wander-posts-block-info">
											<span class="entry-meta"><?php echo do_shortcode('[post_date]');?></span>
											<h3><?php the_title();?></h3>
											<?php
											if(!empty($post_categories)){ ?>
												<ul class="post-categories">
													<?php 
														foreach ($post_categories as $post_category) {
															$cat = get_category( $post_category );
															echo '<li>'. $cat->name .'</li>';
														}
													?>
												</ul>
											<?php } ?>
										</div>
										<span class="overlay"></span>
									</div>
								</a>
							</div>
                		<?php }
                	$count++;
                	endwhile;
                endif;
    wp_reset_postdata();
	?>
	<div class="clear" style="clear:both;"></div>
</div>