<?php
/**
 * This file adds the blog page to the theme
 *
 * @package      Linda
 * @license      GPL-2.0+
 */

/*
Template Name: Blog
*/



genesis();