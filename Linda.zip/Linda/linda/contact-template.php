<?php
/**
 *
 * @package      linda
 * @license      GPL-2.0+
 */

/*
Template Name: Contact
*/

add_action( 'genesis_meta', 'linda_template_name_genesis_meta' );
/**
 * Add widget support for this template. If no widgets are active, display the default Genesis loop.
 *
 */
 
function linda_template_name_genesis_meta() {
 
 if ( is_active_sidebar( 'linda-contact-widget-left' ) ) {
 
 remove_action( 'genesis_loop', 'genesis_do_loop' );
 add_action( 'genesis_loop', 'linda_template_name_widget_name' );
 }
}

 add_filter( 'body_class', 'add_body_class' );
 
 function add_body_class( $classes ) {
   $classes[] = 'linda-contact';
   return $classes;
 }
 
 
//* Remove Page Title
remove_action('genesis_entry_header', 'genesis_do_post_title');

//* Force full width content layout
add_filter( 'genesis_site_layout', '__genesis_return_full_width_content' );


//* Contact Page - Left Widget Area
add_action( 'genesis_entry_content', 'linda_contact_left' );
function linda_contact_left() {
 
    genesis_widget_area( 'linda-contact-left', array(
        'before' => '<div class="linda-contact-left widget-area"><div class="wrap one-half first">',
        'after'  => '</div></div>', 
    ) );
    
}
 
//* Contact Page - Right Widget Area
add_action( 'genesis_entry_content', 'linda_contact_right' );
function linda_contact_right() {
 
    genesis_widget_area( 'linda-contact-right', array(
        'before' => '<div class="linda-contact-right widget-area"><div class="wrap one-half">',
        'after'  => '</div></div>', 
    ) );
    
}

genesis();