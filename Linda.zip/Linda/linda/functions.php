<?php
//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );

//* Set Localization (do not remove)
load_child_theme_textdomain( 'linda', apply_filters( 'child_theme_textdomain', get_stylesheet_directory() . '/languages', 'linda' ) );

//* Add WordPress theme customizer color support
require_once( get_stylesheet_directory() . '/lib/customize.php' );

//* Child theme (do not remove)
define( 'CHILD_THEME_NAME', 'linda' );

//* Enqueue scripts and styles
add_action( 'wp_enqueue_scripts', 'linda_enqueue_scripts_styles' );
function linda_enqueue_scripts_styles() {

    wp_enqueue_script( 'linda-global', get_bloginfo( 'stylesheet_directory' ) . '/js/global.js', array( 'jquery' ), '1.0.0' );
    wp_enqueue_style( 'linda-ionicons', '//code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css', array(), CHILD_THEME_VERSION );
    wp_enqueue_style( 'dashicons' );
    wp_enqueue_style( 'linda-google-fonts', '//fonts.googleapis.com/css?family=Josefin+Sans:300,400,700|Lora:400,400i,700', array(), CHILD_THEME_VERSION );
    
    if ( class_exists( 'woocommerce' ) ) {
        wp_enqueue_style( 'custom-stylesheet', CHILD_URL . '/woo/linda-woocommerce.css', array() );
    }
}

//* Add HTML5 markup structure
add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption' ) );

//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

// Register responsive menu script
add_action( 'wp_enqueue_scripts', 'linda_responsive_menu' );
function linda_responsive_menu() {

    wp_enqueue_script( 'linda-responsive-menu', get_stylesheet_directory_uri() . '/js/responsive-menu.js', array( 'jquery' ), '1.0.0', true );
 
}

//* Add new image sizes
add_image_size( 'blog-image', 700, 9999, FALSE );
add_image_size( 'home-featured', 1040, 9999, FALSE );
add_image_size( 'category-page', 330, 500, TRUE );
add_image_size( 'category-index', 320, 320, TRUE );

function remove_admin_login_header() {
    remove_action('wp_head', '_admin_bar_bump_cb');
}
add_action('get_header', 'remove_admin_login_header');

//* Add support for a 3-column footer widget area
add_theme_support( 'genesis-footer-widgets', 3 );

//* Reposition the 3-column footer
remove_action( 'genesis_before_footer', 'genesis_footer_widget_areas' );
add_action( 'genesis_after', 'genesis_footer_widget_areas', 5 );

//* Reposition the footer
remove_action( 'genesis_footer', 'genesis_do_footer' );
add_action( 'genesis_after', 'genesis_do_footer', 12 );

//* Customize the footer credits
add_filter( 'genesis_footer_creds_text', 'linda_footer_creds_text' );
function linda_footer_creds_text() {

    echo '<div class="creds"><p>';
    echo ' &copy; ';
    echo date('Y ');
    echo get_bloginfo( 'name' );
    echo ' &middot; by <a target="_blank" href="https://eatinglinks.tk">MY OWN BLOGDESIGN</a>';
    echo '</p></div>';

}

//* Automatic titles on archive pages
function linda_default_term_title( $value, $term_id, $meta_key, $single ) {
    if( ( is_category() || is_tag() || is_tax() ) && 'headline' == $meta_key && ! is_admin() ) {
    
        // Grab the current value, be sure to remove and re-add the hook to avoid infinite loops
        remove_action( 'get_term_metadata', 'linda_default_term_title', 10 );
        $value = get_term_meta( $term_id, 'headline', true );
        add_action( 'get_term_metadata', 'linda_default_term_title', 10, 4 );
        // Use term name if empty
        if( empty( $value ) ) {
            $term = get_term_by( 'term_taxonomy_id', $term_id );
            $value = $term->name;
        }
    
    }
    return $value;      
}
add_filter( 'get_term_metadata', 'linda_default_term_title', 10, 4 );


//* Set number of posts on category archive pages
function linda_category_post_count($query)
{
    if ($query->is_main_query() && $query->is_category() && !is_admin())
        $query->set('posts_per_page', 6);
}
 
add_action('pre_get_posts', 'linda_category_post_count');


//* Modify Genesis Read More Link
add_filter( 'excerpt_more', 'linda_read_more_link' );
add_filter( 'get_the_content_more_link', 'linda_read_more_link' );
add_filter( 'the_content_more_link', 'linda_read_more_link' );
/**
 * Modify the Genesis read more link.
 *
 * @since  1.0.0
 *
 * @param  string $more
 * @return string Modified read more text.
 */
function linda_read_more_link() {
    return '...</p><p><a class="more-link" href="' . get_permalink() . '">' . __( 'View Post', 'linda' ) . '</a></p>';
}

//* Unregister the header right widget area
unregister_sidebar( 'header-right' );

//* Reposition header
remove_action( 'genesis_header', 'genesis_header_markup_open', 5 );
remove_action( 'genesis_header', 'genesis_do_header' );
remove_action( 'genesis_header', 'genesis_header_markup_close', 10 ) ;

add_action( 'genesis_before', 'genesis_header_markup_open', 5 );
add_action( 'genesis_before', 'genesis_do_header' );
add_action( 'genesis_before', 'genesis_header_markup_close', 10 );

//* Reposition the secondary navigation menu
remove_action( 'genesis_after_header', 'genesis_do_subnav' );
add_action( 'genesis_before', 'genesis_do_subnav', 12 );

//* Reposition the primary navigation menu
remove_action( 'genesis_after_header', 'genesis_do_nav' );
add_action( 'genesis_before', 'genesis_do_nav', 1 );

//* Remove output of primary navigation right extras
remove_filter( 'genesis_nav_items', 'genesis_nav_right', 10, 2 );
remove_filter( 'wp_nav_menu_items', 'genesis_nav_right', 10, 2 );

//* Unregister layout settings
genesis_unregister_layout( 'content-sidebar-sidebar' );
genesis_unregister_layout( 'sidebar-content-sidebar' );
genesis_unregister_layout( 'sidebar-sidebar-content' );

//* Unregister secondary sidebar
unregister_sidebar( 'sidebar-alt' );

//* Add support for custom header
add_theme_support( 'custom-header', array(
    'flex-height'     => true,
    'width'           => 900,
    'height'          => 300,
    'header-selector' => '.site-title a',
    'header-text'     => false,
) );

//* Add support for structural wraps
add_theme_support( 'genesis-structural-wraps', array(
    'header',
    'nav',
    'subnav',
    'footer-widgets',
    'footer',
) );

//* Above Header widget area
add_action( 'genesis_before', 'linda_above_header', 1 );
function linda_above_header() {
    if( is_active_sidebar('above-header') ) {
        genesis_widget_area( 'above-header', array(
            'before'    => '<div class="above-header wrap widget-area">',
            'after'     => '</div>',
        ) );
    }
}

//* Above Footer widget area
add_action( 'genesis_before_footer', 'linda_above_footer', 1 );
function linda_above_footer() {
    if( is_active_sidebar('above-footer') ) {
        genesis_widget_area( 'above-footer', array(
            'before'    => '<div class="above-footer wrap widget-area">',
            'after'     => '</div>',
        ) );
    }
}

//* Below Header widget area
add_action( 'genesis_after_header', 'linda_below_header' );
function linda_below_header() {
    if( is_home() && !is_paged()  && is_active_sidebar('below-header') ) {
        genesis_widget_area( 'below-header', array(
            'before'    => '<div class="below-header wrap widget-area">',
            'after'     => '</div>',
        ) );
    }
}

//* Modify the size of the Gravatar in the author box
add_filter( 'genesis_author_box_gravatar_size', 'linda_author_box_gravatar' );
function linda_author_box_gravatar( $size ) {

    return 176;

}

//* Modify the size of the Gravatar in the entry comments
add_filter( 'genesis_comment_list_args', 'linda_comments_gravatar' );
function linda_comments_gravatar( $args ) {

    $args['avatar_size'] = 120;

    return $args;

}

//* Remove comment form allowed tags
add_filter( 'comment_form_defaults', 'linda_remove_comment_form_allowed_tags' );
function linda_remove_comment_form_allowed_tags( $defaults ) {

    $defaults['comment_field'] = '<p class="comment-form-comment"><label for="comment">' . _x( 'Comment', 'noun', 'linda' ) . '</label> <textarea id="comment" name="comment" cols="45" rows="8" aria-required="true"></textarea></p>';
    $defaults['comment_notes_after'] = '';

    return $defaults;

}

//* Customize search form input button text
add_filter( 'genesis_search_button_text', 'linda_search_button_text' );
function linda_search_button_text( $text ) {
    return esc_attr( 'Go' );
}

//* Customize search form input box text
add_filter( 'genesis_search_text', 'sp_search_text' );
function sp_search_text( $text ) {
    return esc_attr( 'Looking for...' );
}


//* Genesis Previous/Next Post Post Navigation
add_action( 'genesis_before_comments', 'linda_prev_next_post_nav' );

function linda_prev_next_post_nav() {

    if ( is_single() ) {

        echo '<div class="prev-next-navigation">';
        previous_post_link( '<div class="previous">%link</div>', '%title' );
        next_post_link( '<div class="next">%link</div>', '%title' );
        echo '</div><!-- .prev-next-navigation -->';
    }
}

//* Add support for after entry widget
add_theme_support( 'genesis-after-entry-widget-area' );

//* Add Theme Support for WooCommerce
add_theme_support( 'genesis-connect-woocommerce' );

//* Remove Add to Cart on Archives
add_action( 'woocommerce_after_shop_loop_item', 'linda_remove_add_to_cart_buttons', 1 );
function linda_remove_add_to_cart_buttons() {

    remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart' );
}

//* Remove Related Products
remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20 );

//* Force full width layout on WooCommerce pages
function linda_woo_full_layout() {
 if( is_page ( array( 'shop', 'cart', 'checkout' )) || 'product' == get_post_type() ) {
 return 'full-width-content';
 }
}
add_filter( 'genesis_site_layout', 'linda_woo_full_layout' );


//* Display 12 products per page
add_filter( 'loop_shop_per_page', create_function( '$cols', 'return 12;' ), 20 );


//* Setup widget counts
function linda_count_widgets( $id ) {
    global $sidebars_widgets;

    if ( isset( $sidebars_widgets[ $id ] ) ) {
        return count( $sidebars_widgets[ $id ] );
    }

}

function linda_widget_area_class( $id ) {
    $count = linda_count_widgets( $id );

    $class = '';

    if( $count == 1 ) {
        $class .= ' widget-full';
    } elseif( $count % 3 == 1 ) {
        $class .= ' widget-thirds';
    } elseif( $count % 4 == 1 ) {
        $class .= ' widget-fourths';
    } elseif( $count % 2 == 0 ) {
        $class .= ' widget-halves uneven';
    } else {
        $class .= ' widget-halves';
    }
    return $class;

}


//* Customize the entry meta in the entry header
add_filter( 'genesis_post_info', 'linda_post_info_filter' );
function linda_post_info_filter( $post_info ) {

    $post_info = '[post_date]';

    return $post_info;

}

//* Position post info above post title
remove_action( 'genesis_entry_header', 'genesis_post_info', 12);
add_action( 'genesis_entry_header', 'genesis_post_info', 9 );

//* Customize the entry meta in the entry footer
add_filter( 'genesis_post_meta', 'linda_post_meta_filter' );
function linda_post_meta_filter( $post_meta ) {

    $post_meta = 'By [post_author_posts_link] [post_categories before=" &middot; <em>in</em> "]  [post_tags before=" &middot; Tagged: "] [post_edit]';

    return $post_meta;

}


//* Reposition the Genesis Simple Share buttons
add_action( 'genesis_entry_footer', 'share_icons_footer', 9 );
function share_icons_footer() {
	if( 'post' === get_post_type() && function_exists( 'genesis_share_get_icon_output' ) ) {
		genesis_share_icon_output( 'before_entry_header', array(  'facebook', 'twitter', 'pinterest', 'googlePlus' ) );
	}
}

//* Add Full-Width Footer widget area (for Instagram)
add_action( 'genesis_after', 'linda_instagram', 10 );
function linda_instagram() {

    if (is_active_sidebar( 'linda-instagram' )) {
        genesis_widget_area( 'linda-instagram', array(
            'before' => '<div class="linda-instagram widget-area"><div>',
            'after' => '</div></div>'
            ) );
    }
}


//* Add shop the post custom field
add_action( 'genesis_after_entry', 'shop_post_widget', 1 );
function shop_post_widget() {
if(is_page() || is_front_page() || is_single() ) {
genesis_custom_field('shop_post');
}
}

//* Register widget areas
genesis_register_sidebar( array(
    'id'            => 'above-header',
    'name'          => 'Above Header',
    'description'   => 'This is a widget area that appears above your header. You could add a newsletter signup, advertisement banner, or anything you want here.'
) );
genesis_register_sidebar( array(
    'id'            => 'below-header',
    'name'          => 'Below Header',
    'description'   => 'This is a widget area that appears between your header and blog posts. You could add an image slider, newsletter signup, or anything you want here.'
) );
//* Register widget areas
genesis_register_sidebar( array(
    'id'            => 'above-footer',
    'name'          => 'Above Footer',
    'description'   => 'This is a widget area that appears above the 3 footer columns. You could add a newsletter signup, advertisement banner, or anything you want here.'
) );
genesis_register_sidebar( array(
    'id'          => 'category-page',
    'name'        => __( 'Category Index Page', 'linda' ),
    'description' => __( 'This is the area for the Category Index.', 'linda' ),
) );
genesis_register_sidebar( array(
    'id'            => 'linda-instagram',
    'name'          => __( 'Instagram Footer Area', 'linda' ),
    'description'   => __( 'This is the full-width footer area for the Instagram widget.', 'linda' ),
) );
genesis_register_sidebar( array(
    'id'          => 'linda-contact-left',
    'name'        => __( 'Contact Page - Left Column', 'linda' ),
    'description' => __( 'This is the area for the left half of the contact page.', 'linda' ),
) );
genesis_register_sidebar( array(
    'id'            => 'linda-contact-right',
    'name'          => __( 'Contact Page - Right Column', 'linda' ),
    'description'   => __( 'This is the area for the right half of the contact page.', 'linda' ),
) );

//* Add Page Widget Area to Content - HTML5 only
add_action( 'genesis_entry_footer', 'custom_instagram_menu_add_page_content' );
function custom_instagram_menu_add_page_content() {
	if ( is_page_template( 'instagram_landing.php' ) ) {
	genesis_widget_area ('instagram-landing-page-widget', array(
        'before' => '<div class="instagram-landing-page-widget"><div class="wrap">',
        'after' => '</div></div>',
	) );
	}
}

//* Register Instagram Landing Page Widget Area
genesis_register_sidebar( array(
	'id'		=> 'instagram-landing-page-widget',
	'name'		=> __( 'Instagram Menu', 'linda' ),
	'description'	=> __( 'This is the widget area for your custom Instagram Menu.', 'linda' ),
) );