<?php
// Start the engine
require_once( get_template_directory() . '/lib/init.php' );

// Child theme (do not remove)
define( 'CHILD_THEME_NAME', 'Runway Theme' );

// Add Viewport meta tag for mobile browsers
add_action( 'genesis_meta', 'sample_viewport_meta_tag' );
function sample_viewport_meta_tag() {
	echo '<meta name="viewport" content="width=device-width, initial-scale=1.0"/>';
}

// Add support for custom background
add_theme_support( 'custom-background' );

// Add support for 3-column footer widgets
add_theme_support( 'genesis-footer-widgets', 3 );

/** Customize the credits */
add_filter( 'genesis_footer_creds_text', 'custom_footer_creds_text' );
function custom_footer_creds_text() {
    echo '<div class="creds"><p>';
    echo 'Copyright &copy; ';
    echo date('Y');
    echo ' Runway Theme by <a href="http://exempel.se"> My OWN Design<a/>';
    echo '</p></div>';
}

// Enqueue sticky menu script
add_action( 'wp_enqueue_scripts', 'custom_enqueue_script' );
function custom_enqueue_script() {
wp_enqueue_script( 'sticky-menu', get_stylesheet_directory_uri() . '/js/sticky-menu.js', array( 'jquery' ), '', true );
}

// Add support for custom header
add_theme_support( 'genesis-custom-header', array(
	'flex-height'	=> true,
	'height'		=> 100,
	'width'			=> 1152
) );

// Reposition the secondary navigation menu
remove_action( 'genesis_after_header', 'genesis_do_subnav' );
add_action( 'genesis_before', 'genesis_do_subnav' );

// Unregister other site layouts
genesis_unregister_layout( 'full-width-content' );
genesis_unregister_layout( 'content-sidebar-sidebar' );
genesis_unregister_layout( 'sidebar-sidebar-content' );
genesis_unregister_layout( 'sidebar-content-sidebar' );

// Customize the post info function
add_filter( 'genesis_post_info', 'post_info_filter' );
function post_info_filter($post_info) {
if ( !is_page() ) {
    $post_info = '[post_date] [post_comments]';
    return $post_info;
}}

// Modify the speak your mind text
add_filter( 'genesis_comment_form_args', 'custom_comment_form_args' );
function custom_comment_form_args($args) {    
$args['title_reply'] = 'Leave a Comment';    
return $args;
}

// Create color style options
add_theme_support( 'genesis-style-selector', array(
'runway-cobalt' => __( 'Cobalt', 'runway' ),
'runway-plum' => __( 'Plum', 'runway' ),
'runway-emerald' => __( 'Emerald', 'runway' ),
'runway-pink' => __( 'Pink', 'runway' ),
'runway-crimson' => __( 'Crimson', 'runway' ),
'runway-aqua' => __( 'Aqua', 'runway' ),
'runway-gold' => __( 'Gold', 'runway' ),
) );

// Add Slider Widget Area
genesis_register_sidebar( array(
    'id' => 'home-featured',
    'name' => __( 'Home Featured', 'runway' ),
    'description' => __( 'This is the widget area for the Genesis Responsive Slider.', 'runway' ),
) );

/** Custom image sizes */
add_image_size( 'Grid', 200, 200, TRUE );
