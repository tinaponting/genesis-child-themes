<?php

/** Add the home featured section */
add_action( 'genesis_before_loop', 'runway_home_featured' );
function runway_home_featured() {

    /** Do nothing on page 2 or greater */
    if ( get_query_var( 'paged' ) >= 2 )
        return;

    genesis_widget_area( 'home-featured', array(
    'before' => '<div class="home-featured widget-area">',
    ) );

}

// Limit Post Title
function titlelimitchar($title){
    if(strlen($title) > 18 && !(is_single()) && !(is_page())){
        $title = substr($title,0,18) . "..";
    }
    return $title;
}
add_filter( 'the_title', 'titlelimitchar' );


genesis();