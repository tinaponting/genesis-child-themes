<?php
/** Start the engine */
require_once( TEMPLATEPATH . '/lib/init.php' );

/** Child theme (do not remove) */
define( 'CHILD_THEME_NAME', 'Blogtastic Theme', 'blogstatic' );

/** Add support for custom background */
add_custom_background();

/** Add support for custom header */
add_theme_support( 'genesis-custom-header', array( 'width' => 1100, 'height' => 120, 'textcolor' => '333333', 'admin_header_callback' => 'georgia_admin_style' ) );


/** Add Viewport meta tag for mobile browsers */
add_action( 'genesis_meta', 'executive_add_viewport_meta_tag' );
function executive_add_viewport_meta_tag() {
    echo '<meta name="viewport" content="width=device-width, initial-scale=1.0"/>';
}

/** Customize the footer */
remove_action( 'genesis_footer', 'genesis_do_footer' );
add_action( 'genesis_footer', 'child_do_footer' );
function child_do_footer() {
    ?>
<p> <a href= "http://exempel.se/"> MY OWN DESIGN </a></p>
    <?php
}

/** Unregister site layouts */
genesis_unregister_layout( 'content-sidebar-sidebar' );
genesis_unregister_layout( 'sidebar-sidebar-content' );
genesis_unregister_layout( 'sidebar-content-sidebar' );

/** Add new image sizes **/
add_image_size('grid-thumbnail', 300, 300, TRUE);
add_image_size( 'post-photo', 660, 250, true );


/** Modify post navigation */
add_action('genesis_before_comments', 'genesis_post_nav');
function genesis_post_nav(){

    echo '<div class="post-nav">';
    echo '<div class="next-post-nav">';
    echo '<span class="next">';
    echo 'Next Post';
    echo '</span>';
    echo next_post_link('%link', '%title');
    echo '</div>';
    echo '<div class="prev-post-nav">';
    echo '<span class="prev">';
    echo 'Previous Post';
    echo '</span>';
    echo previous_post_link('%link', '%title');
    echo '</div>';
    echo '</div>';

}

/** Add support for 3-column footer widgets */
add_theme_support( 'genesis-footer-widgets', 3 );

/** Add inner wrap div to markup */
add_theme_support( 'genesis-structural-wraps', array( 'header', 'nav', 'subnav', 'inner', 'footer-widgets', 'footer' ) );

//* Remove the header right widget area
unregister_sidebar( 'header-right' );

/** Unregister secondary sidebar */unregister_sidebar( 'sidebar-alt' );

/** Move Genesis Comments */
add_action( 'genesis_before_comments' , 'wpb_move_comments' );
function wpb_move_comments ()
{
if ( is_single() && have_comments() )
{
remove_action( 'genesis_comment_form', 'genesis_do_comment_form' );
add_action( 'genesis_comments', 'genesis_do_comment_form', 5 );
}
}

add_action( 'genesis_after_sidebar_widget_area', 'blissful_split_sidebars' );
/**
 * Add split sidebars underneath the primary sidebar
 */
function blissful_split_sidebars() {
	foreach ( array( 'sidebar-split-left', 'sidebar-split-right', 'sidebar-split-bottom' ) as $area ) {
		echo '<div class="' . $area . '">';
		dynamic_sidebar( $area );
		echo '</div><!-- end #' . $area . '-->';
	}
}

genesis_register_sidebar( array(
	'id'			=> 'sidebar-split-left',
	'name'			=> __( 'Sidebar Split Left', 'blissful' ),
	'description'	=> __( 'This is the left side of the split sidebar', 'blissful' ),
) );
genesis_register_sidebar( array(
	'id'			=> 'sidebar-split-right',
	'name'			=> __( 'Sidebar Split Right', 'blissful' ),) );


add_theme_support( 'genesis-style-selector', array(
'blogtastic-purple-turquoise' => __( 'Purple-Turquoise', 'blogtastic' ),
'blogtastic-blue-pink' => __( 'Blue-Pink', 'blogtastic' )
) );


