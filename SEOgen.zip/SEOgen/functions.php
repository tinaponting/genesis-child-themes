<?php
require_once(TEMPLATEPATH.'/lib/init.php'); // Start Genesis Engine
require_once(STYLESHEETPATH.'/lib/init.php'); // Start blog Options
require_once(STYLESHEETPATH.'/lib/updates.php'); // updates
include_once( 'lib/customizer.php' );

//* Add HTML5 markup structure
add_theme_support( 'html5' );


/** Support for various Image sizes */
add_theme_support('post-thumbnails');
//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Add support for custom background
add_theme_support( 'custom-background' );
//* Remove for custom background
 remove_custom_background();

// Add widgeted footer section
add_action('genesis_before_footer', 'footer_bottom_widgets'); 
function footer_bottom_widgets() {
    require(CHILD_DIR.'/footer-widgeted.php');
}

 //* Display author box on archive pages
add_filter( 'get_the_author_genesis_author_box_archive', '__return_true' );

//* Customize the author box title
add_filter( 'genesis_author_box_title', 'custom_author_box_title' );
function custom_author_box_title() {
	return "<h3 itemscope=\"Name\"> " . get_the_author() . "</h3>";
}

/** Register widget areas */
genesis_register_sidebar( array(
	'id'			=> 'front_page_top_widget',
	'name'			=> __( 'Front Page Top Widget', 'SEOGEN Genesis Theme' ),
	'description'	=> __( 'This is the front page top widget if you are using a two or three column site layout option.', 'SEOGEN Genesis Theme' ),
	
) );

genesis_register_sidebar( array(
	'id'			=> 'front_page_content_widget',
	'name'			=> __( 'Front Page Content Widget', 'SEOGEN Genesis Theme' ),
	'description'	=> __( 'This is the front page Content widget if you are using a two or three column site layout option.', 'SEOGEN Genesis Theme' ),
	
) );

genesis_register_sidebar( array(
	'id'			=> 'single_post_related',
	'name'			=> __( 'Single Page Related Post Widget', 'SEOGEN Genesis Theme' ),
	'description'	=> __( 'This is the Single Page Related Post widget if you are using a two or three column site layout option.', 'SEOGEN Genesis Theme' ),
	
) );

//Remove Post  entry footer  Meta data 
remove_action( 'genesis_entry_footer', 'genesis_post_meta' );
//remove archive description
remove_action( 'genesis_before_content', 'genesis_do_taxonomy_title_description', 15 );

//placeholder for comment box in single page
add_filter('comment_form_default_fields','comment_form_placeholder');
function comment_form_placeholder($fields){ 
	$fields['author'] = '<p class="comment-form-author">' . '<label for="author">' . __( '', 'genesis' ) . '</label> ' . 	
	( $req ? '<span class="required">*</span>' : '' ) .                   
	'<input id="author" name="author" type="text" placeholder="Name *" value="' . 				
	esc_attr( $commenter['comment_author'] ) . '" size="30"' . $aria_req . ' /></p>';				
    $fields['email'] = '<p class="comment-form-email"><label for="email">' . __( '', 'genesis' ) . '</label> ' .
	( $req ? '<span class="required">*</span>' : '' ) .
	'<input id="email" name="email" type="text" placeholder="Email *" value="' . 	
	esc_attr(  $commenter['comment_author_email'] ) . '" size="30"' . $aria_req . ' /></p>';	
	$fields['url'] = '<p class="comment-form-url"><label for="url">' . __( '', 'genesis' ) . '</label>' .    
	'<input id="url" name="url" type="text" placeholder="URL *" value="' . 	
	esc_attr( $commenter['comment_author_url'] ) . '" size="30" /></p>';	
    return $fields;
}

function string_limit_words($string, $word_limit)
{
  $words = explode(' ', $string, ($word_limit + 1));
  if(count($words) > $word_limit)
  array_pop($words);
  return implode(' ', $words);
}
 
// Customizes Footer Text (set in options) 
if (genesism_get_option('footer1')) { 
	add_filter('genesis_footer_creds_text', 'custom_footer_creds_text');
	function custom_footer_creds_text($creds) {
    	$creds = genesism_get_option('footer_text');
    return $creds;
	}
}

/* Archive Title */
add_filter( 'genesis_term_meta_headline', 'be_default_category_title', 10, 2 );
function be_default_category_title( $headline, $term ) {
	if( ( is_category() || is_tag() || is_tax() ) && empty( $headline ) )$headline = $term->name;	return $headline;
}
add_filter( 'genesis_before_header', 'search_box',2 );
function search_box( $text ) {
	return esc_attr( 'Go' );
}

/* Basically Removing the Title and Description Option */
remove_action( 'genesis_site_title', 'genesis_seo_site_title' );
remove_action( 'genesis_site_description', 'genesis_seo_site_description' );

/* BEGIN Custom User Contact Info */
function extra_contact_info($contactmethods) {
$contactmethods['facebook'] = 'Facebook';
$contactmethods['twitter'] = 'Twitter';
return $contactmethods;
}
add_filter('user_contactmethods', 'extra_contact_info');
/* END Custom User Contact Info */

add_action( 'genesis_before_comments', 'themeprefix_alt_author_box',2 );
function themeprefix_alt_author_box() {
if( is_single() ) {
 
echo "<div class=\"about-author\"><div class=\"author-info\" itemscope=\"itemscope\" itemtype=\"http://schema.org/person\">" . get_avatar( get_the_author_meta( 'ID' ), '100' ) . "</div>
  <div class='author_right_cnt'>";?>
  <h3 class="author_name"><?php the_author_posts_link(); ?></h3> 
  <?php echo "<p itemprop=\"description\">" . get_the_author_meta( 'description' ) . 
 "</p>
 <div class=\"author_social\">"; 

 if ( get_the_author_meta( 'facebook' ) != '' ) {
 echo "<a title='Facebook' class=\"afb fa\" href=\"https://www.facebook.com/". get_the_author_meta( 'facebook' ) . "\"><i class='fa icon-facebook'></i></a>";
 }
 if ( get_the_author_meta( 'twitter' ) != '' ) {
 echo "<a title='Twitter' class=\"atw fa\" href=\"https://twitter.com/". get_the_author_meta( 'twitter' ) . "\"><i class='fa icon-twitter'></i></a>";
 }

echo "</div></div></div>";
 }
}
// Register Genesis Menus
function register_additional_menu() { 
register_nav_menu( 'First-menu' ,__( 'Top Menu' ));
register_nav_menu( 'Second-menu' ,__( 'Bottom Menu' ));
     
} 
add_action( 'init', 'register_additional_menu' );
 
/** Remove Header */
remove_action( 'genesis_header', 'genesis_header_markup_open', 5 );
remove_action( 'genesis_header', 'genesis_do_header' );
remove_action( 'genesis_header', 'genesis_header_markup_close', 15 );

/** Add custom header support */		  
add_action('genesis_header','injectHeader');
function injectHeader(){ 
?>
<div class="top_header">
	<div class="top_inner_header wrap">
		<div class="top_header_wrap">
			<div class="top_left_header">
				<?php 
					if (genesism_get_option('breaking_news')){
				?>
					<div class="news-ticker">
						<div class="news-ticker_title">
							<h3><?php echo genesism_option('breaking_news_text'); ?></h3>
						</div>
						<div class="news-ticker_content">
							<div class="newsticker">
								<ul class="newsticker-list">
									<?php
									$month = date('m');
									query_posts('post_type=post&posts_per_page=10&orderby=comment_count&order=DESC&monthnum=' . $month);
									while (have_posts()): the_post(); ?>
									<li class="newsticker-item">
									<?php 
										echo "<a href='". get_permalink() ."'>".
										get_the_title() ."".
										"</a>";
										?>
									</li>
									<?php endwhile;
									wp_reset_query(); ?>
								</ul>		
							</div>
							<!--<div id="nt-title-container">
								<ul class="slide" id="nt-title">
									<?php
									$month = date('m');
									query_posts('post_type=post&posts_per_page=10&orderby=comment_count&order=DESC&monthnum=' . $month);
									while (have_posts()): the_post(); ?>
										<li>
										<?php 
										echo "<h4><a href='". get_permalink() ."'>".
										get_the_title() ."".
										"</a></h4>";
										?>
										</li>
									<?php endwhile;
									wp_reset_query(); ?>
								</ul>
							</div>-->			
						</div>
					</div>
				<?php 
				}
				?>
			</div>
			<div class="top_right_header">
				<?php 
					if (genesism_get_option('top_menu')){
				?>
					<div class='top_menu'>
					<span class="menu_control">≡ Menu</span>
					<?php wp_nav_menu( array( 'theme_location' => 'First-menu','container' => false,'menu_id' => 'menu-nav-menu' ) );?>
					</div>
				<?php 
				}
				?>
			</div>
		</div>
	</div>
</div>
<div class="center_header">
	<div class="center_inner_header wrap">
		<div class="center_left_header">
			<?php 
				if (genesism_get_option('header')){
			?>
			<div class="header_left" itemprop="headline">
			<?php
			if (genesism_get_option('header')){?>
				<a itemprop="url" title="<?php bloginfo('name'); ?>" href="<?php bloginfo('wpurl'); ?>"><img src="<?php echo genesism_option('header_text'); ?>" alt="<?php bloginfo('name'); ?>"/></a>
			<?php
			}
			else { ?>
				<h1 itemprop="headline"><a title="<?php bloginfo('name'); ?>" href="<?php bloginfo('wpurl'); ?>"><?php bloginfo('name');?> </a></h1>
				<p><?php bloginfo('description'); ?></p>
			<?php } ?>
			</div>
			<?php 
			}
			?>
		</div>
		<div class="center_right_header">
			<?php 
				if (genesism_get_option('top_ad')){
			?>
				<div class="top_ad">
					<?php echo genesism_option('top_ad_img'); ?>
				</div>	
			<?php 
			}
			?>
		</div>
	</div>
</div>
<div class="bottom_header_menu">
	<div class="bottom_inner_header_menu wrap">
		<?php 
			if (genesism_get_option('bottom_menu')){
		?>
			<div class="bottom_menu_section">
				<span class="menu_control">≡ Menu</span>
				<?php wp_nav_menu( array( 'theme_location' => 'Second-menu','container' => false,'menu_class' =>'menu2', 'menu_id' => 'bottom_menu' ) );?>	
			</div>
		<?php 
			}
		?>		
	</div>
</div>
<div class="bottom_header">
	<div class="bottom_inner_heder wrap">
		<div class="bottom_left_header">
			<?php
			if(genesism_get_option('search_box')){
			?>
				<div class='widget_search_box widget'>
					<div class='widget_search'>
						<div class='search-btn'>
						<button type='submit' class='btn btn-success'>
						<i class='fa icon-search'></i>
						</button>
						</div>
						<div class='search_cont'>
						<form method='get' action='<?php echo get_bloginfo('home'); ?>'>
						<input type='text' placeholder='<?php echo genesism_option('search_text'); ?>' name='s' id='s' />			
						</form>
						</div>
					</div>
				</div>
			<?php 
			}
			?>
		</div>
		<div class="bottom_right_header">
			<?php
			if(!genesism_get_option('header_social')){
			?>
				<div class="header_social">
					<?php
					if(!genesism_get_option('fb_check')){
					?>
					<div class="social_icons">
					<a class="facebook" title="Facebook" href="<?php echo genesism_option('facebook_text2'); ?>" target="_blank">
					<i class="fa icon-facebook"></i>
					</a>
					</div>
					<?php
					}
					if(!genesism_get_option('tw_check')){
					?>
					<div class="social_icons">
					<a class="twitter" title="Twitter" href="<?php echo genesism_option('twitter_text2'); ?>" target="_blank">
					<i class="fa icon-twitter"></i>
					</a>
					</div>
					<?php
					}
					if(!genesism_get_option('gp_check')){
					?>
					<div class="social_icons">
					<a class="googleplus" title="google plus" href="<?php echo genesism_option('googleplus_text2'); ?>" target="_blank">
					<i class="fa icon-google-plus"></i>
					</a>
					</div>
					<?php
					}
					if(!genesism_get_option('pin_check')){
					?>
					<div class="social_icons">
					<a class="pinterest" title="pinterest" href="<?php echo genesism_option('pinterest_text2'); ?>" target="_blank">
					<i class="fa icon-pinterest"></i>
					</a>
					</div>
					<?php
					}
					if(!genesism_get_option('lin_check')){
					?>
						<div class="social_icons">
					<a class="linkedin" title="linkedin" href="<?php echo genesism_option('linkedin_text2'); ?>" target="_blank">
					<i class="fa icon-linkedin2"></i>
					</a>
					</div>
					<?php
					}
					if(!genesism_get_option('yt_check')){
					?>
					<div class="social_icons">
					<a class="youtube" title="youtube" href="<?php echo genesism_option('youtube_text2'); ?>" target="_blank">
					<i class="fa icon-youtube3"></i>
					</a>
					</div>
					<?php
					}
					if(!genesism_get_option('dri_check')){
					?>
					<div class="social_icons">
					<a class="dribbble" title="dribbble" href="<?php echo genesism_option('dribbble_text2'); ?>" target="_blank">
					<i class="fa icon-dribbble"></i>
					</a>
					</div>
					<?php
					}
					if(!genesism_get_option('flkr_check')){
					?>
					<div class="social_icons">
					<a class="flickr" title="flickr" href="<?php echo genesism_option('flickr_text2'); ?>" target="_blank">
					<i class="fa icon-flickr3"></i>
					</a>
					</div>
					<?php
					}
					if(!genesism_get_option('vim_check')){
					?>
					<div class="social_icons">
					<a class="vimeo-square" title="Vimeo Square" href="<?php echo genesism_option('vimeo_text2'); ?>" target="_blank">
					<i class="fa icon-vimeo"></i>
					</a>
					</div>
					<?php
					}
					if(!genesism_get_option('rss_check')){
					?>
					<div class="social_icons">
					<a class="rss" title="Rss Feed" href="<?php echo genesism_option('rssfeed_text2'); ?>" target="_blank">
					<i class="fa icon-feed2"></i>
					</a>
					</div>
					<?php
					}
					?>
				</div>
			<?php 
			}
			?>	
		</div>
	</div>
</div>
<?php
}
add_action('genesis_before_content_sidebar_wrap','before_content_sidebar_wrap');
function before_content_sidebar_wrap(){
?>
<div class="main_container">
<?php 
}
add_action ('genesis_before_sidebar_widget_area','before_sidebar_widget_area');
function before_sidebar_widget_area(){
?>
<div class="sidebar_section">
<?php 
}
add_action ('genesis_before_sidebar_widget_area','sidebar_social_follow',1);
function sidebar_social_follow(){
if(!genesism_get_option('sidebar_social')){
?>
<div class="sidebar_social_follow sidebar_widget">
	<div class="sidebar_heading">
		<h3><span class="sidebar_title"></span>Social Follow</h3>
	</div>
	<div class="sideber_social_follow_cnt sidebar_content">
		<?php
		if(!genesism_get_option('fb_check1')){
		?>
		<div class="sidebar_social_icons">
		<a class="facebook" title="Facebook" href="<?php echo genesism_option('facebook_text'); ?>" target="_blank">
		<i class="fa icon-facebook"></i>
		</a>
		</div>
		<?php
		}
		if(!genesism_get_option('tw_check1')){
		?>
		<div class="sidebar_social_icons">
		<a class="twitter" title="Twitter" href="<?php echo genesism_option('twitter_text'); ?>" target="_blank">
		<i class="fa icon-twitter"></i>
		</a>
		</div>
		<?php
		}
		if(!genesism_get_option('gp_check1')){
		?>
		<div class="sidebar_social_icons">
		<a class="googleplus" title="google plus" href="<?php echo genesism_option('googleplus_text'); ?>" target="_blank">
		<i class="fa icon-google-plus"></i>
		</a>
		</div>
		<?php
		}
		if(!genesism_get_option('rss_check1')){
		?>
		<div class="sidebar_social_icons">
		<a class="rss" title="Rss Feed" href="<?php echo genesism_option('rssfeed_text'); ?>" target="_blank">
		<i class="fa icon-feed2"></i>
		</a>
		</div>
		<?php
		}
		if(!genesism_get_option('pin_check1')){
		?>
		<div class="sidebar_social_icons">
		<a class="pinterest" title="pinterest" href="<?php echo genesism_option('pinterest_text'); ?>" target="_blank">
		<i class="fa icon-pinterest"></i>
		</a>
		</div>
		<?php
		}
		if(!genesism_get_option('lin_check1')){
		?>
		<div class="sidebar_social_icons">
		<a class="linkedin" title="linkedin" href="<?php echo genesism_option('linkedin_text'); ?>" target="_blank">
		<i class="fa icon-linkedin2"></i>
		</a>
		</div>
		<?php
		}
		if(!genesism_get_option('dri_check1')){
		?>
		<div class="sidebar_social_icons">
		<a class="dribbble" title="Dribbble" href="<?php echo genesism_option('dribbble_text'); ?>" target="_blank">
		<i class="fa icon-dribbble"></i>
		</a>
		</div>
		<?php
		}
		if(!genesism_get_option('yt_check1')){
		?>
		<div class="sidebar_social_icons">
		<a class="youtube" title="youtube" href="<?php echo genesism_option('youtube_text'); ?>" target="_blank">
		<i class="fa icon-youtube3"></i>
		</a>
		</div>
		<?php
		}
		if(!genesism_get_option('vim_check1')){
		?>
		<div class="sidebar_social_icons">
		<a class="vimeo-square" title="Vimeo Square" href="<?php echo genesism_option('vimeo_text'); ?>" target="_blank">
		<i class="fa icon-vimeo"></i>
		</a>
		</div>
		<?php
		}
		if(!genesism_get_option('tum_check1')){
		?>
		<div class="sidebar_social_icons">
		<a class="tumblr" title="Tumblr" href="<?php echo genesism_option('tumblr_text'); ?>" target="_blank">
		<i class="fa icon-tumblr"></i>
		</a>
		</div>
		<?php
		}
		if(!genesism_get_option('fli_check1')){
		?>
		<div class="sidebar_social_icons">
		<a class="flickr" title="Flickr" href="<?php echo genesism_option('flickr_text'); ?>" target="_blank">
		<i class="fa icon-flickr3"></i>
		</a>
		</div>
		<?php
		}
		if(!genesism_get_option('ins_check1')){
		?>
		<div class="sidebar_social_icons">
		<a class="instagram" title="Instagram" href="<?php echo genesism_option('instagram_text'); ?>" target="_blank">
		<i class="fa icon-instagram"></i>
		</a>
		</div>
		<?php
		}
		?>
	</div>
</div>
<?php 
}
}
add_action ('genesis_before_sidebar_widget_area','sidebar_optin',4);
function sidebar_optin(){
if(genesism_get_option('sidebar_optin')){	
?>
<div class="sidebar_optin sidebar_widget">
	<div class="sidebar_heading">
		<h3><span class="sidebar_title"></span><?php echo genesism_option('optin_header'); ?></h3>
	</div>
	<div class="sidebar_optin_cnt sidebar_content">
		<form method="post" class="form" action="<?php echo stripslashes(genesism_option('optin_url')); ?>" target="_blank">
			<div class="names"><input class="name" type="text" name="<?php echo stripslashes(genesism_option('optin_name')); ?>" placeholder="<?php echo stripslashes(genesism_option('name_text')); ?>"><div class='admins'></div></div>
			<div class="names"><input class="email" type="text" name="<?php echo stripslashes(genesism_option('optin_email')); ?>" placeholder="<?php echo stripslashes(genesism_option('email_text')); ?>"><div class='mails'></div></div>
			<?php echo stripslashes(genesism_option('optin_hidden')); ?>
			<input name="submit" class="submit" type="submit" value="<?php echo stripslashes(genesism_option('submit_text')); ?>"/>
		</form>
	</div>
</div>
<?php 
}
}
add_action ('genesis_after_sidebar_widget_area','after_sidebar_widget_area');
function after_sidebar_widget_area(){
?>
</div>
<?php 
}
add_action('genesis_after_content_sidebar_wrap','after_content_sidebar_wrap');
function after_content_sidebar_wrap(){
?>
</div>
<?php 
}
add_action('genesis_before_footer','before_footer');
function before_footer(){
?>
<div class="footer_section">
<?php
}
add_action('genesis_after_footer','after_footer');
function after_footer(){
?>
</div>
<?php
}

// Add Post Feature image
add_action( 'genesis_entry_header', 'custom_post_featureimage', 1 );
function custom_post_featureimage() {
if(!is_page()&&!is_single()){  
?>
<div class="post_featured_img" itemprop="image">
<?php
 // Defaults
         $f_img_width = genesism_get_option('f_img_width');
        $f_img_height = genesism_get_option('f_img_height');
        $default_img =  'Feature_image'; 

		// Auto feature image defaults
		$thumb = get_post_thumbnail_id(); 
		$img_url = wp_get_attachment_url( $thumb,'full' ); 
		$image = aq_resize( $img_url,$f_img_width,$f_img_height, true );
		// Catch the Image defaults
        $catch_img_url = catch_that_image( $thumb,'full' );
        $catch_image = aq_resize( $catch_img_url, $f_img_width, $f_img_height, true );
        // Default Image
        $default_image = aq_resize( $default_img, $f_img_width, $f_img_height, true );
		if(has_post_thumbnail())
		echo
		"<div class=\"featured_image\">\n".
		"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width . "\" height=\"" . $f_img_height . "\" alt=\"" . get_the_title() . "\"></a>\n".
		"</div>\n";
		elseif (catch_that_image()){ 
		echo
		"<div class=\"featured_image\">\n".
		"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width . "\" height=\"" . $f_img_height . "\" alt=\"" . get_the_title() . "\"></a>\n".
		"</div>\n"; 
		} 
		/*featured image ends here*/
?>
</div>
<?php	
}      
}

add_action( 'genesis_post_info', 'post_info_filter' );
function post_info_filter() {	
if(!is_page()){ 
?>
<div class="byline">
	<?php
		$category = get_the_category(); 
	?>
	<span class='author' itemprop="author"><?php the_author() ?></span>
	<span class="cat" itemprop="keywords"><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></span>
	<time class='date' datetime='<?php the_time('c'); ?>' itemprop="datePublished"><?php the_time('M jS, Y') ?></time>
	<span class='info_comments'><a  href="<?php the_permalink(); ?>#comments" title="<?php comments_number(__('0 Comment','fb'),__('1 Comment','periodic'),__('% Comments','fb')); ?>"><?php comments_number(__('0 Comment','periodic'),__('1 Comment','periodic'),__('% Comments','fb')); ?> </a></span>						
	<span class="edit_link"><?php edit_post_link(); ?></span>
</div>								
<?php
}
}
add_action('genesis_entry_content','post_ad',2);
function post_ad(){
if(genesism_get_option('postadcheck')){
if ( is_single() ) {?>
		<div class="post-ad" style="float:<?php echo genesism_option('float');?>; padding-right:0px; padding-left:21px; padding-top: 11px;">
		<?php  echo stripslashes((genesism_get_option('postad')));?>
		</div>
        <?php
}
}
}
add_action ('genesis_entry_content','post_read_more');
function post_read_more(){
if(genesism_get_option('read_more')){
if(!is_page()&&!is_single()){
?>
<div class="read_more">
	<a class="read_more_btn" href="<?php echo the_permalink(); ?>"><?php  echo (genesism_get_option('read_text'));?></a>
</div>
<?php 
}
}
}
add_action( 'genesis_before_comments', 'social_post',1);
function social_post(){
if(genesism_get_option('social_post_button')){
if ( is_single() ) {?>
<div class="sharing group sharing_social_count single_page_cnt">
<div class="block_title">
	<h3><?php  echo (genesism_get_option('sharehead'));?></h3>
	<span class="sep"></span>
</div>
<ul class="social_share_count">
		<li class="share_tweet">
		<a href="http://twitter.com/share?text=<?php echo htmlspecialchars(urlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8')), ENT_COMPAT, 'UTF-8'); ?>&amp;url=<?php the_permalink(); ?>" target="_blank">
		<i class="icon-twitter icon"></i>
		<span>
		 Twitter
		</span>
		</a>
		</li>
		<li class="share_fb">
		<a href="http://www.facebook.com/sharer.php?u=<?php the_permalink(); ?>&amp;t=<?php echo htmlspecialchars(urlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8')), ENT_COMPAT, 'UTF-8'); ?>" target="_blank">
		<i class="icon-facebook icon"></i>
		<span>
		 Facebook
		</span>
		</a>
		</li>
		<li class="share_plus">
		<a href="https://plus.google.com/share?url=<?php the_permalink(); ?>" target="_blank" title="Click to share">
		<i class="icon-google-plus icon"></i>
		<span>
		 Linkedin
		</span>
		</a> 
		</li>
		<li class="share_reddit">
		<a target="_blank" href="http://www.reddit.com/submit?url=<?php the_permalink(); ?>&amp;title=<?php echo htmlspecialchars(urlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8')), ENT_COMPAT, 'UTF-8'); ?>">
		<i class="icon-reddit icon"></i>
		<span>
		 Reddit
		</span>
		</a>
		</li>
		<li class="share_pintrest">
		<a target="_blank" href="http://pinterest.com/pinthis?url=<?php the_permalink(); ?>&amp;title=<?php echo htmlspecialchars(urlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8')), ENT_COMPAT, 'UTF-8'); ?>">
		<i class="icon-pinterest icon"></i>
		<span>
		 Pintrest
		</span>
		</a>
		</li>		
	</ul>
</div>
<?php
}
}
}
//Related Post Box
add_action( 'genesis_before_comments', 'related_posts',2);
function related_posts(){
?>
<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Single Page Related Post Widget') ) : ?>
<div class="widget">
<h4 itemprop="headline"><?php _e("Single Page Related Post #Widget", 'genesis'); ?></h4>
<p><?php _e("Displays Single Page Realated Post with thumbnails.", 'genesis'); ?></p>
</div><!-- end .widget -->
<?php endif; ?> 
<?php 
}
add_action('wp_head','color_box');
function color_box(){
$body_bg_color = get_option('body_bg_color');
$body_txt_color = get_option('body_txt_color');
$top_header_bg_color = get_option('top_header_bg_color');
$btm_menu_bg_color =get_option('btm_menu_bg_color');
$btm_bg_color =get_option('btm_bg_color');
$title_color =get_option('title_color');
$title_hover_color = get_option('title_hover_color');
$byline_color = get_option('byline_color');
$border_color = get_option('border_color');
$read_bg =get_option('read_bg');
$sidebar_bg =get_option('sidebar_bg');
$footer_bg =get_option('footer_bg');
$footer_bg2 = get_option('footer_bg2');
$footer_color = get_option('footer_color');
$footer_head = get_option('footer_head');
?>
<style type="text/css">
a{
	color:<?php echo $title_hover_color; ?> ;
}
a:hover {
	color:<?php echo $body_txt_color; ?> ;
}
body {
	background-color: <?php echo $body_bg_color; ?>;
}
body,.menu a {
	color:<?php echo $body_txt_color; ?> ;
}
.menu2 li{
	border-color:<?php echo $body_txt_color; ?> ;
}
.top_header{
    background-color: <?php echo $top_header_bg_color; ?> ;
}
.bottom_header_menu{
    background-color: <?php echo $btm_menu_bg_color; ?> ;
}
.bottom_header,.search_cont input[type="text"]{
    background-color:<?php echo $btm_bg_color; ?>;
}
.site-header,.sidebar .widget-title:before,.latest_news_btm_section h6 a,
.line_title .sep, .footer_optin_cnt input[type="submit"],.block_title .sep,
.read_more_btn:before,.editor_picks_title,.thumb .entry-cat ,.sidebar_title,
.sidebar_optin_cnt  input[type="submit"],.author_social a,.comment-form .form-submit input[type="submit"],
.landing_optin_cnt input[type="submit"],.comment-reply a:hover,.menu2 li a:hover,
.menu2 .current-menu-item > a,.menu2 .sub-menu,
.archive-pagination li a:hover, .archive-pagination .active a{
	background:<?php echo $title_hover_color; ?> ;
}
.entry_title h3 a,.entry_excerpt p,.sidebar_heading h3,.sidebar_heading h3 a,
.sidebar li a,.entry-header .entry-title a,.comment-reply-title, .entry-comments h3,
.sidebar .widget-title,.block_title h3,.author_social a:hover,.footer_optin_cnt input[type="submit"]:hover,
.sidebar .tagcloud a,.entry-title a,.author_right_cnt h3 a{
	color:<?php echo $title_color; ?> ;
}
.entry_title h3 a:hover,.comment-reply a:hover,.sidebar .widget_categories ul li a:before,
.latest_news_btm_section  h5 a:hover,.info_comments a:before,.home_byline a:hover,
.top_right_fifth_cat_content span a:hover,.last_updated  li a:before,.sidebar li a:hover,
.trend_title a:before,.entry-header .entry-title a:hover,.byline span:before,.byline span a:hover,
.cat a:before,.author_right_cnt h3 a:hover,.landing_page_feature_section .column1 h3 a:hover,
.menu .current-menu-item > a,.menu a:hover,.site-footer a:hover,
.newsticker-item a,.entry-title a:hover{
	color:<?php echo $title_hover_color; ?>;
}
.comment-reply-title:after, .entry-comments h3:after{
	border-bottom-color:<?php echo $title_hover_color; ?>;
}
.sidebar .widget-title:after,.sidebar_heading h3:after{
	border-top-color:<?php echo $title_hover_color; ?> ;
}
.archive-title{
	border-bottom-color:<?php echo $title_hover_color; ?> ;
}
.sidebar .tagcloud a:hover{
	border-color:<?php echo $title_hover_color; ?> ;
}
.sidebar .tagcloud a:hover{
	background-color:<?php echo $title_hover_color; ?>;
}
.top_left_byline,.read_more_btn,.top_left_fifth_cat_content {
	border-right-color:<?php echo $title_hover_color; ?> ;
}
.home_byline span,.home_byline span a,.top_right_fifth_cat_content span a,.last_updated  li ,
.byline span, .byline span a,.recent_cnt span ,.top_right_byline h5,.top_right_byline span a,
.top_right_byline span,.second_cat__byline span,.second_cat__byline span a,.byline time{
	color:<?php echo $byline_color; ?>;
}
.byline,.second_cat__byline{
	border-bottom-color:<?php echo $border_color; ?> ;
	border-top-color:<?php echo $border_color; ?> ;
}
.block_title,.second_cat_right_section,.third_cat_content,.fifth_cat_content,
.blog .entry,.archive .entry,.comment-reply-title, .entry-comments h3,
.archive-description,.menu .sub-menu li {
	border-bottom-color:<?php echo $border_color; ?>;
}
.comment-respond input[type="email"], .comment-respond input[type="text"], .comment-respond input[type="url"],
.landing_optin_cnt input[type="text"],li.comment,.sidebar .widget,.sidebar_widget,.about-author{
	border-color:<?php echo $border_color; ?> ;
}
.author_section .avatar,.editor_picks_section,.sidebar_heading h3,
.sidebar_optin_cnt  input[type="text"],.author-info img,.author_social a:hover,
.comment .avatar ,.sidebar .widget-title,.top_cnt_section,.comment-reply a{
	background:<?php echo $border_color; ?>;
}
.read_more_btn,.search-btn button{
	background:<?php echo $read_bg; ?> ;
}
.sidebar .tagcloud a{
	border-color:<?php echo $read_bg; ?>;
}
.sidebar .widget,.sidebar_widget,.about-author,.menu .sub-menu li a:hover{
	background:<?php echo $sidebar_bg; ?>;
}
.footer-widgets{
	background:<?php echo $footer_bg; ?> ;
}
.site-footer{
	background:<?php echo $footer_bg2; ?> ;
} 
.footer-widgets a, .footer-widgets p,.site-footer p,.site-footer a{
	color:<?php echo $footer_color; ?> ;
}  
.footer-widgets .line_title h3{
	color:<?php echo $footer_head; ?> ;
}
<?php  echo (genesism_get_option('custom_css'));?>
</style>
<?php
}
add_action( 'wp_enqueue_scripts', 'enqueue_script' );
function enqueue_script() {	
	wp_enqueue_script( 'jquery.newsticker', get_stylesheet_directory_uri() . '/scripts/jquery.newsticker.js', array( 'jquery' ), '', true );		
	wp_enqueue_script( 'jquery.flexslider-min', get_stylesheet_directory_uri() . '/scripts/jquery.flexslider-min.js', array( 'jquery' ), '', true );	
	wp_enqueue_script( 'newssticker', get_stylesheet_directory_uri() . '/scripts/newssticker.js', array( 'jquery' ), '', true );	
	wp_enqueue_script( 'flexslider', get_stylesheet_directory_uri() . '/scripts/flexslider.js', array( 'jquery' ), '', true );
	wp_enqueue_script( 'menu', get_stylesheet_directory_uri() . '/scripts/menu.js', array( 'jquery' ), '', true );	
}
add_action('wp_footer','script_box');
function script_box(){?>
<script type="text/javascript">
function loadScript(src) {
     var element = document.createElement("script");
     element.src = src;
     document.body.appendChild(element);
}
// Add a script element as a child of the body
function downloadJSAtOnload() {
}
 // Check for browser support of event handling capability
 if (window.addEventListener)
     window.addEventListener("load", downloadJSAtOnload, false);
	 else if (window.attachEvent)
     window.attachEvent("onload", downloadJSAtOnload);
 else window.onload = downloadJSAtOnload; 
 (function() {
      function getScript(url,success){
        var script=document.createElement('script');
        script.src=url;
        var head=document.getElementsByTagName('head')[0],
            done=false;
        script.onload=script.onreadystatechange = function(){
          if ( !done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete') ) {
            done=true;
            success();
            script.onload = script.onreadystatechange = null;
            head.removeChild(script);
          }
        };
        head.appendChild(script);
      }
        getScript('https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js',function(){
        });
    })();
</script>
<?php
}
// Auto Resize Image
function aq_resize( $url, $width, $height = null, $crop = null, $single = true ) {

//validate inputs
if(!$url OR !$width ) return false;

//define upload path & dir
$upload_info = wp_upload_dir();
$upload_dir = $upload_info['basedir'];
$upload_url = $upload_info['baseurl'];

//check if $img_url is local
if(strpos( $url, $upload_url ) === false) return false;

//define path of image
$rel_path = str_replace( $upload_url, '', $url);
$img_path = $upload_dir . $rel_path;

//check if img path exists, and is an image indeed
if( !file_exists($img_path) OR !getimagesize($img_path) ) return false;

//get image info
$info = pathinfo($img_path);
$ext = $info['extension'];
list($orig_w,$orig_h) = getimagesize($img_path);

//get image size after cropping
$dims = image_resize_dimensions($orig_w, $orig_h, $width, $height, $crop);
$dst_w = $dims[4];
$dst_h = $dims[5];

//use this to check if cropped image already exists, so we can return that instead
$suffix = "{$dst_w}x{$dst_h}";
$dst_rel_path = str_replace( '.'.$ext, '', $rel_path);
$destfilename = "{$upload_dir}{$dst_rel_path}-{$suffix}.{$ext}";

if(!$dst_h) {
//can't resize, so return original url
$img_url = $url;
$dst_w = $orig_w;
$dst_h = $orig_h;
}
//else check if cache exists
elseif(file_exists($destfilename) && getimagesize($destfilename)) {
$img_url = "{$upload_url}{$dst_rel_path}-{$suffix}.{$ext}";
}
//else, we resize the image and return the new resized image url
else {
// Note: This pre-3.5 fallback check will edited out in subsequent version
if(function_exists('wp_get_image_editor')) {
$editor = wp_get_image_editor($img_path);
if ( is_wp_error( $editor ) || is_wp_error( $editor->resize( $width, $height, $crop ) ) )
return false;
$resized_file = $editor->save();
if(!is_wp_error($resized_file)) {
$resized_rel_path = str_replace( $upload_dir, '', $resized_file['path']);
$img_url = $upload_url . $resized_rel_path;
} else {
return false;
}
} else {
$resized_img_path = image_resize( $img_path, $width, $height, $crop ); // Fallback foo
if(!is_wp_error($resized_img_path)) {
$resized_rel_path = str_replace( $upload_dir, '', $resized_img_path);
$img_url = $upload_url . $resized_rel_path;
} else {
return false;
}
}
}
//return the output
if($single) {
//str return
$image = $img_url;
} else {
//array return
$image = array (
0 => $img_url,
1 => $dst_w,
2 => $dst_h
);
}
return $image;
}
function catch_that_image() {
        global $post, $posts;
        $first_img = '';
        ob_start();
        ob_end_clean();
        $output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
        if(count($matches [1]))$first_img = $matches [1] [0];
        return $first_img;
}
//Last Updated Post Widget Starts Here
class gl_last_update_widget extends WP_Widget {
function __construct() {
parent::__construct(
'gl_last_update_widget', 
__('SEOGen - Last Updated Post', 'gl_last_update_widget_domain'), 
array( 'description' => __( 'Displays Last Updated Post', 'gl_last_update_widget_domain' ), ) 
);
}
public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];
?>
<div class="last_updated_pst">	
	<div class="last_updated sidebar_content">
		<?php		
			// Query Arguments
			$lastupdated_args = array(
			'orderby' => 'modified',
			);
			//Loop to display 5 recently updated posts
			$lastupdated_loop = new WP_Query( $lastupdated_args );
			$counter = 1;
			echo '<ul>';
			while( $lastupdated_loop->have_posts() && $counter <= $instance[ 'post_count' ] ) : $lastupdated_loop->the_post();
			echo '<li><a href="' . get_permalink( $lastupdated_loop->post->ID ) . '"> ' .get_the_title( $lastupdated_loop->post->ID ) . '</a> ( '. get_the_modified_date() .') </li>';
			$counter++;
			endwhile; 
			echo '</ul>';
			wp_reset_postdata(); 		
		?>
	</div>
</div>
<?php
echo $args['after_widget'];
}	
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Last Updated Post', 'gl_last_update_widget_domain' );
}
 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '5', 'gl_last_update_widget_domain' );
}
?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>
<?php 
}
public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
return $instance;
}
} 
//Last Updated Post Widget Ends Here
// Trending Post Widget Starts Here
class gl_trending_widget extends WP_Widget {
function __construct() {
parent::__construct(
'gl_trending_widget', 
__('SEOGen - Trending Post', 'gl_trending_widget_domain'), 
array( 'description' => __( 'Displays Trending Post', 'gl_trending_widget_domain' ), ) 
);
}
public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];
?>
<div class="trending_post">	
	<div class="trending_post_section sidebar_content">
		<ul>
			<?php		
				query_posts( array( 'post_type' => 'post', 'posts_per_page' => $instance['post_count'], 'orderby' => 'comment_count','order' => 'desc') );
				if(have_posts()) : 
				while(have_posts()) : the_post();
			?>
				<li class="trend_title"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></li>
			<?php 
				endwhile;
				endif;
				wp_reset_query();
			?>
		</ul>
	</div>
</div>
<?php
echo $args['after_widget'];
}		
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Trending Post', 'gl_trending_widget_domain' );
}
 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '5', 'gl_trending_widget_domain' );
}
?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>
<p>
<?php 
}
public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
return $instance;
}
}
//Trending Post Widget Ends Here
// Sidebar Category Widget Starts Here
class gl_sidbar_catgory_widget extends WP_Widget {
function __construct() {
parent::__construct(
'gl_sidbar_catgory_widget', 
__('SEOGen - Sidebar Category', 'gl_sidbar_catgory_widget_domain'), 
array( 'description' => __( 'Displays Sidebar Category Post', 'gl_sidbar_catgory_widget_domain' ), ) 
);
}
public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );
$fifth_cat_id = apply_filters( 'fifth_cat_id', $instance['fifth_cat_id'] );
echo $args['before_widget'];
if ( ! empty( $title ) )
/*echo $args['before_title'] . $title . $args['after_title'];*/
?>
<div class="fifth_catgory">
	<div class='sidebar_heading'>
			<?php 
			echo "<h3><span class='sidebar_title'></span><a title='";
			$category=get_the_category_by_id($instance['fifth_cat_id']); echo $category;
			echo "'".
			" href='";
			$category_link = get_category_link($instance['fifth_cat_id']);
			echo esc_url( $category_link );
			echo "'".
			">";
			$category=get_the_category_by_id($instance['fifth_cat_id']); echo $category;
			echo "</a></h3>";
			?>
		</div>
	<div class="fifth_catgory_section sidebar_content">
		<?php 
		query_posts( array('posts_per_page'=>$instance['post_count'], cat=>$instance['fifth_cat_id']) );
		while ( have_posts() ) : the_post();
		?>
			<div class="fifth_cat_content">			
				<div class="top_entry_content fifth_category_cnt">
					
					<div class="top_fifth_cat_content">
						<div class="top_left_fifth_cat_content entry_image thumb overlay" itemprop="image">
								<?php
								// Defaults
								$f_img_width9 = $instance['width_size'];
								$f_img_height9 = $instance['height_size'];
								$default_img =  'Feature_image'; 

								// Auto feature image defaults
								$thumb = get_post_thumbnail_id(); 
								$img_url = wp_get_attachment_url( $thumb,'full' ); 
								$image = aq_resize( $img_url,$f_img_width9,$f_img_height9, true );
								// Catch the Image defaults
								$catch_img_url = catch_that_image( $thumb,'full' );
								$catch_image = aq_resize( $catch_img_url, $f_img_width9, $f_img_height9, true );
								// Default Image
								$default_image = aq_resize( $default_img, $f_img_width9, $f_img_height9, true );	
								if(has_post_thumbnail())
								echo
								"<div class=\"featured_image\">\n".
								"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width9 . "\" height=\"" . $f_img_height9 . "\" alt=\"" . get_the_title() . "\"></a>\n".
								"</div>\n";
								elseif (catch_that_image()){ 
								echo
								"<div class=\"featured_image\">\n".
								"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width9 . "\" height=\"" . $f_img_height9 . "\" alt=\"" . get_the_title() . "\"></a>\n".
								"</div>\n"; 
								} 
								/*featured image ends here*/
								?>
								<div class="readmore_section"> 
									<a href="<?php echo the_permalink(); ?>"><i class="fa icon-paper-plane"></i></a>
								</div>
						</div>
						<div class="top_right_fifth_cat_content">
							<span class="post_date">
								<time datetime="<?php the_time('c') ?>" itemprop="datePublished"><strong><?php the_time('d') ?></strong><span><?php the_time('M') ?></span><span><?php the_time('Y') ?></span></time>
							</span>
							<span class='info_comments'><a  href="<?php the_permalink(); ?>#comments" title="<?php comments_number(__('0 Comment','fb'),__('1 Comment','periodic'),__('% Comments','fb')); ?>"><?php comments_number(__('0 Comment','periodic'),__('1 Comment','periodic'),__('% Comments','fb')); ?> </a></span>						
						</div>
					</div>
					<div class="fifth_cat_btm_cnt">
						<div class="entry_title">
							<?php echo "<h3 itemprop='headline'><a href='". get_permalink() ."'>".get_the_title()."";
							echo "</a></h3>";?>
						</div>
						<div class="entry_excerpt" itemprop="text">
							<p>
								<?php
								$excerpt=get_the_excerpt();
								echo string_limit_words($excerpt,12);
								?>
							</p>
						</div>
					</div>
				</div>
			</div>
		<?php
		endwhile;
		wp_reset_query(); 
		?>
	</div>
</div>
<?php
echo $args['after_widget'];
}		
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Sidebar Category Post', 'gl_sidbar_catgory_widget_domain' );
}
 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '2', 'gl_sidbar_catgory_widget_domain' );
}
 if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '173', 'gl_sidbar_catgory_widget_domain' );
}
 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '100', 'gl_sidbar_catgory_widget_domain' );
}
 if ( isset( $instance[ 'fifth_cat_id' ] ) ) {
$fifth_cat_id = $instance[ 'fifth_cat_id' ];
}
else {
$fifth_cat_id = __( '8', 'gl_sidbar_catgory_widget_domain' );
}
?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'fifth_cat_id' ); ?>"><?php _e( 'Sidebar Category ID:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'fifth_cat_id' ); ?>" name="<?php echo $this->get_field_name( 'fifth_cat_id' ); ?>" type="text" value="<?php echo esc_attr( $fifth_cat_id ); ?>" />
</p>
<?php 
}
public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';
$instance['fifth_cat_id'] = ( ! empty( $new_instance['fifth_cat_id'] ) ) ? strip_tags( $new_instance['fifth_cat_id'] ) : '';
return $instance;
}
}
//Sidebar Category Widget Ends Here
// Latest News Widget Starts Here
class gl_latest_news_widget extends WP_Widget {
function __construct() {
parent::__construct(
'gl_latest_news_widget', 
__('SEOGen - Latest News', 'gl_latest_news_widget_domain'), 
array( 'description' => __( 'Displays Latest News Post', 'gl_latest_news_widget_domain' ), ) 
);
}
public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );
$width_size1 = apply_filters( 'width_size1', $instance['width_size1'] );
$height_size1 = apply_filters( 'height_size1', $instance['height_size1'] );
echo $args['before_widget'];
if ( ! empty( $title ) )
/*echo $args['before_title'] . $title . $args['after_title'];*/
?>
<div class='latest_news'>
	<div class="left_latest_news">
		<div class="flexslider carousel">
			<ul class='slides'>
				<li>
					<div class="slider_section">
						<?php 
						$i = 1;
						query_posts( array('posts_per_page'=>5) );
						while ( have_posts() ) : the_post();?>
						<?php
						if(($i == 1)){
						?>
							<div class="left_latest_news_section latest_news_section">
								<div class="latest_news_image" itemprop="image">
								<?php
								// Defaults
								$f_img_width1 = $instance['width_size'];
								$f_img_height1 = $instance['height_size'];
								$default_img =  'Feature_image'; 

								// Auto feature image defaults
								$thumb = get_post_thumbnail_id(); 
								$img_url = wp_get_attachment_url( $thumb,'full' ); 
								$image = aq_resize( $img_url,$f_img_width1,$f_img_height1, true );
								// Catch the Image defaults
								$catch_img_url = catch_that_image( $thumb,'full' );
								$catch_image = aq_resize( $catch_img_url, $f_img_width1, $f_img_height1, true );
								// Default Image
								$default_image = aq_resize( $default_img, $f_img_width1, $f_img_height1, true );
								if(has_post_thumbnail())
								echo
								"<div class=\"featured_image \">\n".
								"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width1 . "\" height=\"" . $f_img_height1 . "\" alt=\"" . get_the_title() . "\"></a>\n".
								"</div>\n";
								elseif (catch_that_image()){ 
								echo
								"<div class=\"featured_image\">\n".
								"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width1 . "\" height=\"" . $f_img_height1 . "\" alt=\"" . get_the_title() . "\"></a>\n".
								"</div>\n"; 
								} 
								?>
								</div>
									<div class='latest_news_btm_section left_btm_sec'>
									<?php
									$category = get_the_category(); 
									?>
									<h6><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></h6>
									<h5 itemprop="headline"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a></h5>
									<span class='date' itemprop="datePublished"><?php the_time('M jS, Y') ?></span>
									</div>
							</div>
							<?php
							}
							else{
							?>
								<div class="right_latest_news latest_news_section">
									<div class="latest_news_image" itemprop="image">
									<?php
									// Defaults
									$f_img_width2 = $instance['width_size1'];
									$f_img_height2 = $instance['height_size1'];
									$default_img =  'Feature_image'; 

									// Auto feature image defaults
									$thumb = get_post_thumbnail_id(); 
									$img_url = wp_get_attachment_url( $thumb,'full' ); 
									$image = aq_resize( $img_url,$f_img_width2,$f_img_height2, true );
									// Catch the Image defaults
									$catch_img_url = catch_that_image( $thumb,'full' );
									$catch_image = aq_resize( $catch_img_url, $f_img_width2, $f_img_height2, true );
									// Default Image
									$default_image = aq_resize( $default_img, $f_img_width2, $f_img_height2, true );	
									if(has_post_thumbnail())
									echo
									"<div class=\"featured_image\">\n".
									"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width2 . "\" height=\"" . $f_img_height2 . "\" alt=\"" . get_the_title() . "\"></a>\n".
									"</div>\n";
									elseif (catch_that_image()){ 
									echo
									"<div class=\"featured_image\">\n".
									"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width2 . "\" height=\"" . $f_img_height2 . "\" alt=\"" . get_the_title() . "\"></a>\n".
									"</div>\n"; 
									} 
									/*featured image ends here*/
									?>
									</div>
										<div class='latest_news_btm_section right_btm_sec'>
										<?php
										$category = get_the_category(); 
										?>
										<h6><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></h6>
										<h5 itemprop="headline"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a></h5>
										<span class='date' itemprop="datePublished"><?php the_time('M jS, Y') ?></span>
										</div>
								</div>
							<?php
							}
							?>
						<?php
						$i++;
						endwhile;
						wp_reset_query(); ?>
					</div>
				</li>
				<li>
					<div class="slider_section">
						<?php 
						$i = 1;
						query_posts( array('posts_per_page'=>10, 'offset'=>5) );
						while ( have_posts() ) : the_post();?>
						<?php
						if(($i == 1)){
						?>
							<div class="left_latest_news_section latest_news_section">
								<div class="latest_news_image" itemprop="image">
								<?php
								// Defaults
								$f_img_width1 = $instance['width_size'];
								$f_img_height1 = $instance['height_size'];
								$default_img =  'Feature_image'; 

								// Auto feature image defaults
								$thumb = get_post_thumbnail_id(); 
								$img_url = wp_get_attachment_url( $thumb,'full' ); 
								$image = aq_resize( $img_url,$f_img_width1,$f_img_height1, true );
								// Catch the Image defaults
								$catch_img_url = catch_that_image( $thumb,'full' );
								$catch_image = aq_resize( $catch_img_url, $f_img_width1, $f_img_height1, true );
								// Default Image
								$default_image = aq_resize( $default_img, $f_img_width1, $f_img_height1, true );
								if(has_post_thumbnail())
								echo
								"<div class=\"featured_image\">\n".
								"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width1 . "\" height=\"" . $f_img_height1 . "\" alt=\"" . get_the_title() . "\"></a>\n".
								"</div>\n";
								elseif (catch_that_image()){ 
								echo
								"<div class=\"featured_image\">\n".
								"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width1 . "\" height=\"" . $f_img_height1 . "\" alt=\"" . get_the_title() . "\"></a>\n".
								"</div>\n"; 
								} 
								?>
								</div>
									<div class='latest_news_btm_section left_btm_sec'>
									<?php
									$category = get_the_category(); 
									?>
									<h6><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></h6>
									<h5 itemprop="headline"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a></h5>
									<span class='date' itemprop="datePublished"><?php the_time('M jS, Y') ?></span>
									</div>
							</div>
							<?php
							}
							elseif(($i == 2) || ($i == 3) || ($i == 4) || ($i == 5)){ 
							?>
								<div class="right_latest_news latest_news_section">
									<div class="latest_news_image" itemprop="image">
									<?php
									// Defaults
									$f_img_width2 = $instance['width_size1'];
									$f_img_height2 = $instance['height_size1'];
									$default_img =  'Feature_image'; 

									// Auto feature image defaults
									$thumb = get_post_thumbnail_id(); 
									$img_url = wp_get_attachment_url( $thumb,'full' ); 
									$image = aq_resize( $img_url,$f_img_width2,$f_img_height2, true );
									// Catch the Image defaults
									$catch_img_url = catch_that_image( $thumb,'full' );
									$catch_image = aq_resize( $catch_img_url, $f_img_width2, $f_img_height2, true );
									// Default Image
									$default_image = aq_resize( $default_img, $f_img_width2, $f_img_height2, true );
									if(has_post_thumbnail())
									echo
									"<div class=\"featured_image\">\n".
									"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width2 . "\" height=\"" . $f_img_height2 . "\" alt=\"" . get_the_title() . "\"></a>\n".
									"</div>\n";
									elseif (catch_that_image()){ 
									echo
									"<div class=\"featured_image\">\n".
									"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width2 . "\" height=\"" . $f_img_height2 . "\" alt=\"" . get_the_title() . "\"></a>\n".
									"</div>\n"; 
									} 
									/*featured image ends here*/
									?>
									</div>
										<div class='latest_news_btm_section right_btm_sec'>
										<?php
										$category = get_the_category(); 
										?>
										<h6><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></h6>
										<h5 itemprop="headline"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a></h5>
										<span class='date' itemprop="datePublished"><?php the_time('M jS, Y') ?></span>
										</div>
								</div>
							<?php
							}
							?>
						<?php
						$i++;
						endwhile;
						wp_reset_query(); ?>
					</div>
				</li>
				<li>
					<div class="slider_section">
					<?php 
						$i = 1;
						query_posts( array('posts_per_page'=>15, 'offset'=>10) );
						while ( have_posts() ) : the_post();?>
						<?php
						if(($i == 1)){
						?>
							<div class="left_latest_news_section latest_news_section">
								<div class="latest_news_image" itemprop="image">
								<?php
								// Defaults
								$f_img_width1 = $instance['width_size'];
								$f_img_height1 = $instance['height_size'];
								$default_img =  'Feature_image'; 

								// Auto feature image defaults
								$thumb = get_post_thumbnail_id(); 
								$img_url = wp_get_attachment_url( $thumb,'full' ); 
								$image = aq_resize( $img_url,$f_img_width1,$f_img_height1, true );
								// Catch the Image defaults
								$catch_img_url = catch_that_image( $thumb,'full' );
								$catch_image = aq_resize( $catch_img_url, $f_img_width1, $f_img_height1, true );
								// Default Image
								$default_image = aq_resize( $default_img, $f_img_width1, $f_img_height1, true );
								if(has_post_thumbnail())
								echo
								"<div class=\"featured_image\">\n".
								"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width1 . "\" height=\"" . $f_img_height1 . "\" alt=\"" . get_the_title() . "\"></a>\n".
								"</div>\n";
								elseif (catch_that_image()){ 
								echo
								"<div class=\"featured_image\">\n".
								"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width1 . "\" height=\"" . $f_img_height1 . "\" alt=\"" . get_the_title() . "\"></a>\n".
								"</div>\n"; 
								} 
								?>
								</div>
									<div class='latest_news_btm_section left_btm_sec'>
									<?php
									$category = get_the_category(); 
									?>
									<h6><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></h6>
									<h5 itemprop="headline"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a></h5>
									<span class='date' itemprop="datePublished"><?php the_time('M jS, Y') ?></span>
									</div>
							</div>
							<?php
							}
							elseif(($i == 2) || ($i == 3) || ($i == 4) || ($i == 5)){ 
							?>
								<div class="right_latest_news latest_news_section">
									<div class="latest_news_image" itemprop="image">
									<?php
									// Defaults
									$f_img_width2 = $instance['width_size1'];
									$f_img_height2 = $instance['height_size1'];
									$default_img =  'Feature_image'; 

									// Auto feature image defaults
									$thumb = get_post_thumbnail_id(); 
									$img_url = wp_get_attachment_url( $thumb,'full' ); 
									$image = aq_resize( $img_url,$f_img_width2,$f_img_height2, true );
									// Catch the Image defaults
									$catch_img_url = catch_that_image( $thumb,'full' );
									$catch_image = aq_resize( $catch_img_url, $f_img_width2, $f_img_height2, true );
									// Default Image
									$default_image = aq_resize( $default_img, $f_img_width2, $f_img_height2, true );									
									if(has_post_thumbnail())
									echo
									"<div class=\"featured_image\">\n".
									"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width2 . "\" height=\"" . $f_img_height2 . "\" alt=\"" . get_the_title() . "\"></a>\n".
									"</div>\n";
									elseif (catch_that_image()){ 
									echo
									"<div class=\"featured_image\">\n".
									"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width2 . "\" height=\"" . $f_img_height2 . "\" alt=\"" . get_the_title() . "\"></a>\n".
									"</div>\n"; 
									} 
									/*featured image ends here*/
									?>
									</div>
										<div class='latest_news_btm_section right_btm_sec'>
										<?php
										$category = get_the_category(); 
										?>
										<h6><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></h6>
										<h5 itemprop="headline"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a></h5>
										<span class='date' itemprop="datePublished"><?php the_time('M jS, Y') ?></span>
										</div>
								</div>
							<?php
							}
							?>
						<?php
						$i++;
						endwhile;
						wp_reset_query(); ?>
					</div>
				</li>
			</ul>
		</div>
	</div>
</div>
<?php
echo $args['after_widget'];
}		
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Latest News Post', 'gl_latest_news_widget_domain' );
}
 if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '598', 'gl_latest_news_widget_domain' );
}
 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '302', 'gl_latest_news_widget_domain' );
}
 if ( isset( $instance[ 'width_size1' ] ) ) {
$width_size1 = $instance[ 'width_size1' ];
}
else {
$width_size1 = __( '298', 'gl_latest_news_widget_domain' );
}
 if ( isset( $instance[ 'height_size1' ] ) ) {
$height_size1 = $instance[ 'height_size1' ];
}
else {
$height_size1 = __( '150', 'gl_latest_news_widget_domain' );
}
?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Left Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Left Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'width_size1' ); ?>"><?php _e( 'Right Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size1' ); ?>" name="<?php echo $this->get_field_name( 'width_size1' ); ?>" type="text" value="<?php echo esc_attr( $width_size1 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size1' ); ?>"><?php _e( 'Right Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size1' ); ?>" name="<?php echo $this->get_field_name( 'height_size1' ); ?>" type="text" value="<?php echo esc_attr( $height_size1 ); ?>" />
</p>
<?php 
}
public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';
$instance['width_size1'] = ( ! empty( $new_instance['width_size1'] ) ) ? strip_tags( $new_instance['width_size1'] ) : '';
$instance['height_size1'] = ( ! empty( $new_instance['height_size1'] ) ) ? strip_tags( $new_instance['height_size1'] ) : '';
return $instance;
}
}
//Latest News Widget Ends Here
// Content First Category Widget Starts Here
class gl_content_first_catgory_widget extends WP_Widget {
function __construct() {
parent::__construct(
'gl_content_first_catgory_widget', 
__('S&G - Content First Category', 'gl_content_first_catgory_widget_domain'), 
array( 'description' => __( 'Displays Content First Category Post', 'gl_content_first_catgory_widget_domain' ), ) 
);
}
public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );
$cat_id = apply_filters( 'cat_id', $instance['cat_id'] );
$read_more = apply_filters( 'read_more', $instance['read_more'] );
echo $args['before_widget'];
if ( ! empty( $title ) )
/*echo $args['before_title'] . $title . $args['after_title'];*/
?>
<div class="top_content_section">
	<div class="top_section">
		<div class='block_title'>
			<?php 
			echo "<a title='";
			$category=get_the_category_by_id( $instance['cat_id'] ); echo $category;
			echo "'".
			" href='";
			$category_link = get_category_link( $instance['cat_id'] );
			echo esc_url( $category_link );
			echo "'".
			"><h3>";
			$category=get_the_category_by_id( $instance['cat_id'] ); echo $category;
			echo "</h3></a>";
			?>
			<span class="sep"></span>
		</div>
		<?php 
		query_posts( array('posts_per_page'=>$instance['post_count'], cat=>$instance['cat_id']) );
		while ( have_posts() ) : the_post();
		$i++;
	$class = ( $i % 2 ) ? 'top_cnt_section' : 'top_cnt_section last'; 
		?>
			<div class="<?php echo $class; ?>">
				<div class="entry_image thumb overlay" itemprop="image">
					<?php
					// Defaults
					$f_img_width5 = $instance['width_size'];
					$f_img_height5 = $instance['height_size'];
					$default_img =  'Feature_image'; 

					// Auto feature image defaults
					$thumb = get_post_thumbnail_id(); 
					$img_url = wp_get_attachment_url( $thumb,'full' ); 
					$image = aq_resize( $img_url,$f_img_width5,$f_img_height5, true );
					// Catch the Image defaults
					$catch_img_url = catch_that_image( $thumb,'full' );
					$catch_image = aq_resize( $catch_img_url, $f_img_width5, $f_img_height5, true );
					// Default Image
					$default_image = aq_resize( $default_img, $f_img_width5, $f_img_height5, true );
					if(has_post_thumbnail())
					echo
					"<div class=\"featured_image\">\n".
					"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width5 . "\" height=\"" . $f_img_height5 . "\" alt=\"" . get_the_title() . "\"></a>\n".
					"</div>\n";
					elseif (catch_that_image()){ 
					echo
					"<div class=\"featured_image\">\n".
					"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width5 . "\" height=\"" . $f_img_height5 . "\" alt=\"" . get_the_title() . "\"></a>\n".
					"</div>\n"; 
					} 
					/*featured image ends here*/
					?>
					<div class="more"> 
					<a href="<?php echo the_permalink(); ?>"><i class="fa icon-paper-plane"></i></a>
					</div>
					<div class="entry-cat category">
					<?php
					$category = get_the_category(); 
					?>
					<h4><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></h4>
					</div>
				</div>
				<div class="top_entry_content">
					<div class="entry_title">
						<?php echo "<h3 itemprop='headline'><a href='". get_permalink() ."'>".get_the_title()."";
						echo "</a></h3>";?>
					</div>
					<div class="top_byline">
						<div class="top_left_byline">			
							<span class="post_date">
								<time datetime="<?php the_time('c') ?>" itemprop="datePublished"><strong><?php the_time('d') ?></strong><span><?php the_time('M') ?></span><span><?php the_time('Y') ?></span></time>
							</span>
						</div>
						<div class="top_right_byline">
							<h5 class='author' itemprop="author"><?php the_author() ?></h5>
							<span class='info_comments'><a  href="<?php the_permalink(); ?>#comments" title="<?php comments_number(__('0','fb'),__('1','periodic'),__('%','fb')); ?>"><?php comments_number(__('0','periodic'),__('1','periodic'),__('%','fb')); ?> </a></span>						
							<span itemprop="dateModified"> Last Updated: <?php the_modified_time('M jS, Y'); ?></span>
						</div>
					</div>
					<div class="entry_excerpt" itemprop="text">
						<p>
							<?php
							$excerpt=get_the_excerpt();
							echo string_limit_words($excerpt,25);
							?>
						</p>
					</div>
					<div class="read_more">
						<a class="read_more_btn" href="<?php echo the_permalink(); ?>"><?php echo $instance[ 'read_more' ]; ?></a>
					</div>
				</div>
			</div>
		<?php
		endwhile;
		wp_reset_query(); 
		?>
	</div>
</div>
<?php
echo $args['after_widget'];
}		
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Content First Category Post', 'gl_content_first_catgory_widget_domain' );
}
 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '2', 'gl_content_first_catgory_widget_domain' );
}
 if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '350', 'gl_content_first_catgory_widget_domain' );
}
 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '192', 'gl_content_first_catgory_widget_domain' );
}
 if ( isset( $instance[ 'cat_id' ] ) ) {
$cat_id = $instance[ 'cat_id' ];
}
else {
$cat_id = __( '2', 'gl_content_first_catgory_widget_domain' );
}
 if ( isset( $instance[ 'read_more' ] ) ) {
$read_more = $instance[ 'read_more' ];
}
else {
$read_more = __( 'View More', 'gl_content_first_catgory_widget_domain' );
}
?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'cat_id' ); ?>"><?php _e( 'Content First Category ID:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'cat_id' ); ?>" name="<?php echo $this->get_field_name( 'cat_id' ); ?>" type="text" value="<?php echo esc_attr( $cat_id ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'read_more' ); ?>"><?php _e( 'Read More Text:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'read_more' ); ?>" name="<?php echo $this->get_field_name( 'read_more' ); ?>" type="text" value="<?php echo esc_attr( $read_more ); ?>" />
</p>
<?php 
}
public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';
$instance['cat_id'] = ( ! empty( $new_instance['cat_id'] ) ) ? strip_tags( $new_instance['cat_id'] ) : '';
$instance['read_more'] = ( ! empty( $new_instance['read_more'] ) ) ? strip_tags( $new_instance['read_more'] ) : '';
return $instance;
}
}
//Content First Category Widget Ends Here
// Content Second Category Widget Starts Here
class gl_content_second_catgory_widget extends WP_Widget {
function __construct() {
parent::__construct(
'gl_content_second_catgory_widget', 
__('S&G - Content Second Category', 'gl_content_second_catgory_widget_domain'), 
array( 'description' => __( 'Displays Content Second Category Post', 'gl_content_second_catgory_widget_domain' ), ) 
);
}
public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );
$cat_id = apply_filters( 'cat_id', $instance['cat_id'] );
$width_size1 = apply_filters( 'width_size1', $instance['width_size1'] );
$height_size1 = apply_filters( 'height_size1', $instance['height_size1'] );
echo $args['before_widget'];
if ( ! empty( $title ) )
/*echo $args['before_title'] . $title . $args['after_title'];*/
?>
<div class="second_category">
	<div class="second_category_section">
		<div class='block_title'>
			<?php 
			echo "<a title='";
			$category=get_the_category_by_id( $instance['cat_id'] ); echo $category;
			echo "'".
			" href='";
			$category_link = get_category_link( $instance['cat_id'] );
			echo esc_url( $category_link );
			echo "'".
			"><h3>";
			$category=get_the_category_by_id( $instance['cat_id'] ); echo $category;
			echo "</h3></a>";
			?>
			<span class="sep"></span>
		</div>
		<div class="second_cat_cnt_section">
		<?php 
		$i = 1;
		query_posts( array('posts_per_page'=>$instance['post_count'], cat=>$instance['cat_id']) );
		while ( have_posts() ) : the_post();	
		?>
				<?php 
				if(($i == 1)){
				?>
					<div class="second_cat_left_section">
						<div class="entry_image thumb overlay" itemprop="image">
							<?php
							// Defaults
							$f_img_width3 = $instance['width_size'];
							$f_img_height3 = $instance['height_size'];
							$default_img =  'Feature_image'; 

							// Auto feature image defaults
							$thumb = get_post_thumbnail_id(); 
							$img_url = wp_get_attachment_url( $thumb,'full' ); 
							$image = aq_resize( $img_url,$f_img_width3,$f_img_height3, true );
							// Catch the Image defaults
							$catch_img_url = catch_that_image( $thumb,'full' );
							$catch_image = aq_resize( $catch_img_url, $f_img_width3, $f_img_height3, true );
							// Default Image
							$default_image = aq_resize( $default_img, $f_img_width3, $f_img_height3, true );	
							if(has_post_thumbnail())
							echo
							"<div class=\"featured_image\">\n".
							"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width3 . "\" height=\"" . $f_img_height3 . "\" alt=\"" . get_the_title() . "\"></a>\n".
							"</div>\n";
							elseif (catch_that_image()){ 
							echo
							"<div class=\"featured_image\">\n".
							"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width3 . "\" height=\"" . $f_img_height3 . "\" alt=\"" . get_the_title() . "\"></a>\n".
							"</div>\n"; 
							} 
							/*featured image ends here*/
							?>
							<div class="more"> 
							<a href="<?php echo the_permalink(); ?>"><i class="fa icon-paper-plane"></i></a>
							</div>
							<div class="entry-cat category">
							<?php
							$category = get_the_category(); 
							?>
							<h4><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></h4>
							</div>
						</div>
						<div class="top_entry_content">
							<div class="entry_title">
								<?php echo "<h3 itemprop='headline'><a href='". get_permalink() ."'>".get_the_title()."";
								echo "</a></h3>";?>
							</div>
							<div class="second_cat__byline">
									<span class='author' itemprop="author"><?php the_author() ?></span>
									<span class='date' itemprop="datePublished"><?php the_time('M jS, Y') ?> at <?php the_time('g:i a'); ?></span>
									<span class='info_comments'><a  href="<?php the_permalink(); ?>#comments" title="<?php comments_number(__('0 ','fb'),__('1 ','periodic'),__('% ','fb')); ?>"><?php comments_number(__('0 ','periodic'),__('1 ','periodic'),__('% ','fb')); ?> </a></span>						
							</div>
							<div class="entry_excerpt" itemprop="text">
								<p>
									<?php
									$excerpt=get_the_excerpt();
									echo string_limit_words($excerpt,25);
									?>
								</p>
							</div>
						</div>
					</div>
				<?php
				}
				else{
				?>
					<div class="second_cat_right_section">
						<div class="entry_image thumb overlay second_cat_right_img" itemprop="image">
							<?php
							// Defaults
							$f_img_width4 = $instance['width_size1'];
							$f_img_height4 = $instance['height_size1'];
							$default_img =  'Feature_image'; 

							// Auto feature image defaults
							$thumb = get_post_thumbnail_id(); 
							$img_url = wp_get_attachment_url( $thumb,'full' ); 
							$image = aq_resize( $img_url,$f_img_width4,$f_img_height4, true );
							// Catch the Image defaults
							$catch_img_url = catch_that_image( $thumb,'full' );
							$catch_image = aq_resize( $catch_img_url, $f_img_width4, $f_img_height4, true );
							// Default Image
							$default_image = aq_resize( $default_img, $f_img_width4, $f_img_height4, true );
							if(has_post_thumbnail())
							echo
							"<div class=\"featured_image\">\n".
							"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width4 . "\" height=\"" . $f_img_height4 . "\" alt=\"" . get_the_title() . "\"></a>\n".
							"</div>\n";
							elseif (catch_that_image()){ 
							echo
							"<div class=\"featured_image\">\n".
							"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width4 . "\" height=\"" . $f_img_height4 . "\" alt=\"" . get_the_title() . "\"></a>\n".
							"</div>\n"; 
							} 
							/*featured image ends here*/
							?>
							<div class="readmore_section"> 
							<a href="<?php echo the_permalink(); ?>"><i class="fa icon-paper-plane"></i></a>
							</div>
							<div class="entry-cat category">
							<?php
							$category = get_the_category(); 
							?>
							<h4><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></h4>
							</div>
						</div>
						<div class="top_entry_content second_right_cnt">
							<div class="entry_title">
								<?php echo "<h3 itemprop='headline'><a href='". get_permalink() ."'>".get_the_title()."";
								echo "</a></h3>";?>
							</div>
							<div class="home_byline">
								<span class='author' itemprop="author"><?php the_author() ?></span>
								<span class='info_comments'><a  href="<?php the_permalink(); ?>#comments" title="<?php comments_number(__('0 ','fb'),__('1 ','periodic'),__('% ','fb')); ?>"><?php comments_number(__('0 ','periodic'),__('1 ','periodic'),__('% ','fb')); ?> </a></span>						
							</div>
						</div>
					</div>
				<?php 
				}
				$i++;
				endwhile;
				wp_reset_query(); 
				?>
			</div>
	</div>
</div>
<?php
echo $args['after_widget'];
}		
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Content Second Category Post', 'gl_content_second_catgory_widget_domain' );
}
 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '5', 'gl_content_second_catgory_widget_domain' );
}
 if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '385', 'gl_content_second_catgory_widget_domain' );
}
 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '215', 'gl_content_second_catgory_widget_domain' );
}
 if ( isset( $instance[ 'cat_id' ] ) ) {
$cat_id = $instance[ 'cat_id' ];
}
else {
$cat_id = __( '8', 'gl_content_second_catgory_widget_domain' );
}
 if ( isset( $instance[ 'width_size1' ] ) ) {
$width_size1 = $instance[ 'width_size1' ];
}
else {
$width_size1 = __( '144', 'gl_content_second_catgory_widget_domain' );
}
 if ( isset( $instance[ 'height_size1' ] ) ) {
$height_size1 = $instance[ 'height_size1' ];
}
else {
$height_size1 = __( '80', 'gl_content_second_catgory_widget_domain' );
}
?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'cat_id' ); ?>"><?php _e( 'Content Second Category ID:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'cat_id' ); ?>" name="<?php echo $this->get_field_name( 'cat_id' ); ?>" type="text" value="<?php echo esc_attr( $cat_id ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Left Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Left Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'width_size1' ); ?>"><?php _e( 'Right Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size1' ); ?>" name="<?php echo $this->get_field_name( 'width_size1' ); ?>" type="text" value="<?php echo esc_attr( $width_size1 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size1' ); ?>"><?php _e( 'Right Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size1' ); ?>" name="<?php echo $this->get_field_name( 'height_size1' ); ?>" type="text" value="<?php echo esc_attr( $height_size1 ); ?>" />
</p>
<?php 
}
public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';
$instance['cat_id'] = ( ! empty( $new_instance['cat_id'] ) ) ? strip_tags( $new_instance['cat_id'] ) : '';
$instance['width_size1'] = ( ! empty( $new_instance['width_size1'] ) ) ? strip_tags( $new_instance['width_size1'] ) : '';
$instance['height_size1'] = ( ! empty( $new_instance['height_size1'] ) ) ? strip_tags( $new_instance['height_size1'] ) : '';
return $instance;
}
}
//Content Second Category Widget Ends Here
// Content Third Category Widget Starts Here
class gl_content_third_catgory_widget extends WP_Widget {
function __construct() {
parent::__construct(
'gl_content_third_catgory_widget', 
__('S&G - Content Third Category', 'gl_content_third_catgory_widget_domain'), 
array( 'description' => __( 'Displays Content Third Category Post', 'gl_content_third_catgory_widget_domain' ), ) 
);
}
public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );
$cat_id = apply_filters( 'cat_id', $instance['cat_id'] );
$read_more = apply_filters( 'read_more', $instance['read_more'] );
echo $args['before_widget'];
if ( ! empty( $title ) )
/*echo $args['before_title'] . $title . $args['after_title'];*/
?>
<div class="third_category">
	<div class="third_category_section">
		<div class='block_title'>
			<?php 
			echo "<a title='";
			$category=get_the_category_by_id($instance[ 'cat_id' ]); echo $category;
			echo "'".
			" href='";
			$category_link = get_category_link($instance[ 'cat_id' ]);
			echo esc_url( $category_link );
			echo "'".
			"><h3>";
			$category=get_the_category_by_id($instance[ 'cat_id' ]); echo $category;
			echo "</h3></a>";
			?>
			<span class="sep"></span>
		</div>
		<?php 
		query_posts( array('posts_per_page'=>$instance['post_count'], cat=>$instance[ 'cat_id' ]) );
		while ( have_posts() ) : the_post();
		?>
			<div class="third_cat_content">
				<div class="entry_image thumb overlay third_category_img" itemprop="image">
					<?php
					// Defaults
					$f_img_width6 = $instance[ 'width_size' ];
					$f_img_height6 = $instance[ 'height_size' ];
					$default_img =  'Feature_image'; 

					// Auto feature image defaults
					$thumb = get_post_thumbnail_id(); 
					$img_url = wp_get_attachment_url( $thumb,'full' ); 
					$image = aq_resize( $img_url,$f_img_width6,$f_img_height6, true );
					// Catch the Image defaults
					$catch_img_url = catch_that_image( $thumb,'full' );
					$catch_image = aq_resize( $catch_img_url, $f_img_width6, $f_img_height6, true );
					// Default Image
					$default_image = aq_resize( $default_img, $f_img_width6, $f_img_height6, true );
					if(has_post_thumbnail())
					echo
					"<div class=\"featured_image\">\n".
					"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width6 . "\" height=\"" . $f_img_height6 . "\" alt=\"" . get_the_title() . "\"></a>\n".
					"</div>\n";
					elseif (catch_that_image()){ 
					echo
					"<div class=\"featured_image\">\n".
					"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width6 . "\" height=\"" . $f_img_height6 . "\" alt=\"" . get_the_title() . "\"></a>\n".
					"</div>\n"; 
					} 
					/*featured image ends here*/
					?>
					<div class="more"> 
					<a href="<?php echo the_permalink(); ?>"><i class="fa icon-paper-plane"></i></a>
					</div>
					<div class="entry-cat category">
					<?php
					$category = get_the_category(); 
					?>
					<h4><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></h4>
					</div>
				</div>
				<div class="top_entry_content third_category_cnt">
					<div class="author_section">
						<span itemprop="author"><?php the_author() ?></span>
						<?php echo get_avatar( get_the_author_meta( 'ID' ) , 40 ); ?>
					</div>
					<div class="entry_title">
						<?php echo "<h3 itemprop='headline'><a href='". get_permalink() ."'>".get_the_title()."";
						echo "</a></h3>";?>
					</div>
					<div class="top_byline">
						<div class="top_left_byline">			
							<span class="post_date">
								<time datetime="<?php the_time('c') ?>" itemprop="datePublished"><strong><?php the_time('d') ?></strong><span><?php the_time('M') ?></span><span><?php the_time('Y') ?></span></time>
							</span>
						</div>
						<div class="top_right_byline">
							<span class='info_comments'><a  href="<?php the_permalink(); ?>#comments" title="<?php comments_number(__('0 ','fb'),__('1 ','periodic'),__('% ','fb')); ?>"><?php comments_number(__('0 ','periodic'),__('1 ','periodic'),__('% ','fb')); ?> </a></span>						
							<time datetime="<?php the_time('c'); ?>" itemprop="datePublished"> Last Updated: <?php the_modified_time('M jS, Y'); ?></time>
						</div>
					</div>
					<div class="entry_excerpt" itemprop="text">
						<p>
							<?php
							$excerpt=get_the_excerpt();
							echo string_limit_words($excerpt,15);
							?>
						</p>
					</div>
					<div class="read_more">
						<a class="read_more_btn" href="<?php echo the_permalink(); ?>"><?php echo $instance[ 'read_more' ]; ?></a>
					</div>
				</div>
			</div>
		<?php
		endwhile;
		wp_reset_query(); 
		?>
	</div>
</div>
<?php
echo $args['after_widget'];
}		
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Content Third Category Post', 'gl_content_third_catgory_widget_domain' );
}
 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '3', 'gl_content_third_catgory_widget_domain' );
}
 if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '385', 'gl_content_third_catgory_widget_domain' );
}
 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '250', 'gl_content_third_catgory_widget_domain' );
}
 if ( isset( $instance[ 'cat_id' ] ) ) {
$cat_id = $instance[ 'cat_id' ];
}
else {
$cat_id = __( '6', 'gl_content_third_catgory_widget_domain' );
}
 if ( isset( $instance[ 'read_more' ] ) ) {
$read_more = $instance[ 'read_more' ];
}
else {
$read_more = __( 'View More', 'gl_content_third_catgory_widget_domain' );
}
?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'cat_id' ); ?>"><?php _e( 'Content Third Category ID:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'cat_id' ); ?>" name="<?php echo $this->get_field_name( 'cat_id' ); ?>" type="text" value="<?php echo esc_attr( $cat_id ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'read_more' ); ?>"><?php _e( 'Read More Text:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'read_more' ); ?>" name="<?php echo $this->get_field_name( 'read_more' ); ?>" type="text" value="<?php echo esc_attr( $read_more ); ?>" />
</p>
<?php 
}
public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';
$instance['cat_id'] = ( ! empty( $new_instance['cat_id'] ) ) ? strip_tags( $new_instance['cat_id'] ) : '';
$instance['read_more'] = ( ! empty( $new_instance['read_more'] ) ) ? strip_tags( $new_instance['read_more'] ) : '';
return $instance;
}
}
//Content Third Category Widget Ends Here
// Content Editors Picks Widget Starts Here
class gl_content_editors_picks_widget extends WP_Widget {
function __construct() {
parent::__construct(
'gl_content_editors_picks_widget', 
__('S&G - Content Editors Picks', 'gl_content_editors_picks_widget_domain'), 
array( 'description' => __( 'Displays Content Editors Picks Post', 'gl_content_editors_picks_widget_domain' ), ) 
);
}
public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$editors_id1 = apply_filters( 'editors_id1', $instance['editors_id1'] );
$editors_id2 = apply_filters( 'editors_id2', $instance['editors_id2'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );
echo $args['before_widget'];
if ( ! empty( $title ) )
/*echo $args['before_title'] . $title . $args['after_title'];*/
?>
<div class="editor_picks">
	<div class="editor_picks_section">
		<div class="editor_picks_title">
			<h4><?php echo $instance['title']; ?></h4>
		</div>
		<?php
			query_posts('p='. $editors_id1 .'&posts_per_page=1');
			while (have_posts()): the_post(); 
		?>
		<div class="editor_picks_content">
			<div class="entry_image thumb overlay editor_picks_img" itemprop="image">
				<?php
				// Defaults
				$f_img_width7 = $instance['width_size'];
				$f_img_height7 = $instance['height_size'];
				$default_img =  'Feature_image'; 

				// Auto feature image defaults
				$thumb = get_post_thumbnail_id(); 
				$img_url = wp_get_attachment_url( $thumb,'full' ); 
				$image = aq_resize( $img_url,$f_img_width7,$f_img_height7, true );
				// Catch the Image defaults
				$catch_img_url = catch_that_image( $thumb,'full' );
				$catch_image = aq_resize( $catch_img_url, $f_img_width7, $f_img_height7, true );
				// Default Image
				$default_image = aq_resize( $default_img, $f_img_width7, $f_img_height7, true );
				if(has_post_thumbnail())
				echo
				"<div class=\"featured_image\">\n".
				"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width7 . "\" height=\"" . $f_img_height7 . "\" alt=\"" . get_the_title() . "\"></a>\n".
				"</div>\n";
					elseif (catch_that_image()){ 
				echo
				"<div class=\"featured_image\">\n".
				"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width7 . "\" height=\"" . $f_img_height7 . "\" alt=\"" . get_the_title() . "\"></a>\n".
				"</div>\n"; 
				} 
				/*featured image ends here*/
				?>
				<div class="readmore_section"> 
					<a href="<?php echo the_permalink(); ?>"><i class="fa icon-paper-plane"></i></a>
				</div>
				<div class="entry-cat category">
					<?php
					$category = get_the_category(); 
					?>
					<h4><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></h4>
				</div>
			</div>
			<div class="top_entry_content editor_picks_cnt">
				<div class="home_byline">
					<span class='author' itemprop="author"><?php the_author() ?></span>
					<span class='info_comments'><a  href="<?php the_permalink(); ?>#comments" title="<?php comments_number(__('0','fb'),__('1 ','periodic'),__('%','fb')); ?>"><?php comments_number(__('0','periodic'),__('1','periodic'),__('%','fb')); ?> </a></span>						
				</div>
				<div class="entry_title">
					<?php echo "<h3 itemprop='headline'><a href='". get_permalink() ."'>".get_the_title()."";
					echo "</a></h3>";?>
				</div>
				
			</div>
		</div>
		<?php
			endwhile;
		?>
		<?php
			query_posts('p='. $editors_id2 .'&posts_per_page=1');
			while (have_posts()): the_post(); 
		?>
		<div class="editor_picks_content">
			<div class="entry_image thumb overlay editor_picks_img" itemprop="image">
				<?php
				// Defaults
				$f_img_width7 = $instance['width_size'];
				$f_img_height7 = $instance['height_size'];
				$default_img =  'Feature_image'; 

				// Auto feature image defaults
				$thumb = get_post_thumbnail_id(); 
				$img_url = wp_get_attachment_url( $thumb,'full' ); 
				$image = aq_resize( $img_url,$f_img_width7,$f_img_height7, true );
				// Catch the Image defaults
				$catch_img_url = catch_that_image( $thumb,'full' );
				$catch_image = aq_resize( $catch_img_url, $f_img_width7, $f_img_height7, true );
				// Default Image
				$default_image = aq_resize( $default_img, $f_img_width7, $f_img_height7, true );
				if(has_post_thumbnail())
				echo
				"<div class=\"featured_image\">\n".
				"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width7 . "\" height=\"" . $f_img_height7 . "\" alt=\"" . get_the_title() . "\"></a>\n".
				"</div>\n";
					elseif (catch_that_image()){ 
				echo
				"<div class=\"featured_image\">\n".
				"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width7 . "\" height=\"" . $f_img_height7 . "\" alt=\"" . get_the_title() . "\"></a>\n".
				"</div>\n"; 
				} 
				/*featured image ends here*/
				?>
				<div class="readmore_section"> 
					<a href="<?php echo the_permalink(); ?>"><i class="fa icon-paper-plane"></i></a>
				</div>
				<div class="entry-cat category">
					<?php
					$category = get_the_category(); 
					?>
					<h4><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></h4>
				</div>
			</div>
			<div class="top_entry_content editor_picks_cnt">
				<div class="home_byline">
					<span class='author' itemprop="author"><?php the_author() ?></span>
					<span class='info_comments'><a  href="<?php the_permalink(); ?>#comments" title="<?php comments_number(__('0','fb'),__('1','periodic'),__('%','fb')); ?>"><?php comments_number(__('0','periodic'),__('1','periodic'),__('%','fb')); ?> </a></span>						
				</div>
				<div class="entry_title">
					<?php echo "<h3 itemprop='headline'><a href='". get_permalink() ."'>".get_the_title()."";
					echo "</a></h3>";?>
				</div>
			</div>
		</div>
		<?php
			endwhile;
		?>
	</div>
</div>
<?php
echo $args['after_widget'];
}		
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Editorial Picks', 'gl_content_editors_picks_widget_domain' );
}
 if ( isset( $instance[ 'editors_id1' ] ) ) {
$editors_id1 = $instance[ 'editors_id1' ];
}
else {
$editors_id1 = __( '16', 'gl_content_editors_picks_widget_domain' );
}
 if ( isset( $instance[ 'editors_id2' ] ) ) {
$editors_id2 = $instance[ 'editors_id2' ];
}
else {
$editors_id2 = __( '42', 'gl_content_editors_picks_widget_domain' );
}
 if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '151', 'gl_content_editors_picks_widget_domain' );
}
 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '120', 'gl_content_editors_picks_widget_domain' );
}
?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'editors_id1' ); ?>"><?php _e( 'First Post ID :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'editors_id1' ); ?>" name="<?php echo $this->get_field_name( 'editors_id1' ); ?>" type="text" value="<?php echo esc_attr( $editors_id1 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'editors_id2' ); ?>"><?php _e( 'Second Post ID:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'editors_id2' ); ?>" name="<?php echo $this->get_field_name( 'editors_id2' ); ?>" type="text" value="<?php echo esc_attr( $editors_id2 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>
<?php 
}
public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['editors_id1'] = ( ! empty( $new_instance['editors_id1'] ) ) ? strip_tags( $new_instance['editors_id1'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';
$instance['editors_id2'] = ( ! empty( $new_instance['editors_id2'] ) ) ? strip_tags( $new_instance['editors_id2'] ) : '';
return $instance;
}
}
//Content Editors Picks Widget Ends Here
// Content Fourth Category Widget Starts Here
class gl_content_fourth_catgory_widget extends WP_Widget {
function __construct() {
parent::__construct(
'gl_content_fourth_catgory_widget', 
__('S&G - Content Fourth Category', 'gl_content_fourth_catgory_widget_domain'), 
array( 'description' => __( 'Displays Content Fourth Category Post', 'gl_content_fourth_catgory_widget_domain' ), ) 
);
}
public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );
$cat_id = apply_filters( 'cat_id', $instance['cat_id'] );
$read_more = apply_filters( 'read_more', $instance['read_more'] );
echo $args['before_widget'];
if ( ! empty( $title ) )
/*echo $args['before_title'] . $title . $args['after_title'];*/
?>
<div class="fourth_category">
		<div class='block_title'>
			<?php 
			echo "<a title='";
			$category=get_the_category_by_id($instance['cat_id']); echo $category;
			echo "'".
			" href='";
			$category_link = get_category_link($instance['cat_id']);
			echo esc_url( $category_link );
			echo "'".
			"><h3>";
			$category=get_the_category_by_id($instance['cat_id']); echo $category;
			echo "</h3></a>";
			?>
			<span class="sep"></span>
		</div>
			<div class="fourth_category_section">
				<?php 
					query_posts( array('posts_per_page'=>$instance['post_count'], cat=>$instance['cat_id']) );
					while ( have_posts() ) : the_post();
					$i++;
					$class = ( $i % 2 ) ? 'lat_news' : 'lat_news last'; 
				?>
					<div class="<?php echo $class; ?> <?php $category=get_the_category_by_id('8'); echo $category; ?>">
						<div class='all_news_section'>
							<div class="entry_image thumb overlay" itemprop="image">
								<?php								
								// Defaults
								$f_img_width8 = $instance['width_size'];
								$f_img_height8 = $instance['height_size'];
								$default_img =  'Feature_image'; 

								// Auto feature image defaults
								$thumb = get_post_thumbnail_id(); 
								$img_url = wp_get_attachment_url( $thumb,'full' ); 
								$image = aq_resize( $img_url,$f_img_width8,$f_img_height8, true );
								// Catch the Image defaults
								$catch_img_url = catch_that_image( $thumb,'full' );
								$catch_image = aq_resize( $catch_img_url, $f_img_width8, $f_img_height8, true );
								// Default Image
								$default_image = aq_resize( $default_img, $f_img_width8, $f_img_height8, true );
								if(has_post_thumbnail())
								echo
								"<div class=\"featured_image\">\n".
								"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width8 . "\" height=\"" . $f_img_height8 . "\" alt=\"" . get_the_title() . "\"></a>\n".
								"</div>\n";
								elseif (catch_that_image()){ 
								echo
								"<div class=\"featured_image\">\n".
								"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width8 . "\" height=\"" . $f_img_height8 . "\" alt=\"" . get_the_title() . "\"></a>\n".
								"</div>\n"; 
								} 
								/*featured image ends here*/
								?>
								<div class="more"> 
									<a href="<?php echo the_permalink(); ?>"><i class="fa icon-paper-plane"></i></a>
								</div>
								<div class="entry-cat category">
									<?php
									$category = get_the_category(); 
									?>
									<h4><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></h4>
								</div>
							</div>
							<div class="entry_content">
								<div class="entry_title">
									<?php echo "<h3 itemprop='headline'><a href='". get_permalink() ."'>".get_the_title()."";
									echo "</a></h3>";?>
								</div>
								<div class="home_byline">
									<span class='author' itemprop="author"><?php the_author() ?></span>
									<time class='date' datetime="<?php the_time('c'); ?>" itemprop="datePublished"><?php the_time('M jS, Y') ?></time>
									<span class='info_comments'><a  href="<?php the_permalink(); ?>#comments" title="<?php comments_number(__('0','fb'),__('1','periodic'),__('% ','fb')); ?>"><?php comments_number(__('0','periodic'),__('1 ','periodic'),__('% ','fb')); ?> </a></span>						
								</div>
								<div class="entry_excerpt" itemprop="text">
									<p>
										<?php
										$excerpt=get_the_excerpt();
										echo string_limit_words($excerpt,25);
										?>
									</p>
								</div>
								<div class="read_more">
									<a class="read_more_btn" href="<?php echo the_permalink(); ?>"><?php echo $instance[ 'read_more' ]; ?></a>
								</div>
							</div>
						</div>
					</div>
				<?php				
				endwhile;
				wp_reset_query(); 
				?>	
			</div>
</div>
<?php
echo $args['after_widget'];
}		
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Content Fourth Category Post', 'gl_content_fourth_catgory_widget_domain' );
}
 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '4', 'gl_content_fourth_catgory_widget_domain' );
}
 if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '392', 'gl_content_fourth_catgory_widget_domain' );
}
 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '205', 'gl_content_fourth_catgory_widget_domain' );
}
 if ( isset( $instance[ 'cat_id' ] ) ) {
$cat_id = $instance[ 'cat_id' ];
}
else {
$cat_id = __( '4', 'gl_content_fourth_catgory_widget_domain' );
}
 if ( isset( $instance[ 'read_more' ] ) ) {
$read_more = $instance[ 'read_more' ];
}
else {
$read_more = __( 'View More', 'gl_content_fourth_catgory_widget_domain' );
}
?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'cat_id' ); ?>"><?php _e( 'Content Fourth Category ID:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'cat_id' ); ?>" name="<?php echo $this->get_field_name( 'cat_id' ); ?>" type="text" value="<?php echo esc_attr( $cat_id ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'read_more' ); ?>"><?php _e( 'Read More Text:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'read_more' ); ?>" name="<?php echo $this->get_field_name( 'read_more' ); ?>" type="text" value="<?php echo esc_attr( $read_more ); ?>" />
</p>
<?php 
}
public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';
$instance['cat_id'] = ( ! empty( $new_instance['cat_id'] ) ) ? strip_tags( $new_instance['cat_id'] ) : '';
$instance['read_more'] = ( ! empty( $new_instance['read_more'] ) ) ? strip_tags( $new_instance['read_more'] ) : '';
return $instance;
}
}
//Content Fourth Category Widget Ends Here
// Realated Post Widget Starts Here
class gl_related_post_widget extends WP_Widget {
function __construct() {
parent::__construct(
'gl_related_post_widget', 
__('S&G - Realated Post', 'gl_related_post_widget_domain'), 
array( 'description' => __( 'Displays Realated Post', 'gl_related_post_widget_domain' ), ) 
);
}
public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );
echo $args['before_widget'];
if ( ! empty( $title ) )
/*echo $args['before_title'] . $title . $args['after_title'];*/
?>
<div class="thesis_related single_page_cnt">
<?php
global $post;
	if ( is_single() ) {
		$tags = get_the_tags($post->ID);
			if ($tags) {
			$tag_ids = array();
			foreach($tags as $individual_tag) $tag_ids[] = $individual_tag->term_id;
			$args=array(
			'tag__in' => $tag_ids,
			'post__not_in' => array($post->ID),
			'showposts'=>$instance['post_count'],  // Number of related posts that will be shown.
			'caller_get_posts'=>1
			);
	$my_query = new wp_query($args);
			if( $my_query->have_posts() ) {
	echo	'<div id="relatedposts">'.
				'<div class="block_title">'.
					'<h3>'. $title .'</h3>'.
					'<span class="sep"></span>'.
				'</div>'.
			'<div class="related_section">';
		while ($my_query->have_posts()) {
			$my_query->the_post();
	 ?>
			<div class="related_post_section">
							<div class="entry_image thumb overlay">
								<?php
								  $f_img_width1 = $instance['width_size'];
								  $f_img_height1 = $instance['height_size'];
								// Auto feature image defaults
								$thumb = get_post_thumbnail_id(); 
								$img_url = wp_get_attachment_url( $thumb,'full' ); 
								$image = aq_resize( $img_url, $f_img_width1, $f_img_height1, true );
								// Catch the Image defaults
								$catch_img_url = catch_that_image( $thumb,'full' );
								$catch_image = aq_resize( $catch_img_url, $f_img_width1, $f_img_height1, true );
								if(has_post_thumbnail())
								echo
								"<div class=\"featured_image\">\n".
								"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width1 . "\" height=\"" . $f_img_height1 . "\" alt=\"" . get_the_title() . "\"></a>\n".
								"</div>\n";
								elseif (catch_that_image()){ 
								echo
								"<div class=\"featured_image\">\n".
								"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width1 . "\" height=\"" . $f_img_height1 . "\" alt=\"" . get_the_title() . "\"></a>\n".
								"</div>\n"; 
								} 
								/*featured image ends here*/
								?>
								<div class="more"> 
									<a href="<?php echo the_permalink(); ?>"><i class="fa icon-paper-plane"></i></a>
								</div>
								<div class="entry-cat category">
									<?php
									$category = get_the_category(); 
									?>
									<h4><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></h4>
								</div>
							</div>
							<div class="entry_content related_post_cnt">
								<div class="entry_title">
									<?php echo "<h3><a href='". get_permalink() ."'>".get_the_title()."";
									echo "</a></h3>";?>
								</div>
								<div class="home_byline">
									<span class='author' itemprop="author"><?php the_author() ?></span>
									<time class='date' datetime="<?php the_time('c'); ?>" itemprop="datePublished"><?php the_time('M jS, Y') ?></time>									
								</div>
							</div>
					</div>
	<?php
			}
			echo '</div>';
			echo '</div>';
			}
		}
	$post = $backup;
			wp_reset_query();
			?>
			<div class="clear"></div>
			<?php
			 }
?>
</div>
<?php
echo $args['after_widget'];
}		
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Realated Post', 'gl_related_post_widget_domain' );
}
 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '2', 'gl_related_post_widget_domain' );
}
 if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '400', 'gl_related_post_widget_domain' );
}
 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '207', 'gl_related_post_widget_domain' );
}
?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>
<?php 
}
public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';
return $instance;
}
}
//Realated Post Widget Ends Here
// Register and load the widget
function gl_load_widget() {
	register_widget( 'gl_last_update_widget' );
	register_widget( 'gl_trending_widget' );
	register_widget( 'gl_sidbar_catgory_widget' );
	register_widget( 'gl_latest_news_widget' );
	register_widget( 'gl_content_first_catgory_widget' );
	register_widget( 'gl_content_second_catgory_widget' );
	register_widget( 'gl_content_third_catgory_widget' );
	register_widget( 'gl_content_editors_picks_widget' );
	register_widget( 'gl_content_fourth_catgory_widget' );
	register_widget( 'gl_related_post_widget' );
}
add_action( 'widgets_init', 'gl_load_widget' );