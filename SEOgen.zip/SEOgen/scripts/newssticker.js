
var j=jQuery.noConflict();
j(function() {
    j('.newsticker').newsticker();
	
});

