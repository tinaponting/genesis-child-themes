var j=jQuery.noConflict();
	var j = jQuery.noConflict();
	j(window).load(function() {
	j('.flexslider').flexslider({
	animation: 'slide'
	});
	});