<div class="footer-widgets">
	<div class="wrap">
    	
<div class='footer_section'>

<div class='footer_widget about_us'>
<?php if(genesism_get_option('footer_aboutus')){
?>
<div class="line_title">
<h3><?php echo genesism_option('aboutus_title'); ?></h3>
<div class="sep"></div>
</div>
<div class="about_us_cnt_social">
<p><?php echo genesism_option('aboutus_cnt'); ?></p>
<?php 
if(!genesism_get_option('footer_social')){
?>
<div class='footer_social_follow'>
	<?php 
	if(!genesism_get_option('fb_chech2')){
	?>
	<div class="footer_social_icons">
	<a class="Facebook" title="Facebook" href="<?php echo genesism_option('facebook_text3'); ?>" target="_blank">
	<i class="fa icon-facebook"></i>
	</a>
	</div>
	<?php 
	}
	if(!genesism_get_option('tw_chech2')){
	?>
	<div class="footer_social_icons">
	<a class="Twitter" title="Twitter" href="<?php echo genesism_option('twitter_text3'); ?>" target="_blank">
	<i class="fa icon-twitter"></i>
	</a>
	</div>
	<?php 
	}
	if(!genesism_get_option('gp_chech2')){
	?>
	<div class="footer_social_icons">
	<a class="googleplus" title="google plus" href="<?php echo genesism_option('googleplus_text3'); ?>" target="_blank">
	<i class="fa icon-google-plus"></i>
	</a>
	</div>
	<?php 
	}
	if(!genesism_get_option('pin_chech2')){
	?>
	<div class="footer_social_icons">
	<a class="pinterest" title="pinterest" href="<?php echo genesism_option('pinterest_text3'); ?>" target="_blank">
	<i class="fa icon-pinterest"></i>
	</a>
	</div>
	<?php 
	}
	if(!genesism_get_option('lin_chech2')){
	?>
		<div class="footer_social_icons">
	<a class="linkedin" title="linkedin" href="<?php echo genesism_option('linkedin_text3'); ?>" target="_blank">
	<i class="fa icon-linkedin2"></i>
	</a>
	</div>
	<?php 
	}
	if(!genesism_get_option('yt_chech2')){
	?>
	<div class="footer_social_icons">
	<a class="youtube" title="youtube" href="<?php echo genesism_option('youtube_text3'); ?>" target="_blank">
	<i class="fa icon-youtube3"></i>
	</a>
	</div>
	<?php 
	}
	if(!genesism_get_option('dri_chech2')){
	?>
	<div class="footer_social_icons">
	<a class="dribbble" title="dribbble" href="<?php echo genesism_option('dribbble_text3'); ?>" target="_blank">
	<i class="fa icon-dribbble"></i>
	</a>
	</div>
	<?php 
	}
	if(!genesism_get_option('fli_chech2')){
	?>
	<div class="footer_social_icons">
	<a class="flickr" title="flickr" href="<?php echo genesism_option('flickr_text3'); ?>" target="_blank">
	<i class="fa icon-flickr3"></i>
	</a>
	</div>
	<?php 
	}
	?>
</div>
<?php
}
?>
</div>
<?php 
}
?>
</div>



<div class='footer_widget recent_post'>
<?php if(genesism_get_option('recent_news')){
?>
<div class="line_title">
<h3><?php echo genesism_option('recent_news_title'); ?></h3>
<div class="sep"></div>
</div>
<div class="recent_news_section">
<?php
query_posts( array('posts_per_page'=>3) );
while ( have_posts() ) : the_post();
?>
<div class="recent_news_cnt">
<div class="recent_news_img">
<?php
// Defaults
$f_img_width10 = 85;
$f_img_height10 = 80;
$default_img =  'Feature_image'; 
// Auto feature image defaults
$thumb = get_post_thumbnail_id(); 
$img_url = wp_get_attachment_url( $thumb,'full' ); 
$image = aq_resize( $img_url,$f_img_width10,$f_img_height10, true );
// Catch the Image defaults
$catch_img_url = catch_that_image( $thumb,'full' );
$catch_image = aq_resize( $catch_img_url, $f_img_width10, $f_img_height10, true );
// Default Image
$default_image = aq_resize( $default_img, $f_img_width10, $f_img_height10, true );
								
if(has_post_thumbnail())
echo
"<div class=\"featured_image\">\n".
"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width10 . "\" height=\"" . $f_img_height10 . "\" alt=\"" . get_the_title() . "\"></a>\n".
"</div>\n";
elseif (catch_that_image()){ 
echo
"<div class=\"featured_image\">\n".
"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width10 . "\" height=\"" . $f_img_height10 . "\" alt=\"" . get_the_title() . "\"></a>\n".
"</div>\n"; 
} 
/*featured image ends here*/
?>
</div>
<div class="recent_cnt">
<time datetime="<?php the_time('c'); ?>" itemprop="datePublished" class='date'><?php the_time('M jS, Y') ?></time>
<h4><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a></h4>
</div>
</div>
<?php
endwhile;
wp_reset_query(); 
?>
</div>
<?php
}
?>
</div>



<div class='footer_widget recent_comments'>
<div class="line_title">
<h3><?php echo genesism_option('recent_comments_title'); ?></h3>
<div class="sep"></div>
</div>
<?php 
global $wpdb;
$query = "SELECT * from $wpdb->comments WHERE comment_approved= '1'
ORDER BY comment_date DESC LIMIT 0 ,3";
$comments = $wpdb->get_results($query);

if ($comments) {

foreach ($comments as $comment) {
$url = '<a href="'. get_permalink($comment->comment_post_ID).'#comment-'.$comment->comment_ID .'" title="'.$comment->comment_author .' | '.get_the_title($comment->comment_post_ID).'">';
$img_w=''. $options['width'] .'';
echo '<div class="avt_rec">';
echo '<div class="avt_img">';
echo $url;
echo get_avatar( $comment->comment_author_email, $img_w);
echo '</a></div>';

echo '<div class="rec_aut">';
echo $url;
echo $comment->comment_author;
echo '<br>';
echo get_the_title($comment->comment_post_ID);
echo '</a></div>';
echo '</div>';
}
}
?>
</div>



<div class='footer_widget footer_optin'>
<?php if(genesism_get_option('footer_optin')){
?>
<div class="line_title">
<h3><?php echo genesism_option('footer_optin_header'); ?></h3>
<div class="sep"></div>
</div>
<div class="footer_optin_section">
<p><?php echo genesism_option('optin_cnt'); ?></p>
<div class="footer_optin_cnt">
<form method="post" class="form" action="<?php echo stripslashes(genesism_option('optin_url2')); ?>" target="_blank">
<div class="names"><input class="email" type="text" name="<?php echo stripslashes(genesism_option('optin_email2')); ?>" placeholder="<?php echo stripslashes(genesism_option('email_text')); ?>"><div class='mails'></div></div>
<?php echo stripslashes(genesism_option('optin_hidden2')); ?>
<input name="submit" class="submit" type="submit" value="Sign Up"/>
</form>	
</div>
</div>
<?php 
}
?>
</div>

</div>
	
    </div><!-- end .wrap -->
</div><!-- end #footer-widgets -->