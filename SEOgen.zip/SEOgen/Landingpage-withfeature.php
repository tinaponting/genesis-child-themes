<?php
/*
Template Name: Landing Page with Feature
*/


// Add custom body class to the head
add_filter( 'body_class', 'metro_add_body_class' );
function metro_add_body_class( $classes ) {
   $classes[] = 'landingwithheader';
   return $classes;
}

remove_action( 'genesis_sidebar_alt', 'genesis_do_sidebar_alt' );
remove_action( 'genesis_sidebar', 'genesis_do_sidebar' );
remove_action ('genesis_before_sidebar_widget_area','sidebar_social_follow',1);
remove_action ('genesis_before_sidebar_widget_area','sider_advertisement',2);
remove_action ('genesis_before_sidebar_widget_area','fifth_catgory',3);
remove_action ('genesis_before_sidebar_widget_area','sidebar_optin',4);
remove_action ('genesis_before_sidebar_widget_area','last_updated_post',5);
remove_action ('genesis_before_sidebar_widget_area','trending_post',6);


add_action('genesis_before_content','landing_page_optin',1);
function landing_page_optin(){
if(genesism_get_option('landing_optin')){
?>
<div class="landing_page_optin">
	<div class="landing_page_optin_section">
		<div class="landing_page_left">
		<?php echo (genesism_option('landing_page_video')); ?>
		
		</div>
		<div class="landing_page_right">
			<h3><?php echo genesism_option('landing_optin_header'); ?></h3>
			<p><?php echo genesism_option('landing_optin_cnt'); ?></p>
			<div class="landing_optin_cnt">
				<form method="post" class="form" action="<?php echo stripslashes(genesism_option('optin_url1')); ?>" target="_blank">
					<div class="names"><input class="name" type="text" name="<?php echo stripslashes(genesism_option('optin_name1')); ?>" placeholder="<?php echo stripslashes(genesism_option('name_text1')); ?>"><div class='admins'></div></div>
					<div class="names"><input class="email" type="text" name="<?php echo stripslashes(genesism_option('optin_email1')); ?>" placeholder="<?php echo stripslashes(genesism_option('email_text1')); ?>"><div class='mails'></div></div>
					<?php echo stripslashes(genesism_option('optin_hidden1')); ?>
					<input name="submit" class="submit" type="submit" value="<?php echo stripslashes(genesism_option('submit_text1')); ?>"/>
				</form>	
			</div>
		</div>
	</div>
</div>
<?php 
}
}

add_action('genesis_before_content','landing_page_feature',2);
function landing_page_feature(){
if(genesism_get_option('landing_feature')){
?>
<div class="landing_page_feature"  >

	<h3><?php echo genesism_option('landing_feature_title'); ?></h3>
	
	<div class="landing_page_feature_section">

		<div class="column1">
			<img alt="<?php echo genesism_option('landing_feature_subtitle1'); ?>" src="<?php echo genesism_option('landing_feature_img1'); ?>"/>
			<h3><a href="<?php echo genesism_option('landing_feature_readtxt_link1'); ?>"><?php echo genesism_option('landing_feature_subtitle1'); ?></a></h3>
			<p><?php echo genesism_option('landing_feature_cnt1'); ?></p>
			<a class="read_more_btn" href="<?php echo genesism_option('landing_feature_readtxt_link1'); ?>"><?php echo genesism_option('landing_feature_read_txt1'); ?></a>
		</div>

		<div class="column1 column2">
			<img alt="<?php echo genesism_option('landing_feature_subtitle2'); ?>" src="<?php echo genesism_option('landing_feature_img2'); ?>"/>
			<h3><a href="<?php echo genesism_option('landing_feature_readtxt_link2'); ?>"><?php echo genesism_option('landing_feature_subtitle2'); ?></a></h3>
			<p><?php echo genesism_option('landing_feature_cnt2'); ?></p>
			<a class="read_more_btn" href="<?php echo genesism_option('landing_feature_readtxt_link2'); ?>"><?php echo genesism_option('landing_feature_read_txt2'); ?></a>
		</div>

		<div class="column1">
			<img alt="<?php echo genesism_option('landing_feature_subtitle3'); ?>" src="<?php echo genesism_option('landing_feature_img3'); ?>"/>
			<h3><a href="<?php echo genesism_option('landing_feature_readtxt_link3'); ?>"><?php echo genesism_option('landing_feature_subtitle3'); ?></a></h3>
			<p><?php echo genesism_option('landing_feature_cnt3'); ?></p>
			<a class="read_more_btn" href="<?php echo genesism_option('landing_feature_readtxt_link3'); ?>"><?php echo genesism_option('landing_feature_read_txt3'); ?></a>
		</div>

		<div class="column1 last">
			<img alt="<?php echo genesism_option('landing_feature_subtitle4'); ?>" src="<?php echo genesism_option('landing_feature_img4'); ?>"/>
			<h3><a href="<?php echo genesism_option('landing_feature_readtxt_link4'); ?>"><?php echo genesism_option('landing_feature_subtitle4'); ?></a></h3>
			<p><?php echo genesism_option('landing_feature_cnt4'); ?></p>
			<a class="read_more_btn" href="<?php echo genesism_option('landing_feature_readtxt_link4'); ?>"><?php echo genesism_option('landing_feature_read_txt4'); ?></a>
		</div>

	</div>
</div>
<?php 
}
}


genesis();