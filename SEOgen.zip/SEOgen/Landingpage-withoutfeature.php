<?php
/*
Template Name: Landing Page without Feature
*/


// Add custom body class to the head
add_filter( 'body_class', 'metro_add_body_class' );
function metro_add_body_class( $classes ) {
   $classes[] = 'landingwithheader';
   return $classes;
}

remove_action( 'genesis_sidebar_alt', 'genesis_do_sidebar_alt' );
remove_action( 'genesis_sidebar', 'genesis_do_sidebar' );
remove_action ('genesis_before_sidebar_widget_area','sidebar_social_follow',1);
remove_action ('genesis_before_sidebar_widget_area','sider_advertisement',2);
remove_action ('genesis_before_sidebar_widget_area','fifth_catgory',3);
remove_action ('genesis_before_sidebar_widget_area','sidebar_optin',4);
remove_action ('genesis_before_sidebar_widget_area','last_updated_post',5);
remove_action ('genesis_before_sidebar_widget_area','trending_post',6);


add_action('genesis_before_content','landing_page_optin',1);
function landing_page_optin(){
if(genesism_get_option('landing_optin')){
?>
<div class="landing_page_optin">
	<div class="landing_page_optin_section">
		<div class="landing_page_left">
		<?php echo (genesism_option('landing_page_video')); ?>
		
		</div>
		<div class="landing_page_right">
			<h3><?php echo genesism_option('landing_optin_header'); ?></h3>
			<p><?php echo genesism_option('landing_optin_cnt'); ?></p>
			<div class="landing_optin_cnt">
				<form method="post" class="form" action="<?php echo stripslashes(genesism_option('optin_url3')); ?>" target="_blank">
					<div class="names"><input class="name" type="text" name="<?php echo stripslashes(genesism_option('optin_name3')); ?>" placeholder="<?php echo stripslashes(genesism_option('name_text1')); ?>"><div class='admins'></div></div>
					<div class="names"><input class="email" type="text" name="<?php echo stripslashes(genesism_option('optin_email3')); ?>" placeholder="<?php echo stripslashes(genesism_option('email_text1')); ?>"><div class='mails'></div></div>
					<?php echo stripslashes(genesism_option('optin_hidden3')); ?>
					<input name="submit" class="submit" type="submit" value="<?php echo stripslashes(genesism_option('submit_text1')); ?>"/>
				</form>	
			</div>
		</div>
	</div>
</div>
<?php 
}
}


genesis();