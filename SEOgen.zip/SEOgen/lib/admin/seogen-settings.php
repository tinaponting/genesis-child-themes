<?php

/**
 * This function registers the default values for genesis theme settings
 */
 
function genesism_theme_settings_defaults() {
$defaults = array( // define our defaults
'style' => 'default',
'custom' => 0,
'shortcodes-css' => 1,
'header'=>1,
'header_text'=>'http://seogen.genesislovers.com/wp-content/uploads/2016/02/logo.png',
'top_menu'=>1,
'top_ad'=>1,
'top_ad_img'=>'<img alt="Top Ad" src ="http://seogen.genesislovers.com/wp-content/uploads/2016/02/adtop.png"/>',
'bottom_menu'=>1,
'breaking_news'=>1,
'breaking_news_text'=>'Top News',
'search_box'=>1,
'search_text'=>'Search Here...',
'sidebar_optin'=>1,
'optin_url'=>'#',
'optin_header'=>'Subscribe Me',
'name_text'=>'Your Name...',
'email_text'=>'Your Email ...',
'submit_text'=>'Sign Up',
'footer_aboutus'=>1,
'aboutus_title'=>'About US',
'aboutus_cnt'=>'Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
'recent_news'=>1,
'recent_news_title'=>'Recent News',
'recent_comments'=>1,
'recent_comments_title'=>'Recent Comments',
'footer_optin'=>1,
'optin_url2'=>'#',
'footer_optin_header'=>'Subscribe me',
'optin_cnt'=>'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis tincidunt non nunc non luctus.',
'email_text'=>'Your Email ...',
'submit_text'=>'Sign Up',
'read_more'=>1,
'read_text'=>'Read More',
'postadcheck'=>1,
'float'=>'right',
'postad'=>'<img alt="Single Content Ad" src="http://seogen.genesislovers.com/wp-content/uploads/2016/01/postad.png"/>',
'social_post_button'=>1,
'sharehead'=>'Sharing',
'landing_optin'=>1,
'optin_url3'=>'#',
'landing_optin_header'=>'Lorem Ipsum is simply dummy',
'landing_optin_cnt'=>'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s.',
'name_text1'=>'Your Name...',
'email_text1'=>'Your Email...',
'submit_text1'=>'Sign Up',
'landing_page_video'=>'<iframe width="560" height="315" src="https://www.youtube.com/embed/kCUrfTZi9L0" allowfullscreen></iframe>',
'landing_feature'=>1,
'landing_feature_title'=>'Landing Page Feature',
'landing_feature_img1'=>'http://seogen.genesislovers.com/wp-content/uploads/2016/01/landingfeature1.png',
'landing_feature_subtitle1'=>'Lorem Ipsum is simply dummy text',
'landing_feature_cnt1'=>'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s.',
'landing_feature_read_txt1'=>'View More',
'landing_feature_img2'=>'http://seogen.genesislovers.com/wp-content/uploads/2016/01/landingfeature2.png',
'landing_feature_subtitle2'=>'Printing and typesetting industry',
'landing_feature_cnt2'=>'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s.',
'landing_feature_read_txt2'=>'View More',
'landing_feature_img3'=>'http://seogen.genesislovers.com/wp-content/uploads/2016/01/landingfeature3.png',
'landing_feature_subtitle3'=>'Industry’s standard dummy text',
'landing_feature_cnt3'=>'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s.',
'landing_feature_read_txt3'=>'View More',
'landing_feature_img4'=>'http://seogen.genesislovers.com/wp-content/uploads/2016/01/landingfeature4.png',
'landing_feature_subtitle4'=>'Lorem Ipsum is simply dummy text',
'landing_feature_cnt4'=>'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s.',
'landing_feature_read_txt4'=>'View More',
'footer1' => 1,

'f_img_width'=>'254',
'f_img_height'=>'168',
'footer_text' => 'Copyright &copy;'.date('Y') .  ' <a href="'. get_bloginfo('url') .'">' . get_bloginfo('name') . '</a>'
	
	);
	
	return apply_filters('genesism_theme_settings_defaults', $defaults);

}



function genesism_theme_settings_boxes() {
	global $_genesism_theme_settings_pagehook;
	
	if (function_exists('add_screen_option')) { add_screen_option('layout_columns', array('max' => 2, 'default' => 2) ); }

add_meta_box('genesism-theme-settings-version', __('Theme Information', 'genesism'), 'genesism_theme_settings_info_box', $_genesism_theme_settings_pagehook, 'normal');	
 }
  
 function genesism_theme_settings_info_box() { 
?>

<p class="bolder"><strong><?php echo CHILD_THEME_NAME; ?></strong> by <a href="http://genesislovers.com">genesislovers.com</a></p>
<p><strong>
  <?php _e('Version:', 'genesism'); ?>
  </strong> <?php echo CHILD_THEME_VERSION; ?> <strong>
   </p>
<p><span class="description">
  <?php _e('For support, please visit <a href="http://genesislovers.com/contact-us/">http://genesislovers.com/contact-us/</a>', 'genesism'); ?>
  </span></p>

<div id="tabs">
	<ul>
		<li><a href="#tabs-1"><?php _e("Header Logo", 'genesism'); ?></a></li>
		<li><a href="#tabs-2"><?php _e("Top Menu", 'genesism'); ?></a></li>
		<li><a href="#tabs-3"><?php _e("Header Advertisement", 'genesism'); ?></a></li>
		<li><a href="#tabs-4"><?php _e("Bottom Menu", 'genesism'); ?></a></li>
		<li><a href="#tabs-5"><?php _e("Breaking News", 'genesism'); ?></a></li>
		<li><a href="#tabs-6"><?php _e("Search Box", 'genesism'); ?></a></li>
		<li><a href="#tabs-7"><?php _e("Header Social follow", 'genesism'); ?></a></li>		
		<li><a href="#tabs-8"><?php _e("Sidebar Social follow", 'genesism'); ?></a></li>		
		<li><a href="#tabs-9"><?php _e("Sidebar Optin Box", 'genesism'); ?></a></li>		
		<li><a href="#tabs-10"><?php _e("Footer AboutUs & Social Follow", 'genesism'); ?></a></li>
		<li><a href="#tabs-11"><?php _e("Recent News Box", 'genesism'); ?></a></li>
		<li><a href="#tabs-12"><?php _e("Recent Comments Box", 'genesism'); ?></a></li>
		<li><a href="#tabs-13"><?php _e("Footer Optin Box", 'genesism'); ?></a></li>
		<li><a href="#tabs-14"><?php _e("Feature image on Blog Post", 'genesism'); ?></a></li>
		<li><a href="#tabs-15"><?php _e("Read More Box", 'genesism'); ?></a></li>
		<li><a href="#tabs-16"><?php _e("Post Top Advertisement", 'genesism'); ?></a></li>
		<li><a href="#tabs-17"><?php _e("Post Social share", 'genesism'); ?></a></li>		
		<li><a href="#tabs-18"><?php _e("Landing Page Optin", 'genesism'); ?></a></li>
		<li><a href="#tabs-19"><?php _e("Landing Page Feature", 'genesism'); ?></a></li>		
		<li><a href="#tabs-20"><?php _e("Footer Text section", 'genesism'); ?></a></li>
		<li><a href="#tabs-21"><?php _e("Custom CSS", 'genesism'); ?></a></li>
	</ul>
	<div id="tabs-1">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[header]" id="<?php echo SEOGEN_SETTINGS_FIELD; ?>[header]" value="1" <?php checked(1, genesism_get_option('header')); ?> />
				<label for="<?php echo SEOGEN_SETTINGS_FIELD; ?>[header]">
				<?php _e("Enable Header Logo", 'genesism'); ?>
				</label>
			</li>
				<li class="second_list">
				<label>Enter the Logo image url here</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[header_text]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('header_text') ); ?></textarea>
			</li>
		</ul>
	</div>
	<div id="tabs-2">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[top_menu]" id="<?php echo SEOGEN_SETTINGS_FIELD; ?>[top_menu]" value="1" <?php checked(1, genesism_get_option('top_menu')); ?> />
				<label for="<?php echo SEOGEN_SETTINGS_FIELD; ?>[top_menu]">
				<?php _e("Enable Top Menu Section", 'genesism'); ?>
				</label>
			</li>
		</ul>
	</div>
	<div id="tabs-3">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[top_ad]" id="<?php echo SEOGEN_SETTINGS_FIELD; ?>[top_ad]" value="1" <?php checked(1, genesism_get_option('top_ad')); ?> />
				<label for="<?php echo SEOGEN_SETTINGS_FIELD; ?>[top_ad]">
				<?php _e("Enable Header Advertisement", 'genesism'); ?>
				</label>
			</li>
				<li class="second_list">
				<label>Enter the Header Advertisement URL Link here</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[top_ad_img]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('top_ad_img') ); ?></textarea>
			</li>
		</ul>
	</div>
	<div id="tabs-4">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[bottom_menu]" id="<?php echo SEOGEN_SETTINGS_FIELD; ?>[bottom_menu]" value="1" <?php checked(1, genesism_get_option('bottom_menu')); ?> />
				<label for="<?php echo SEOGEN_SETTINGS_FIELD; ?>[bottom_menu]">
				<?php _e("Enable Bottom Menu Section", 'genesism'); ?>
				</label>
			</li>
		</ul>
	</div>
	<div id="tabs-5">
		 <ul>
			<li class="first_list chkbox">
			  <input type="checkbox" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[breaking_news]" id="<?php echo SEOGEN_SETTINGS_FIELD; ?>[breaking_news]" value="1" <?php checked(1, genesism_get_option('breaking_news')); ?> />
			   <label for="<?php echo SEOGEN_SETTINGS_FIELD; ?>[breaking_news]">
			  <?php _e("Enable Breaking News Box", 'genesism'); ?>
			 </label>
			</li>
			 <li class="second_list">
			  <label>Enter the Breaking News Title here</label>
			  <textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[breaking_news_text]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('breaking_news_text') ); ?></textarea>
			</li>
		</ul>
	</div>
	
	<div id="tabs-6">
		 <ul>
			<li class="first_list chkbox">
			  <input type="checkbox" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[search_box]" id="<?php echo SEOGEN_SETTINGS_FIELD; ?>[search_box]" value="1" <?php checked(1, genesism_get_option('search_box')); ?> />
			   <label for="<?php echo SEOGEN_SETTINGS_FIELD; ?>[search_box]">
			  <?php _e("Enable Search Box", 'genesism'); ?>
			 </label>
			</li>
			 <li class="second_list">
			  <label>Enter the Search Place holder Text here</label>
			  <textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[search_text]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('search_text') ); ?></textarea>
			</li>
		</ul>
	</div>
	
	<div id="tabs-7">
		<ul>
			
			<li class="second_list"><label>Paste Your Facebook URL Link</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[facebook_text2]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option(facebook_text2) ); ?></textarea> 
			</li>
			<li class="second_list"><label>Paste Your Twitter URL Link</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[twitter_text2]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('twitter_text2') ); ?></textarea> 
			</li>
			<li class="second_list"><label>Paste Your Googleplus URL Link</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[googleplus_text2]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('googleplus_text2') ); ?></textarea> 
			</li>
			<li class="second_list"><label>Paste Your Pinterest URL Link</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[pinterest_text2]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('pinterest_text2') ); ?></textarea>
			</li>
			<li class="second_list"><label>Paste Your Linkedin URL Link</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[linkedin_text2]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('linkedin_text2') ); ?></textarea> 
			</li>
			<li class="second_list"><label>Paste Your Youtube URL Link</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[youtube_text2]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('youtube_text2') ); ?></textarea>
			</li>
			<li class="second_list"><label>Paste Your Dribbble URL Link</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[dribbble_text2]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('dribbble_text2') ); ?></textarea>
			</li>
			<li class="second_list"><label>Paste Your Flickr URL Link</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[flickr_text2]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('flickr_text2') ); ?></textarea>
			</li>
			<li class="second_list"><label>Paste Your Vimeo URL Link</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[vimeo_text2]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('vimeo_text2') ); ?></textarea>
			</li>
			<li class="second_list"><label>Paste Your Rssfeed URL Link</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[rssfeed_text2]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('rssfeed_text2') ); ?></textarea>
			</li>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[header_social]" id="<?php echo SEOGEN_SETTINGS_FIELD; ?>[header_social]" value="1" <?php checked(1, genesism_get_option(header_social)); ?> />
				<label for="<?php echo SEOGEN_SETTINGS_FIELD; ?>[header_social]">
				<?php _e("Disable Social follow Icons", 'genesism'); ?>
				</label>
			</li>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[fb_check]" id="<?php echo SEOGEN_SETTINGS_FIELD; ?>[fb_check]" value="1" <?php checked(1, genesism_get_option(fb_check)); ?> />
				<label for="<?php echo SEOGEN_SETTINGS_FIELD; ?>[fb_check]">
				<?php _e("Disable Facebook Icon", 'genesism'); ?>
				</label>
			</li>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[tw_check]" id="<?php echo SEOGEN_SETTINGS_FIELD; ?>[tw_check]" value="1" <?php checked(1, genesism_get_option(tw_check)); ?> />
				<label for="<?php echo SEOGEN_SETTINGS_FIELD; ?>[tw_check]">
				<?php _e("Disable Twitter Icon", 'genesism'); ?>
				</label>
			</li>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[gp_check]" id="<?php echo SEOGEN_SETTINGS_FIELD; ?>[gp_check]" value="1" <?php checked(1, genesism_get_option(gp_check)); ?> />
				<label for="<?php echo SEOGEN_SETTINGS_FIELD; ?>[gp_check]">
				<?php _e("Disable Googleplus Icon", 'genesism'); ?>
				</label>
			</li>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[pin_check]" id="<?php echo SEOGEN_SETTINGS_FIELD; ?>[pin_check]" value="1" <?php checked(1, genesism_get_option(pin_check)); ?> />
				<label for="<?php echo SEOGEN_SETTINGS_FIELD; ?>[pin_check]">
				<?php _e("Disable Pinterest Icon", 'genesism'); ?>
				</label>
			</li>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[lin_check]" id="<?php echo SEOGEN_SETTINGS_FIELD; ?>[lin_check]" value="1" <?php checked(1, genesism_get_option(lin_check)); ?> />
				<label for="<?php echo SEOGEN_SETTINGS_FIELD; ?>[lin_check]">
				<?php _e("Disable Linkedin Icon", 'genesism'); ?>
				</label>
			</li>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[yt_check]" id="<?php echo SEOGEN_SETTINGS_FIELD; ?>[yt_check]" value="1" <?php checked(1, genesism_get_option(yt_check)); ?> />
				<label for="<?php echo SEOGEN_SETTINGS_FIELD; ?>[yt_check]">
				<?php _e("Disable Youtube Icon", 'genesism'); ?>
				</label>
			</li>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[dri_check]" id="<?php echo SEOGEN_SETTINGS_FIELD; ?>[dri_check]" value="1" <?php checked(1, genesism_get_option(dri_check)); ?> />
				<label for="<?php echo SEOGEN_SETTINGS_FIELD; ?>[dri_check]">
				<?php _e("Disable Dribbble Icon", 'genesism'); ?>
				</label>
			</li>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[flkr_check]" id="<?php echo SEOGEN_SETTINGS_FIELD; ?>[flkr_check]" value="1" <?php checked(1, genesism_get_option(flkr_check)); ?> />
				<label for="<?php echo SEOGEN_SETTINGS_FIELD; ?>[flkr_check]">
				<?php _e("Disable Flickr Icon", 'genesism'); ?>
				</label>
			</li>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[vim_check]" id="<?php echo SEOGEN_SETTINGS_FIELD; ?>[vim_check]" value="1" <?php checked(1, genesism_get_option(vim_check)); ?> />
				<label for="<?php echo SEOGEN_SETTINGS_FIELD; ?>[vim_check]">
				<?php _e("Disable Vimeo Icon", 'genesism'); ?>
				</label>
			</li>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[rss_check]" id="<?php echo SEOGEN_SETTINGS_FIELD; ?>[rss_check]" value="1" <?php checked(1, genesism_get_option(rss_check)); ?> />
				<label for="<?php echo SEOGEN_SETTINGS_FIELD; ?>[rss_check]">
				<?php _e("Disable Rssfeed Icon", 'genesism'); ?>
				</label>
			</li>
			
		</ul>			
	</div>
	
	
	<div id="tabs-8">
		<ul>
			
			<li class="second_list"><label>Enter the Sidebar Social Follow Title here</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[facebook_text]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('facebook_text') ); ?></textarea> 
			</li>
			<li class="second_list"><label>Here to Paste Your Social Facebook URL Link</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[facebook_text]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('facebook_text') ); ?></textarea> 
			</li>
			<li class="second_list"><label>Here to Paste Your Social Twitter URL Link</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[twitter_text]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('twitter_text') ); ?></textarea> 
			</li>
			<li class="second_list"><label>Here to Paste Your Social Googleplus URL Link </label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[googleplus_text]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('googleplus_text') ); ?></textarea> 
			 </li>
			<li class="second_list"><label>Here to Paste Your Social Rssfeed URL Link </label>
			   <td><textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[rssfeed_text]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('rssfeed_text') ); ?></textarea> 
			</li>
			<li class="second_list"><label>Here to Paste Your Social Pinterest URL Link </label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[pinterest_text]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('pinterest_text') ); ?></textarea>
			</li>
			<li class="second_list"><label>Here to Paste Your Social Linkedin URL Link </label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[linkedin_text]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('linkedin_text') ); ?></textarea> 
			</li>
			<li class="second_list"><label>Here to Paste Your Social Dribbble URL Link </label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[dribbble_text]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('dribbble_text') ); ?></textarea>
			</li>
			<li class="second_list"><label>Here to Paste Your Social Youtube URL Link </label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[youtube_text]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('youtube_text') ); ?></textarea>
			</li>
			<li class="second_list"><label>Here to Paste Your Social Vimeo URL Link </label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[vimeo_text]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('vimeo_text') ); ?></textarea>
			</li>
			<li class="second_list"><label>Here to Paste Your Social Tumblr URL Link </label>
			 <textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[tumblr_text]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('tumblr_text') ); ?></textarea>
			</li>
			<li class="second_list"><label>Here to Paste Your Social Flickr URL Link </label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[flickr_text]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('flickr_text') ); ?></textarea>
			</li>
			<li class="second_list"><label>Here to Paste Your Social Instagram URL Link </label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[instagram_text]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('instagram_text') ); ?></textarea>
			</li>
			
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[sidebar_social]" id="<?php echo SEOGEN_SETTINGS_FIELD; ?>[sidebar_social]" value="1" <?php checked(1, genesism_get_option(sidebar_social)); ?> />
				<label for="<?php echo SEOGEN_SETTINGS_FIELD; ?>[sidebar_social]">
				<?php _e("Disable Sidebar Social follow Icons", 'genesism'); ?>
				</label>
			</li>
			
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[fb_check1]" id="<?php echo SEOGEN_SETTINGS_FIELD; ?>[fb_check1]" value="1" <?php checked(1, genesism_get_option(fb_check1)); ?> />
				<label for="<?php echo SEOGEN_SETTINGS_FIELD; ?>[fb_check1]">
				<?php _e("Disable Facebook Icon", 'genesism'); ?>
				</label>
			</li>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[tw_check1]" id="<?php echo SEOGEN_SETTINGS_FIELD; ?>[tw_check1]" value="1" <?php checked(1, genesism_get_option(tw_check1)); ?> />
				<label for="<?php echo SEOGEN_SETTINGS_FIELD; ?>[tw_check1]">
				<?php _e("Disable Twitter Icon", 'genesism'); ?>
				</label>
			</li>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[gp_check1]" id="<?php echo SEOGEN_SETTINGS_FIELD; ?>[gp_check1]" value="1" <?php checked(1, genesism_get_option(gp_check1)); ?> />
				<label for="<?php echo SEOGEN_SETTINGS_FIELD; ?>[gp_check1]">
				<?php _e("Disable Googleplus Icon", 'genesism'); ?>
				</label>
			</li>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[rss_check1]" id="<?php echo SEOGEN_SETTINGS_FIELD; ?>[rss_check1]" value="1" <?php checked(1, genesism_get_option(rss_check1)); ?> />
				<label for="<?php echo SEOGEN_SETTINGS_FIELD; ?>[rss_check1]">
				<?php _e("Disable Rssfeed Icon", 'genesism'); ?>
				</label>
			</li>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[pin_check1]" id="<?php echo SEOGEN_SETTINGS_FIELD; ?>[pin_check1]" value="1" <?php checked(1, genesism_get_option(pin_check1)); ?> />
				<label for="<?php echo SEOGEN_SETTINGS_FIELD; ?>[pin_check1]">
				<?php _e("Disable Pinterest Icon", 'genesism'); ?>
				</label>
			</li>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[lin_check1]" id="<?php echo SEOGEN_SETTINGS_FIELD; ?>[lin_check1]" value="1" <?php checked(1, genesism_get_option(lin_check1)); ?> />
				<label for="<?php echo SEOGEN_SETTINGS_FIELD; ?>[lin_check1]">
				<?php _e("Disable Linkedin Icon", 'genesism'); ?>
				</label>
			</li>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[dri_check1]" id="<?php echo SEOGEN_SETTINGS_FIELD; ?>[dri_check1]" value="1" <?php checked(1, genesism_get_option(dri_check1)); ?> />
				<label for="<?php echo SEOGEN_SETTINGS_FIELD; ?>[dri_check1]">
				<?php _e("Disable Dribbble Icon", 'genesism'); ?>
				</label>
			</li>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[yt_check1]" id="<?php echo SEOGEN_SETTINGS_FIELD; ?>[yt_check1]" value="1" <?php checked(1, genesism_get_option(yt_check1)); ?> />
				<label for="<?php echo SEOGEN_SETTINGS_FIELD; ?>[yt_check1]">
				<?php _e("Disable Youtube Icon", 'genesism'); ?>
				</label>
			</li>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[vim_check1]" id="<?php echo SEOGEN_SETTINGS_FIELD; ?>[vim_check1]" value="1" <?php checked(1, genesism_get_option(vim_check1)); ?> />
				<label for="<?php echo SEOGEN_SETTINGS_FIELD; ?>[vim_check1]">
				<?php _e("Disable Vimeo Icon", 'genesism'); ?>
				</label>
			</li>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[tum_check1]" id="<?php echo SEOGEN_SETTINGS_FIELD; ?>[tum_check1]" value="1" <?php checked(1, genesism_get_option(tum_check1)); ?> />
				<label for="<?php echo SEOGEN_SETTINGS_FIELD; ?>[tum_check1]">
				<?php _e("Disable Tumblr Icon", 'genesism'); ?>
				</label>
			</li>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[fli_check1]" id="<?php echo SEOGEN_SETTINGS_FIELD; ?>[fli_check1]" value="1" <?php checked(1, genesism_get_option(fli_check1)); ?> />
				<label for="<?php echo SEOGEN_SETTINGS_FIELD; ?>[fli_check1]">
				<?php _e("Disable Flickr Icon", 'genesism'); ?>
				</label>
			</li>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[ins_check1]" id="<?php echo SEOGEN_SETTINGS_FIELD; ?>[ins_check1]" value="1" <?php checked(1, genesism_get_option(ins_check1)); ?> />
				<label for="<?php echo SEOGEN_SETTINGS_FIELD; ?>[ins_check1]">
				<?php _e("Disable Instagram Icon", 'genesism'); ?>
				</label>
			</li>

		</ul>
	</div>
	
	
	<div id="tabs-9">
		 <ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[sidebar_optin]" id="<?php echo SEOGEN_SETTINGS_FIELD; ?>[sidebar_optin]" value="1" <?php checked(1, genesism_get_option('sidebar_optin')); ?> />
				<label for="<?php echo SEOGEN_SETTINGS_FIELD; ?>[sidebar_optin]">
				<?php _e("Enable Sidebar Optin Box", 'genesism'); ?>
				</label>
			</li>
			<li class="second_list">
				<label>Paste your optin code and Press Tab Button</label>
				<textarea id="optin_code" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[optin_code]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_code') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form name</label>
				<textarea id="optin_name" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[optin_name]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('optin_name') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form Email</label>
				<textarea id="optin_email" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[optin_email]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('optin_email') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form action url</label>
				<textarea id="optin_url" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[optin_url]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_url') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Hidden fields</label>
				<textarea id="optin_hidden" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[optin_hidden]" rows="10" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_hidden') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Enter your Optin Header Text</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[optin_header]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('optin_header') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change your Enter your name text here</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[name_text]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('name_text') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change your Enter your email text here</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[email_text]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('email_text') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change your Subscribe me button text</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[submit_text]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('submit_text') ); ?></textarea>
			</li>
		  </ul>
<script type="text/javascript">
var j = jQuery.noConflict();
j(document).ready(function(){
j("#optin_code").blur(function(){
var txt=j(this).val();
if(txt=="")
{
j("#optin_url").val("");
j("#optin_hidden").val("");
j("#optin_name").val("");
j("#optin_email").val("");
return false;
}
var pos1=0;
var pos2=0;
var i=1;
var hidden="";
while(1)
{
pos1=txt.indexOf("<input",pos1);
if(pos1<0) break;
pos2=txt.indexOf(">",pos1+1);
var text=txt.substr(pos1,pos2-pos1);
pp=text.indexOf('type="hidden"');
pp1=text.indexOf('type="submit"');
if(pp>0)
{
hidden+=text+">";
}
if(pp<0 && pp1<0){
pp=text.indexOf('name="');
pp=pp+6;
pp1=text.indexOf('"',pp+1);
var tt=text.substr(pp,pp1-pp);
if(i==1) j("#optin_name").val(tt);
else j("#optin_email").val(tt);
i++;
}
pos1=pos2+1;
}
pos1=txt.indexOf("<form",0);
pos2=txt.indexOf(">",pos1+1);
text=txt.substr(pos1,pos2-pos1);
pp=text.indexOf('action="');
pp=pp+8;
pp1=text.indexOf('"',pp+1);
var tt=text.substr(pp,pp1-pp);
j("#optin_url").val(tt);
j("#optin_hidden").val(hidden);
});
});
</script>  
	</div>
	
	<div id="tabs-10">
		<ul>
			<li class="first_list chkbox">
			  <input type="checkbox" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[footer_aboutus]" id="<?php echo SEOGEN_SETTINGS_FIELD; ?>[footer_aboutus]" value="1" <?php checked(1, genesism_get_option('footer_aboutus')); ?> />
			   <label for="<?php echo SEOGEN_SETTINGS_FIELD; ?>[footer_aboutus]">
			  <?php _e("Enable Footer About Us and Social Follow Box", 'genesism'); ?>
			 </label>
			</li>
			 <li class="second_list">
			  <label>Change Your Footer About Us Title here</label>
			  <textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[aboutus_title]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('aboutus_title') ); ?></textarea>
			</li>
			<li class="second_list">
			  <label>Change Your Footer About Us Content here</label>
			  <textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[aboutus_cnt]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option(aboutus_cnt) ); ?></textarea>
			</li>
			<li class="second_list"><label>Here to Paste Your Social Facebook URL Link</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[facebook_text3]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('facebook_text3') ); ?></textarea> 
			</li>
			<li class="second_list"><label>Here to Paste Your Social Twitter URL Link</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[twitter_text3]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('twitter_text3') ); ?></textarea> 
			</li>
			<li class="second_list"><label>Here to Paste Your Social Googleplus URL Link </label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[googleplus_text3]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('googleplus_text3') ); ?></textarea> 
			 </li>
			<li class="second_list"><label>Here to Paste Your Social Pinterest URL Link </label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[pinterest_text3]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('pinterest_text3') ); ?></textarea>
			</li>
			<li class="second_list"><label>Here to Paste Your Social Linkedin URL Link </label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[linkedin_text3]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('linkedin_text3') ); ?></textarea> 
			</li>
			<li class="second_list"><label>Here to Paste Your Social Youtube URL Link </label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[youtube_text3]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('youtube_text3') ); ?></textarea> 
			</li>
			<li class="second_list"><label>Here to Paste Your Social Dribbble URL Link </label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[dribbble_text3]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('dribbble_text3') ); ?></textarea>
			</li>
			<li class="second_list"><label>Here to Paste Your Social Flickr URL Link </label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[flickr_text3]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('flickr_text3') ); ?></textarea>
			</li>
			
			<li class="first_list chkbox">
			  <input type="checkbox" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[footer_social]" id="<?php echo SEOGEN_SETTINGS_FIELD; ?>[footer_social]" value="1" <?php checked(1, genesism_get_option('footer_social')); ?> />
			   <label for="<?php echo SEOGEN_SETTINGS_FIELD; ?>[footer_social]">
			  <?php _e("Disable Footer Social Follow Icons", 'genesism'); ?>
			 </label>
			</li>
			<li class="first_list chkbox">
			  <input type="checkbox" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[fb_chech2]" id="<?php echo SEOGEN_SETTINGS_FIELD; ?>[fb_chech2]" value="1" <?php checked(1, genesism_get_option('fb_chech2')); ?> />
			   <label for="<?php echo SEOGEN_SETTINGS_FIELD; ?>[fb_chech2]">
			  <?php _e("Disable Facebook Icon", 'genesism'); ?>
			 </label>
			</li>
			<li class="first_list chkbox">
			  <input type="checkbox" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[tw_chech2]" id="<?php echo SEOGEN_SETTINGS_FIELD; ?>[tw_chech2]" value="1" <?php checked(1, genesism_get_option('tw_chech2')); ?> />
			   <label for="<?php echo SEOGEN_SETTINGS_FIELD; ?>[tw_chech2]">
			  <?php _e("Disable Twitter Icon", 'genesism'); ?>
			 </label>
			</li>
			<li class="first_list chkbox">
			  <input type="checkbox" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[gp_chech2]" id="<?php echo SEOGEN_SETTINGS_FIELD; ?>[gp_chech2]" value="1" <?php checked(1, genesism_get_option('gp_chech2')); ?> />
			   <label for="<?php echo SEOGEN_SETTINGS_FIELD; ?>[gp_chech2]">
			  <?php _e("Disable Googleplus Icon", 'genesism'); ?>
			 </label>
			</li>
			<li class="first_list chkbox">
			  <input type="checkbox" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[pin_chech2]" id="<?php echo SEOGEN_SETTINGS_FIELD; ?>[pin_chech2]" value="1" <?php checked(1, genesism_get_option('pin_chech2')); ?> />
			   <label for="<?php echo SEOGEN_SETTINGS_FIELD; ?>[pin_chech2]">
			  <?php _e("Disable Pinterest Icon", 'genesism'); ?>
			 </label>
			</li>
			<li class="first_list chkbox">
			  <input type="checkbox" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[lin_chech2]" id="<?php echo SEOGEN_SETTINGS_FIELD; ?>[lin_chech2]" value="1" <?php checked(1, genesism_get_option('lin_chech2')); ?> />
			   <label for="<?php echo SEOGEN_SETTINGS_FIELD; ?>[lin_chech2]">
			  <?php _e("Disable Linkedin Icon", 'genesism'); ?>
			 </label>
			</li>
			<li class="first_list chkbox">
			  <input type="checkbox" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[yt_chech2]" id="<?php echo SEOGEN_SETTINGS_FIELD; ?>[yt_chech2]" value="1" <?php checked(1, genesism_get_option('yt_chech2')); ?> />
			   <label for="<?php echo SEOGEN_SETTINGS_FIELD; ?>[yt_chech2]">
			  <?php _e("Disable Youtube Icon", 'genesism'); ?>
			 </label>
			</li>
			<li class="first_list chkbox">
			  <input type="checkbox" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[dri_chech2]" id="<?php echo SEOGEN_SETTINGS_FIELD; ?>[dri_chech2]" value="1" <?php checked(1, genesism_get_option('dri_chech2')); ?> />
			   <label for="<?php echo SEOGEN_SETTINGS_FIELD; ?>[dri_chech2]">
			  <?php _e("Disable Dribbble Icon", 'genesism'); ?>
			 </label>
			</li>
			<li class="first_list chkbox">
			  <input type="checkbox" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[fli_chech2]" id="<?php echo SEOGEN_SETTINGS_FIELD; ?>[fli_chech2]" value="1" <?php checked(1, genesism_get_option('fli_chech2')); ?> />
			   <label for="<?php echo SEOGEN_SETTINGS_FIELD; ?>[fli_chech2]">
			  <?php _e("Disable Flickr Icon", 'genesism'); ?>
			 </label>
			</li>
			
		  </ul>
	</div>
	
	<div id="tabs-11">
		<ul>
			<li class="first_list chkbox">
			  <input type="checkbox" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[recent_news]" id="<?php echo SEOGEN_SETTINGS_FIELD; ?>[recent_news]" value="1" <?php checked(1, genesism_get_option('recent_news')); ?> />
			   <label for="<?php echo SEOGEN_SETTINGS_FIELD; ?>[recent_news]">
			  <?php _e("Enable Recent News Box", 'genesism'); ?>
			 </label>
			</li>
			 <li class="second_list">
			  <label>Change Your Recent News Title here</label>
			  <textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[recent_news_title]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('recent_news_title') ); ?></textarea>
			</li>
		  </ul>
	</div>
	
	<div id="tabs-12">
		<ul>
			<li class="first_list chkbox">
			  <input type="checkbox" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[recent_comments]" id="<?php echo SEOGEN_SETTINGS_FIELD; ?>[recent_comments]" value="1" <?php checked(1, genesism_get_option('recent_comments')); ?> />
			   <label for="<?php echo SEOGEN_SETTINGS_FIELD; ?>[recent_comments]">
			  <?php _e("Enable Recent Comments Box", 'genesism'); ?>
			 </label>
			</li>
			 <li class="second_list">
			  <label>Change Your Recent Comments Title here</label>
			  <textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[recent_comments_title]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('recent_comments_title') ); ?></textarea>
			</li>
		 </ul>
	</div>
	
	<div id="tabs-13">
		<ul>
			<li class="first_list chkbox">
			  <input type="checkbox" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[footer_optin]" id="<?php echo SEOGEN_SETTINGS_FIELD; ?>[footer_optin]" value="1" <?php checked(1, genesism_get_option('footer_optin')); ?> />
			   <label for="<?php echo SEOGEN_SETTINGS_FIELD; ?>[footer_optin]">
			  <?php _e("Enable Footer Optin Box", 'genesism'); ?>
			 </label>
			</li>
			<li class="second_list">
				<label>Paste your optin code and Press Tab Button</label>
				<textarea id="optin_code2" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[optin_code2]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_code2') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form name</label>
				<textarea id="optin_name2" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[optin_name2]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('optin_name2') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form Email</label>
				<textarea id="optin_email2" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[optin_email2]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('optin_email2') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form action url</label>
				<textarea id="optin_url2" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[optin_url2]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_url2') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Hidden fields</label>
				<textarea id="optin_hidden2" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[optin_hidden]" rows="10" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_hidden') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Enter your Optin Header Text</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[footer_optin_header]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('footer_optin_header') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change your Optin Content here</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[optin_cnt]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_cnt') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change your Enter your email text here</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[email_text]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('email_text') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change your Subscribe me button text</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[submit_text]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('submit_text') ); ?></textarea>
			</li>
		  </ul>
<script type="text/javascript">
var j = jQuery.noConflict();
j(document).ready(function(){
j("#optin_code2").blur(function(){
var txt=j(this).val();
if(txt=="")
{
j("#optin_url2").val("");
j("#optin_hidden2").val("");
j("#optin_name2").val("");
j("#optin_email2").val("");
return false;
}
var pos1=0;
var pos2=0;
var i=1;
var hidden="";
while(1)
{
pos1=txt.indexOf("<input",pos1);
if(pos1<0) break;
pos2=txt.indexOf(">",pos1+1);
var text=txt.substr(pos1,pos2-pos1);
pp=text.indexOf('type="hidden"');
pp1=text.indexOf('type="submit"');
if(pp>0)
{
hidden+=text+">";
}
if(pp<0 && pp1<0){
pp=text.indexOf('name="');
pp=pp+6;
pp1=text.indexOf('"',pp+1);
var tt=text.substr(pp,pp1-pp);
if(i==1) j("#optin_name2").val(tt);
else j("#optin_email2").val(tt);
i++;
}
pos1=pos2+1;
}
pos1=txt.indexOf("<form",0);
pos2=txt.indexOf(">",pos1+1);
text=txt.substr(pos1,pos2-pos1);
pp=text.indexOf('action="');
pp=pp+8;
pp1=text.indexOf('"',pp+1);
var tt=text.substr(pp,pp1-pp);
j("#optin_url2").val(tt);
j("#optin_hidden2").val(hidden);
});
});
</script>  
	</div>
	<div id="tabs-14">
		<ul>
			<li class="second_list">
				<label>Enter the Blog Post feature image Width Size here</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[f_img_width]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('f_img_width') ); ?></textarea> 
			</li>
			<li class="second_list">
				<label>Enter the Blog Post feature image Height Size here</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[f_img_height]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('f_img_height') ); ?></textarea> 
			</li>
		</ul>
	</div>
	
	<div id="tabs-15">
		<ul>
			<li class="first_list chkbox">
			  <input type="checkbox" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[read_more]" id="<?php echo SEOGEN_SETTINGS_FIELD; ?>[read_more]" value="1" <?php checked(1, genesism_get_option('read_more')); ?> />
			   <label for="<?php echo SEOGEN_SETTINGS_FIELD; ?>[read_more]">
			  <?php _e("Enable Read More Box", 'genesism'); ?>
			 </label>
			</li>
			 <li class="second_list">
			  <label>Change Your Read More Text here</label>
			  <textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[read_text]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('read_text') ); ?></textarea>
			</li>
		</ul>
	</div>
	
	<div id="tabs-16">
		<ul>
			<li class="first_list chkbox">
			  <input type="checkbox" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[postadcheck]" id="<?php echo SEOGEN_SETTINGS_FIELD; ?>[postadcheck]" value="1" <?php checked(1, genesism_get_option('postadcheck')); ?> />
				<label for="<?php echo SEOGEN_SETTINGS_FIELD; ?>[postadcheck]">
				<?php _e("Enable postad section", 'genesism'); ?>
			  </label>
			</li>
			<li class="second_list">
				<label>Enter the ad position ... left or right...</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[float]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('float') ); ?></textarea> 
			</li>
			<li class="second_list">
				<label>Enter the Post ad image url</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[postad]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('postad') ); ?></textarea> 
			 </li>
		</ul>
	</div>
	
	<div id="tabs-17">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[social_post_button]" id="<?php echo SEOGEN_SETTINGS_FIELD; ?>[social_post_button]" value="1" <?php checked(1, genesism_get_option('social_post_button')); ?> />
				<label for="<?php echo SEOGEN_SETTINGS_FIELD; ?>[social_post_button]">
				<?php _e("Enable post social share section", 'genesism'); ?>
				</label>
			</li>
			<li class="second_list">
				<label>share Heading</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[sharehead]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('sharehead') ); ?></textarea>
			</li>
		</ul>
	</div>
	
		
	<div id="tabs-18">
		<ul>
			<li class="first_list chkbox">
			  <input type="checkbox" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[landing_optin]" id="<?php echo SEOGEN_SETTINGS_FIELD; ?>[landing_optin]" value="1" <?php checked(1, genesism_get_option('landing_optin')); ?> />
			   <label for="<?php echo SEOGEN_SETTINGS_FIELD; ?>[landing_optin]">
			  <?php _e("Enable Landing Page Optin Box", 'genesism'); ?>
			 </label>
			</li>
			<li class="second_list">
				<label>Paste your optin code and Press Tab Button</label>
				<textarea id="optin_code3" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[optin_code3]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_code3') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form name</label>
				<textarea id="optin_name3" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[optin_name3]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('optin_name3') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form Email</label>
				<textarea id="optin_email3" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[optin_email3]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('optin_email3') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form action url</label>
				<textarea id="optin_url3" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[optin_url3]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_url3') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Hidden fields</label>
				<textarea id="optin_hidden3" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[optin_hidden3]" rows="10" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_hidden3') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Enter your Landing Page Optin Header Text</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[landing_optin_header]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('landing_optin_header') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Enter your Landing Page Optin Content</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[landing_optin_cnt]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_optin_cnt') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change your Enter your Name Place holder text here</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[name_text1]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('name_text1') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Change your Enter your Email Place holder text here</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[email_text1]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('email_text1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change your Subscribe me button text</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[submit_text1]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('submit_text1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Enter your Landing Page Video Image URL Link here</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[landing_page_video]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_page_video') ); ?></textarea>
			</li>
		</ul>
<script type="text/javascript">
var j = jQuery.noConflict();
j(document).ready(function(){
j("#optin_code3").blur(function(){
var txt=j(this).val();
if(txt=="")
{
j("#optin_url3").val("");
j("#optin_hidden3").val("");
j("#optin_name3").val("");
j("#optin_email").val("");
return false;
}
var pos1=0;
var pos2=0;
var i=1;
var hidden="";
while(1)
{
pos1=txt.indexOf("<input",pos1);
if(pos1<0) break;
pos2=txt.indexOf(">",pos1+1);
var text=txt.substr(pos1,pos2-pos1);
pp=text.indexOf('type="hidden"');
pp1=text.indexOf('type="submit"');
if(pp>0)
{
hidden+=text+">";
}
if(pp<0 && pp1<0){
pp=text.indexOf('name="');
pp=pp+6;
pp1=text.indexOf('"',pp+1);
var tt=text.substr(pp,pp1-pp);
if(i==1) j("#optin_name3").val(tt);
else j("#optin_email3").val(tt);
i++;
}
pos1=pos2+1;
}
pos1=txt.indexOf("<form",0);
pos2=txt.indexOf(">",pos1+1);
text=txt.substr(pos1,pos2-pos1);
pp=text.indexOf('action="');
pp=pp+8;
pp1=text.indexOf('"',pp+1);
var tt=text.substr(pp,pp1-pp);
j("#optin_url3").val(tt);
j("#optin_hidden3").val(hidden);
});
});
</script>  
	</div>
	
	<div id="tabs-19">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[landing_feature]" id="<?php echo SEOGEN_SETTINGS_FIELD; ?>[landing_feature]" value="1" <?php checked(1, genesism_get_option('landing_feature')); ?> />
				<label for="<?php echo SEOGEN_SETTINGS_FIELD; ?>[landing_feature]">
				<?php _e("Enable Landing Page Feature Section", 'genesism'); ?>
				</label>
			</li>
			
			<li class="second_list">
				<label>Change the Landing Page Feature Title text here</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[landing_feature_title]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('landing_feature_title') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Paste the Landing Page Feature Image1 URL Link here</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[landing_feature_img1]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_img1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Page Feature Subtitle Text1 here</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[landing_feature_subtitle1]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('landing_feature_subtitle1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Page Feature Content1 here</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[landing_feature_cnt1]" rows="5" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_cnt1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Page Feature Read More Text1 here</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[landing_feature_read_txt1]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('landing_feature_read_txt1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Paste the Landing Page Feature Read More Text1 URL Link here</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[landing_feature_readtxt_link1]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_readtxt_link1') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Paste the Landing Page Feature Image2 URL Link here</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[landing_feature_img2]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_img2') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Page Feature Subtitle Text2 here</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[landing_feature_subtitle2]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('landing_feature_subtitle2') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Page Feature Content2 here</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[landing_feature_cnt2]" rows="5" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_cnt2') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Page Feature Read More Text2 here</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[landing_feature_read_txt2]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('landing_feature_read_txt2') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Paste the Landing Page Feature Read More Text2 URL Link here</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[landing_feature_readtxt_link2]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_readtxt_link2') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Paste the Landing Page Feature Image3 URL Link here</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[landing_feature_img3]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_img3') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Page Feature Subtitle Text3 here</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[landing_feature_subtitle3]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('landing_feature_subtitle3') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Page Feature Content3 here</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[landing_feature_cnt3]" rows="5" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_cnt3') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Page Feature Read More Text3 here</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[landing_feature_read_txt3]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('landing_feature_read_txt3') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Paste the Landing Page Feature Read More Text3 URL Link here</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[landing_feature_readtxt_link3]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_readtxt_link3') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Paste the Landing Page Feature Image4 URL Link here</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[landing_feature_img4]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_img4') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Page Feature Subtitle Text4 here</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[landing_feature_subtitle4]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('landing_feature_subtitle4') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Page Feature Content4 here</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[landing_feature_cnt4]" rows="5" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_cnt4') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Page Feature Read More Text4 here</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[landing_feature_read_txt4]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('landing_feature_read_txt4') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Paste the Landing Page Feature Read More Text4 URL Link here</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[landing_feature_readtxt_link4]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_readtxt_link4') ); ?></textarea>
			</li>
			
			
		</ul>
	</div>
		
	<div id="tabs-20">
		 <ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[footer1]" id="<?php echo SEOGEN_SETTINGS_FIELD; ?>[footer1]" value="1" <?php checked(1, genesism_get_option('footer1')); ?> />
				<label for="<?php echo SEOGEN_SETTINGS_FIELD; ?>[footer1]">
				<?php _e("Enable Footer text", 'genesism'); ?>
				</label>
			</li>
			<li class="second_list"><label>Use custom footer text?</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[footer_text]" rows="5" cols="50"><?php echo htmlspecialchars( genesism_get_option('footer_text') ); ?></textarea> 
			</li>
		</ul>
	</div>
	
	<div id="tabs-21">
		 <ul>
			
			<li class="second_list"><label>Enter the Custom CSS</label>
				<textarea name="<?php echo SEOGEN_SETTINGS_FIELD; ?>[custom_css]" rows="25" cols="70"><?php echo htmlspecialchars( genesism_get_option('custom_css') ); ?></textarea> 
			</li>
		</ul>
	</div>
	
</div>    
  
 
 
<?php
}
