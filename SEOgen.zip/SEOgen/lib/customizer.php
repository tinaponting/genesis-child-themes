<?php

function seogen_customize_register( $wp_customize ) {
 /*******************************************
Color scheme
********************************************/
 
// add the section to contain the settings
$wp_customize->add_section( 'textcolors' , array(
    'title' =>  'Color Scheme',
) );

// Background Color
$txtcolors[] = array(
    'slug'=>'body_bg_color', 
    'default' => '#fff',
    'label' => 'Background Color'
);

 
// Body Text Color
$txtcolors[] = array(
    'slug'=>'body_txt_color', 
    'default' => '#555',
    'label' => 'Body Text Color'
);

// Top Header Background

$txtcolors[] = array(
    'slug'=>'top_header_bg_color', 
    'default' => '#e4e5e6',
    'label' => 'Top Header BG Color'
);


// Bottom Menu Background

$txtcolors[] = array(
    'slug'=>'btm_menu_bg_color', 
    'default' => '#111',
    'label' => 'Bottom Menu Background'
);

// Bottom Header Background

$txtcolors[] = array(
    'slug'=>'btm_bg_color', 
    'default' => '#E9E9E9',
    'label' => 'Bottom Header BG Color'
);

// Header Text Color
$txtcolors[] = array(
    'slug'=>'title_color', 
    'default' => '#1D1F22',
    'label' => 'Header Text Color'
);


// Title Hover color
$txtcolors[] = array(
    'slug'=>'title_hover_color', 
    'default' => '#E74C3C',
    'label' => 'Title Hover Color'
);


// Byline Color
$txtcolors[] = array(
    'slug'=>'byline_color', 
    'default' => '#aaa',
    'label' => 'Byline Color'
);

 
// Border color 
$txtcolors[] = array(
    'slug'=>'border_color', 
    'default' => '#EEEEEE',
    'label' => 'Border Color '
);


// Readmore BG color
$txtcolors[] = array(
    'slug'=>'read_bg', 
    'default' => '#ddd',
    'label' => 'Readmore BG Color'
);


// Sidebar BG color
$txtcolors[] = array(
    'slug'=>'sidebar_bg', 
    'default' => '#f9f9f9',
    'label' => 'Sidebar BG Color'
);

//Top Footer BG
$txtcolors[] = array(
    'slug'=>'footer_bg', 
    'default' => '#292929',
    'label' => 'Top Footer BG Color '
);

//site Footer BG
$txtcolors[] = array(
    'slug'=>'footer_bg2', 
    'default' => '#1D1F22',
    'label' => 'Site Footer BG Color '
);



//Footer Text
$txtcolors[] = array(
    'slug'=>'footer_color', 
    'default' => '#A2ACB3',
    'label' => 'Footer Text Color '
);



//Footer Title
$txtcolors[] = array(
    'slug'=>'footer_head', 
    'default' => '#fff',
    'label' => 'Footer Title Color '
);


// add the settings and controls for each color
foreach( $txtcolors as $txtcolor ) {
 
    // SETTINGS
    $wp_customize->add_setting(
        $txtcolor['slug'], array(
            'default' => $txtcolor['default'],
            'type' => 'option', 
            'capability' => 
            'edit_theme_options'
        )
    );
    // CONTROLS
    $wp_customize->add_control(
        new WP_Customize_Color_Control(
            $wp_customize,
            $txtcolor['slug'], 
            array('label' => $txtcolor['label'], 
            'section' => 'textcolors',
            'settings' => $txtcolor['slug'])
        )
    );
}
}
add_action( 'customize_register', 'seogen_customize_register' );