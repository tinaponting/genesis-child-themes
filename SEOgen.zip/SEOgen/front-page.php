<?php
/*
Template Name: Front Page
*/

// Add custom body class to the head
add_filter( 'body_class', 'metro_add_body_class' );
function metro_add_body_class( $classes ) {
   $classes[] = 'frontpage';
   return $classes;
}

// set full width layout
add_filter ( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );

remove_action( 'genesis_entry_content', 'genesis_do_post_content' );
remove_action( 'genesis_loop', 'genesis_do_loop' );
//* Reposition the breadcrumbs
remove_action( 'genesis_before_loop', 'genesis_do_breadcrumbs' );

add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_content_sidebar' );


add_action('genesis_before_content_sidebar_wrap','slider');
function slider(){
?>

<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Front Page Top Widget') ) : ?>
<div class="widget">
<h4 itemprop="headline"><?php _e("Front Page Top #Widget", 'genesis'); ?></h4>
<p><?php _e("Displays Latest posts with thumbnails.", 'genesis'); ?></p>
</div><!-- end .widget -->
<?php endif; ?> 
<?php
}


add_action('genesis_before_loop','content_catgory_widget',2);
function content_catgory_widget(){

?>
<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Front Page Content Widget') ) : ?>
<div class="widget">
<h4 itemprop="headline"><?php _e("Front Page Content #Widget", 'genesis'); ?></h4>
<p><?php _e("Displays Front Page Content posts with thumbnails.", 'genesis'); ?></p>
</div><!-- end .widget -->
<?php endif; ?> 
<?php 

}


genesis();