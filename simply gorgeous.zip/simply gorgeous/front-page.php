<?php
/**
 * This file adds the Home Page to the Simply Gorgeous Theme.
 */
add_action( 'genesis_meta', 'gorgeous_home_genesis_meta' );
/**
 * Add widget support for homepage. If no widgets active, display the default loop.
 */
function gorgeous_home_genesis_meta() {
	if ( is_active_sidebar( 'home-top' ) || is_active_sidebar( 'home-middle-left' ) || is_active_sidebar( 'home-middle-right' ) || is_active_sidebar( 'home-bottom' ) ) {
		// Force content-sidebar layout setting
		add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );
		// Add gorgeous-home body class
		add_filter( 'body_class', 'gorgeous_body_class' );
		function gorgeous_body_class( $classes ) {$classes[] = 'gorgeous-home';return $classes;
		}
		// Remove the default Genesis loop
		remove_action( 'genesis_loop', 'genesis_do_loop' );
		// Add homepage widgets
		add_action( 'genesis_loop', 'gorgeous_home_featured' );
	}}
//* Hooks home top section widget area to home page
add_action( 'genesis_meta', 'gorgeous_home_featured' );
/**
 * Add widget support for homepage. If no widgets active, display the default loop.
 */
function gorgeous_home_featured() {
	if ( is_front_page() & is_active_sidebar('home-slider' )){
		add_action('genesis_after_header','gorgeous_home_top');
	}}
function gorgeous_home_top() {
	echo '<div class="home-top-feature"><div class="wrap">';
    echo '<div class="home-top"><div class="wrap">';
    genesis_widget_area( 'home-slider', array(
		'before'=> '<div class="home-slider widget-area"><div class="wrap">',
		'after'=> '</div></div>',
    ));
    echo '</div></div>';
    echo '<div class="home-middle"><div class="wrap">';
    genesis_widget_area( 'home-middle-left', array(
		'before'=> '<div class="home-middle-left widget-area"><div class="wrap">',
		'after'=> '</div></div>',
    ));
    genesis_widget_area( 'home-middle-middle', array(
		'before'=> '<div class="home-middle-middle widget-area"><div class="wrap">',
		'after'=> '</div></div>',
    ));
     genesis_widget_area( 'home-middle-right', array(
		'before'=> '<div class="home-middle-right widget-area"><div class="wrap">',
		'after'=> '</div></div>',
    ));
    echo '</div></div>';
    echo '</div></div>';
}
genesis();