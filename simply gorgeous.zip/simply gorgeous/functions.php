<?php 
//* Start the engine 
include_once( get_template_directory() . '/lib/init.php' );
//* Enqueue Lato Google font 
add_action( 'wp_enqueue_scripts', 'genesis_sample_google_fonts' ); 
function genesis_sample_google_fonts() { 
	wp_enqueue_script( 'gorgeous-responsive-menu', get_bloginfo( 'stylesheet_directory' ) . '/js/responsive-menu.js', array( 'jquery' ), '1.0.0' ); 
	wp_enqueue_style( 'google-font', '//fonts.googleapis.com/css?family=Lato:300,700|Fauna+One|Playfair+Display', array() ); 
} 
//* Enqueue Dashicons 
add_action( 'wp_enqueue_scripts', 'enqueue_dashicons' ); 
function enqueue_dashicons() { wp_enqueue_style( 'dashicons' ); 
}
//* Enqueue CSS files
add_action( 'wp_enqueue_scripts', 'enqueue_styles' );
function enqueue_styles() {
	wp_enqueue_style( 'genericons-style', get_stylesheet_directory_uri() . '/genericons/genericons.css' );
}
//* Reposition enqueue of css file 
remove_action( 'genesis_meta', 'genesis_load_stylesheet' ); 
add_action( 'wp_enqueue_scripts', 'genesis_enqueue_main_stylesheet', 15 ); 
//* Add HTML5 markup structure 
add_theme_support( 'html5' ); 
//* Add new image sizes 
add_image_size( 'featured', 460, 300, TRUE ); 
add_image_size( 'home-middle', 365, 150, TRUE ); 
add_image_size( 'home-middle-tall', 365 ); 
add_image_size( 'home-middle-small', 75, 75, TRUE ); 
add_image_size( 'home-middle-medium', 100, 100, TRUE ); 
add_image_size( 'sidebar', 280, 150, TRUE ); 
//* Add viewport meta tag for mobile browsers 
add_theme_support( 'genesis-responsive-viewport' ); 
//* Add support for custom background 
add_theme_support( 'custom-background' ); 
//* Add support for custom header 
add_theme_support( 'custom-header', array( 
	'width'=> 300, 
	'height'=> 150, 
	'header-selector'=> '.site-title a', 
	'header-text'=> false 
)); 
//* Add support for 3-column footer widgets 
add_theme_support( 'genesis-footer-widgets', 3 ); 
//* Remove the header right widget area 
unregister_sidebar( 'header-right' ); 
//* Reposition the secondary navigation 
remove_action( 'genesis_after_header', 'genesis_do_subnav' ); 
add_action( 'genesis_before', 'genesis_do_subnav' );
//* Add Support for Comment Numbering 
add_action ('genesis_before_comment', 'afn_numbered_comments'); 
function afn_numbered_comments () { 
    if (function_exists('gtcn_comment_numbering')) 
    echo gtcn_comment_numbering($comment->comment_ID, $args); 
} 
//* Set Genesis Responsive Slider defaults 
add_filter( 'genesis_responsive_slider_settings_defaults', 'gorgeous_responsive_slider_defaults' ); 
function gorgeous_responsive_slider_defaults( $defaults ) { 
	$args = array( 
		'posts_num'=> '5', 
		'slideshow_height'=> '500', 
		'slideshow_title_show'=> 1, 
		'slideshow_width'=> '739', 
	); 
	$args = wp_parse_args( $args, $defaults ); return $args; 
} 
//* Hooks previous and next post 
add_action( 'genesis_entry_footer', 'single_post_nav', 9 ); 
function single_post_nav() { 
	if ( is_singular('post' ) ) { 
		$prev_post = get_adjacent_post(false, 'Previous', true); 
		$next_post = get_adjacent_post(false, 'Next', false); 
		echo '<div class="prev-next-post-links">'; 
			previous_post_link( '<div class="previous-post-link" title="Previous Post: ' . $prev_post->post_title . '">%link</div>', '&laquo;' ); 
			next_post_link( '<div class="next-post-link" title="Next Post: ' . $next_post->post_title . '">%link</div>', '&raquo;' ); 
		echo '</div>'; 
	}}
//* Customize the credits 
add_filter('genesis_footer_creds_text', 'custom_footer_creds_text');
function custom_footer_creds_text() {
    echo '<div class="creds"><p>';
    echo 'Copyright &copy; ';
    echo date('Y');
    echo ' &middot; <a target="_blank" href="http://exempelse">Min egen text här</a>';
    echo '</p></div>';
}
//* Register widget areas 
genesis_register_sidebar( array( 
	'id'=> 'home-slider', 
	'name'=> __( 'Home Slider', 'gorgeous' ), 
	'description'=> __( 'This is the slider on the home page', 'gorgeous' ), 
)); 
//* Register widget areas 
genesis_register_sidebar( array( 
	'id'=> 'home-middle-left', 
	'name'=> __( 'Home Middle Left', 'gorgeous' ), 
	'description'=> __( 'This is the call to action on the home page', 'gorgeous' ), 
)); 
genesis_register_sidebar( array( 
	'id'=> 'home-middle-middle', 
	'name'=> __( 'Home Middle Middle', 'gorgeous' ), 
	'description'=> __( 'This is the call to action on the home page', 'gorgeous' ), 
)); 
genesis_register_sidebar( array( 
	'id'=> 'home-middle-right', 
	'name'=> __( 'Home Middle Right', 'gorgeous' ), 
	'description'=> __( 'This is the call to action on the home page', 'gorgeous' ), 
));
genesis_register_sidebar( array( 	'id'=> 'widget-after-footer', 
	'name'=> __( 'Widget After Footer', 'pinspired' ), 
	'description'=> __( 'This is the widget area after the footer', 'pinspired' ), 
)); 
//* Hooks widget area after footer 
add_action( 'genesis_after_footer', 'widget_after_footer'  );  
function widget_after_footer() { 
    genesis_widget_area( 'widget-after-footer', array( 
	'before'=> '<div class="widget-after-footer widget-area"><div class="wrap">', 
	'after'=> '</div></div>', 
));} 
genesis_register_sidebar( array(
	'id'=> 'nav-social-menu',
	'name'=> __( 'Nav Social Menu', 'your-theme-slug' ),
	'description'=> __( 'This is the nav social menu section.', 'your-theme-slug' ),
));
add_filter( 'genesis_nav_items', 'sws_social_icons', 10, 2 );
add_filter( 'wp_nav_menu_items', 'sws_social_icons', 10, 2 );
function sws_social_icons($menu, $args) {
	$args = (array)$args;
	if ( 'secondary' !== $args['theme_location'] )return $menu;
	ob_start();
	genesis_widget_area('nav-social-menu');
	$social = ob_get_clean();return $menu . $social;
}