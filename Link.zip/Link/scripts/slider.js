/*var j=jQuery.noConflict();
	j(function(){
		j('.flicker-example').flickerplate(
		{
            auto_flick 				: true,
            auto_flick_delay 		: 8,
            flick_animation 		: 'transform-slide'
        });
	});
	*/
	
var j=jQuery.noConflict();
j(document).ready(function(){
j('.example-animation').DrSlider(); //Yes! that's it!
            });
