<?php

function link_customize_register( $wp_customize ) {
 /*******************************************
Color scheme
********************************************/
 
// add the section to contain the settings
$wp_customize->add_section( 'textcolors' , array(
    'title' =>  'Color Scheme',
) );

// Background Color
$txtcolors[] = array(
    'slug'=>'body_bg_color', 
    'default' => '#f5f5f5',
    'label' => 'Background Color'
);

 
// Body Text Color
$txtcolors[] = array(
    'slug'=>'body_txt_color', 
    'default' => '#888',
    'label' => 'Body Text Color'
);


// Top Header BG Color
$txtcolors[] = array(
    'slug'=>'top_bg_color', 
    'default' => '#f9f9f9',
    'label' => 'Top Header BG Color'
);

// Center Header BG Color
$txtcolors[] = array(
    'slug'=>'center_bg_color', 
    'default' => '#fff',
    'label' => 'Center Header BG Color'
);

// Bottom Header BG Color
$txtcolors[] = array(
    'slug'=>'bottom_bg_color', 
    'default' => '#2b2b2b',
    'label' => 'Bottom Header BG Color'
);

// Text1 color
$txtcolors[] = array(
    'slug'=>'text1', 
    'default' => '#111',
    'label' => 'Text1 Color'
);

// Text2 color
$txtcolors[] = array(
    'slug'=>'text2', 
    'default' => '#666666',
    'label' => 'Text2 Color'
);

// Byline Color

$txtcolors[] = array(
    'slug'=>'byline_color', 
    'default' => '#bcbcbc',
    'label' => 'Byline Color'
);

 
// Title Hover color 
$txtcolors[] = array(
    'slug'=>'title_hover_color', 
    'default' => '#24ACEF',
    'label' => 'Title Hover Color '
);

// Hover BG color 
$txtcolors[] = array(
    'slug'=>'hover_bg_color', 
    'default' => '#24ACEF',
    'label' => 'Hover BG Color '
);

//border Color
$txtcolors[] = array(
    'slug'=>'border_color', 
    'default' => '#e6e6e6',
    'label' => 'border Color '
);

//Latest BG Color
$txtcolors[] = array(
    'slug'=>'latest_bg', 
    'default' => '#fafafa',
    'label' => 'Latest BG Color '
);

//Top Footer BG
$txtcolors[] = array(
    'slug'=>'top_footer', 
    'default' => '#292a2c',
    'label' => 'Top Footer BG Color '
);

//Bottom Footer BG
$txtcolors[] = array(
    'slug'=>'bottom_footer', 
    'default' => '#141517',
    'label' => 'Bottom Footer BG Color '
);

//Footer Text BG
$txtcolors[] = array(
    'slug'=>'footer_text_color', 
    'default' => '#949596',
    'label' => 'Footer Text Color '
);




// add the settings and controls for each color
foreach( $txtcolors as $txtcolor ) {
 
    // SETTINGS
    $wp_customize->add_setting(
        $txtcolor['slug'], array(
            'default' => $txtcolor['default'],
            'type' => 'option', 
            'capability' => 
            'edit_theme_options'
        )
    );
    // CONTROLS
    $wp_customize->add_control(
        new WP_Customize_Color_Control(
            $wp_customize,
            $txtcolor['slug'], 
            array('label' => $txtcolor['label'], 
            'section' => 'textcolors',
            'settings' => $txtcolor['slug'])
        )
    );
}
}
add_action( 'customize_register', 'link_customize_register' );