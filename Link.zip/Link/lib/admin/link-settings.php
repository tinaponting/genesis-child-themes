<?php

/**
 * This function registers the default values for genesis theme settings
 */
 
function genesism_theme_settings_defaults() {
$defaults = array( // define our defaults
'style' => 'default',
'custom' => 0,
'shortcodes-css' => 1,

'f_img_width'=>'798',
'f_img_height'=>'300',

'header' => 1,
'header_social' => 1,
'contact_box' => 1,
'search_box' => 1,
'bottom_menu' => 1,
'optin_section' => 1,
'read_more' => 1,
'social_share' => 1,
'sidebar_optin' => 1,
'footer_photo' => 1,
'postadcheck' => 1,
'social_post_button' => 1,
'landing_optin' => 1,
'landing_feature' => 1,
'footer1' => 1,

'header_text' => 'http://link.genesislovers.com/wp-content/uploads/2016/01/logo1.png',
'contact_time' => 'Mon - Sat: 7:00 - 17:00',
'contact_phone' => '+ 000 00 111 5555',
'contact_email' => 'contactus@gmail.com',
'search_text' => 'Search Here...',
'optin_header' => 'Subscribe me',

'optin_cnt' => 'Petu unde onatus error sit voluptatem accusantium.Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
'name_text' => 'Enter your name',
'email_text' => 'Enter your email ',
'submit_text' => 'Subscribe me',
'read_text' => 'Read More',
'optin_header1' => 'Newsletter',
'name_text1' => 'Enter your name',
'email_text1' => 'Enter your email',
'submit_text1' => 'Subscribe me',
'footer_photo_title' => 'News In Post Image',
'postad' => '<img alt="Single Ad" src="http://link.genesislovers.com/wp-content/uploads/2016/01/sidebarad.png"/>',
'share_title' => 'Sharing',

'landing_optin_header' => 'Lorem Ipsum is simply dummy text ',
'landing_optin_cnt' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s.',
'name_text2' => 'Your Name',
'email_text2' => 'Your Email',
'submit_text2' => 'Subscribe me',
'landing_bgimg' => 'http://link.genesislovers.com/wp-content/uploads/2016/01/optinbg1.jpg',

'landing_title' => 'Landing Page Feature',
'landing_feature_cnt' => 'Petu unde onatus error sit voluptatem accusantium.Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
'landing_feature_img1' => 'http://link.genesislovers.com/wp-content/uploads/2016/01/landingfeature1.png',
'landing_subtitle1' => 'Lorem Ipsum is simply dummy text ',
'landing_feature_cnt1' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s.',
'landing_feature_readmore1' => 'Readmore',
'landing_feature_img2' => 'http://link.genesislovers.com/wp-content/uploads/2016/01/landingfeature2.png',
'landing_subtitle2' => 'Lorem Ipsum is simply dummy text',
'landing_feature_cnt2' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s.',
'landing_feature_readmore2' => 'Readmore',
'landing_feature_img3' => 'http://link.genesislovers.com/wp-content/uploads/2016/01/landingfeature1.png',
'landing_subtitle3' => 'Lorem Ipsum is simply dummy text',
'landing_feature_cnt3' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s.',
'landing_feature_readmore3' => 'Readmore',
'landing_feature_img4' => 'http://link.genesislovers.com/wp-content/uploads/2016/01/landingfeature3.png',
'landing_subtitle4' => 'Lorem Ipsum is simply dummy text',
'landing_feature_cnt4' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s.',
'landing_feature_readmore4' => 'Read More',

'footer_text' => 'Copyright &copy;'.date('Y') .  ' <a href="'. get_bloginfo('url') .'">' . get_bloginfo('name') . '</a>'
	
	);
	
	return apply_filters('genesism_theme_settings_defaults', $defaults);

}



function genesism_theme_settings_boxes() {
	global $_genesism_theme_settings_pagehook;
	
	if (function_exists('add_screen_option')) { add_screen_option('layout_columns', array('max' => 2, 'default' => 2) ); }

add_meta_box('genesism-theme-settings-version', __('Theme Information', 'genesism'), 'genesism_theme_settings_info_box', $_genesism_theme_settings_pagehook, 'normal');	
 }
  
 function genesism_theme_settings_info_box() { 
?>

<p class="bolder"><strong><?php echo CHILD_THEME_NAME; ?></strong> by <a href="http://genesislovers.com">genesislovers.com</a></p>
<p><strong>
  <?php _e('Version:', 'genesism'); ?>
  </strong> <?php echo CHILD_THEME_VERSION; ?> <strong>
   </p>
<p><span class="description">
  <?php _e('For support, please visit <a href="http://genesislovers.com/contact-us/">http://genesislovers.com/contact-us/</a>', 'genesism'); ?>
  </span></p>

<div id="tabs">

	<ul>
		<li><a href="#tabs-1"><?php _e("Header Logo", 'genesism'); ?></a></li>
		<li><a href="#tabs-2"><?php _e("Header Social Follow", 'genesism'); ?></a></li>
		<li><a href="#tabs-3"><?php _e("Contact Box", 'genesism'); ?></a></li>		
		<li><a href="#tabs-4"><?php _e("Search Box Section", 'genesism'); ?></a></li>
		<li><a href="#tabs-5"><?php _e("Bottom Menu Section", 'genesism'); ?></a></li>		
		<li><a href="#tabs-6"><?php _e("Optin Section", 'genesism'); ?></a></li>		
		<li><a href="#tabs-7"><?php _e("Featured Image", 'genesism'); ?></a></li>
		<li><a href="#tabs-8"><?php _e("Read More Box", 'genesism'); ?></a></li>
		<li><a href="#tabs-9"><?php _e("Social Share Box", 'genesism'); ?></a></li>		
		<li><a href="#tabs-10"><?php _e("Sidebar Optin Box", 'genesism'); ?></a></li>		
		<li><a href="#tabs-11"><?php _e("Footer Photo Image Box", 'genesism'); ?></a></li>
		<li><a href="#tabs-12"><?php _e("Single Page Advertisement Box", 'genesism'); ?></a></li>
		<li><a href="#tabs-13"><?php _e("Single Page Social Share", 'genesism'); ?></a></li>		
		<li><a href="#tabs-14"><?php _e("Landing Page Optin", 'genesism'); ?></a></li>
		<li><a href="#tabs-15"><?php _e("Landing Page Feature", 'genesism'); ?></a></li>
		<li><a href="#tabs-16"><?php _e("Footer Text", 'genesism'); ?></a></li>
		<li><a href="#tabs-17"><?php _e("Custom CSS", 'genesism'); ?></a></li>
		
	</ul>
	
	
	
	<div id="tabs-1">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo LINK_SETTINGS_FIELD; ?>[header]" id="<?php echo LINK_SETTINGS_FIELD; ?>[header]" value="1" <?php checked(1, genesism_get_option('header')); ?> />
				<label for="<?php echo LINK_SETTINGS_FIELD; ?>[header]">
				<?php _e("Enable Header Logo", 'genesism'); ?>
				</label>
			</li>
			<li class="second_list">
				<label>Enter the Logo image url here</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[header_text]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('header_text') ); ?></textarea>
			</li>
		</ul>
	</div>
	
	<div id="tabs-2">
		<ul>
			

			<li class="second_list"><label>Paste Your Facebook URL Link</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[facebook_text2]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('facebook_text2') ); ?></textarea> 
			</li>
			<li class="second_list"><label>Paste Your Googleplus URL Link</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[googleplus_text2]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('googleplus_text2') ); ?></textarea> 
			</li>
			<li class="second_list"><label>Paste Your Twitter URL Link</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[twitter_text2]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('twitter_text2') ); ?></textarea> 
			</li>
			
			<li class="second_list"><label>Paste Your Pinterest URL Link</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[pinterest_text2]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('pinterest_text2') ); ?></textarea>
			</li>
			<li class="second_list"><label>Paste Your Linkedin URL Link</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[linkedin_text2]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('linkedin_text2') ); ?></textarea> 
			</li>
			<li class="second_list"><label>Paste Your Youtube URL Link</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[youtube_text2]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('youtube_text2') ); ?></textarea>
			</li>
			
			<li class="second_list"><label>Paste Your Instagram URL Link</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[instagram_text2]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('instagram_text2') ); ?></textarea>
			</li>
			
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo LINK_SETTINGS_FIELD; ?>[header_social]" id="<?php echo LINK_SETTINGS_FIELD; ?>[header_social]" value="1" <?php checked(1, genesism_get_option(header_social)); ?> />
				<label for="<?php echo LINK_SETTINGS_FIELD; ?>[header_social]">
				<?php _e("Disable Social follow Icons", 'genesism'); ?>
				</label>
			</li>
			
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo LINK_SETTINGS_FIELD; ?>[fb_check]" id="<?php echo LINK_SETTINGS_FIELD; ?>[fb_check]" value="1" <?php checked(1, genesism_get_option(fb_check)); ?> />
				<label for="<?php echo LINK_SETTINGS_FIELD; ?>[fb_check]">
				<?php _e("Disable Facebook Icon", 'genesism'); ?>
				</label>
			</li>
			
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo LINK_SETTINGS_FIELD; ?>[gp_check]" id="<?php echo LINK_SETTINGS_FIELD; ?>[gp_check]" value="1" <?php checked(1, genesism_get_option(gp_check)); ?> />
				<label for="<?php echo LINK_SETTINGS_FIELD; ?>[gp_check]">
				<?php _e("Disable Googleplus Icon", 'genesism'); ?>
				</label>
			</li>
			
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo LINK_SETTINGS_FIELD; ?>[tw_check]" id="<?php echo LINK_SETTINGS_FIELD; ?>[tw_check]" value="1" <?php checked(1, genesism_get_option(tw_check)); ?> />
				<label for="<?php echo LINK_SETTINGS_FIELD; ?>[tw_check]">
				<?php _e("Disable Twitter Icon", 'genesism'); ?>
				</label>
			</li>
			
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo LINK_SETTINGS_FIELD; ?>[pin_check]" id="<?php echo LINK_SETTINGS_FIELD; ?>[pin_check]" value="1" <?php checked(1, genesism_get_option(pin_check)); ?> />
				<label for="<?php echo LINK_SETTINGS_FIELD; ?>[pin_check]">
				<?php _e("Disable Pinterest Icon", 'genesism'); ?>
				</label>
			</li>
			
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo LINK_SETTINGS_FIELD; ?>[lin_check]" id="<?php echo LINK_SETTINGS_FIELD; ?>[lin_check]" value="1" <?php checked(1, genesism_get_option(lin_check)); ?> />
				<label for="<?php echo LINK_SETTINGS_FIELD; ?>[lin_check]">
				<?php _e("Disable Linkedin Icon", 'genesism'); ?>
				</label>
			</li>
			
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo LINK_SETTINGS_FIELD; ?>[yt_check]" id="<?php echo LINK_SETTINGS_FIELD; ?>[yt_check]" value="1" <?php checked(1, genesism_get_option(yt_check)); ?> />
				<label for="<?php echo LINK_SETTINGS_FIELD; ?>[yt_check]">
				<?php _e("Disable Youtube Icon", 'genesism'); ?>
				</label>
			</li>
			
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo LINK_SETTINGS_FIELD; ?>[ins_check]" id="<?php echo LINK_SETTINGS_FIELD; ?>[ins_check]" value="1" <?php checked(1, genesism_get_option(ins_check)); ?> />
				<label for="<?php echo LINK_SETTINGS_FIELD; ?>[ins_check]">
				<?php _e("Disable Instagram Icon", 'genesism'); ?>
				</label>
			</li>
			
		</ul>			
	</div>
	
	<div id="tabs-3">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo LINK_SETTINGS_FIELD; ?>[contact_box]" id="<?php echo LINK_SETTINGS_FIELD; ?>[contact_box]" value="1" <?php checked(1, genesism_get_option('contact_box')); ?> />
				<label for="<?php echo LINK_SETTINGS_FIELD; ?>[contact_box]">
				<?php _e("Enable Contact Box", 'genesism'); ?>
				</label>
			</li>
			<li class="second_list">
				<label>Enter the Contact Time here</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[contact_time]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('contact_time') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Enter the Contact Phone number here</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[contact_phone]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('contact_phone') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Enter the Contact Email Id here</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[contact_email]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('contact_email') ); ?></textarea>
			</li>
		</ul>
	</div>
	
	<div id="tabs-4">
		 <ul>
			<li class="first_list chkbox">
			  <input type="checkbox" name="<?php echo LINK_SETTINGS_FIELD; ?>[search_box]" id="<?php echo LINK_SETTINGS_FIELD; ?>[search_box]" value="1" <?php checked(1, genesism_get_option('search_box')); ?> />
			   <label for="<?php echo LINK_SETTINGS_FIELD; ?>[search_box]">
			  <?php _e("Enable Search Box", 'genesism'); ?>
			 </label>
			</li>
			<li class="second_list">
			  <label>Enter the Search Place holder Text here</label>
			  <textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[search_text]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('search_text') ); ?></textarea>
			</li>
		</ul>
	</div>
	
	<div id="tabs-5">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo LINK_SETTINGS_FIELD; ?>[bottom_menu]" id="<?php echo LINK_SETTINGS_FIELD; ?>[bottom_menu]" value="1" <?php checked(1, genesism_get_option('bottom_menu')); ?> />
				<label for="<?php echo LINK_SETTINGS_FIELD; ?>[bottom_menu]">
				<?php _e("Enable Bottom Menu", 'genesism'); ?>
				</label>
			</li>
		</ul>
	</div>
	
	
	
	<div id="tabs-6">
		 <ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo LINK_SETTINGS_FIELD; ?>[optin_section]" id="<?php echo LINK_SETTINGS_FIELD; ?>[optin_section]" value="1" <?php checked(1, genesism_get_option('optin_section')); ?> />
				<label for="<?php echo LINK_SETTINGS_FIELD; ?>[optin_section]">
				<?php _e("Enable Optin Box", 'genesism'); ?>
				</label>
			</li>
			<li class="second_list">
				<label>Paste your optin code and Press Tab Button</label>
				<textarea id="optin_code" name="<?php echo LINK_SETTINGS_FIELD; ?>[optin_code]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_code') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form name</label>
				<textarea id="optin_name" name="<?php echo LINK_SETTINGS_FIELD; ?>[optin_name]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('optin_name') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form Email</label>
				<textarea id="optin_email" name="<?php echo LINK_SETTINGS_FIELD; ?>[optin_email]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('optin_email') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form action url</label>
				<textarea id="optin_url" name="<?php echo LINK_SETTINGS_FIELD; ?>[optin_url]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_url') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Hidden fields</label>
				<textarea id="optin_hidden" name="<?php echo LINK_SETTINGS_FIELD; ?>[optin_hidden]" rows="10" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_hidden') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Enter your Optin Header Text</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[optin_header]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('optin_header') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Enter your Optin Content</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[optin_cnt]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_cnt') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change your Enter your name text here</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[name_text]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('name_text') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change your Enter your email text here</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[email_text]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('email_text') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change your Subscribe me button text</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[submit_text]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('submit_text') ); ?></textarea>
			</li>
		  </ul>
 <script type="text/javascript">
var j = jQuery.noConflict();
j(document).ready(function(){
j("#optin_code").blur(function(){
var txt=j(this).val();			
if(txt=="")
{
j("#optin_url").val("");
j("#optin_hidden").val("");
j("#optin_name").val("");
j("#optin_email").val("");
return false;

}
var pos1=0;
var pos2=0;
var i=1;
var hidden="";
while(1)
{
pos1=txt.indexOf("<input",pos1);
if(pos1<0) break;
pos2=txt.indexOf(">",pos1+1);
var text=txt.substr(pos1,pos2-pos1);					
pp=text.indexOf('type="hidden"');
pp1=text.indexOf('type="submit"');	
if(pp>0)
{
hidden+=text+">";
}
if(pp<0 && pp1<0){
pp=text.indexOf('name="');
pp=pp+6;
pp1=text.indexOf('"',pp+1);
var tt=text.substr(pp,pp1-pp);
if(i==1) j("#optin_name").val(tt);
else j("#optin_email").val(tt);
i++;
}
pos1=pos2+1;
}
pos1=txt.indexOf("<form",0);
pos2=txt.indexOf(">",pos1+1);
text=txt.substr(pos1,pos2-pos1);
pp=text.indexOf('action="');
pp=pp+8;
pp1=text.indexOf('"',pp+1);
var tt=text.substr(pp,pp1-pp);
j("#optin_url").val(tt);
j("#optin_hidden").val(hidden);
});
});
</script>  
	</div>
	
	
	
	<div id="tabs-7">
		<ul>
			<li class="second_list"><label>Width of the Featured Image</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[f_img_width]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('f_img_width') ); ?></textarea> 
			</li>
			<li class="second_list"><label>Height of the Featured Image</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[f_img_height]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('f_img_height') ); ?></textarea> 
			</li>
		</ul>
	</div>
	
	<div id="tabs-8">
		<ul>
			<li class="first_list chkbox">
			  <input type="checkbox" name="<?php echo LINK_SETTINGS_FIELD; ?>[read_more]" id="<?php echo LINK_SETTINGS_FIELD; ?>[read_more]" value="1" <?php checked(1, genesism_get_option('read_more')); ?> />
			   <label for="<?php echo LINK_SETTINGS_FIELD; ?>[read_more]">
			  <?php _e("Enable Read More Box", 'genesism'); ?>
			 </label>
			</li>
			 <li class="second_list">
			  <label>Change Your Read More Text here</label>
			  <textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[read_text]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('read_text') ); ?></textarea>
			</li>
		</ul>
	</div>
	
	<div id="tabs-9">
		<ul>
			<li class="first_list chkbox">
			  <input type="checkbox" name="<?php echo LINK_SETTINGS_FIELD; ?>[social_share]" id="<?php echo LINK_SETTINGS_FIELD; ?>[social_share]" value="1" <?php checked(1, genesism_get_option('social_share')); ?> />
			   <label for="<?php echo LINK_SETTINGS_FIELD; ?>[social_share]">
			  <?php _e("Enable Social Share Box", 'genesism'); ?>
			 </label>
			</li>
		</ul>
	</div>
	
		
	<div id="tabs-10">
		 <ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo LINK_SETTINGS_FIELD; ?>[sidebar_optin]" id="<?php echo LINK_SETTINGS_FIELD; ?>[sidebar_optin]" value="1" <?php checked(1, genesism_get_option('sidebar_optin')); ?> />
				<label for="<?php echo LINK_SETTINGS_FIELD; ?>[sidebar_optin]">
				<?php _e("Enable Sidebar Optin", 'genesism'); ?>
				</label>
			</li>
			<li class="second_list">
				<label>Paste your optin code and Press Tab Button</label>
				<textarea id="optin_code3" name="<?php echo LINK_SETTINGS_FIELD; ?>[optin_code3]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_code3') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form name</label>
				<textarea id="optin_name3" name="<?php echo LINK_SETTINGS_FIELD; ?>[optin_name3]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('optin_name3') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form Email</label>
				<textarea id="optin_email3" name="<?php echo LINK_SETTINGS_FIELD; ?>[optin_email3]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('optin_email3') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form action url</label>
				<textarea id="optin_url3" name="<?php echo LINK_SETTINGS_FIELD; ?>[optin_url3]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_url3') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Hidden fields</label>
				<textarea id="optin_hidden3" name="<?php echo LINK_SETTINGS_FIELD; ?>[optin_hidden3]" rows="10" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_hidden3') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Enter your Optin Header Text</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[optin_header1]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('optin_header1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change your Enter your name text here</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[name_text1]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('name_text1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change your Enter your email text here</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[email_text1]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('email_text1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change your Subscribe me button text</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[submit_text1]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('submit_text1') ); ?></textarea>
			</li>
		  </ul>
 <script type="text/javascript">
var j = jQuery.noConflict();
j(document).ready(function(){
j("#optin_code3").blur(function(){
var txt=j(this).val();
if(txt=="")
{
j("#optin_url3").val("");
j("#optin_hidden3").val("");
j("#optin_name3").val("");
j("#optin_email3").val("");
return false;
}
var pos1=0;
var pos2=0;
var i=1;
var hidden="";
while(1)
{
pos1=txt.indexOf("<input",pos1);
if(pos1<0) break;
pos2=txt.indexOf(">",pos1+1);
var text=txt.substr(pos1,pos2-pos1);
pp=text.indexOf('type="hidden"');
pp1=text.indexOf('type="submit"');
if(pp>0)
{
hidden+=text+">";
}
if(pp<0 && pp1<0){
pp=text.indexOf('name="');
pp=pp+6;
pp1=text.indexOf('"',pp+1);
var tt=text.substr(pp,pp1-pp);
if(i==1) j("#optin_name3").val(tt);
else j("#optin_email3").val(tt);
i++;
}
pos1=pos2+1;
}
pos1=txt.indexOf("<form",0);
pos2=txt.indexOf(">",pos1+1);
text=txt.substr(pos1,pos2-pos1);
pp=text.indexOf('action="');
pp=pp+8;
pp1=text.indexOf('"',pp+1);
var tt=text.substr(pp,pp1-pp);
j("#optin_url3").val(tt);
j("#optin_hidden3").val(hidden);
});
});

</script>  
	</div>
	
		
	<div id="tabs-11">
		 <ul>
			<li class="first_list chkbox">
			  <input type="checkbox" name="<?php echo LINK_SETTINGS_FIELD; ?>[footer_photo]" id="<?php echo LINK_SETTINGS_FIELD; ?>[footer_photo]" value="1" <?php checked(1, genesism_get_option('footer_photo')); ?> />
			   <label for="<?php echo LINK_SETTINGS_FIELD; ?>[footer_photo]">
			  <?php _e("Enable Footer Photo Image Box", 'genesism'); ?>
			 </label>
			</li>
			 <li class="second_list">
			  <label>Change Your Footer Photo Image Title here</label>
			  <textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[footer_photo_title]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('footer_photo_title') ); ?></textarea>
			</li>
		  </ul>
	</div>
	
	<div id="tabs-12">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo LINK_SETTINGS_FIELD; ?>[postadcheck]" id="<?php echo LINK_SETTINGS_FIELD; ?>[postadcheck]" value="1" <?php checked(1, genesism_get_option('postadcheck')); ?> />
				<label for="<?php echo LINK_SETTINGS_FIELD; ?>[postadcheck]">
				<?php _e("Enable Post Advertisement Section", 'genesism'); ?>
				</label>
			</li>
			<li class="second_list">
				<label>Enter the Post Advertisement Image url</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[postad]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('postad') ); ?></textarea>
			</li>
		</ul>
	</div>
	
	<div id="tabs-13">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo LINK_SETTINGS_FIELD; ?>[social_post_button]" id="<?php echo LINK_SETTINGS_FIELD; ?>[social_post_button]" value="1" <?php checked(1, genesism_get_option('social_post_button')); ?> />
				<label for="<?php echo LINK_SETTINGS_FIELD; ?>[social_post_button]">
				<?php _e("Enable Single Page social share section", 'genesism'); ?>
				</label>
			</li>
			<li class="second_list">
				<label>Enter the Single Page Social Share Title here</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[share_title]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('share_title') ); ?></textarea>
			</li>
		</ul>
	</div>
	
		
	<div id="tabs-14">
		<ul>
			<li class="first_list chkbox">
			  <input type="checkbox" name="<?php echo LINK_SETTINGS_FIELD; ?>[landing_optin]" id="<?php echo LINK_SETTINGS_FIELD; ?>[landing_optin]" value="1" <?php checked(1, genesism_get_option('landing_optin')); ?> />
			   <label for="<?php echo LINK_SETTINGS_FIELD; ?>[landing_optin]">
			  <?php _e("Enable Landing Page Optin Box", 'genesism'); ?>
			 </label>
			</li>
			<li class="second_list">
				<label>Paste your optin code and Press Tab Button</label>
				<textarea id="optin_code2" name="<?php echo LINK_SETTINGS_FIELD; ?>[optin_code2]" rows="2" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_code2') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form name</label>
				<textarea id="optin_name2" name="<?php echo LINK_SETTINGS_FIELD; ?>[optin_name2]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('optin_name2') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form Email</label>
				<textarea id="optin_email2" name="<?php echo LINK_SETTINGS_FIELD; ?>[optin_email2]" rows="1" cols="20"><?php echo htmlspecialchars( genesism_get_option('optin_email2') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Form action url</label>
				<textarea id="optin_url2" name="<?php echo LINK_SETTINGS_FIELD; ?>[optin_url2]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_url2') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Hidden fields</label>
				<textarea id="optin_hidden2" name="<?php echo LINK_SETTINGS_FIELD; ?>[optin_hidden2]" rows="10" cols="70"><?php echo htmlspecialchars( genesism_get_option('optin_hidden2') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Enter your Optin Header Text</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[landing_optin_header]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('landing_optin_header') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Enter your Optin Header Text</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[landing_optin_cnt]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_optin_cnt') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change your Enter your Name Place holder text here</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[name_text2]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('name_text2') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Change your Enter your Email Place holder text here</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[email_text2]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('email_text2') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change your Subscribe me button text</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[submit_text2]" rows="1" cols="30"><?php echo htmlspecialchars( genesism_get_option('submit_text2') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Paste Your Landing Page Background Image URL Link here</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[landing_bgimg]" rows="1" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_bgimg') ); ?></textarea>
			</li>
		</ul>
<script type="text/javascript">
var j = jQuery.noConflict();
j(document).ready(function(){
j("#optin_code2").blur(function(){
var txt=j(this).val();
if(txt=="")
{
j("#optin_url2").val("");
j("#optin_hidden2").val("");
j("#optin_name2").val("");
j("#optin_email2").val("");
return false;
}
var pos1=0;
var pos2=0;
var i=1;
var hidden="";
while(1)
{
pos1=txt.indexOf("<input",pos1);
if(pos1<0) break;
pos2=txt.indexOf(">",pos1+1);
var text=txt.substr(pos1,pos2-pos1);
pp=text.indexOf('type="hidden"');
pp1=text.indexOf('type="submit"');
if(pp>0)
{
hidden+=text+">";
}
if(pp<0 && pp1<0){
pp=text.indexOf('name="');
pp=pp+6;
pp1=text.indexOf('"',pp+1);
var tt=text.substr(pp,pp1-pp);
if(i==1) j("#optin_name2").val(tt);
else j("#optin_email2").val(tt);
i++;
}
pos1=pos2+1;
}
pos1=txt.indexOf("<form",0);
pos2=txt.indexOf(">",pos1+1);
text=txt.substr(pos1,pos2-pos1);
pp=text.indexOf('action="');
pp=pp+8;
pp1=text.indexOf('"',pp+1);
var tt=text.substr(pp,pp1-pp);
j("#optin_url2").val(tt);
j("#optin_hidden2").val(hidden);
});
});
</script>  
	</div>
	
	<div id="tabs-15">
		<ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo LINK_SETTINGS_FIELD; ?>[landing_feature]" id="<?php echo LINK_SETTINGS_FIELD; ?>[landing_feature]" value="1" <?php checked(1, genesism_get_option('landing_feature')); ?> />
				<label for="<?php echo LINK_SETTINGS_FIELD; ?>[landing_feature]">
				<?php _e("Enable Landing Page Feature Section", 'genesism'); ?>
				</label>
			</li>
			<li class="second_list">
				<label>Change the Landing Page Feature Title text here</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[landing_title]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('landing_title') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Page Feature Content here</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[landing_feature_cnt]" rows="5" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_cnt') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Paste the Landing Page Feature Image1 URL Link here</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[landing_feature_img1]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_img1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Page Feature Subtitle1 here</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[landing_subtitle1]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('landing_subtitle1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Page Feature Content1 here</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[landing_feature_cnt1]" rows="5" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_cnt1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Page Feature Read More Text1 here</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[landing_feature_readmore1]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('landing_feature_readmore1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Paste the Landing Page Feature Read More Text1 URL Link here</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[landing_feature_readmore_link1]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_readmore_link1') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Paste the Landing Page Feature Image2 URL Link here</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[landing_feature_img2]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_img2') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Page Feature Subtitle2 here</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[landing_subtitle2]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('landing_subtitle2') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Page Feature Content2 here</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[landing_feature_cnt2]" rows="5" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_cnt2') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Page Feature Read More Text2 here</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[landing_feature_readmore2]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('landing_feature_readmore2') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Paste the Landing Page Feature Read More Text2 URL Link here</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[landing_feature_readmore_link2]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_readmore_link2') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Paste the Landing Page Feature Image3 URL Link here</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[landing_feature_img3]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_img3') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Page Feature Subtitle3 here</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[landing_subtitle3]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('landing_subtitle3') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Page Feature Content3 here</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[landing_feature_cnt3]" rows="5" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_cnt3') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Page Feature Read More Text3 here</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[landing_feature_readmore3]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('landing_feature_readmore3') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Paste the Landing Page Feature Read More Text3 URL Link here</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[landing_feature_readmore_link3]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_readmore_link3') ); ?></textarea>
			</li>
			
			<li class="second_list">
				<label>Paste the Landing Page Feature Image4 URL Link here</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[landing_feature_img4]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_img4') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Page Feature Subtitle4 here</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[landing_subtitle4]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('landing_subtitle4') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Page Feature Content4 here</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[landing_feature_cnt4]" rows="5" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_cnt4') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Change the Landing Page Feature Read More Text4 here</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[landing_feature_readmore4]" rows="1" cols="40"><?php echo htmlspecialchars( genesism_get_option('landing_feature_readmore4') ); ?></textarea>
			</li>
			<li class="second_list">
				<label>Paste the Landing Page Feature Read More Text4 URL Link here</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[landing_feature_readmore_link4]" rows="3" cols="70"><?php echo htmlspecialchars( genesism_get_option('landing_feature_readmore_link4') ); ?></textarea>
			</li>
			
		</ul>
	</div>
	
	<div id="tabs-16">
		 <ul>
			<li class="first_list chkbox">
				<input type="checkbox" name="<?php echo LINK_SETTINGS_FIELD; ?>[footer1]" id="<?php echo LINK_SETTINGS_FIELD; ?>[footer1]" value="1" <?php checked(1, genesism_get_option('footer1')); ?> />
				<label for="<?php echo LINK_SETTINGS_FIELD; ?>[footer1]">
				<?php _e("Enable Footer text", 'genesism'); ?>
				</label>
			</li>
			<li class="second_list"><label>Use custom footer text?</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[footer_text]" rows="5" cols="50"><?php echo htmlspecialchars( genesism_get_option('footer_text') ); ?></textarea> 
			</li>
		</ul>
	</div>
	
	<div id="tabs-17">
		 <ul>
			<li class="second_list"><label>Enter the Custom CSS</label>
				<textarea name="<?php echo LINK_SETTINGS_FIELD; ?>[custom_css]" rows="25" cols="70"><?php echo htmlspecialchars( genesism_get_option('custom_css') ); ?></textarea> 
			</li>
		</ul>
	</div>

	
</div>  
  
<?php
}
 
 
 