<?php
/*
Template Name: Front Page
*/

// Add custom body class to the head
add_filter( 'body_class', 'metro_add_body_class' );
function metro_add_body_class( $classes ) {
   $classes[] = 'frontpage';
   return $classes;
}

// set full width layout
add_filter ( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );
remove_action( 'genesis_entry_content', 'genesis_do_post_content' );
remove_action( 'genesis_loop', 'genesis_do_loop' );
remove_action( 'genesis_sidebar', 'genesis_do_sidebar' );


add_action('genesis_before_content_sidebar_wrap','slider_widget',1);
function slider_widget(){

?>
<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Front Page Slider Widget') ) : ?>
<div class="widget">
<h4 itemprop="headline"><?php _e("Front Page Slider #Widget", 'genesis'); ?></h4>
<p><?php _e("Displays Front Page Slider posts with thumbnails.", 'genesis'); ?></p>
</div><!-- end .widget -->
<?php endif; ?> 

<?php 
}

add_action('genesis_before_content_sidebar_wrap','content_widget',3);
function content_widget(){

?>
<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Front Page Content Widget') ) : ?>
<div class="widget">
<h4 itemprop="headline"><?php _e("Front Page Content #Widget", 'genesis'); ?></h4>
<p><?php _e("Displays Front Page Content posts with thumbnails.", 'genesis'); ?></p>
</div><!-- end .widget -->
<?php endif; ?> 

<?php 
}


add_action('genesis_before_content_sidebar_wrap','optin_section',2);
function optin_section(){
if (genesism_get_option('optin_section')){
?>
<div class="optin_section">
	<div class="optin_box_section wrap">
		<div class="line_title">
			<h3><?php echo genesism_option('optin_header'); ?></h3>
			<p><?php echo genesism_option('optin_cnt'); ?></p>
			<div class="line_under"><div class="line_center"></div></div>
			<div class="line_under below_line"><div class="line_center"></div></div>
		</div>
		<div class="optin_cnt">
			
			<form method="post" class="form" action="<?php echo stripslashes(genesism_option('optin_url')); ?>" target="_blank">	
				<div class="names">
				<input class="name" type="text" name="<?php echo stripslashes(genesism_option('optin_name')); ?>" placeholder="<?php echo stripslashes(genesism_option('name_text')); ?>"><div class='admins'></div></div>
				<div class="names">				
				<input class="email" type="text" name="<?php echo stripslashes(genesism_option('optin_email')); ?>" placeholder="<?php echo stripslashes(genesism_option('email_text')); ?>"><div class='mails'></div></div>
				<?php echo stripslashes(genesism_option('optin_hidden')); ?>
				<input name="submit" class="submit" type="submit" value="<?php echo stripslashes(genesism_option('submit_text')); ?>"/>
			</form>
		</div>
	</div>
</div>
<?php 
}
}



genesis();