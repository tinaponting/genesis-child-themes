<?php
/*
Template Name: Landing Page without Feature
*/


// Add custom body class to the head
add_filter( 'body_class', 'metro_add_body_class' );
function metro_add_body_class( $classes ) {
   $classes[] = 'landingpage';
   return $classes;
}

add_filter ( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );
remove_action( 'genesis_sidebar_alt', 'genesis_do_sidebar_alt' );
remove_action( 'genesis_sidebar', 'genesis_do_sidebar' );
remove_action( 'genesis_after_header', 'genesis_do_nav' );
 remove_action('genesis_before_footer', 'footer_bottom_widgets');
remove_action( 'genesis_sidebar', 'genesis_do_sidebar' );


add_action('genesis_before_content','before_content');
function before_content(){
?>
<div class="main_container wrap">
<?php 
}

add_action('genesis_after_content','after_content');
function after_content(){
?>
</div>
<?php
}

add_action('genesis_before_content_sidebar_wrap','landingpage_optin',1);
function landingpage_optin(){
if (genesism_get_option('landing_optin')){
?>
<div class="landingpage_optin" style="background-image:url('<?php echo genesism_option('landing_bgimg'); ?>')">
	<div class="landingpage_optin_section wrap">
		<div class="landing_optin_cnt">
			<div class="landing_optin_title">
				<h3><?php echo genesism_option('landing_optin_header'); ?></h3>
				<p><?php echo genesism_option('landing_optin_cnt'); ?></p>
			</div>
			<form method="post" class="form" action="<?php echo stripslashes(genesism_option('optin_url2')); ?>" target="_blank">
				<div class="landing_optin_inputs">
				<div class="names"><input class="name" type="text" name="<?php echo stripslashes(genesism_option('optin_name2')); ?>" placeholder="<?php echo stripslashes(genesism_option('name_text2')); ?>"><div class='admins'></div></div>
				<div class="names"><input class="email" type="text" name="<?php echo stripslashes(genesism_option('optin_email2')); ?>" placeholder="<?php echo stripslashes(genesism_option('email_text2')); ?>"><div class='mails'></div></div>
				</div>
				<?php echo stripslashes(genesism_option('optin_hidden2')); ?>
				<input name="submit" class="submit" type="submit" value="<?php echo stripslashes(genesism_option('submit_text2')); ?>"/>
			</form>
		</div>
	</div>
</div>
<?php 
}	
}


genesis();