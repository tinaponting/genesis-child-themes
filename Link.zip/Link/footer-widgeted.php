<div class="footer-widgets">
	<div class="wrap">
    	<div class="footer_widget footer1">
		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer Widget1') ) : ?>
    			<div class="widget">
            		<div class="footer_widget_title"><h3 itemprop="headline"><?php _e("Footer #Widget1", 'genesis'); ?></h3></div>
            		<p><?php _e("This is an example of a widget area that you can place text to describe a product or service. You can also use other WordPress widgets such as recent posts, recent comments, a tag cloud or more.", 'genesis'); ?></p>
	    		</div><!-- end .widget -->
	    	<?php endif; ?> 
		</div>
   		<!-- end .footer-widget1 -->
    
		<div class="footer_widget footer2">
  
        	<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer Widget2') ) : ?>
    			<div class="widget">
            		<div class="footer_widget_title"><h3 itemprop="headline"><?php _e("Footer #Widget2", 'genesis'); ?></h3></div>
            		<p><?php _e("This is an example of a widget area that you can place text to describe a product or service. You can also use other WordPress widgets such as recent posts, recent comments, a tag cloud or more.", 'genesis'); ?></p>
	    		</div><!-- end .widget -->
	  
			
			<?php endif; ?> 		
    	</div><!-- end .footer-widget2 -->
	
    	<!-- end .footer-middle -->
    	<div class="footer_widget footer3">
			
		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer Widget3') ) : ?>
    			<div class="widget">
            		<div class="footer_widget_title"><h3 itemprop="headline"><?php _e("Footer #Widget3", 'genesis'); ?></h3></div>
            		<p><?php _e("This is an example of a widget area that you can place text to describe a product or service. You can also use other WordPress widgets such as recent posts, recent comments, a tag cloud or more.", 'genesis'); ?></p>
	    		</div><!-- end .widget -->
	  
			
			<?php endif; ?>
    	</div><!-- end .footer-widget3 -->
		
		<?php 
		if (genesism_get_option('footer_photo')){
		?>
		<div class="widget footer_widget footer4">
			<h4 class="widget-title widgettitle"><?php echo genesism_option('footer_photo_title'); ?></h4>
			<div class="footer_widget_cnt">
				<?php 
					query_posts( array('posts_per_page'=>6) );
					while ( have_posts() ) : the_post();
					$i++;
					$class = ( $i % 3 ) ? 'flickr_photo' : 'flickr_photo last';
				?>
					<div class="<?php echo $class; ?>">
						<div class="flickr_img" itemprop="image">
							<?php
							// Defaults
							$f_img_width6 = 89;
							$f_img_height6 = 65;
							$default_img =  'Feature_image'; 

							// Auto feature image defaults
							$thumb = get_post_thumbnail_id(); 
							$img_url = wp_get_attachment_url( $thumb,'full' ); 
							$image = aq_resize( $img_url,$f_img_width6,$f_img_height6, true );
							// Catch the Image defaults
							$catch_img_url = catch_that_image( $thumb,'full' );
							$catch_image = aq_resize( $catch_img_url, $f_img_width6, $f_img_height6, true );
							// Default Image
							$default_image = aq_resize( $default_img, $f_img_width6, $f_img_height6, true );
							
							if(has_post_thumbnail())
							echo
							"<div class=\"featured_image\">\n".
							"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width6 . "\" height=\"" . $f_img_height6 . "\" alt=\"" . get_the_title() . "\"></a>\n".
							"</div>\n";
							elseif (catch_that_image()){ 
							echo
							"<div class=\"featured_image\">\n".
							"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width6 . "\" height=\"" . $f_img_height6 . "\" alt=\"" . get_the_title() . "\"></a>\n".
							"</div>\n"; 
							} 
							/*featured image ends here*/
							?>						
						</div>
					</div>
				<?php
					endwhile;
					wp_reset_query(); 
				?>
			</div>
		</div> 
		<?php 
		}
		?>
    	</div><!-- end .wrap -->
</div><!-- end #footer-widgets -->