<?php
require_once(TEMPLATEPATH.'/lib/init.php'); // Start Genesis Engine
require_once(STYLESHEETPATH.'/lib/init.php'); // Start blog Options
require_once(STYLESHEETPATH.'/lib/updates.php'); // updates

include_once( 'lib/customizer.php' );
//* Add HTML5 markup structure
add_theme_support( 'html5' );


/** Support for various Image sizes */
add_theme_support('post-thumbnails');
//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Add support for custom background
add_theme_support( 'custom-background' );

 

// Add widgeted footer section
add_action('genesis_before_footer', 'footer_bottom_widgets'); 
function footer_bottom_widgets() {
    require(CHILD_DIR.'/footer-widgeted.php');
}

 //* Display author box on archive pages
add_filter( 'get_the_author_genesis_author_box_archive', '__return_true' );

//* Customize the author box title
add_filter( 'genesis_author_box_title', 'custom_author_box_title' );
function custom_author_box_title() {
	return "<h3 itemscope=\"Name\"> " . get_the_author() . "</h3>";
}


/** Register widget areas */

genesis_register_sidebar( array(
	'id'			=> 'front_page_slider_widget',
	'name'			=> __( 'Front Page Slider Widget', 'Link Genesis Theme' ),
	'description'	=> __( 'This is the front page Slider widget if you are using a two or three column site layout option.', 'Link Genesis Theme' ),
	
) );

genesis_register_sidebar( array(
	'id'			=> 'front_page_content_widget',
	'name'			=> __( 'Front Page Content Widget', 'Link Genesis Theme' ),
	'description'	=> __( 'This is the front page Content widget if you are using a two or three column site layout option.', 'Link Genesis Theme' ),
	
) );


genesis_register_sidebar( array(
	'id'			=> 'single_post_related',
	'name'			=> __( 'Single Page Related Post Widget', 'Link Genesis Theme' ),
	'description'	=> __( 'This is the Single Page Related Post widget if you are using a two or three column site layout option.', 'Link Genesis Theme' ),
	
) );

genesis_register_sidebar( array(
	'id'			=> 'footer-widget1',
	'name'			=> __( 'Footer Widget1', 'Link Genesis Theme' ),
	'description'	=> __( 'This is the footer widget1 section.', 'Link Genesis Theme' ),
) );

genesis_register_sidebar( array(
	'id'			=> 'footer-widget2',
	'name'			=> __( 'Footer Widget2', 'Link Genesis Theme' ),
	'description'	=> __( 'This is the footer widget2 section.', 'Link Genesis Theme' ),
) );

genesis_register_sidebar( array(
	'id'			=> 'footer-widget3',
	'name'			=> __( 'Footer Widget3', 'Link Genesis Theme' ),
	'description'	=> __( 'This is the footer widget3 section.', 'Link Genesis Theme' ),
) );

//Remove Post  entry footer  Meta data 
remove_action( 'genesis_entry_footer', 'genesis_post_meta' );
//remove archive description
remove_action( 'genesis_before_content', 'genesis_do_taxonomy_title_description', 15 );


add_filter( 'genesis_term_meta_headline', 'be_default_category_title', 10, 2 );
function be_default_category_title( $headline, $term ) {
	if( ( is_category() || is_tag() || is_tax() ) && empty( $headline ) )
		$headline = $term->name;
		
	return $headline;
}

add_filter('comment_form_defaults','comment_reform');
function comment_reform ($arg) {
$arg['title_reply'] = __(' <div class="single_page_title"><h3>Leave A Reply</h3></div> ');
return $arg;
}

//placeholder for comment box in single page
add_filter('comment_form_default_fields','comment_form_placeholder');
function comment_form_placeholder($fields){ 
	$fields['author'] = '<p class="comment-form-author">' . '<label for="author">' . __( '', 'genesis' ) . '</label> ' . 	
	( $req ? '<span class="required">*</span>' : '' ) .                   
	'<input id="author" name="author" type="text" placeholder="Name *" value="' . 				
	esc_attr( $commenter['comment_author'] ) . '" size="30"' . $aria_req . ' /></p>';				
    $fields['email'] = '<p class="comment-form-email"><label for="email">' . __( '', 'genesis' ) . '</label> ' .
	( $req ? '<span class="required">*</span>' : '' ) .
	'<input id="email" name="email" type="text" placeholder="Email *" value="' . 	
	esc_attr(  $commenter['comment_author_email'] ) . '" size="30"' . $aria_req . ' /></p>';	
	$fields['url'] = '<p class="comment-form-url"><label for="url">' . __( '', 'genesis' ) . '</label>' .    
	'<input id="url" name="url" type="text" placeholder="URL *" value="' . 	
	esc_attr( $commenter['comment_author_url'] ) . '" size="30" /></p>';	
    return $fields;
}

function string_limit_words($string, $word_limit)
{
  $words = explode(' ', $string, ($word_limit + 1));
  if(count($words) > $word_limit)
  array_pop($words);
  return implode(' ', $words);
}
 
// Customizes Footer Text (set in options) 
if (genesism_get_option('footer1')) { 
	add_filter('genesis_footer_creds_text', 'custom_footer_creds_text');
	function custom_footer_creds_text($creds) {
    	$creds = genesism_get_option('footer_text');
    return $creds;
	}
}



add_filter( 'genesis_before_header', 'search_box',2 );
function search_box( $text ) {
	return esc_attr( 'Go' );
}
remove_action( 'genesis_site_title', 'genesis_seo_site_title' );
remove_action( 'genesis_site_description', 'genesis_seo_site_description' );
/* BEGIN Custom User Contact Info */
function extra_contact_info($contactmethods) {

$contactmethods['facebook'] = 'Facebook';
$contactmethods['twitter'] = 'Twitter';

return $contactmethods;
}
add_filter('user_contactmethods', 'extra_contact_info');
/* END Custom User Contact Info */




add_action( 'genesis_entry_footer', 'themeprefix_alt_author_box',3 );
function themeprefix_alt_author_box() {
if( is_single() ) {
 
echo "<div class=\"about-author single_page_cnt\">
	<div class=\"single_page_title\"><h3>About The Author</h3></div>
	<div class=\"author_section\">
		<div class=\"author-info\" itemscope=\"itemscope\" itemtype=\"http://schema.org/person\">" . get_avatar( get_the_author_meta( 'ID' ), '100' ) . "</div>
		<div class='author_right_cnt'>
			<div class='author_right_topcnt'>";?>
			
			<h3 class="author_name"><?php the_author_posts_link(); ?></h3> 
			<?php echo"<div class=\"author_social\">"; 

				 if ( get_the_author_meta( 'facebook' ) != '' ) {
				 echo "<a title='Facebook' class=\"afb fa\" href=\"https://www.facebook.com/". get_the_author_meta( 'facebook' ) . "\"><i class='fa icon-facebook'></i></a>";
				 }
				 if ( get_the_author_meta( 'googleplus' ) != '' ) {
				 echo "<a title='Googleplus' class=\"agp fa\" href=\"https://plus.google.com/". get_the_author_meta( 'googleplus' ) . "\"><i class='fa icon-google'></i></a>";
				 }
				 if ( get_the_author_meta( 'twitter' ) != '' ) {
				 echo "<a title='Twitter' class=\"atw fa\" href=\"https://twitter.com/". get_the_author_meta( 'twitter' ) . "\"><i class='fa icon-twitter'></i></a>";
				 }
 
				echo "</div>
			</div>
			<p itemprop=\"description\">" . get_the_author_meta( 'description' ) . 
			"</p>
			
			</div>".
		"</div>".
	"</div>";
 }
} 
 
//* Remove the entry meta in the entry header 
 

 add_filter( 'genesis_post_info', 'sp_post_info_filter' );
function sp_post_info_filter($post_info) {
if ( is_single() ) {
	$post_info = '[post_date] by [post_author_posts_link] [post_comments]';
	return $post_info;
}}
 
// Register Genesis Menus
add_action( 'init', 'register_additional_menu' );
function register_additional_menu() {
  
register_nav_menu( 'FirstMenu' ,__( 'Menu Section' ));
     
} 


// Portfolio Post Type
add_action('init','bts_create_portfolio_init');
function bts_create_portfolio_init()  {
	$labels = array
	(
		'name' => _x('Portfolio', 'post type general name'),
		'singular_name' => _x('item', 'post type singular name'),
		'add_new' => _x('Add New', 'Portfolio Item'),
		'add_new_item' => __('Add New Portfolio Item'),
		'edit_item' => __('Edit Portfolio Item'),
		'new_item' => __('New Portfolio Item'),
		'view_item' => __('View Portfolio Item'),
		'search_items' => __('Search Portfolio'),
		'not_found' =>  __('No portfolio items found'),
		'not_found_in_trash' => __('No portfolio items found in Trash'), 
		'parent_item_colon' => ''
	);
	$support = array
	(
		'title',
		'editor',
		'author',
		'thumbnail',
		'custom-fields',
		'comments',
		'thesis-seo', 
		'thesis-layouts',
		'revisions'
	);
	$args = array
	(
		'labels' => $labels,
		'public' => TRUE,
		'rewrite' => array('slug'=>'portfolio'),
		'capability_type' => 'page',
		'hierarchical' => FALSE,
		'query_var' => true,
		'supports' => $support,
		'taxonomies' => array('portfolio_category'),
		'menu_position' => 5
	); 
	register_post_type('portfolio',$args);
	
	register_taxonomy(
        'portfolio_category',        
        'portfolio',
        array(
            'hierarchical' => TRUE,
            'label' => 'Categories',
            'query_var' => TRUE,
            'rewrite' => FALSE,
        )
    );  
}


//Testimonial
add_action('init','bts_create_testimonial_init');
function bts_create_testimonial_init()  {
	$labels = array
	(
		'name' => _x('Testimonial', 'post type general name'),
		'singular_name' => _x('item', 'post type singular name'),
		'add_new' => _x('Add New', 'Testimonial Item'),
		'add_new_item' => __('Add New Testimonial Item'),
		'edit_item' => __('Edit Testimonial Item'),
		'new_item' => __('New Testimonial Item'),
		'view_item' => __('View Testimonial Item'),
		'search_items' => __('Search Testimonial'),
		'not_found' =>  __('No Testimonial items found'),
		'not_found_in_trash' => __('No Testimonial items found in Trash'), 
		'parent_item_colon' => ''
	);
	$support = array
	(
		'title',
		'editor',
		'author',
		'thumbnail',
		'custom-fields',
		'revisions'
	);
	$args = array
	(
		'labels' => $labels,
		'public' => TRUE,
		'rewrite' => array('slug'=>'testimonial'),
		'capability_type' => 'page',
		'hierarchical' => FALSE,
		'query_var' => true,
		'supports' => $support,
		'taxonomies' => array('testimonial_category'),
		'menu_position' => 5
	); 
	register_post_type('testimonial',$args);
	
	register_taxonomy(          
        'testimonial',
        array(
            'hierarchical' => TRUE,
            'label' => 'Categories',
            'query_var' => TRUE,
            'rewrite' => FALSE,
        )
    );  
}

/** Remove Header */
remove_action( 'genesis_header', 'genesis_header_markup_open', 5 );
remove_action( 'genesis_header', 'genesis_do_header' );
remove_action( 'genesis_header', 'genesis_header_markup_close', 15 );

/** Add custom header support */

add_action('genesis_header','injectHeader');
		  
function injectHeader(){ 
?>
<div class="top_header">
	<div class="top_inner_header wrap ">
		<?php 
		if (!genesism_get_option('header_social')){
		?>
		<div class="top_left_header">
			<ul class="header_social">
				<?php 
				if (!genesism_get_option('fb_check')){
				?>
				<li class="social_icons">
					<a class="facebook" title="Facebook" href="<?php echo genesism_option('facebook_text2'); ?>" target="_blank">
					<i class="fa icon-facebook"></i>
					</a>
				</li>
				<?php
				}
				if (!genesism_get_option('gp_check')){
				?>
				<li class="social_icons">
					<a class="googleplus" title="google plus" href="<?php echo genesism_option('googleplus_text2'); ?>" target="_blank">
					<i class="fa icon-google"></i>
					</a>
				</li>
				<?php
				}
				if (!genesism_get_option('tw_check')){
				?>
				<li class="social_icons">
					<a class="twitter" title="Twitter" href="<?php echo genesism_option('twitter_text2'); ?>" target="_blank">
					<i class="fa icon-twitter"></i>
					</a>
				</li>
				<?php
				}
				if (!genesism_get_option('pin_check')){
				?>
				<li class="social_icons">
					<a class="pinterest" title="pinterest" href="<?php echo genesism_option('pinterest_text2'); ?>" target="_blank">
					<i class="fa icon-pinterest"></i>
					</a>
				</li>
				<?php
				}
				if (!genesism_get_option('lin_check')){
				?>
				<li class="social_icons">
					<a class="linkedin" title="linkedin" href="<?php echo genesism_option('linkedin_text2'); ?>" target="_blank">
					<i class="fa icon-linkedin"></i>
					</a>
				</li>
				<?php
				}
				if (!genesism_get_option('yt_check')){
				?>
				<li class="social_icons">
					<a class="youtube" title="youtube" href="<?php echo genesism_option('youtube_text2'); ?>" target="_blank">
					<i class="fa icon-youtube"></i>
					</a>
				</li>
				<?php
				}
				if (!genesism_get_option('ins_check')){
				?>
				<li class="social_icons">
					<a class="instagram" title="Instagram" href="<?php echo genesism_option('instagram_text2'); ?>" target="_blank">
					<i class="fa icon-instagram"></i>
					</a>
				</li>
				<?php
				}
				?>
			</ul>
		</div>
		<?php 
		}
		?>
		<?php 
		if (genesism_get_option('contact_box')){
		?>
		<div class="contact_box top_right_header">
			<div class="contact1 time">
				<span><?php echo genesism_option('contact_time'); ?></span>
			</div>
			<div class="contact1 phonenum">
				<span><?php echo genesism_option('contact_phone'); ?></span>
			</div>
			<div class="contact1 email">
				<span><?php echo genesism_option('contact_email'); ?></span>
			</div>
		</div>	
		<?php 
		}
		?>
	</div>
</div>
<div class="center_header">
	<div class="center_inner_header wrap">
		<div class="center_left_header">
			<div class="logo_section">
				<?php
				if (genesism_get_option('header')){?>
					<a itemprop="url" title="<?php bloginfo('name'); ?>" href="<?php bloginfo('wpurl'); ?>"><img src="<?php echo genesism_option('header_text'); ?>" alt="<?php bloginfo('name'); ?>"/></a>
				<?php
				}
				else { ?>
					<h1 itemprop="headline"><a title="<?php bloginfo('name'); ?>" href="<?php bloginfo('wpurl'); ?>"><?php bloginfo('name');?> </a></h1>
					<p><?php bloginfo('description'); ?></p>
				<?php } ?>
			</div>	
			<?php
				/*if (genesism_get_option('top_ad')){?>
			<div class="top_advertisement">
				<?php echo genesism_option('header_ad'); ?>
			</div>
			<?php 
			}*/
			?>
		</div>
		<div class="center_right_header">
			<?php 
			if (genesism_get_option('search_box')){
			?>
			<div class='widget_search'>
				<form method='get' action='<?php echo get_bloginfo('home'); ?>'>
					<input type='text' placeholder='<?php echo genesism_option('search_text'); ?>' name='s' id='s' />			
					<button type='submit' class='btn btn-success'>
					<i class='fa icon-search'></i>
					</button>
				</form>
			</div>
			<?php 
			}
			?>
		</div>
	</div>
</div>
<div class="bottom_header">
	<div class="bottom_inner_header wrap">
		<?php 
		if (genesism_get_option('bottom_menu')){?>
		<div class="bottom_menu">
			<span class="menu_control">≡ Menu</span>
			<?php wp_nav_menu( array( 'theme_location' => 'FirstMenu','container' => false,'menu_id' => 'menu_top_menu' ) );?>
		</div>
		
		<?php 
		}
		?>
	</div>
</div>
<?php 
} 

add_action('genesis_before_header','before_header');	
function before_header() { ?>
<div class="headermain" itemscope="itemscope" itemtype="http://schema.org/WPHeader">
<?php
}


add_action('genesis_after_header','after_header');			
function after_header() { ?>
<div class="click_icon"></div>
 </div>	

<?php
}




add_action ('genesis_before_sidebar_widget_area','sidebar_optin',1);
function sidebar_optin(){	
if (genesism_get_option('sidebar_optin')){
?>
<div class="sidebar_optin sidebar_widget">
	<div class="widget_inner1">
		<div class="widget_inner2">
			<h3 class="wg-title"><span><?php echo genesism_option('optin_header1'); ?></span></h3>
			<div class="sidebar_optin sidebar_cnt">
				<form method="post" class="form" action="<?php echo stripslashes(genesism_option('optin_url3')); ?>" target="_blank">
					<div class="names"><input class="name" type="text" name="<?php echo stripslashes(genesism_option('optin_name3')); ?>" placeholder="<?php echo stripslashes(genesism_option('name_text1')); ?>"><div class='admins'></div></div>
					<div class="names"><input class="email" type="text" name="<?php echo stripslashes(genesism_option('optin_email3')); ?>" placeholder="<?php echo stripslashes(genesism_option('email_text1')); ?>"><div class='mails'></div></div>
					<?php echo stripslashes(genesism_option('optin_hidden3')); ?>
					<input name="submit" class="submit" type="submit" value="<?php echo stripslashes(genesism_option('submit_text1')); ?>"/>
				</form>
			</div>	
		</div>
	</div>
</div>
<?php 
}
}


add_action ('genesis_before_entry','before_entry');
function before_entry(){
?>
<div class="blog_inner1">
<div class="blog_inner2">
<div class="blog_inner3">
<?php 
}




add_action ('genesis_after_entry','after_entry');
function after_entry(){
?>
</div>
</div>
</div>
<?php 
}


add_action( 'genesis_entry_header', 'post_info_filter',1 );
function post_info_filter() {
if(!is_page()&&!is_single()){ 
?>
<div class="post_meta_section">
	<div class="home_byline">
		<?php
			$category = get_the_category(); 
		?>
		<span class="cat"><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></span>
		<time class='date' datetime="<?php the_time('c'); ?>" itemprop="datePublished"><?php the_time('M jS, Y') ?></time>	
		<span class="info_comments"><a  href="<?php the_permalink(); ?>#comments" title="<?php comments_number(__('0 Comment','fb'),__('1 Comment','periodic'),__('% Comments','fb')); ?>"><?php comments_number(__('0 Comment','periodic'),__('1 Comment','periodic'),__('%Comments','fb')); ?> </a></span>	
		<span class="edit_link"><?php edit_post_link(); ?></span>
	</div>	

	<div class="post_date" itemprop="datePublished">
		<span class='pst_date'><?php the_time('j') ?></span>
		<span class='month'><?php the_time('M ') ?></span>			
		<span class='month year'><?php the_time('Y') ?></span>	
	</div>
</div>							
<?php
}
}

add_filter( 'genesis_entry_header', 'post_category',1);
function post_category() {
if ( is_single() ) {?>
<div class="catgory_section">	
<?php
$category = get_the_category(); 
?>
<h6><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></h6>	
</div>								
<?php
}
}

add_action( 'genesis_post_info', 'single_info_filter' );
function single_info_filter() {
if ( is_single() ) {?>
<div class="single_byline">
	<?php
		$category = get_the_category(); 
	?>
	<span class='author' itemprop="author"><?php the_author() ?></span>
	<time class='date' datetime="<?php the_time('c'); ?>" itemprop="datePublished"><?php the_time('M jS, Y') ?></time>
	<span class="info_comments"><a  href="<?php the_permalink(); ?>#comments" title="<?php comments_number(__('0 Comment','fb'),__('1 Comment','periodic'),__('% Comments','fb')); ?>"><?php comments_number(__('0 Comment','periodic'),__('1 Comment','periodic'),__('%Comments','fb')); ?> </a></span>	
	<span class="edit_link"><?php edit_post_link(); ?></span>
</div>								
<?php
}
}

// Customize the post meta function
add_filter('genesis_entry_footer', 'post_meta_filter',1);
function post_meta_filter() {
if ( is_single() ) {?>
<p class='post_tags' itemprop="keywords"> 
	<?php // Tag
		$posttags = get_the_tags();
		if ($posttags) {
		foreach($posttags as $tag) {
		echo "Tags : ";
		echo $tag->name .' '; 
		}
		}
	?>
</p>
<?php
}
}
   
  

/** Genesis Previous/Next Post Post Navigation */
add_action ('genesis_entry_footer','prev_next_post_nav',2);
function prev_next_post_nav(){
if ( is_single() ) {
echo '<div class="prev_next_navigation single_page_cnt">';?>
<div class="previous_post prev_next">
<?php
$prev_post = get_previous_post();
if (!empty( $prev_post )): ?>
  <a href="<?php echo get_permalink( $prev_post->ID ); ?>"><div class="ins_prestoryImage"><?php echo get_the_post_thumbnail($prev_post->ID, 'thumbnail', array(120,120)); ?></div><span><?php echo get_the_title( $prev_post->ID );?></span></a>
<?php endif; ?>
</div>
<div class="next_post prev_next">
<?php
$nextPost = get_next_post();
if (!empty( $nextPost )): ?>
  <a href="<?php echo get_permalink( $nextPost->ID ); ?>"><div class="prestoryImage"><?php echo get_the_post_thumbnail($nextPost->ID, 'thumbnail', array(120,120)); ?></div><span><?php echo get_the_title( $nextPost->ID );?></span></a>
<?php endif; ?>


</div>
<?php

echo '</div><!-- .prev-next-navigation -->';
}
}



add_action ('genesis_entry_content','post_read_more');
function post_read_more(){
if(!is_page()&&!is_single()){
if (genesism_get_option('read_more')){
?>
<div class="read_more">
	<a class="read_more_btn" href="<?php echo the_permalink(); ?>"><span><?php  echo (genesism_get_option('read_text'));?></span></a>
</div>
<?php 
}
}
}

add_action ('genesis_entry_footer','content_bottom');
function content_bottom(){
if(!is_page()&&!is_single()){ 
?>
<div class="content_bottom">
	<div class="author_block">
		<div class="author_avt">
			<?php echo get_avatar( get_the_author_meta( 'ID' ) , 50 ); ?>
		</div>
		<div class="author_name">
			<span><?php the_author() ?></span>
		</div>
	</div>
	<?php 
	if (genesism_get_option('social_share')){
	?>
	<div class="post_social_share">
		<div class="hme_post_social_share">
		<div class="hme_post_sharing">
		<i class="icon-share2"></i>
		<ul>
			<li class="share_tweet">
				<a href="http://twitter.com/share?text=<?php echo htmlspecialchars(urlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8')), ENT_COMPAT, 'UTF-8'); ?>&amp;url=<?php the_permalink(); ?>" target="_blank">
				<i class="icon-twitter icon"></i>
				</a>
			</li>
			<li class="share_fb">
				<a href="http://www.facebook.com/sharer.php?u=<?php the_permalink(); ?>&amp;t=<?php echo htmlspecialchars(urlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8')), ENT_COMPAT, 'UTF-8'); ?>" target="_blank">
				<i class="icon-facebook icon"></i>
				</a>
			</li>
			<li class="share_plus">
				<a href="https://plus.google.com/share?url=<?php the_permalink(); ?>" target="_blank" title="Click to share">
				<i class="icon-google icon"></i>
				</a>
			</li>
			<li class="share_linkedin">
				<a target="_blank" href="http://www.linkedin.com/shareArticle?mini=true&amp;url=<?php the_permalink(); ?>">
				<i class="icon-linkedin icon"></i>
				</a> 
			</li>
			<li class="share_pintrest">
				<a target="_blank" href="http://pinterest.com/pinthis?url=<?php the_permalink(); ?>&amp;title=<?php echo htmlspecialchars(urlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8')), ENT_COMPAT, 'UTF-8'); ?>">
				<i class="icon-pinterest icon"></i>
				</a>
			</li>
		</ul>
		</div>
		</div>
	</div>
	<?php 
	}
	?>
</div>
<?php 
}
}



add_action('genesis_entry_content','post_ad',2);
function post_ad(){
if(genesism_get_option('postadcheck')){
if ( is_single() ) {?>
		<div class="post-ad">
		<?php  echo stripslashes((genesism_get_option('postad')));?>
		</div>
        <?php
}
}
}


add_action( 'genesis_entry_footer', 'social_post',1);
function social_post(){
if(genesism_get_option('social_post_button')){
if ( is_single() ) {?>
<div class="sharing group sharing_social single_page_cnt">
	<div class="single_page_title">
		<h3><?php echo genesism_option('share_title'); ?></h3>
	</div>
<ul class="nav post-social single_page_social_share">
	
		<li class="share_tweet">
		<a href="http://twitter.com/share?text=<?php echo htmlspecialchars(urlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8')), ENT_COMPAT, 'UTF-8'); ?>&amp;url=<?php the_permalink(); ?>" target="_blank">
		<i class="single_share icon-twitter icon"></i>
		<span class="share_text">
		 Twitter
		</span>
		</a>
		</li>
		<li class="share_fb">
		<a href="http://www.facebook.com/sharer.php?u=<?php the_permalink(); ?>&amp;t=<?php echo htmlspecialchars(urlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8')), ENT_COMPAT, 'UTF-8'); ?>" target="_blank">
		<i class="single_share icon-facebook icon"></i>
		<span>
		 Facebook
		</span>
		</a>
		</li>
		<li class="share_plus">
		<a href="https://plus.google.com/share?url=<?php the_permalink(); ?>" target="_blank" title="Click to share">
		<i class="single_share icon-google-plus icon"></i>
		<span>
		 G-plus
		</span>
		</a>
		</li>
		<li class="share_linkedin">
		<a target="_blank" href="http://www.linkedin.com/shareArticle?mini=true&amp;url=<?php the_permalink(); ?>">
		<i class="single_share icon-linkedin icon"></i>
		<span>
		 Linkedin
		</span>
		</a> 
		</li>
		<li class="share_reddit">
		<a target="_blank" href="http://www.reddit.com/submit?url=<?php the_permalink(); ?>&amp;title=<?php echo htmlspecialchars(urlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8')), ENT_COMPAT, 'UTF-8'); ?>">
		<i class="single_share icon-reddit icon"></i>
		<span>
		 Reddit
		</span>
		</a>
		</li>
		<li class="share_pintrest">
		<a target="_blank" href="http://pinterest.com/pinthis?url=<?php the_permalink(); ?>&amp;title=<?php echo htmlspecialchars(urlencode(html_entity_decode(get_the_title(), ENT_COMPAT, 'UTF-8')), ENT_COMPAT, 'UTF-8'); ?>">
		<i class="single_share icon-pinterest icon"></i>
		<span>
		 Pintrest
		</span>
		</a>
		</li>		
	</ul>

</div>
<?php
}
}
}


	//Related Post Box

add_action( 'genesis_entry_footer', 'related_posts',4);
function related_posts(){

?>

<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Single Page Related Post Widget') ) : ?>
<div class="widget">
<h4 itemprop="headline"><?php _e("Single Page Related Post #Widget", 'genesis'); ?></h4>
<p><?php _e("Displays Single Page Realated Post with thumbnails.", 'genesis'); ?></p>
</div><!-- end .widget -->
<?php endif; ?> 
<?php
}



add_action('wp_head','color_box');
function color_box(){

$body_bg_color = get_option('body_bg_color');
$body_txt_color = get_option('body_txt_color');
$top_bg_color = get_option('top_bg_color');
$center_bg_color =get_option('center_bg_color');
$bottom_bg_color =get_option('bottom_bg_color');
$text1 =get_option('text1');
$text2 =get_option('text2');
$byline_color =get_option('byline_color');
$title_hover_color =get_option('title_hover_color');
$hover_bg_color =get_option('hover_bg_color');
$border_color =get_option('border_color');
$latest_bg =get_option('latest_bg');
$top_footer =get_option('top_footer');
$bottom_footer =get_option('bottom_footer');
$footer_text_color =get_option('footer_text_color');

?>
<style type="text/css">

body{
	background:<?php echo $body_bg_color; ?> ;
	color:<?php echo $body_txt_color; ?> ;
}
.last_updated ul li:before{
	color:<?php echo $body_txt_color; ?> ;
}
.top_header{
	background:<?php echo $top_bg_color; ?>;
}

.center_header{
	background:<?php echo $center_bg_color; ?>;
}

.bottom_header {
    background:<?php echo $bottom_bg_color; ?> ;
}

a,.line_title h3,.author_block .author_name,
.post_date .pst_date,.single_page_title h3,
.entry-title,.landingpage_feature1 h3,
.landingpage_feature_title h3,.entry-comments h3,
.archive-description h1,.wg-title,.sidebar .widget-title{
	color:<?php echo $text1; ?> ;
}

.bottom_feature_cnt p,.portfolio_btm_cnt span,.portfolio_btm_cnt time,.latest_cnt p,
.hme_byline span, .hme_byline span a{
	color:<?php echo $text2; ?> ;
}

.home_byline span, .single_byline span,
.home_byline span a,.single_byline span a,
.home_byline time, .single_byline time{
	color:<?php echo $byline_color; ?>;
}

a:hover,.menu a:hover,.team_social a:hover,
.hme_byline span a:hover,.read_btn:hover,
.read_more_btn:hover ,.hme_post_sharing li a:hover,
.sidebar_optin  input[type="submit"]:hover,
.catgory_section h6 a,.prev_next a ,.author_right_topcnt h3,
.landing_optin_cnt input[type="submit"]:hover,
.comment-form .form-submit input[type="submit"]:hover,
.error404 .entry-content .search-form input[type="submit"]:hover,.author-box h3{
	color:<?php echo $title_hover_color; ?> ;
}

.home_byline span a:hover, .single_byline span a:hover,.testimonial_cnt h2 a:hover,
.site-footer p a:hover{
	color:<?php echo $title_hover_color; ?>;
}

.menu li:hover,.menu li.current-menu-item{
	border-top-color:<?php echo $title_hover_color; ?> ;
}
.footer-widgets .widget-title:after{
	border-bottom-color:<?php echo $title_hover_color; ?> ;
}
.archive-pagination li a ,.comment-reply a{
	background:<?php echo $bottom_bg_color; ?> ;
}

.feature_cnt1:hover,.team_section .team-item .pop-overlay,
.team_section .team-item .team-pop ,.latest_img time,
.optin_section,.post_date .pst_date:after,
.wg-title span:before,.sidebar .tagcloud a:hover,
.landing_optin_cnt input[type="submit"],
.archive-pagination li a:hover, .archive-pagination .active a,
.footer_widget .tagcloud a:hover,.cbp-fwslider nav span:hover,
.cbp-fwdots span.cbp-fwcurrent,.cbp-fwdots span:hover,.sidebar .widget-title:before,
.widget_search .btn:hover,.comment-reply a:hover{
	background:<?php echo $hover_bg_color; ?> ;
}

.read_btn,.read_more_btn,.sidebar_optin  input[type="submit"],
.comment-form .form-submit input[type="submit"],
.error404 .entry-content .search-form input[type="submit"]{
	background:<?php echo $hover_bg_color; ?> ;
	border-color:<?php echo $hover_bg_color; ?> ;
}

.nav-link,.slider_readmore a,.image_overlay {
	background:<?php echo $hover_bg_color; ?>!important;
}
.nav-link:hover{
	background:<?php echo $bottom_bg_color; ?> !important;
}
.nav-link.active{
	background:<?php echo $bottom_bg_color; ?>!important;
}
.catgory_section h6 a{
	border-bottom-color:<?php echo $hover_bg_color; ?>;
}

.blog_inner1,.sidebar_widget,.landing_optin_inputs  input[type="text"],
.post_date,.author_social a,.hme_post_sharing li,.widget_search  input[type="text"],
.sidebar_optin input[type="text"],.single_page_social_share li,
.latest_news_sec,.sidebar .widget{
	border-color:<?php echo $border_color; ?> ;	
}

.blog_inner2,.widget_inner1,.single_byline,.hme_byline,.sidebar .widget-wrap {
	border-bottom-color:<?php echo $border_color; ?>;
	border-top-color:<?php echo $border_color; ?>;	
}
.menu .sub-menu li{
	border-top-color:<?php echo $border_color; ?> ;
}
.content_bottom {
	border-top-color:<?php echo $border_color; ?>;	
}

.blog_inner3,.widget_inner2,.single_page_title h3,.entry-comments h3,
.sidebar li,.popular_post_section{
	border-bottom-color:<?php echo $border_color; ?>;
}

.flickerplate,.line_under .line_center,.cbp-fwdots span {
	background:<?php echo $border_color; ?>;
}

.latest_news_sec,.portfolio_btm_cnt,#relatedposts li{
	background:<?php echo $latest_bg; ?> ;
}

.oi_tringle{
	border-bottom-color:<?php echo $latest_bg; ?>;
}

.footer-widgets{
	background:<?php echo $top_footer; ?> ;
}

.site-footer{
	background:<?php echo $bottom_footer; ?> ;
}

.footer-widgets, .footer-widgets a {
    color: <?php echo $footer_text_color; ?> ;
}

<?php echo genesism_option('custom_css'); ?>

</style>
<?php
}



add_action( 'wp_enqueue_scripts', 'enqueue_script' );
function enqueue_script() {	
	
	
	wp_enqueue_script( 'jquery.devrama.slider', get_stylesheet_directory_uri() . '/scripts/jquery.devrama.slider.js', array( 'jquery' ), '', true );
	wp_enqueue_script( 'modernizr.custom', get_stylesheet_directory_uri() . '/scripts/modernizr.custom.js', array( 'jquery' ), '', true );	
	wp_enqueue_script( 'jquery.flexslider-min', get_stylesheet_directory_uri() . '/scripts/jquery.flexslider-min.js', array( 'jquery' ), '', true );
	
	wp_enqueue_script( 'slider.min', get_stylesheet_directory_uri() . '/scripts/slider.js', array( 'jquery' ), '', true );
	wp_enqueue_script( 'main', get_stylesheet_directory_uri() . '/scripts/main.js', array( 'jquery' ), '', true );	
	wp_enqueue_script( 'menu', get_stylesheet_directory_uri() . '/scripts/menu.js', array( 'jquery' ), '', true );
	
}


add_action('wp_footer','script_box');
function script_box(){?>
<script type="text/javascript">
function loadScript(src) {
     var element = document.createElement("script");
     element.src = src;
     document.body.appendChild(element);
}
// Add a script element as a child of the body
function downloadJSAtOnload() {
}
 // Check for browser support of event handling capability
 if (window.addEventListener)
     window.addEventListener("load", downloadJSAtOnload, false);
	 else if (window.attachEvent)
     window.attachEvent("onload", downloadJSAtOnload);
 else window.onload = downloadJSAtOnload; 
 (function() {
      function getScript(url,success){
        var script=document.createElement('script');
        script.src=url;
        var head=document.getElementsByTagName('head')[0],
            done=false;
        script.onload=script.onreadystatechange = function(){
          if ( !done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete') ) {
            done=true;
            success();
            script.onload = script.onreadystatechange = null;
            head.removeChild(script);
          }
        };
        head.appendChild(script);
      }
        getScript('https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js',function(){
        });
    })();
</script>
<?php
}



// Auto Resize Image
function aq_resize( $url, $width, $height = null, $crop = null, $single = true ) {

//validate inputs
if(!$url OR !$width ) return false;

//define upload path & dir
$upload_info = wp_upload_dir();
$upload_dir = $upload_info['basedir'];
$upload_url = $upload_info['baseurl'];

//check if $img_url is local
if(strpos( $url, $upload_url ) === false) return false;

//define path of image
$rel_path = str_replace( $upload_url, '', $url);
$img_path = $upload_dir . $rel_path;

//check if img path exists, and is an image indeed
if( !file_exists($img_path) OR !getimagesize($img_path) ) return false;

//get image info
$info = pathinfo($img_path);
$ext = $info['extension'];
list($orig_w,$orig_h) = getimagesize($img_path);

//get image size after cropping
$dims = image_resize_dimensions($orig_w, $orig_h, $width, $height, $crop);
$dst_w = $dims[4];
$dst_h = $dims[5];

//use this to check if cropped image already exists, so we can return that instead
$suffix = "{$dst_w}x{$dst_h}";
$dst_rel_path = str_replace( '.'.$ext, '', $rel_path);
$destfilename = "{$upload_dir}{$dst_rel_path}-{$suffix}.{$ext}";

if(!$dst_h) {
//can't resize, so return original url
$img_url = $url;
$dst_w = $orig_w;
$dst_h = $orig_h;
}
//else check if cache exists
elseif(file_exists($destfilename) && getimagesize($destfilename)) {
$img_url = "{$upload_url}{$dst_rel_path}-{$suffix}.{$ext}";
}
//else, we resize the image and return the new resized image url
else {

// Note: This pre-3.5 fallback check will edited out in subsequent version
if(function_exists('wp_get_image_editor')) {

$editor = wp_get_image_editor($img_path);

if ( is_wp_error( $editor ) || is_wp_error( $editor->resize( $width, $height, $crop ) ) )
return false;

$resized_file = $editor->save();

if(!is_wp_error($resized_file)) {
$resized_rel_path = str_replace( $upload_dir, '', $resized_file['path']);
$img_url = $upload_url . $resized_rel_path;
} else {
return false;
}

} else {

$resized_img_path = image_resize( $img_path, $width, $height, $crop ); // Fallback foo
if(!is_wp_error($resized_img_path)) {
$resized_rel_path = str_replace( $upload_dir, '', $resized_img_path);
$img_url = $upload_url . $resized_rel_path;
} else {
return false;
}

}

}

//return the output
if($single) {
//str return
$image = $img_url;
} else {
//array return
$image = array (
0 => $img_url,
1 => $dst_w,
2 => $dst_h
);
}

return $image;
}


function catch_that_image() {
        global $post, $posts;
        $first_img = '';
        ob_start();
        ob_end_clean();
        $output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
        if(count($matches [1]))$first_img = $matches [1] [0];
        return $first_img;
}

 

// Add Post Feature image

add_action( 'genesis_entry_content', 'custom_post_featureimage', 1 );
function custom_post_featureimage() {
if(!is_page()&&!is_single()){  
?>
<div class="post_featured_img" itemprop="image">
<?php
 // Defaults
         $f_img_width = genesism_get_option('f_img_width');
        $f_img_height = genesism_get_option('f_img_height');
        $default_img =  'Feature_image'; 

		// Auto feature image defaults
		$thumb = get_post_thumbnail_id(); 
		$img_url = wp_get_attachment_url( $thumb,'full' ); 
		$image = aq_resize( $img_url, $f_img_width, $f_img_height, true );
		// Catch the Image defaults
        $catch_img_url = catch_that_image( $thumb,'full' );
        $catch_image = aq_resize( $catch_img_url, $f_img_width, $f_img_height, true );
        // Default Image
        $default_image = aq_resize( $default_img, $f_img_width, $f_img_height, true );
		if(has_post_thumbnail())
		echo
		"<div class=\"featured_image\">\n".
		"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width . "\" height=\"" . $f_img_height . "\" alt=\"" . get_the_title() . "\"></a>\n".
		"</div>\n";
		elseif (catch_that_image()){ 
		echo
		"<div class=\"featured_image\">\n".
		"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width . "\" height=\"" . $f_img_height . "\" alt=\"" . get_the_title() . "\"></a>\n".
		"</div>\n"; 
		} 
		/*featured image ends here*/
?>
</div>
<?php	
}      
}
 

//* Remove for custom background
 remove_custom_background();
 
 
 //All Genesis Lovers Widget Starts Here

//Last Updated Post Widget Starts Here
class gl_last_update_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_last_update_widget', 

__('Link - Last Updated Post', 'gl_last_update_widget_domain'), 

array( 'description' => __( 'Displays Last Updated Post', 'gl_last_update_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );

echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];

?>
<div class="last_updated_pst">
				<div class="last_updated ">
					<?php
						
						// Query Arguments
						$lastupdated_args = array(
						'orderby' => 'modified',
						);
						//Loop to display 5 recently updated posts
						$lastupdated_loop = new WP_Query( $lastupdated_args );
						$counter = 1;
						echo '<ul>';
						while( $lastupdated_loop->have_posts() && $counter <= $instance['post_count'] ) : $lastupdated_loop->the_post();
						echo '<li><a href="' . get_permalink( $lastupdated_loop->post->ID ) . '"> ' .get_the_title( $lastupdated_loop->post->ID ) . '</a> ( '. get_the_modified_date() .') </li>';
						$counter++;
						endwhile; 
						echo '</ul>';
						wp_reset_postdata(); 
						
					?>
				</div>
	
</div>

<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Last Updated Post', 'gl_last_update_widget_domain' );
}

 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '5', 'gl_last_update_widget_domain' );
}

?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>
<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
return $instance;
}
} 

//Last Updated Post Widget Ends Here

// Popular Widget Starts Here

class gl_popular_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_popular_widget', 

__('Link - Popular Post', 'gl_popular_widget_domain'), 

array( 'description' => __( 'Displays Popular Post', 'gl_popular_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );

echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];

?>

<div class="popular_post">
			
				<div class='popular_post_cnt sidebar_cnt'>
					<?php
						query_posts('post_type=post&posts_per_page='. $post_count .' &orderby=comment_count&order=DESC');
						while (have_posts()): the_post(); 
					?>
						<div class='popular_post_section entry_cnt'>
							<div class='popular_img' itemprop="image">
								<?php
									$f_img_width = $instance['width_size'];
									$f_img_height = $instance['height_size'];
									$default_img =  'Feature_image'; 

									// Auto feature image defaults
									$thumb = get_post_thumbnail_id(); 
									$img_url = wp_get_attachment_url( $thumb,'full' ); 
									$image = aq_resize( $img_url, $f_img_width, $f_img_height, true );
									// Catch the Image defaults
									$catch_img_url = catch_that_image( $thumb,'full' );
									$catch_image = aq_resize( $catch_img_url, $f_img_width, $f_img_height, true );
									if(has_post_thumbnail())
									echo
									"<div class=\"featured_image\">\n".
									"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width . "\" height=\"" . $f_img_height . "\" alt=\"" . get_the_title() . "\"></a><div class='img_hover'><a class=\"link\" href=\"" . get_permalink() . "\"></a></div>\n".
									"</div>\n";
									elseif (catch_that_image()){ 
									echo
									"<div class=\"featured_image\">\n".
									"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width . "\" height=\"" . $f_img_height . "\" alt=\"" . get_the_title() . "\"></a><div class='img_hover'><a class=\"link\" href=\"" . get_permalink() . "\"></a></div>\n".
									"</div>\n";  
									} 
								?>
							</div>
							<div class="popular_cnt">
								<h3 itemprop="headline"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a></h3>
								<time class='date' datetime="<?php the_time('c'); ?>" itemprop="datePublished"><?php the_time('M jS, Y') ?></time>
							</div>
						</div>
					<?php
						endwhile;
					?>
				</div>
	
</div>

<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Popular Post', 'gl_popular_widget_domain' );
}

 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '4', 'gl_popular_widget_domain' );
}

 if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '102', 'gl_popular_widget_domain' );
}

 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '80', 'gl_popular_widget_domain' );
}

?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>
<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';
return $instance;
}
}

//Popular Post Widget Ends Here

// About Us Widget Starts Here

class gl_aboutus_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_aboutus_widget', 

__('Link - About Us ', 'gl_aboutus_widget_domain'), 

array( 'description' => __( 'Displays About Us Content', 'gl_aboutus_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$about_us_img = apply_filters( 'about_us_img', $instance['about_us_img'] );
$aboutus_name = apply_filters( 'aboutus_name', $instance['aboutus_name'] );
$sb_aboutus_cnt = apply_filters( 'sb_aboutus_cnt', $instance['sb_aboutus_cnt'] );
$sb_aboutus_read = apply_filters( 'sb_aboutus_read', $instance['sb_aboutus_read'] );
$sb_aboutus_read_link = apply_filters( 'sb_aboutus_read_link', $instance['sb_aboutus_read_link'] );

echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];

?>
<div class='sidebar_about'>	

	<div class="sidebar_cnt">
		<img alt="<?php echo $instance['aboutus_name']; ?>" src="<?php echo $instance['about_us_img']; ?>"/>
		<h4><?php echo $instance['aboutus_name']; ?></h4>
		<p><?php echo $instance['sb_aboutus_cnt']; ?></p>
		<a class="read_more_btn" href="<?php echo $instance['sb_aboutus_read_link']; ?>"><span><?php echo $instance['sb_aboutus_read']; ?></span></a>
	</div>	
</div>
<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'About Us', 'gl_aboutus_widget_domain' );
}

 if ( isset( $instance[ 'about_us_img' ] ) ) {
$about_us_img = $instance[ 'about_us_img' ];
}
else {
$about_us_img = __( ' ', 'gl_aboutus_widget_domain' );
}

 if ( isset( $instance[ 'aboutus_name' ] ) ) {
$aboutus_name = $instance[ 'aboutus_name' ];
}
else {
$aboutus_name = __( '', 'gl_aboutus_widget_domain' );
}

 if ( isset( $instance[ 'sb_aboutus_cnt' ] ) ) {
$sb_aboutus_cnt = $instance[ 'sb_aboutus_cnt' ];
}
else {
$sb_aboutus_cnt = __( 'About Us Content', 'gl_aboutus_widget_domain' );
}

 if ( isset( $instance[ 'sb_aboutus_read' ] ) ) {
$sb_aboutus_read = $instance[ 'sb_aboutus_read' ];
}
else {
$sb_aboutus_read = __( 'Read More', 'gl_aboutus_widget_domain' );
}

 if ( isset( $instance[ 'sb_aboutus_read_link' ] ) ) {
$sb_aboutus_read_link = $instance[ 'sb_aboutus_read_link' ];
}
else {
$sb_aboutus_read_link = __( '', 'gl_aboutus_widget_domain' );
}

?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'About Us Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'about_us_img' ); ?>"><?php _e( 'About Us Image URL Link:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'about_us_img' ); ?>" name="<?php echo $this->get_field_name( 'about_us_img' ); ?>" type="text" value="<?php echo esc_attr( $about_us_img ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'aboutus_name' ); ?>"><?php _e( 'About Us Name:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'aboutus_name' ); ?>" name="<?php echo $this->get_field_name( 'aboutus_name' ); ?>" type="text" value="<?php echo esc_attr( $aboutus_name ); ?>"/>
</p>
<p>
<label for="<?php echo $this->get_field_id( 'sb_aboutus_cnt' ); ?>"><?php _e( 'About Us Content:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'sb_aboutus_cnt' ); ?>" name="<?php echo $this->get_field_name( 'sb_aboutus_cnt' ); ?>" type="text" value="<?php echo esc_attr( $sb_aboutus_cnt ); ?>"/>
</p>
<p>
<label for="<?php echo $this->get_field_id( 'sb_aboutus_read' ); ?>"><?php _e( 'About Us Readmore Text:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'sb_aboutus_read' ); ?>" name="<?php echo $this->get_field_name( 'sb_aboutus_read' ); ?>" type="text" value="<?php echo esc_attr( $sb_aboutus_read ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'sb_aboutus_read_link' ); ?>"><?php _e( 'About Us Readmore Text URL Link:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'sb_aboutus_read_link' ); ?>" name="<?php echo $this->get_field_name( 'sb_aboutus_read_link' ); ?>" type="text" value="<?php echo esc_attr( $sb_aboutus_read_link ); ?>" />
</p>
<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['about_us_img'] = ( ! empty( $new_instance['about_us_img'] ) ) ? strip_tags( $new_instance['about_us_img'] ) : '';
$instance['aboutus_name'] = ( ! empty( $new_instance['aboutus_name'] ) ) ? strip_tags( $new_instance['aboutus_name'] ) : '';
$instance['sb_aboutus_cnt'] = ( ! empty( $new_instance['sb_aboutus_cnt'] ) ) ? strip_tags( $new_instance['sb_aboutus_cnt'] ) : '';
$instance['sb_aboutus_read'] = ( ! empty( $new_instance['sb_aboutus_read'] ) ) ? strip_tags( $new_instance['sb_aboutus_read'] ) : '';
$instance['sb_aboutus_read_link'] = ( ! empty( $new_instance['sb_aboutus_read_link'] ) ) ? strip_tags( $new_instance['sb_aboutus_read_link'] ) : '';
return $instance;
}
}

// About Us Widget Ends Here


// Sidebar Search Widget Starts Here

class gl_sidebar_search_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_sidebar_search_widget', 

__('Link - Sidebar Search ', 'gl_sidebar_search_widget_domain'), 

array( 'description' => __( 'A Sidebar Search form for your site.', 'gl_sidebar_search_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$search_text1 = apply_filters( 'search_text1', $instance['search_text1'] );

echo $args['before_widget'];
if ( ! empty( $title ) )
echo $args['before_title'] . $title . $args['after_title'];

?>
<div class='widget_search'>
	<div class="sidebar_cnt">
		<form method='get' action='<?php echo get_bloginfo('home'); ?>'>
			<input type='text' placeholder='<?php echo $instance['search_text1']; ?>' name='s1' id='s1' />			
			<button type='submit' class='btn btn-success'>
			<i class='fa icon-search'></i>
			</button>
		</form>
	</div>
		
</div>
<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Search Box', 'gl_sidebar_search_widget_domain' );
}

 if ( isset( $instance[ 'search_text1' ] ) ) {
$search_text1 = $instance[ 'search_text1' ];
}
else {
$search_text1 = __( 'Search here...', 'gl_sidebar_search_widget_domain' );
}

 

?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'About Us Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'search_text1' ); ?>"><?php _e( 'Search Placeholder Name:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'search_text1' ); ?>" name="<?php echo $this->get_field_name( 'search_text1' ); ?>" type="text" value="<?php echo esc_attr( $search_text1 ); ?>" />
</p>

<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['search_text1'] = ( ! empty( $new_instance['search_text1'] ) ) ? strip_tags( $new_instance['search_text1'] ) : '';
return $instance;
}
}

// Sidebar Search Widget Ends Here

// Realated Post Widget Starts Here

class gl_related_post_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_related_post_widget', 

__('Link - Realated Post', 'gl_related_post_widget_domain'), 

array( 'description' => __( 'Displays Realated Post', 'gl_related_post_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );


echo $args['before_widget'];
if ( ! empty( $title ) )
/*echo $args['before_title'] . $title . $args['after_title'];*/

?>
<?php
global $post;
$ads .= '<div class="thesis_related ">';
	if ( is_single() ) {
		$tags = get_the_tags($post->ID);
			if ($tags) {
			$tag_ids = array();
			foreach($tags as $individual_tag) $tag_ids[] = $individual_tag->term_id;
			$args=array(
			'tag__in' => $tag_ids,
			'post__not_in' => array($post->ID),
			'showposts'=>$instance['post_count'],  // Number of related posts that will be shown.
			'caller_get_posts'=>1
			);
	$my_query = new wp_query($args);
			if( $my_query->have_posts() ) {
		echo '<div id="relatedposts" class="single_page_cnt">';
		?>
		<div class="single_page_title">
			<h3><?php echo $instance['title']; ?></h3>
		</div>	
		<?php echo '<ul>';
		while ($my_query->have_posts()) {
			$my_query->the_post();
	if ( has_post_thumbnail() ) { ?>
			<li>
			
			<div class="related-posts-box" itemscope="itemscope" itemtype="http://schema.org/blogposting">
					<div class="related_image" itemprop="image">
					<?php
						// Defaults
						$f_img_width1 = $instance['width_size'];
						$f_img_height1 = $instance['height_size'];
						$default_img =  'Feature_image'; 

						// Auto feature image defaults
						$thumb = get_post_thumbnail_id(); 
						$img_url = wp_get_attachment_url( $thumb,'full' ); 
						$image = aq_resize( $img_url,$f_img_width1,$f_img_height1, true );
						// Catch the Image defaults
						$catch_img_url = catch_that_image( $thumb,'full' );
						$catch_image = aq_resize( $catch_img_url, $f_img_width1, $f_img_height1, true );
						// Default Image
						$default_image = aq_resize( $default_img, $f_img_width1, $f_img_height1, true );
								
						if(has_post_thumbnail())
						echo
						"<div class=\"featured_image\">\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width1 . "\" height=\"" . $f_img_height1 . "\" alt=\"" . get_the_title() . "\"></a>\n".
						"</div>\n";
						elseif (catch_that_image()){ 
						echo
						"<div class=\"featured_image\">\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width1 . "\" height=\"" . $f_img_height1 . "\" alt=\"" . get_the_title() . "\"></a>\n".
						"</div>\n"; 
						} 
						?>
						</div>
			<div class="related_post_btm">			
			<h4 itemprop="headline"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h4>
			<time class='date' datetime="<?php the_time('c'); ?>" itemprop="datePublished"><?php the_time('M jS, Y') ?></time>
			</div>
			</div>
			</li>
			<?php } else { ?>
		<li><div class="relatedthumb"><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><img src="<?php echo get_post_meta($post->ID, 'Image',true) ?>" width="100" height="100" alt="<?php the_title_attribute(); ?>" /><?php the_title(); ?></a></div></li>
			<?php }
			?>
	<?php
			}
			echo '</ul>';
			echo '</div>';
			}
		}
	$post = $backup;
			wp_reset_query();
			?>
			<div class="clear"></div>
			<?php
			 }
		$ads .= '</div>';
		echo $ads;
		

?>
<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {
if ( isset( $instance[ 'title' ] ) ) {
$title = $instance[ 'title' ];
}
else {
$title = __( 'Related Post', 'gl_related_post_widget_domain' );
}

 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '4', 'gl_related_post_widget_domain' );
}

 if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '178', 'gl_related_post_widget_domain' );
}

 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '150', 'gl_related_post_widget_domain' );
}


?>
<p>
<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
</p>


<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>



<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';


return $instance;
}
}

//Realated Post Widget Ends Here


// Slider Section Widget Starts Here

class gl_slider_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_slider_widget', 

__('Link - Slider Section', 'gl_slider_widget_domain'), 

array( 'description' => __( 'Displays Slider Section0', 'gl_slider_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$slider_img1 = apply_filters( 'slider_img1', $instance['slider_img1'] );
$slider_title1 = apply_filters( 'slider_title1', $instance['slider_title1'] );
$slider_cnt1 = apply_filters( 'slider_cnt1', $instance['slider_cnt1'] );
$slider_readmore1 = apply_filters( 'slider_readmore1', $instance['slider_readmore1'] );
$slider_readmore_link1 = apply_filters( 'slider_readmore_link1', $instance['slider_readmore_link1'] );

$slider_img2 = apply_filters( 'slider_img2', $instance['slider_img2'] );
$slider_title2 = apply_filters( 'slider_title2', $instance['slider_title2'] );
$slider_cnt2 = apply_filters( 'slider_cnt2', $instance['slider_cnt2'] );
$slider_readmore2 = apply_filters( 'slider_readmore2', $instance['slider_readmore2'] );
$slider_readmore_link2 = apply_filters( 'slider_readmore_link2', $instance['slider_readmore_link2'] );

$slider_img3 = apply_filters( 'slider_img3', $instance['slider_img3'] );
$slider_title3 = apply_filters( 'slider_title3', $instance['slider_title3'] );
$slider_cnt3 = apply_filters( 'slider_cnt3', $instance['slider_cnt3'] );
$slider_readmore3 = apply_filters( 'slider_readmore3', $instance['slider_readmore3'] );
$slider_readmore_link3 = apply_filters( 'slider_readmore_link3', $instance['slider_readmore_link3'] );

$slider_img4 = apply_filters( 'slider_img4', $instance['slider_img4'] );
$slider_title4 = apply_filters( 'slider_title4', $instance['slider_title4'] );
$slider_cnt4 = apply_filters( 'slider_cnt4', $instance['slider_cnt4'] );
$slider_readmore4 = apply_filters( 'slider_readmore4', $instance['slider_readmore4'] );
$slider_readmore_link4 = apply_filters( 'slider_readmore_link4', $instance['slider_readmore_link4'] );

echo $args['before_widget'];
if ( ! empty( $title ) )
/*echo $args['before_title'] . $title . $args['after_title'];*/

?>

<div class="slider_box">
	<div class="example-animation">
            <div data-lazy-background="<?php echo $instance['slider_img1']; ?>">
                <h3 data-pos="['0%', '110%', '15%', '15%']" data-duration="700" data-effect="move">
                    <?php echo $instance['slider_title1']; ?>
                </h3>
                <div data-pos="['-30%', '25%', '40%', '15%']" data-duration="700" data-effect="move">
                   <p> <?php echo $instance['slider_cnt1']; ?></p>
                </div>
                <div data-pos="['56%', '-40%', '60%', '15%']" data-duration="700" data-effect="move">
                    <div class="slider_readmore">
						<a class="btn_read" href="<?php echo $instance['slider_readmore_link1']; ?>"><?php echo $instance['slider_readmore1']; ?></a>
					</div>
                </div>
               
            </div>
             <div data-lazy-background="<?php echo $instance['slider_img2']; ?>">
                <h3 data-pos="['0%', '110%', '15%', '15%']" data-duration="700" data-effect="move">
                    <?php echo $instance['slider_title2']; ?>
                </h3>
                <div data-pos="['-30%', '25%', '40%', '15%']" data-duration="700" data-effect="move">
                    <p><?php echo $instance['slider_cnt2']; ?></p>
                </div>
                <div data-pos="['56%', '-40%', '60%', '15%']" data-duration="700" data-effect="move">
                    <div class="slider_readmore">
						<a class="btn_read" href="<?php echo $instance['slider_readmore_link2']; ?>"><?php echo $instance['slider_readmore2']; ?></a>
					</div>
                </div>
               
            </div>
			 <div data-lazy-background="<?php echo $instance['slider_img3']; ?>">
                <h3 data-pos="['0%', '110%', '15%', '15%']" data-duration="700" data-effect="move">
                    <?php echo $instance['slider_title3']; ?>
                </h3>
                <div data-pos="['-30%', '25%', '40%', '15%']" data-duration="700" data-effect="move">
                    <p><?php echo $instance['slider_cnt3']; ?></p>
                </div>
                <div data-pos="['56%', '-40%', '60%', '15%']" data-duration="700" data-effect="move">
                    <div class="slider_readmore">
						<a class="btn_read" href="<?php echo $instance['slider_readmore_link3']; ?>"><?php echo $instance['slider_readmore3']; ?></a>
					</div>
                </div>
               
            </div>
			 <div data-lazy-background="<?php echo $instance['slider_img4']; ?>">
                <h3 data-pos="['0%', '110%', '15%', '15%']" data-duration="700" data-effect="move">
                    <?php echo $instance['slider_title4']; ?>
                </h3>
                <div data-pos="['-30%', '25%', '40%', '15%']" data-duration="700" data-effect="move">
                    <p><?php echo $instance['slider_cnt4']; ?></p>
                </div>
                <div data-pos="['56%', '-40%', '60%', '15%']" data-duration="700" data-effect="move">
                    <div class="slider_readmore">
						<a class="btn_read" href="<?php echo $instance['slider_readmore_link4']; ?>"><?php echo $instance['slider_readmore4']; ?></a>
					</div>
                </div>
               
            </div>
             
        </div>        
</div>

<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {


 if ( isset( $instance[ 'slider_img1' ] ) ) {
$slider_img1 = $instance[ 'slider_img1' ];
}
else {
$slider_img1 = __( '', 'gl_slider_widget_domain' );
}

 if ( isset( $instance[ 'slider_title1' ] ) ) {
$slider_title1 = $instance[ 'slider_title1' ];
}
else {
$slider_title1 = __( '', 'gl_slider_widget_domain' );
}

 if ( isset( $instance[ 'slider_cnt1' ] ) ) {
$slider_cnt1 = $instance[ 'slider_cnt1' ];
}
else {
$slider_cnt1 = __( '', 'gl_slider_widget_domain' );
}

 if ( isset( $instance[ 'slider_readmore1' ] ) ) {
$slider_readmore1 = $instance[ 'slider_readmore1' ];
}
else {
$slider_readmore1 = __( 'View More', 'gl_slider_widget_domain' );
}


 if ( isset( $instance[ 'slider_readmore_link1' ] ) ) {
$slider_readmore_link1 = $instance[ 'slider_readmore_link1' ];
}
else {
$slider_readmore_link1 = __( '', 'gl_slider_widget_domain' );
}


if ( isset( $instance[ 'slider_img2' ] ) ) {
$slider_img2 = $instance[ 'slider_img2' ];
}
else {
$slider_img2 = __( '', 'gl_slider_widget_domain' );
}

 if ( isset( $instance[ 'slider_title2' ] ) ) {
$slider_title2 = $instance[ 'slider_title2' ];
}
else {
$slider_title2 = __( '', 'gl_slider_widget_domain' );
}

 if ( isset( $instance[ 'slider_cnt2' ] ) ) {
$slider_cnt2 = $instance[ 'slider_cnt2' ];
}
else {
$slider_cnt2 = __( '', 'gl_slider_widget_domain' );
}

 if ( isset( $instance[ 'slider_readmore2' ] ) ) {
$slider_readmore2 = $instance[ 'slider_readmore2' ];
}
else {
$slider_readmore2 = __( 'View More', 'gl_slider_widget_domain' );
}


 if ( isset( $instance[ 'slider_readmore_link2' ] ) ) {
$slider_readmore_link2 = $instance[ 'slider_readmore_link2' ];
}
else {
$slider_readmore_link2 = __( '', 'gl_slider_widget_domain' );
}

if ( isset( $instance[ 'slider_img3' ] ) ) {
$slider_img3 = $instance[ 'slider_img3' ];
}
else {
$slider_img3 = __( '', 'gl_slider_widget_domain' );
}

 if ( isset( $instance[ 'slider_title3' ] ) ) {
$slider_title3 = $instance[ 'slider_title3' ];
}
else {
$slider_title3 = __( '', 'gl_slider_widget_domain' );
}

 if ( isset( $instance[ 'slider_cnt3' ] ) ) {
$slider_cnt3 = $instance[ 'slider_cnt3' ];
}
else {
$slider_cnt3 = __( '', 'gl_slider_widget_domain' );
}

 if ( isset( $instance[ 'slider_readmore3' ] ) ) {
$slider_readmore3 = $instance[ 'slider_readmore3' ];
}
else {
$slider_readmore3 = __( 'View More', 'gl_slider_widget_domain' );
}


 if ( isset( $instance[ 'slider_readmore_link3' ] ) ) {
$slider_readmore_link3 = $instance[ 'slider_readmore_link3' ];
}
else {
$slider_readmore_link3 = __( '', 'gl_slider_widget_domain' );
}

 if ( isset( $instance[ 'slider_img4' ] ) ) {
$slider_img4 = $instance[ 'slider_img4' ];
}
else {
$slider_img4 = __( '', 'gl_slider_widget_domain' );
}

 if ( isset( $instance[ 'slider_title4' ] ) ) {
$slider_title4 = $instance[ 'slider_title4' ];
}
else {
$slider_title4 = __( '', 'gl_slider_widget_domain' );
}

 if ( isset( $instance[ 'slider_cnt4' ] ) ) {
$slider_cnt4 = $instance[ 'slider_cnt4' ];
}
else {
$slider_cnt4 = __( '', 'gl_slider_widget_domain' );
}

 if ( isset( $instance[ 'slider_readmore4' ] ) ) {
$slider_readmore4 = $instance[ 'slider_readmore4' ];
}
else {
$slider_readmore4 = __( 'View More', 'gl_slider_widget_domain' );
}

 if ( isset( $instance[ 'slider_readmore_link4' ] ) ) {
$slider_readmore_link4 = $instance[ 'slider_readmore_link4' ];
}
else {
$slider_readmore_link4 = __( '', 'gl_slider_widget_domain' );
}


?>

<p>
<label for="<?php echo $this->get_field_id( 'slider_img1' ); ?>"><?php _e( 'Slider Image One URL Link:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'slider_img1' ); ?>" name="<?php echo $this->get_field_name( 'slider_img1' ); ?>" type="text" value="<?php echo esc_attr( $slider_img1 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'slider_title1' ); ?>"><?php _e( 'Slider Title One:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'slider_title1' ); ?>" name="<?php echo $this->get_field_name( 'slider_title1' ); ?>" type="text" value="<?php echo esc_attr( $slider_title1 ); ?>" />
</p>


<p>
<label for="<?php echo $this->get_field_id( 'slider_cnt1' ); ?>"><?php _e( 'Slider Content One:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'slider_cnt1' ); ?>" name="<?php echo $this->get_field_name( 'slider_cnt1' ); ?>" type="text" value="<?php echo esc_attr( $slider_cnt1 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'slider_readmore1' ); ?>"><?php _e( 'Slider Read More Text One:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'slider_readmore1' ); ?>" name="<?php echo $this->get_field_name( 'slider_readmore1' ); ?>" type="text" value="<?php echo esc_attr( $slider_readmore1 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'slider_readmore_link1' ); ?>"><?php _e( 'Slider Read More Text One URL Link:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'slider_readmore_link1' ); ?>" name="<?php echo $this->get_field_name( 'slider_readmore_link1' ); ?>" type="text" value="<?php echo esc_attr( $slider_readmore_link1 ); ?>" />
</p>


<p>
<label for="<?php echo $this->get_field_id( 'slider_img2' ); ?>"><?php _e( 'Slider Image Two URL Link:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'slider_img2' ); ?>" name="<?php echo $this->get_field_name( 'slider_img2' ); ?>" type="text" value="<?php echo esc_attr( $slider_img2 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'slider_title2' ); ?>"><?php _e( 'Slider Title Two:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'slider_title2' ); ?>" name="<?php echo $this->get_field_name( 'slider_title2' ); ?>" type="text" value="<?php echo esc_attr( $slider_title2 ); ?>" />
</p>


<p>
<label for="<?php echo $this->get_field_id( 'slider_cnt2' ); ?>"><?php _e( 'Slider Content Two:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'slider_cnt2' ); ?>" name="<?php echo $this->get_field_name( 'slider_cnt2' ); ?>" type="text" value="<?php echo esc_attr( $slider_cnt2 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'slider_readmore2' ); ?>"><?php _e( 'Slider Read More Text Two:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'slider_readmore2' ); ?>" name="<?php echo $this->get_field_name( 'slider_readmore2' ); ?>" type="text" value="<?php echo esc_attr( $slider_readmore2 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'slider_readmore_link2' ); ?>"><?php _e( 'Slider Read More Text Two URL Link:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'slider_readmore_link2' ); ?>" name="<?php echo $this->get_field_name( 'slider_readmore_link2' ); ?>" type="text" value="<?php echo esc_attr( $slider_readmore_link2 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'slider_img3' ); ?>"><?php _e( 'Slider Image Three URL Link:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'slider_img3' ); ?>" name="<?php echo $this->get_field_name( 'slider_img3' ); ?>" type="text" value="<?php echo esc_attr( $slider_img3 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'slider_title3' ); ?>"><?php _e( 'Slider Title Three:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'slider_title3' ); ?>" name="<?php echo $this->get_field_name( 'slider_title3' ); ?>" type="text" value="<?php echo esc_attr( $slider_title3 ); ?>" />
</p>


<p>
<label for="<?php echo $this->get_field_id( 'slider_cnt3' ); ?>"><?php _e( 'Slider Content Three:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'slider_cnt3' ); ?>" name="<?php echo $this->get_field_name( 'slider_cnt3' ); ?>" type="text" value="<?php echo esc_attr( $slider_cnt3 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'slider_readmore3' ); ?>"><?php _e( 'Slider Read More Text Three:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'slider_readmore3' ); ?>" name="<?php echo $this->get_field_name( 'slider_readmore3' ); ?>" type="text" value="<?php echo esc_attr( $slider_readmore3 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'slider_readmore_link3' ); ?>"><?php _e( 'Slider Read More Text Three URL Link:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'slider_readmore_link3' ); ?>" name="<?php echo $this->get_field_name( 'slider_readmore_link3' ); ?>" type="text" value="<?php echo esc_attr( $slider_readmore_link3 ); ?>" />
</p>


<p>
<label for="<?php echo $this->get_field_id( 'slider_img4' ); ?>"><?php _e( 'Slider Image Four URL Link:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'slider_img4' ); ?>" name="<?php echo $this->get_field_name( 'slider_img4' ); ?>" type="text" value="<?php echo esc_attr( $slider_img4 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'slider_title4' ); ?>"><?php _e( 'Slider Title Four:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'slider_title4' ); ?>" name="<?php echo $this->get_field_name( 'slider_title4' ); ?>" type="text" value="<?php echo esc_attr( $slider_title4 ); ?>" />
</p>


<p>
<label for="<?php echo $this->get_field_id( 'slider_cnt4' ); ?>"><?php _e( 'Slider Content Four:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'slider_cnt4' ); ?>" name="<?php echo $this->get_field_name( 'slider_cnt4' ); ?>" type="text" value="<?php echo esc_attr( $slider_cnt4 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'slider_readmore4' ); ?>"><?php _e( 'Slider Read More Text Four:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'slider_readmore4' ); ?>" name="<?php echo $this->get_field_name( 'slider_readmore4' ); ?>" type="text" value="<?php echo esc_attr( $slider_readmore4 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'slider_readmore_link4' ); ?>"><?php _e( 'Slider Read More Text Four URL Link:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'slider_readmore_link4' ); ?>" name="<?php echo $this->get_field_name( 'slider_readmore_link4' ); ?>" type="text" value="<?php echo esc_attr( $slider_readmore_link4 ); ?>" />
</p>

<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['slider_img1'] = ( ! empty( $new_instance['slider_img1'] ) ) ? strip_tags( $new_instance['slider_img1'] ) : '';
$instance['slider_title1'] = ( ! empty( $new_instance['slider_title1'] ) ) ? strip_tags( $new_instance['slider_title1'] ) : '';
$instance['slider_cnt1'] = ( ! empty( $new_instance['slider_cnt1'] ) ) ? strip_tags( $new_instance['slider_cnt1'] ) : '';
$instance['slider_readmore1'] = ( ! empty( $new_instance['slider_readmore1'] ) ) ? strip_tags( $new_instance['slider_readmore1'] ) : '';
$instance['slider_readmore_link1'] = ( ! empty( $new_instance['slider_readmore_link1'] ) ) ? strip_tags( $new_instance['slider_readmore_link1'] ) : '';

$instance['slider_img2'] = ( ! empty( $new_instance['slider_img2'] ) ) ? strip_tags( $new_instance['slider_img2'] ) : '';
$instance['slider_title2'] = ( ! empty( $new_instance['slider_title2'] ) ) ? strip_tags( $new_instance['slider_title2'] ) : '';
$instance['slider_cnt2'] = ( ! empty( $new_instance['slider_cnt2'] ) ) ? strip_tags( $new_instance['slider_cnt2'] ) : '';
$instance['slider_readmore2'] = ( ! empty( $new_instance['slider_readmore2'] ) ) ? strip_tags( $new_instance['slider_readmore2'] ) : '';
$instance['slider_readmore_link2'] = ( ! empty( $new_instance['slider_readmore_link2'] ) ) ? strip_tags( $new_instance['slider_readmore_link2'] ) : '';

$instance['slider_img3'] = ( ! empty( $new_instance['slider_img3'] ) ) ? strip_tags( $new_instance['slider_img3'] ) : '';
$instance['slider_title3'] = ( ! empty( $new_instance['slider_title3'] ) ) ? strip_tags( $new_instance['slider_title3'] ) : '';
$instance['slider_cnt3'] = ( ! empty( $new_instance['slider_cnt3'] ) ) ? strip_tags( $new_instance['slider_cnt3'] ) : '';
$instance['slider_readmore3'] = ( ! empty( $new_instance['slider_readmore3'] ) ) ? strip_tags( $new_instance['slider_readmore3'] ) : '';
$instance['slider_readmore_link3'] = ( ! empty( $new_instance['slider_readmore_link3'] ) ) ? strip_tags( $new_instance['slider_readmore_link3'] ) : '';

$instance['slider_img4'] = ( ! empty( $new_instance['slider_img4'] ) ) ? strip_tags( $new_instance['slider_img4'] ) : '';
$instance['slider_title4'] = ( ! empty( $new_instance['slider_title4'] ) ) ? strip_tags( $new_instance['slider_title4'] ) : '';
$instance['slider_cnt4'] = ( ! empty( $new_instance['slider_cnt4'] ) ) ? strip_tags( $new_instance['slider_cnt4'] ) : '';
$instance['slider_readmore4'] = ( ! empty( $new_instance['slider_readmore4'] ) ) ? strip_tags( $new_instance['slider_readmore4'] ) : '';
$instance['slider_readmore_link4'] = ( ! empty( $new_instance['slider_readmore_link4'] ) ) ? strip_tags( $new_instance['slider_readmore_link4'] ) : '';

return $instance;
}
}

//Slider section Widget Ends Here

// Services Section Widget Starts Here

class gl_services_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_services_widget', 

__('Link - Services Section', 'gl_services_widget_domain'), 

array( 'description' => __( 'Displays Services Section0', 'gl_services_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$title = apply_filters( 'widget_title', $instance['title'] );
$services_title = apply_filters( 'services_title', $instance['services_title'] );
$services_cnt = apply_filters( 'services_cnt', $instance['services_cnt'] );
$services_img = apply_filters( 'services_img', $instance['services_img'] );
$services_title1 = apply_filters( 'services_title1', $instance['services_title1'] );
$services_subtitle1 = apply_filters( 'services_subtitle1', $instance['services_subtitle1'] );
$services_subtitle2 = apply_filters( 'services_subtitle2', $instance['services_subtitle2'] );
$services_subtitle3 = apply_filters( 'services_subtitle3', $instance['services_subtitle3'] );
$services_subtitle4 = apply_filters( 'services_subtitle4', $instance['services_subtitle4'] );
$services_subtitle5 = apply_filters( 'services_subtitle5', $instance['services_subtitle5'] );
$services_subtitle6 = apply_filters( 'services_subtitle6', $instance['services_subtitle6'] );

echo $args['before_widget'];
if ( ! empty( $title ) )
/*echo $args['before_title'] . $title . $args['after_title'];*/

?>
<div class="services_box">
	<div class="services_box_section wrap">
		<div class="line_title">
			<h3><?php echo $instance['services_title']; ?></h3>
			<p><?php echo $instance['services_cnt']; ?></p>
			<div class="line_under"><div class="line_center"></div></div>
			<div class="line_under below_line"><div class="line_center"></div></div>
		</div>
		<div class="services_cnt">
			<div class="left_services">
				<img alt="<?php echo $instance['services_title1']; ?>" src="<?php echo $instance['services_img']; ?>"/>
			</div>
			<div class="right_services">
				<h3><?php echo $instance['services_title1']; ?></h3>
					<ul>
						<li><?php echo $instance['services_subtitle1']; ?></li>
						<li><?php echo $instance['services_subtitle2']; ?></li>
						<li><?php echo $instance['services_subtitle3']; ?></li>
						<li><?php echo $instance['services_subtitle4']; ?></li>
						<li><?php echo $instance['services_subtitle5']; ?></li>
						<li><?php echo $instance['services_subtitle6']; ?></li>
					</ul>
			</div>
		</div>
	</div>
</div>

<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {


 if ( isset( $instance[ 'services_title' ] ) ) {
$services_title = $instance[ 'services_title' ];
}
else {
$services_title = __( '', 'gl_services_widget_domain' );
}

 if ( isset( $instance[ 'services_cnt' ] ) ) {
$services_cnt = $instance[ 'services_cnt' ];
}
else {
$services_cnt = __( '', 'gl_services_widget_domain' );
}

 if ( isset( $instance[ 'services_img' ] ) ) {
$services_img = $instance[ 'services_img' ];
}
else {
$services_img = __( '', 'gl_services_widget_domain' );
}

 if ( isset( $instance[ 'services_title1' ] ) ) {
$services_title1 = $instance[ 'services_title1' ];
}
else {
$services_title1 = __( '', 'gl_services_widget_domain' );
}


 if ( isset( $instance[ 'services_subtitle1' ] ) ) {
$services_subtitle1 = $instance[ 'services_subtitle1' ];
}
else {
$services_subtitle1 = __( '', 'gl_services_widget_domain' );
}


if ( isset( $instance[ 'services_subtitle2' ] ) ) {
$services_subtitle2 = $instance[ 'services_subtitle2' ];
}
else {
$services_subtitle2 = __( '', 'gl_services_widget_domain' );
}


 if ( isset( $instance[ 'services_subtitle3' ] ) ) {
$services_subtitle3 = $instance[ 'services_subtitle3' ];
}
else {
$services_subtitle3 = __( '', 'gl_services_widget_domain' );
}

 if ( isset( $instance[ 'services_subtitle4' ] ) ) {
$services_subtitle4 = $instance[ 'services_subtitle4' ];
}
else {
$services_subtitle4 = __( '', 'gl_services_widget_domain' );
}


 if ( isset( $instance[ 'services_subtitle5' ] ) ) {
$services_subtitle5 = $instance[ 'services_subtitle5' ];
}
else {
$services_subtitle5 = __( '', 'gl_services_widget_domain' );
}

if ( isset( $instance[ 'services_subtitle6' ] ) ) {
$services_subtitle6 = $instance[ 'services_subtitle6' ];
}
else {
$services_subtitle6 = __( '', 'gl_services_widget_domain' );
}


?>

<p>
<label for="<?php echo $this->get_field_id( 'services_title' ); ?>"><?php _e( 'Services Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'services_title' ); ?>" name="<?php echo $this->get_field_name( 'services_title' ); ?>" type="text" value="<?php echo esc_attr( $services_title ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'services_cnt' ); ?>"><?php _e( 'Services Content:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'services_cnt' ); ?>" name="<?php echo $this->get_field_name( 'services_cnt' ); ?>" type="text" value="<?php echo esc_attr( $services_cnt ); ?>" />
</p>


<p>
<label for="<?php echo $this->get_field_id( 'services_img' ); ?>"><?php _e( 'Services Image URL Link:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'services_img' ); ?>" name="<?php echo $this->get_field_name( 'services_img' ); ?>" type="text" value="<?php echo esc_attr( $services_img ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'services_title1' ); ?>"><?php _e( 'Services Content Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'services_title1' ); ?>" name="<?php echo $this->get_field_name( 'services_title1' ); ?>" type="text" value="<?php echo esc_attr( $services_title1 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'services_subtitle1' ); ?>"><?php _e( 'Services Content Subtitle1:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'services_subtitle1' ); ?>" name="<?php echo $this->get_field_name( 'services_subtitle1' ); ?>" type="text" value="<?php echo esc_attr( $services_subtitle1 ); ?>" />
</p>


<p>
<label for="<?php echo $this->get_field_id( 'services_subtitle2' ); ?>"><?php _e( 'Services Content Subtitle2:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'services_subtitle2' ); ?>" name="<?php echo $this->get_field_name( 'services_subtitle2' ); ?>" type="text" value="<?php echo esc_attr( $services_subtitle2 ); ?>" />
</p>


<p>
<label for="<?php echo $this->get_field_id( 'services_subtitle3' ); ?>"><?php _e( 'Services Content Subtitle3:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'services_subtitle3' ); ?>" name="<?php echo $this->get_field_name( 'services_subtitle3' ); ?>" type="text" value="<?php echo esc_attr( $services_subtitle3 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'services_subtitle4' ); ?>"><?php _e( 'Services Content Subtitle4:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'services_subtitle4' ); ?>" name="<?php echo $this->get_field_name( 'services_subtitle4' ); ?>" type="text" value="<?php echo esc_attr( $services_subtitle4 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'services_subtitle5' ); ?>"><?php _e( 'Services Content Subtitle5:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'services_subtitle5' ); ?>" name="<?php echo $this->get_field_name( 'services_subtitle5' ); ?>" type="text" value="<?php echo esc_attr( $services_subtitle5 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'services_subtitle6' ); ?>"><?php _e( 'Services Content Subtitle6:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'services_subtitle6' ); ?>" name="<?php echo $this->get_field_name( 'services_subtitle6' ); ?>" type="text" value="<?php echo esc_attr( $services_subtitle6 ); ?>" />
</p>


<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['services_title'] = ( ! empty( $new_instance['services_title'] ) ) ? strip_tags( $new_instance['services_title'] ) : '';
$instance['services_cnt'] = ( ! empty( $new_instance['services_cnt'] ) ) ? strip_tags( $new_instance['services_cnt'] ) : '';
$instance['services_img'] = ( ! empty( $new_instance['services_img'] ) ) ? strip_tags( $new_instance['services_img'] ) : '';
$instance['services_title1'] = ( ! empty( $new_instance['services_title1'] ) ) ? strip_tags( $new_instance['services_title1'] ) : '';
$instance['services_subtitle1'] = ( ! empty( $new_instance['services_subtitle1'] ) ) ? strip_tags( $new_instance['services_subtitle1'] ) : '';
$instance['services_subtitle2'] = ( ! empty( $new_instance['services_subtitle2'] ) ) ? strip_tags( $new_instance['services_subtitle2'] ) : '';
$instance['services_subtitle3'] = ( ! empty( $new_instance['services_subtitle3'] ) ) ? strip_tags( $new_instance['services_subtitle3'] ) : '';
$instance['services_subtitle4'] = ( ! empty( $new_instance['services_subtitle4'] ) ) ? strip_tags( $new_instance['services_subtitle4'] ) : '';
$instance['services_subtitle5'] = ( ! empty( $new_instance['services_subtitle5'] ) ) ? strip_tags( $new_instance['services_subtitle5'] ) : '';
$instance['services_subtitle6'] = ( ! empty( $new_instance['services_subtitle6'] ) ) ? strip_tags( $new_instance['services_subtitle6'] ) : '';


return $instance;
}
}

//Services section Widget Ends Here

// Feature Section Widget Starts Here

class gl_features_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_features_widget', 

__('Link - Feature Section', 'gl_features_widget_domain'), 

array( 'description' => __( 'Displays Feature Section0', 'gl_features_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$feature_bgimg = apply_filters( 'feature_bgimg', $instance['feature_bgimg'] );
$feature_title = apply_filters( 'feature_title', $instance['feature_title'] );
$feature_img1 = apply_filters( 'feature_img1', $instance['feature_img1'] );
$feature_title1 = apply_filters( 'feature_title1', $instance['feature_title1'] );
$feature_title_link1 = apply_filters( 'feature_title_link1', $instance['feature_title_link1'] );
$feature_cnt1 = apply_filters( 'feature_cnt1', $instance['feature_cnt1'] );
$feature_img2 = apply_filters( 'feature_img2', $instance['feature_img2'] );
$feature_title2 = apply_filters( 'feature_title2', $instance['feature_title2'] );
$feature_title_link2 = apply_filters( 'feature_title_link2', $instance['feature_title_link2'] );
$feature_cnt2 = apply_filters( 'feature_cnt2', $instance['feature_cnt2'] );
$feature_img3 = apply_filters( 'feature_img3', $instance['feature_img3'] );
$feature_title3 = apply_filters( 'feature_title3', $instance['feature_title3'] );
$feature_title_link2 = apply_filters( 'feature_title_link2', $instance['feature_title_link2'] );
$feature_cnt3 = apply_filters( 'feature_cnt3', $instance['feature_cnt3'] );

echo $args['before_widget'];
if ( ! empty( $title ) )
/*echo $args['before_title'] . $title . $args['after_title'];*/

?>
<div class="feature_box" style="background-image:url('<?php echo $instance['feature_bgimg']; ?>')">
	<div class="feature_color">
	<div class="feature_box_section wrap">
		<div class="line_title">
			<h3><?php echo $instance['feature_title']; ?></h3>
			<div class="line_under"><div class="line_center"></div></div>
			<div class="line_under below_line"><div class="line_center"></div></div>
		</div>
		<div class="feature_cnt">
			<div class="feature_box1">
				<div class="feature_cnt1">
					<div class="top_feature_cnt">
						<img alt="<?php echo $instance['feature_title1']; ?>" src="<?php echo $instance['feature_img1']; ?>"/>
					</div>
					<div class="bottom_feature_cnt">
						<h3><a href="<?php echo genesism_option('feature_title_link1'); ?>"><?php echo $instance['feature_title1']; ?></a></h3>
						<p><?php echo $instance['feature_cnt1']; ?></p>
					</div>
				</div>
			</div>
			<div class="feature_box1">
				<div class="feature_cnt1">
					<div class="top_feature_cnt">
						<img alt="<?php echo $instance['feature_title2']; ?>" src="<?php echo $instance['feature_img2']; ?>"/>
					</div>
					<div class="bottom_feature_cnt">
						<h3><a href="<?php echo genesism_option('feature_title_link2'); ?>"><?php echo $instance['feature_title2']; ?></a></h3>
						<p><?php echo $instance['feature_cnt2']; ?></p>
					</div>
				</div>
			</div>
			<div class="feature_box1 last">
				<div class="feature_cnt1">
					<div class="top_feature_cnt">
						<img alt="<?php echo $instance['feature_title3']; ?>" src="<?php echo $instance['feature_img3']; ?>"/>
					</div>
					<div class="bottom_feature_cnt">
						<h3><a href="<?php echo genesism_option('feature_title_link3'); ?>"><?php echo $instance['feature_title3']; ?></a></h3>
						<p><?php echo $instance['feature_cnt3']; ?></p>
					</div>
				</div>
			</div>
		</div>
	</div>
	</div>
</div>

<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {


 if ( isset( $instance[ 'feature_bgimg' ] ) ) {
$feature_bgimg = $instance[ 'feature_bgimg' ];
}
else {
$feature_bgimg = __( '', 'gl_features_widget_domain' );
}

 if ( isset( $instance[ 'feature_title' ] ) ) {
$feature_title = $instance[ 'feature_title' ];
}
else {
$feature_title = __( '', 'gl_features_widget_domain' );
}

 if ( isset( $instance[ 'feature_img1' ] ) ) {
$feature_img1 = $instance[ 'feature_img1' ];
}
else {
$feature_img1 = __( '', 'gl_features_widget_domain' );
}

 if ( isset( $instance[ 'feature_title1' ] ) ) {
$feature_title1 = $instance[ 'feature_title1' ];
}
else {
$feature_title1 = __( '', 'gl_features_widget_domain' );
}


 if ( isset( $instance[ 'feature_title_link1' ] ) ) {
$feature_title_link1 = $instance[ 'feature_title_link1' ];
}
else {
$feature_title_link1 = __( '', 'gl_features_widget_domain' );
}


if ( isset( $instance[ 'feature_cnt1' ] ) ) {
$feature_cnt1 = $instance[ 'feature_cnt1' ];
}
else {
$feature_cnt1 = __( '', 'gl_features_widget_domain' );
}


 if ( isset( $instance[ 'feature_img2' ] ) ) {
$feature_img2 = $instance[ 'feature_img2' ];
}
else {
$feature_img2 = __( '', 'gl_features_widget_domain' );
}

 if ( isset( $instance[ 'feature_title2' ] ) ) {
$feature_title2 = $instance[ 'feature_title2' ];
}
else {
$feature_title2 = __( '', 'gl_features_widget_domain' );
}


 if ( isset( $instance[ 'feature_title_link2' ] ) ) {
$feature_title_link2 = $instance[ 'feature_title_link2' ];
}
else {
$feature_title_link2 = __( '', 'gl_features_widget_domain' );
}

if ( isset( $instance[ 'feature_cnt2' ] ) ) {
$feature_cnt2 = $instance[ 'feature_cnt2' ];
}
else {
$feature_cnt2 = __( '', 'gl_features_widget_domain' );
}

if ( isset( $instance[ 'feature_img3' ] ) ) {
$feature_img3 = $instance[ 'feature_img3' ];
}
else {
$feature_img3 = __( '', 'gl_features_widget_domain' );
}

if ( isset( $instance[ 'feature_title3' ] ) ) {
$feature_title3 = $instance[ 'feature_title3' ];
}
else {
$feature_title3 = __( '', 'gl_features_widget_domain' );
}


if ( isset( $instance[ 'feature_title_link3' ] ) ) {
$feature_title_link3 = $instance[ 'feature_title_link3' ];
}
else {
$feature_title_link3 = __( '', 'gl_features_widget_domain' );
}

if ( isset( $instance[ 'feature_cnt3' ] ) ) {
$feature_cnt3 = $instance[ 'feature_cnt3' ];
}
else {
$feature_cnt3 = __( '', 'gl_features_widget_domain' );
}

?>

<p>
<label for="<?php echo $this->get_field_id( 'feature_bgimg' ); ?>"><?php _e( 'Feature Background Image URL Link:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'feature_bgimg' ); ?>" name="<?php echo $this->get_field_name( 'feature_bgimg' ); ?>" type="text" value="<?php echo esc_attr( $feature_bgimg ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'feature_title' ); ?>"><?php _e( 'Feature Title :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'feature_title' ); ?>" name="<?php echo $this->get_field_name( 'feature_title' ); ?>" type="text" value="<?php echo esc_attr( $feature_title ); ?>" />
</p>


<p>
<label for="<?php echo $this->get_field_id( 'feature_img1' ); ?>"><?php _e( 'Feature Image1 URL Link:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'feature_img1' ); ?>" name="<?php echo $this->get_field_name( 'feature_img1' ); ?>" type="text" value="<?php echo esc_attr( $feature_img1 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'feature_title1' ); ?>"><?php _e( 'Feature Subtitle1:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'feature_title1' ); ?>" name="<?php echo $this->get_field_name( 'feature_title1' ); ?>" type="text" value="<?php echo esc_attr( $feature_title1 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'feature_title_link1' ); ?>"><?php _e( 'Feature Subtitle1 Link:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'feature_title_link1' ); ?>" name="<?php echo $this->get_field_name( 'feature_title_link1' ); ?>" type="text" value="<?php echo esc_attr( $feature_title_link1 ); ?>" />
</p>


<p>
<label for="<?php echo $this->get_field_id( 'feature_cnt1' ); ?>"><?php _e( 'Feature Content1:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'feature_cnt1' ); ?>" name="<?php echo $this->get_field_name( 'feature_cnt1' ); ?>" type="text" value="<?php echo esc_attr( $feature_cnt1 ); ?>" />
</p>


<p>
<label for="<?php echo $this->get_field_id( 'feature_img2' ); ?>"><?php _e( 'Feature Image2 URL Link:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'feature_img2' ); ?>" name="<?php echo $this->get_field_name( 'feature_img2' ); ?>" type="text" value="<?php echo esc_attr( $feature_img2 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'feature_title2' ); ?>"><?php _e( 'Feature Subtitle2:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'feature_title2' ); ?>" name="<?php echo $this->get_field_name( 'feature_title2' ); ?>" type="text" value="<?php echo esc_attr( $feature_title2 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'feature_title_link2' ); ?>"><?php _e( 'Feature Subtitle2 Link:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'feature_title_link2' ); ?>" name="<?php echo $this->get_field_name( 'feature_title_link2' ); ?>" type="text" value="<?php echo esc_attr( $feature_title_link2 ); ?>" />
</p>


<p>
<label for="<?php echo $this->get_field_id( 'feature_cnt2' ); ?>"><?php _e( 'Feature Content2:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'feature_cnt2' ); ?>" name="<?php echo $this->get_field_name( 'feature_cnt2' ); ?>" type="text" value="<?php echo esc_attr( $feature_cnt2 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'feature_img3' ); ?>"><?php _e( 'Feature Image1 URL Link:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'feature_img3' ); ?>" name="<?php echo $this->get_field_name( 'feature_img3' ); ?>" type="text" value="<?php echo esc_attr( $feature_img3 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'feature_title3' ); ?>"><?php _e( 'Feature Subtitle3:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'feature_title3' ); ?>" name="<?php echo $this->get_field_name( 'feature_title3' ); ?>" type="text" value="<?php echo esc_attr( $feature_title3 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'feature_title_link3' ); ?>"><?php _e( 'Feature Subtitle3 Link:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'feature_title_link3' ); ?>" name="<?php echo $this->get_field_name( 'feature_title_link3' ); ?>" type="text" value="<?php echo esc_attr( $feature_title_link3 ); ?>" />
</p>


<p>
<label for="<?php echo $this->get_field_id( 'feature_cnt3' ); ?>"><?php _e( 'Feature Content3:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'feature_cnt3' ); ?>" name="<?php echo $this->get_field_name( 'feature_cnt3' ); ?>" type="text" value="<?php echo esc_attr( $feature_cnt3 ); ?>" />
</p>

<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['feature_bgimg'] = ( ! empty( $new_instance['feature_bgimg'] ) ) ? strip_tags( $new_instance['feature_bgimg'] ) : '';
$instance['feature_title'] = ( ! empty( $new_instance['feature_title'] ) ) ? strip_tags( $new_instance['feature_title'] ) : '';
$instance['feature_img1'] = ( ! empty( $new_instance['feature_img1'] ) ) ? strip_tags( $new_instance['feature_img1'] ) : '';
$instance['feature_title1'] = ( ! empty( $new_instance['feature_title1'] ) ) ? strip_tags( $new_instance['feature_title1'] ) : '';
$instance['feature_title_link1'] = ( ! empty( $new_instance['feature_title_link1'] ) ) ? strip_tags( $new_instance['feature_title_link1'] ) : '';
$instance['feature_cnt1'] = ( ! empty( $new_instance['feature_cnt1'] ) ) ? strip_tags( $new_instance['feature_cnt1'] ) : '';

$instance['feature_img2'] = ( ! empty( $new_instance['feature_img2'] ) ) ? strip_tags( $new_instance['feature_img2'] ) : '';
$instance['feature_title2'] = ( ! empty( $new_instance['feature_title2'] ) ) ? strip_tags( $new_instance['feature_title2'] ) : '';
$instance['feature_title_link2'] = ( ! empty( $new_instance['feature_title_link2'] ) ) ? strip_tags( $new_instance['feature_title_link2'] ) : '';
$instance['feature_cnt2'] = ( ! empty( $new_instance['feature_cnt2'] ) ) ? strip_tags( $new_instance['feature_cnt2'] ) : '';

$instance['feature_img3'] = ( ! empty( $new_instance['feature_img3'] ) ) ? strip_tags( $new_instance['feature_img3'] ) : '';
$instance['feature_title3'] = ( ! empty( $new_instance['feature_title3'] ) ) ? strip_tags( $new_instance['feature_title3'] ) : '';
$instance['feature_title_link3'] = ( ! empty( $new_instance['feature_title_link3'] ) ) ? strip_tags( $new_instance['feature_title_link3'] ) : '';
$instance['feature_cnt3'] = ( ! empty( $new_instance['feature_cnt3'] ) ) ? strip_tags( $new_instance['feature_cnt3'] ) : '';

return $instance;
}
}

//Feature section Widget Ends Here

// Portfolio Section Widget Starts Here

class gl_portfolio_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_portfolio_widget', 

__('Link - Portfolio Section', 'gl_portfolio_widget_domain'), 

array( 'description' => __( 'Displays Portfolio Section', 'gl_portfolio_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$portfolio_title = apply_filters( 'portfolio_title', $instance['portfolio_title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );
$read_more = apply_filters( 'read_more', $instance['read_more'] );

echo $args['before_widget'];
if ( ! empty( $title ) )
/*echo $args['before_title'] . $title . $args['after_title'];*/

?>
<div class="portfolio_section">
	<div class="portfolio_box">
		<div class="line_title">
			<h3><?php echo $instance['portfolio_title']; ?></h3>
			<div class="line_under"><div class="line_center"></div></div>
			<div class="line_under below_line"><div class="line_center"></div></div>
		</div>
		<div class="portfolio_box_cnt">
			<?php 
			global $post; 
			$portfolio_category = get_post_meta($post->ID, 'portfolio_category', true);
			$paged = get_query_var('paged') ? get_query_var('paged') : 1;
			$args = array('post_type' => 'portfolio', 'showposts' => $instance['post_count'], 'paged' => $paged, 'portfolio-category' => $portfolio_category);
			$query_args = wp_parse_args($cf, $args);
			$custom_query = new WP_Query($query_args);

			while($custom_query->have_posts()) : $custom_query->the_post(); 
									
			?>
						
				<div class="portfolio_cnt">
					<div class="portfolio_img_sec" itemprop="image">	
					<?php 
						// Defaults
						$f_img_width = $instance['width_size'];
						$f_img_height =$instance['height_size'];
						// Auto feature image defaults
						$thumb = get_post_thumbnail_id(); 
						$img_url = wp_get_attachment_url( $thumb,'full' ); 
						$image = aq_resize( $img_url, $f_img_width, $f_img_height, true );
						// Catch the Image defaults
						$catch_img_url = catch_that_image( $thumb,'full' );
						$catch_image = aq_resize( $catch_img_url, $f_img_width, $f_img_height, true );
						if(has_post_thumbnail())
						echo
						"<div class=\"featured_image\">\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width . "\" height=\"" . $f_img_height . "\" alt=\"" . get_the_title() . "\"><div class='image_overlay'></div></a>\n".
						"</div>\n";
						elseif (catch_that_image()){ 
						echo
						"<div class=\"featured_image\">\n".
						"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width . "\" height=\"" . $f_img_height . "\" alt=\"" . get_the_title() . "\"><div class='image_overlay'></div></a>\n".
						"</div>\n"; 
						} 
						/*featured image ends here*/
					?>
									
					</div>
					<div class="portfolio_btm_cnt">
						<div class="oi_tringle"></div>
						<?php echo "<h3 itemprop='headline'><a href='". get_permalink() ."'>".get_the_title()."";
						echo "</a></h3>";?>
						<span class='author' itemprop="author"><?php the_author() ?></span>
						<time class='date' datetime="<?php the_time('c'); ?>" itemprop="datePublished"><?php the_time('M jS, Y') ?></time>
						
						<div class="ico">
							<a href="<?php echo the_permalink(); ?>"><?php echo $instance['read_more']; ?></a>
						</div>
					</div>
				</div>
			<?php			
			endwhile;
			wp_reset_query(); 
			?>
		</div>
	</div>
</div>

<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {


 if ( isset( $instance[ 'portfolio_title' ] ) ) {
$portfolio_title = $instance[ 'portfolio_title' ];
}
else {
$portfolio_title = __( 'Our Works', 'gl_portfolio_widget_domain' );
}

 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '8', 'gl_portfolio_widget_domain' );
}


if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '335', 'gl_portfolio_widget_domain' );
}


 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '335', 'gl_portfolio_widget_domain' );
}

 
if ( isset( $instance[ 'read_more' ] ) ) {
$read_more = $instance[ 'read_more' ];
}
else {
$read_more = __( 'Readmore', 'gl_portfolio_widget_domain' );
}


?>

<p>
<label for="<?php echo $this->get_field_id( 'portfolio_title' ); ?>"><?php _e( 'Portfolio Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'portfolio_title' ); ?>" name="<?php echo $this->get_field_name( 'portfolio_title' ); ?>" type="text" value="<?php echo esc_attr( $portfolio_title ); ?>" />
</p>


<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>


<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>


<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'read_more' ); ?>"><?php _e( 'Read More Text :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'read_more' ); ?>" name="<?php echo $this->get_field_name( 'read_more' ); ?>" type="text" value="<?php echo esc_attr( $read_more ); ?>" />
</p>


<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['portfolio_title'] = ( ! empty( $new_instance['portfolio_title'] ) ) ? strip_tags( $new_instance['portfolio_title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';
$instance['read_more'] = ( ! empty( $new_instance['read_more'] ) ) ? strip_tags( $new_instance['read_more'] ) : '';



return $instance;
}
}

//Portfolio section Widget Ends Here

// Team Section Widget Starts Here

class gl_team_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_team_widget', 

__('Link - Team Section', 'gl_team_widget_domain'), 

array( 'description' => __( 'Displays Team Section', 'gl_team_widget_domain' ), $widget_ops, $control_ops ) 
);
}

public function widget( $args, $instance ) {
$team_title = apply_filters( 'team_title', $instance['team_title'] );
$team_img1 = apply_filters( 'team_img1', $instance['team_img1'] );
$team_name1 = apply_filters( 'team_name1', $instance['team_name1'] );
$team_profession1 = apply_filters( 'team_profession1', $instance['team_profession1'] );
$team_cnt1 = apply_filters( 'team_cnt1', $instance['team_cnt1'] );
$fbcheck1 = $instance[ 'fbcheck1' ] ? 'true' : 'false';
$gpcheck1 = $instance[ 'gpcheck1' ] ? 'true' : 'false';
$twcheck1 = $instance[ 'twcheck1' ] ? 'true' : 'false';
$lincheck1 = $instance[ 'lincheck1' ] ? 'true' : 'false';
$team_facebook_text1 = apply_filters( 'team_facebook_text1', $instance['team_facebook_text1'] );
$team_googleplus_text1 = apply_filters( 'team_googleplus_text1', $instance['team_googleplus_text1'] );
$team_twitter_text1 = apply_filters( 'team_twitter_text1', $instance['team_twitter_text1'] );
$team_linkedin_text1 = apply_filters( 'team_linkedin_text1', $instance['team_linkedin_text1'] );

$team_img2 = apply_filters( 'team_img2', $instance['team_img2'] );
$team_name2 = apply_filters( 'team_name2', $instance['team_name2'] );
$team_profession2 = apply_filters( 'team_profession2', $instance['team_profession2'] );
$team_cnt2 = apply_filters( 'team_cnt2', $instance['team_cnt2'] );
$fbcheck2 = $instance[ 'fbcheck2' ] ? 'true' : 'false';
$gpcheck2 = $instance[ 'gpcheck2' ] ? 'true' : 'false';
$twcheck2 = $instance[ 'twcheck2' ] ? 'true' : 'false';
$lincheck2 = $instance[ 'lincheck2' ] ? 'true' : 'false';
$team_facebook_text2 = apply_filters( 'team_facebook_text2', $instance['team_facebook_text2'] );
$team_googleplus_text2 = apply_filters( 'team_googleplus_text2', $instance['team_googleplus_text2'] );
$team_twitter_text2 = apply_filters( 'team_twitter_text2', $instance['team_twitter_text2'] );
$team_linkedin_text2 = apply_filters( 'team_linkedin_text2', $instance['team_linkedin_text2'] );

$team_img3 = apply_filters( 'team_img3', $instance['team_img3'] );
$team_name3 = apply_filters( 'team_name3', $instance['team_name3'] );
$team_profession3 = apply_filters( 'team_profession3', $instance['team_profession3'] );
$team_cnt3 = apply_filters( 'team_cnt3', $instance['team_cnt3'] );
$fbcheck3 = $instance[ 'fbcheck3' ] ? 'true' : 'false';
$gpcheck3 = $instance[ 'gpcheck3' ] ? 'true' : 'false';
$twcheck3 = $instance[ 'twcheck3' ] ? 'true' : 'false';
$lincheck3 = $instance[ 'lincheck3' ] ? 'true' : 'false';
$team_facebook_text3 = apply_filters( 'team_facebook_text3', $instance['team_facebook_text3'] );
$team_googleplus_text3 = apply_filters( 'team_googleplus_text3', $instance['team_googleplus_text3'] );
$team_twitter_text3 = apply_filters( 'team_twitter_text3', $instance['team_twitter_text3'] );
$team_linkedin_text3 = apply_filters( 'team_linkedin_text3', $instance['team_linkedin_text3'] );

$team_img4 = apply_filters( 'team_img4', $instance['team_img4'] );
$team_name4 = apply_filters( 'team_name4', $instance['team_name4'] );
$team_profession4 = apply_filters( 'team_profession4', $instance['team_profession4'] );
$team_cnt4 = apply_filters( 'team_cnt4', $instance['team_cnt4'] );
$fbcheck4 = $instance[ 'fbcheck4' ] ? 'true' : 'false';
$gpcheck4 = $instance[ 'gpcheck4' ] ? 'true' : 'false';
$twcheck4 = $instance[ 'twcheck4' ] ? 'true' : 'false';
$lincheck4 = $instance[ 'lincheck4' ] ? 'true' : 'false';
$team_facebook_text4 = apply_filters( 'team_facebook_text4', $instance['team_facebook_text4'] );
$team_googleplus_text4 = apply_filters( 'team_googleplus_text4', $instance['team_googleplus_text4'] );
$team_twitter_text4 = apply_filters( 'team_twitter_text4', $instance['team_twitter_text4'] );
$team_linkedin_text4 = apply_filters( 'team_linkedin_text4', $instance['team_linkedin_text4'] );

echo $args['before_widget'];
if ( ! empty( $title ) )
/*echo $args['before_title'] . $title . $args['after_title'];*/

?>
<div class="team_box">
	<div class="team_box_section wrap">
		<div class="line_title">
			<h3><?php echo $instance['team_title']; ?></h3>
			<div class="line_under"><div class="line_center"></div></div>
			<div class="line_under below_line"><div class="line_center"></div></div>
		</div>
		<div class="team_cnt">
			<div class="team_section">
				<div class="team-item">
					<div class="team-inner">
					<div class="pop-overlay">
						<div class="team-pop">
							<div class="team_name">
								<div class="name"><?php echo $instance['team_name1']; ?></div> 
							</div>
							<p><?php echo $instance['team_cnt1']; ?></p>
							<div class="team_social_follow">
								<ul class="team_social">
									<?php
									if( 'on' == $instance[ 'fbcheck1' ] ) : 
									?>									
									<li class="social_icons">
										<a class="facebook" title="Facebook" href="<?php echo $instance['team_facebook_text1']; ?>" target="_blank">
										<i class="fa icon-facebook"></i>
										</a>
									</li>
									<?php endif; 
									if( 'on' == $instance[ 'gpcheck1' ] ) : 
									?>
									<li class="social_icons">
										<a class="googleplus" title="google plus" href="<?php echo $instance['team_googleplus_text1']; ?>" target="_blank">
										<i class="fa icon-google"></i>
										</a>
									</li>
									<?php endif; 
									if( 'on' == $instance[ 'twcheck1' ] ) : 
									?>
									<li class="social_icons">
										<a class="twitter" title="Twitter" href="<?php echo $instance['team_twitter_text1']; ?>" target="_blank">
										<i class="fa icon-twitter"></i>
										</a>
									</li>
									<?php endif; 
									if( 'on' == $instance[ 'lincheck1' ] ) : 
									?>
									<li class="social_icons">
										<a class="linkedin" title="linkedin" href="<?php echo $instance['team_linkedin_text1']; ?>" target="_blank">
										<i class="fa icon-linkedin"></i>
										</a>
									</li>
									<?php endif; 
									?>
								</ul>
							</div>
						</div>
					</div>
					</div>
					<div class="avatar">
						<img src="<?php echo $instance['team_img1']; ?>" alt="<?php echo $instance['team_name1']; ?>">
					</div>
					<div class="info">
						<div class="name"><?php echo $instance['team_name1']; ?></div>                       
						<div class="pos"><?php echo $instance['team_profession1']; ?></div>
					</div>
				</div>
			</div>
			
			<div class="team_section">
				<div class="team-item">
					<div class="team-inner">
					<div class="pop-overlay">
						<div class="team-pop">
							<div class="team_name">
								<div class="name"><?php echo $instance['team_name2']; ?></div> 
							</div>
							<p><?php echo $instance['team_cnt2']; ?></p>
							<div class="team_social_follow">
								<ul class="team_social">
									<?php 
									if( 'on' == $instance[ 'fbcheck2' ] ) : 
									?>
									<li class="social_icons">
										<a class="facebook" title="Facebook" href="<?php echo $instance['team_facebook_text2']; ?>" target="_blank">
										<i class="fa icon-facebook"></i>
										</a>
									</li>
									<?php endif; 
									if( 'on' == $instance[ 'gpcheck2' ] ) : 
									?>
									<li class="social_icons">
										<a class="googleplus" title="google plus" href="<?php echo $instance['team_googleplus_text2']; ?>" target="_blank">
										<i class="fa icon-google"></i>
										</a>
									</li>
									<?php endif; 
									if( 'on' == $instance[ 'twcheck2' ] ) : 
									?>
									<li class="social_icons">
										<a class="twitter" title="Twitter" href="<?php echo $instance['team_twitter_text2']; ?>" target="_blank">
										<i class="fa icon-twitter"></i>
										</a>
									</li>
									<?php endif; 
									if( 'on' == $instance[ 'lincheck2' ] ) : 
									?>
									<li class="social_icons">
										<a class="linkedin" title="linkedin" href="<?php echo $instance['team_linkedin_text2']; ?>" target="_blank">
										<i class="fa icon-linkedin"></i>
										</a>
									</li>
									<?php endif;  
									?>
								</ul>
							</div>
						</div>
					</div>
					</div>
					<div class="avatar">
						<img src="<?php echo $instance['team_img2']; ?>" alt="<?php echo $instance['team_name2']; ?>">
					</div>
					<div class="info">
						<div class="name"><?php echo $instance['team_name2']; ?></div>                       
						<div class="pos"><?php echo $instance['team_profession2']; ?></div>
					</div>
				</div>
			</div>
			
			<div class="team_section">
				<div class="team-item">
					<div class="team-inner">
					<div class="pop-overlay">
						<div class="team-pop">
							<div class="team_name">
								<div class="name"><?php echo $instance['team_name3']; ?></div> 
							</div>
							<p><?php echo $instance['team_cnt3']; ?></p>
							<div class="team_social_follow">
								<ul class="team_social">
									<?php  
									if( 'on' == $instance[ 'fbcheck3' ] ) : 
									?>
									<li class="social_icons">
										<a class="facebook" title="Facebook" href="<?php echo $instance['team_facebook_text3']; ?>" target="_blank">
										<i class="fa icon-facebook"></i>
										</a>
									</li>
									<?php endif; 
									if( 'on' == $instance[ 'gpcheck3' ] ) : 
									?>
									<li class="social_icons">
										<a class="googleplus" title="google plus" href="<?php echo $instance['team_googleplus_text3']; ?>" target="_blank">
										<i class="fa icon-google"></i>
										</a>
									</li>
									<?php endif; 
									if( 'on' == $instance[ 'twcheck3' ] ) : 
									?>
									<li class="social_icons">
										<a class="twitter" title="Twitter" href="<?php echo $instance['team_twitter_text3']; ?>" target="_blank">
										<i class="fa icon-twitter"></i>
										</a>
									</li>
									<?php endif; 
									if( 'on' == $instance[ 'lincheck3' ] ) : 
									?>
									<li class="social_icons">
										<a class="linkedin" title="linkedin" href="<?php echo $instance['team_linkedin_text3']; ?>" target="_blank">
										<i class="fa icon-linkedin"></i>
										</a>
									</li>
									<?php endif;  
									?>
								</ul>
							</div>
						</div>
					</div>
					</div>
					<div class="avatar">
						<img src="<?php echo $instance['team_img3']; ?>" alt="<?php echo $instance['team_name3']; ?>">
					</div>
					<div class="info">
						<div class="name"><?php echo $instance['team_name3']; ?></div>                       
						<div class="pos"><?php echo $instance['team_profession3']; ?></div>
					</div>
				</div>
			</div>
			
			<div class="team_section last">
				<div class="team-item">
					<div class="team-inner">
					<div class="pop-overlay">
						<div class="team-pop">
							<div class="team_name">
								<div class="name"><?php echo $instance['team_name4']; ?></div> 
							</div>
							<p><?php echo $instance['team_cnt4']; ?></p>
							<div class="team_social_follow">
								<ul class="team_social">
									<?php
									if( 'on' == $instance[ 'fbcheck4' ] ) : 
									?>
									<li class="social_icons">
										<a class="facebook" title="Facebook" href="<?php echo $instance['team_facebook_text4']; ?>" target="_blank">
										<i class="fa icon-facebook"></i>
										</a>
									</li>
									<?php endif; 
									if( 'on' == $instance[ 'gpcheck4' ] ) : 
									?>
									<li class="social_icons">
										<a class="googleplus" title="google plus" href="<?php echo $instance['team_googleplus_text4']; ?>" target="_blank">
										<i class="fa icon-google"></i>
										</a>
									</li>
									<?php endif; 
									if( 'on' == $instance[ 'twcheck4' ] ) : 
									?>
									<li class="social_icons">
										<a class="twitter" title="Twitter" href="<?php echo $instance['team_twitter_text4']; ?>" target="_blank">
										<i class="fa icon-twitter"></i>
										</a>
									</li>
									<?php endif; 
									if( 'on' == $instance[ 'lincheck4' ] ) : 
									?>
									<li class="social_icons">
										<a class="linkedin" title="linkedin" href="<?php echo $instance['team_linkedin_text4']; ?>" target="_blank">
										<i class="fa icon-linkedin"></i>
										</a>
									</li>
									<?php endif; 
									?>
								</ul>
							</div>
						</div>
					</div>
					</div>
					<div class="avatar">
						<img src="<?php echo $instance['team_img4']; ?>" alt="<?php echo $instance['team_name4']; ?>">
					</div>
					<div class="info">
						<div class="name"><?php echo $instance['team_name4']; ?></div>                       
						<div class="pos"><?php echo $instance['team_profession4']; ?></div>
					</div>
				</div>
			</div>
			
		</div>
	</div>
</div>

<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {

$defaults = array( 'fbcheck1' => 'off', 'gpcheck1' => 'off', 'twcheck1' => 'off', 'lincheck1' => 'off', 'fbcheck2' => 'off', 'gpcheck2' => 'off', 'twcheck2' => 'off', 'lincheck2' => 'off', 'fbcheck3' => 'off', 'gpcheck3' => 'off', 'twcheck3' => 'off', 'lincheck3' => 'off', 'fbcheck4' => 'off', 'gpcheck4' => 'off', 'twcheck4' => 'off', 'lincheck4' => 'off' );
    $instance = wp_parse_args( ( array ) $instance, $defaults );
	
	
	
 if ( isset( $instance[ 'team_title' ] ) ) {
$team_title = $instance[ 'team_title' ];
}
else {
$team_title = __( 'Our Team', 'gl_team_widget_domain' );
}

 if ( isset( $instance[ 'team_img1' ] ) ) {
$team_img1 = $instance[ 'team_img1' ];
}
else {
$team_img1 = __( '', 'gl_team_widget_domain' );
}


if ( isset( $instance[ 'team_name1' ] ) ) {
$team_name1 = $instance[ 'team_name1' ];
}
else {
$team_name1 = __( '', 'gl_team_widget_domain' );
}


 if ( isset( $instance[ 'team_profession1' ] ) ) {
$team_profession1 = $instance[ 'team_profession1' ];
}
else {
$team_profession1 = __( '', 'gl_team_widget_domain' );
}

 
if ( isset( $instance[ 'team_cnt1' ] ) ) {
$team_cnt1 = $instance[ 'team_cnt1' ];
}
else {
$team_cnt1 = __( '', 'gl_team_widget_domain' );
}

if ( isset( $instance[ 'team_facebook_text1' ] ) ) {
$team_facebook_text1 = $instance[ 'team_facebook_text1' ];
}
else {
$team_facebook_text1 = __( '', 'gl_team_widget_domain' );
}

if ( isset( $instance[ 'team_googleplus_text1' ] ) ) {
$team_googleplus_text1 = $instance[ 'team_googleplus_text1' ];
}
else {
$team_googleplus_text1 = __( '', 'gl_team_widget_domain' );
}

if ( isset( $instance[ 'team_twitter_text1' ] ) ) {
$team_twitter_text1 = $instance[ 'team_twitter_text1' ];
}
else {
$team_twitter_text1 = __( '', 'gl_team_widget_domain' );
}

if ( isset( $instance[ 'team_linkedin_text1' ] ) ) {
$team_linkedin_text1 = $instance[ 'team_linkedin_text1' ];
}
else {
$team_linkedin_text1 = __( '', 'gl_team_widget_domain' );
}


if ( isset( $instance[ 'team_img2' ] ) ) {
$team_img2 = $instance[ 'team_img2' ];
}
else {
$team_img2 = __( '', 'gl_team_widget_domain' );
}


if ( isset( $instance[ 'team_name2' ] ) ) {
$team_name2 = $instance[ 'team_name2' ];
}
else {
$team_name2 = __( '', 'gl_team_widget_domain' );
}


 if ( isset( $instance[ 'team_profession2' ] ) ) {
$team_profession2 = $instance[ 'team_profession2' ];
}
else {
$team_profession2 = __( '', 'gl_team_widget_domain' );
}

 
if ( isset( $instance[ 'team_cnt2' ] ) ) {
$team_cnt2 = $instance[ 'team_cnt2' ];
}
else {
$team_cnt2 = __( '', 'gl_team_widget_domain' );
}

if ( isset( $instance[ 'team_facebook_text2' ] ) ) {
$team_facebook_text2 = $instance[ 'team_facebook_text2' ];
}
else {
$team_facebook_text2 = __( '', 'gl_team_widget_domain' );
}

if ( isset( $instance[ 'team_googleplus_text2' ] ) ) {
$team_googleplus_text2 = $instance[ 'team_googleplus_text2' ];
}
else {
$team_googleplus_text2 = __( '', 'gl_team_widget_domain' );
}

if ( isset( $instance[ 'team_twitter_text2' ] ) ) {
$team_twitter_text2 = $instance[ 'team_twitter_text2' ];
}
else {
$team_twitter_text2 = __( '', 'gl_team_widget_domain' );
}

if ( isset( $instance[ 'team_linkedin_text2' ] ) ) {
$team_linkedin_text2 = $instance[ 'team_linkedin_text2' ];
}
else {
$team_linkedin_text2 = __( '', 'gl_team_widget_domain' );
}

if ( isset( $instance[ 'team_img3' ] ) ) {
$team_img3 = $instance[ 'team_img3' ];
}
else {
$team_img3 = __( '', 'gl_team_widget_domain' );
}


if ( isset( $instance[ 'team_name3' ] ) ) {
$team_name3 = $instance[ 'team_name3' ];
}
else {
$team_name3 = __( '', 'gl_team_widget_domain' );
}


 if ( isset( $instance[ 'team_profession3' ] ) ) {
$team_profession3 = $instance[ 'team_profession3' ];
}
else {
$team_profession3 = __( '', 'gl_team_widget_domain' );
}

 
if ( isset( $instance[ 'team_cnt3' ] ) ) {
$team_cnt3 = $instance[ 'team_cnt3' ];
}
else {
$team_cnt3 = __( '', 'gl_team_widget_domain' );
}

if ( isset( $instance[ 'team_facebook_text3' ] ) ) {
$team_facebook_text3 = $instance[ 'team_facebook_text3' ];
}
else {
$team_facebook_text3 = __( '', 'gl_team_widget_domain' );
}

if ( isset( $instance[ 'team_googleplus_text3' ] ) ) {
$team_googleplus_text3 = $instance[ 'team_googleplus_text3' ];
}
else {
$team_googleplus_text3 = __( '', 'gl_team_widget_domain' );
}

if ( isset( $instance[ 'team_twitter_text3' ] ) ) {
$team_twitter_text3 = $instance[ 'team_twitter_text3' ];
}
else {
$team_twitter_text3 = __( '', 'gl_team_widget_domain' );
}

if ( isset( $instance[ 'team_linkedin_text3' ] ) ) {
$team_linkedin_text3 = $instance[ 'team_linkedin_text3' ];
}
else {
$team_linkedin_text3 = __( '', 'gl_team_widget_domain' );
}

if ( isset( $instance[ 'team_img4' ] ) ) {
$team_img4 = $instance[ 'team_img4' ];
}
else {
$team_img4 = __( '', 'gl_team_widget_domain' );
}


if ( isset( $instance[ 'team_name4' ] ) ) {
$team_name4 = $instance[ 'team_name4' ];
}
else {
$team_name4 = __( '', 'gl_team_widget_domain' );
}


 if ( isset( $instance[ 'team_profession4' ] ) ) {
$team_profession4 = $instance[ 'team_profession4' ];
}
else {
$team_profession4 = __( '', 'gl_team_widget_domain' );
}

 
if ( isset( $instance[ 'team_cnt4' ] ) ) {
$team_cnt4 = $instance[ 'team_cnt4' ];
}
else {
$team_cnt4 = __( '', 'gl_team_widget_domain' );
}

if ( isset( $instance[ 'team_facebook_text4' ] ) ) {
$team_facebook_text4 = $instance[ 'team_facebook_text4' ];
}
else {
$team_facebook_text4 = __( '', 'gl_team_widget_domain' );
}

if ( isset( $instance[ 'team_googleplus_text4' ] ) ) {
$team_googleplus_text4 = $instance[ 'team_googleplus_text4' ];
}
else {
$team_googleplus_text4 = __( '', 'gl_team_widget_domain' );
}

if ( isset( $instance[ 'team_twitter_text4' ] ) ) {
$team_twitter_text4 = $instance[ 'team_twitter_text4' ];
}
else {
$team_twitter_text4 = __( '', 'gl_team_widget_domain' );
}

if ( isset( $instance[ 'team_linkedin_text4' ] ) ) {
$team_linkedin_text4 = $instance[ 'team_linkedin_text4' ];
}
else {
$team_linkedin_text4 = __( '', 'gl_team_widget_domain' );
}
?>

<p>
<label for="<?php echo $this->get_field_id( 'team_title' ); ?>"><?php _e( 'Team Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'team_title' ); ?>" name="<?php echo $this->get_field_name( 'team_title' ); ?>" type="text" value="<?php echo esc_attr( $team_title ); ?>" />
</p>


<p>
<label for="<?php echo $this->get_field_id( 'team_img1' ); ?>"><?php _e( 'Team Image1 URL Link:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'team_img1' ); ?>" name="<?php echo $this->get_field_name( 'team_img1' ); ?>" type="text" value="<?php echo esc_attr( $team_img1 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'team_name1' ); ?>"><?php _e( 'Team Name1:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'team_name1' ); ?>" name="<?php echo $this->get_field_name( 'team_name1' ); ?>" type="text" value="<?php echo esc_attr( $team_name1 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'team_profession1' ); ?>"><?php _e( 'Team Name1 Profession:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'team_profession1' ); ?>" name="<?php echo $this->get_field_name( 'team_profession1' ); ?>" type="text" value="<?php echo esc_attr( $team_profession1 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'team_cnt1' ); ?>"><?php _e( 'Team Name1 Content :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'team_cnt1' ); ?>" name="<?php echo $this->get_field_name( 'team_cnt1' ); ?>" type="text" value="<?php echo esc_attr( $team_cnt1 ); ?>" />
</p>

<p>
<input class="checkbox" type="checkbox" <?php checked( $instance[ 'fbcheck1' ], 'on' ); ?> id="<?php echo $this->get_field_id( 'fbcheck1' ); ?>" name="<?php echo $this->get_field_name( 'fbcheck1' ); ?>" /> 
<label for="<?php echo $this->get_field_id( 'fbcheck1' ); ?>">Show Facebook Icon</label>
</p>
<p>
<input class="checkbox" type="checkbox" <?php checked( $instance[ 'gpcheck1' ], 'on' ); ?> id="<?php echo $this->get_field_id( 'gpcheck1' ); ?>" name="<?php echo $this->get_field_name( 'gpcheck1' ); ?>" /> 
<label for="<?php echo $this->get_field_id( 'gpcheck1' ); ?>">Show Googleplus Icon</label>
</p>
<p>
<input class="checkbox" type="checkbox" <?php checked( $instance[ 'twcheck1' ], 'on' ); ?> id="<?php echo $this->get_field_id( 'twcheck1' ); ?>" name="<?php echo $this->get_field_name( 'twcheck1' ); ?>" /> 
<label for="<?php echo $this->get_field_id( 'twcheck1' ); ?>">Show Twitter Icon</label>
</p>
<p>
<input class="checkbox" type="checkbox" <?php checked( $instance[ 'lincheck1' ], 'on' ); ?> id="<?php echo $this->get_field_id( 'lincheck1' ); ?>" name="<?php echo $this->get_field_name( 'lincheck1' ); ?>" /> 
<label for="<?php echo $this->get_field_id( 'lincheck1' ); ?>">Show Linkedin Icon</label>
</p>
	
<p>
<label for="<?php echo $this->get_field_id( 'team_facebook_text1' ); ?>"><?php _e( 'Team Name1 Facebook Page URL Link :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'team_facebook_text1' ); ?>" name="<?php echo $this->get_field_name( 'team_facebook_text1' ); ?>" type="text" value="<?php echo esc_attr( $team_facebook_text1 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'team_googleplus_text1' ); ?>"><?php _e( 'Team Name1 Googleplus Page URL Link :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'team_googleplus_text1' ); ?>" name="<?php echo $this->get_field_name( 'team_googleplus_text1' ); ?>" type="text" value="<?php echo esc_attr( $team_googleplus_text1 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'team_twitter_text1' ); ?>"><?php _e( 'Team Name1 Twitter Page URL Link :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'team_twitter_text1' ); ?>" name="<?php echo $this->get_field_name( 'team_twitter_text1' ); ?>" type="text" value="<?php echo esc_attr( $team_twitter_text1 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'team_linkedin_text1' ); ?>"><?php _e( 'Team Name1 Linkedin Page URL Link :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'team_linkedin_text1' ); ?>" name="<?php echo $this->get_field_name( 'team_linkedin_text1' ); ?>" type="text" value="<?php echo esc_attr( $team_linkedin_text1 ); ?>" />
</p>


<p>
<label for="<?php echo $this->get_field_id( 'team_img2' ); ?>"><?php _e( 'Team Image2 URL Link:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'team_img2' ); ?>" name="<?php echo $this->get_field_name( 'team_img2' ); ?>" type="text" value="<?php echo esc_attr( $team_img2 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'team_name2' ); ?>"><?php _e( 'Team Name2:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'team_name2' ); ?>" name="<?php echo $this->get_field_name( 'team_name2' ); ?>" type="text" value="<?php echo esc_attr( $team_name2 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'team_profession2' ); ?>"><?php _e( 'Team Name2 Profession:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'team_profession2' ); ?>" name="<?php echo $this->get_field_name( 'team_profession2' ); ?>" type="text" value="<?php echo esc_attr( $team_profession2 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'team_cnt2' ); ?>"><?php _e( 'Team Name2 Content :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'team_cnt2' ); ?>" name="<?php echo $this->get_field_name( 'team_cnt2' ); ?>" type="text" value="<?php echo esc_attr( $team_cnt2 ); ?>" />
</p>

<p>
<input class="checkbox" type="checkbox" <?php checked( $instance[ 'fbcheck2' ], 'on' ); ?> id="<?php echo $this->get_field_id( 'fbcheck2' ); ?>" name="<?php echo $this->get_field_name( 'fbcheck2' ); ?>" /> 
<label for="<?php echo $this->get_field_id( 'fbcheck2' ); ?>">Show Facebook Icon</label>
</p>
<p>
<input class="checkbox" type="checkbox" <?php checked( $instance[ 'gpcheck2' ], 'on' ); ?> id="<?php echo $this->get_field_id( 'gpcheck2' ); ?>" name="<?php echo $this->get_field_name( 'gpcheck2' ); ?>" /> 
<label for="<?php echo $this->get_field_id( 'gpcheck2' ); ?>">Show Googleplus Icon</label>
</p>
<p>
<input class="checkbox" type="checkbox" <?php checked( $instance[ 'twcheck2' ], 'on' ); ?> id="<?php echo $this->get_field_id( 'twcheck2' ); ?>" name="<?php echo $this->get_field_name( 'twcheck2' ); ?>" /> 
<label for="<?php echo $this->get_field_id( 'twcheck2' ); ?>">Show Twitter Icon</label>
</p>
<p>
<input class="checkbox" type="checkbox" <?php checked( $instance[ 'lincheck2' ], 'on' ); ?> id="<?php echo $this->get_field_id( 'lincheck2' ); ?>" name="<?php echo $this->get_field_name( 'lincheck2' ); ?>" /> 
<label for="<?php echo $this->get_field_id( 'lincheck2' ); ?>">Show Linkedin Icon</label>
</p>

<p>
<label for="<?php echo $this->get_field_id( 'team_facebook_text2' ); ?>"><?php _e( 'Team Name2 Facebook Page URL Link :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'team_facebook_text2' ); ?>" name="<?php echo $this->get_field_name( 'team_facebook_text2' ); ?>" type="text" value="<?php echo esc_attr( $team_facebook_text2 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'team_googleplus_text2' ); ?>"><?php _e( 'Team Name2 Googleplus Page URL Link :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'team_googleplus_text2' ); ?>" name="<?php echo $this->get_field_name( 'team_googleplus_text2' ); ?>" type="text" value="<?php echo esc_attr( $team_googleplus_text2 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'team_twitter_text2' ); ?>"><?php _e( 'Team Name2 Twitter Page URL Link :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'team_twitter_text2' ); ?>" name="<?php echo $this->get_field_name( 'team_twitter_text2' ); ?>" type="text" value="<?php echo esc_attr( $team_twitter_text2 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'team_linkedin_text2' ); ?>"><?php _e( 'Team Name2 Linkedin Page URL Link :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'team_linkedin_text2' ); ?>" name="<?php echo $this->get_field_name( 'team_linkedin_text2' ); ?>" type="text" value="<?php echo esc_attr( $team_linkedin_text2 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'team_img3' ); ?>"><?php _e( 'Team Image3 URL Link:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'team_img3' ); ?>" name="<?php echo $this->get_field_name( 'team_img3' ); ?>" type="text" value="<?php echo esc_attr( $team_img3 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'team_name3' ); ?>"><?php _e( 'Team Name3:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'team_name3' ); ?>" name="<?php echo $this->get_field_name( 'team_name3' ); ?>" type="text" value="<?php echo esc_attr( $team_name3 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'team_profession3' ); ?>"><?php _e( 'Team Name3 Profession:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'team_profession3' ); ?>" name="<?php echo $this->get_field_name( 'team_profession3' ); ?>" type="text" value="<?php echo esc_attr( $team_profession3 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'team_cnt3' ); ?>"><?php _e( 'Team Name3 Content :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'team_cnt3' ); ?>" name="<?php echo $this->get_field_name( 'team_cnt3' ); ?>" type="text" value="<?php echo esc_attr( $team_cnt3 ); ?>" />
</p>

<p>
<input class="checkbox" type="checkbox" <?php checked( $instance[ 'fbcheck3' ], 'on' ); ?> id="<?php echo $this->get_field_id( 'fbcheck3' ); ?>" name="<?php echo $this->get_field_name( 'fbcheck3' ); ?>" /> 
<label for="<?php echo $this->get_field_id( 'fbcheck3' ); ?>">Show Facebook Icon</label>
</p>
<p>
<input class="checkbox" type="checkbox" <?php checked( $instance[ 'gpcheck3' ], 'on' ); ?> id="<?php echo $this->get_field_id( 'gpcheck3' ); ?>" name="<?php echo $this->get_field_name( 'gpcheck3' ); ?>" /> 
<label for="<?php echo $this->get_field_id( 'gpcheck3' ); ?>">Show Googleplus Icon</label>
</p>
<p>
<input class="checkbox" type="checkbox" <?php checked( $instance[ 'twcheck3' ], 'on' ); ?> id="<?php echo $this->get_field_id( 'twcheck3' ); ?>" name="<?php echo $this->get_field_name( 'twcheck3' ); ?>" /> 
<label for="<?php echo $this->get_field_id( 'twcheck3' ); ?>">Show Twitter Icon</label>
</p>
<p>
<input class="checkbox" type="checkbox" <?php checked( $instance[ 'lincheck3' ], 'on' ); ?> id="<?php echo $this->get_field_id( 'lincheck3' ); ?>" name="<?php echo $this->get_field_name( 'lincheck3' ); ?>" /> 
<label for="<?php echo $this->get_field_id( 'lincheck3' ); ?>">Show Linkedin Icon</label>
</p>

<p>
<label for="<?php echo $this->get_field_id( 'team_facebook_text3' ); ?>"><?php _e( 'Team Name3 Facebook Page URL Link :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'team_facebook_text3' ); ?>" name="<?php echo $this->get_field_name( 'team_facebook_text3' ); ?>" type="text" value="<?php echo esc_attr( $team_facebook_text3 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'team_googleplus_text3' ); ?>"><?php _e( 'Team Name3 Googleplus Page URL Link :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'team_googleplus_text3' ); ?>" name="<?php echo $this->get_field_name( 'team_googleplus_text3' ); ?>" type="text" value="<?php echo esc_attr( $team_googleplus_text3 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'team_twitter_text3' ); ?>"><?php _e( 'Team Name3 Twitter Page URL Link :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'team_twitter_text3' ); ?>" name="<?php echo $this->get_field_name( 'team_twitter_text3' ); ?>" type="text" value="<?php echo esc_attr( $team_twitter_text3 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'team_linkedin_text3' ); ?>"><?php _e( 'Team Name3 Linkedin Page URL Link :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'team_linkedin_text3' ); ?>" name="<?php echo $this->get_field_name( 'team_linkedin_text3' ); ?>" type="text" value="<?php echo esc_attr( $team_linkedin_text3 ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'team_img4' ); ?>"><?php _e( 'Team Image4 URL Link:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'team_img4' ); ?>" name="<?php echo $this->get_field_name( 'team_img4' ); ?>" type="text" value="<?php echo esc_attr( $team_img4 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'team_name4' ); ?>"><?php _e( 'Team Name4:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'team_name4' ); ?>" name="<?php echo $this->get_field_name( 'team_name4' ); ?>" type="text" value="<?php echo esc_attr( $team_name4 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'team_profession4' ); ?>"><?php _e( 'Team Name4 Profession:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'team_profession4' ); ?>" name="<?php echo $this->get_field_name( 'team_profession4' ); ?>" type="text" value="<?php echo esc_attr( $team_profession4 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'team_cnt4' ); ?>"><?php _e( 'Team Name4 Content :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'team_cnt4' ); ?>" name="<?php echo $this->get_field_name( 'team_cnt4' ); ?>" type="text" value="<?php echo esc_attr( $team_cnt4 ); ?>" />
</p>

<p>
<input class="checkbox" type="checkbox" <?php checked( $instance[ 'fbcheck4' ], 'on' ); ?> id="<?php echo $this->get_field_id( 'fbcheck4' ); ?>" name="<?php echo $this->get_field_name( 'fbcheck4' ); ?>" /> 
<label for="<?php echo $this->get_field_id( 'fbcheck4' ); ?>">Show Facebook Icon</label>
</p>
<p>
<input class="checkbox" type="checkbox" <?php checked( $instance[ 'gpcheck4' ], 'on' ); ?> id="<?php echo $this->get_field_id( 'gpcheck4' ); ?>" name="<?php echo $this->get_field_name( 'gpcheck4' ); ?>" /> 
<label for="<?php echo $this->get_field_id( 'gpcheck4' ); ?>">Show Googleplus Icon</label>
</p>
<p>
<input class="checkbox" type="checkbox" <?php checked( $instance[ 'twcheck4' ], 'on' ); ?> id="<?php echo $this->get_field_id( 'twcheck4' ); ?>" name="<?php echo $this->get_field_name( 'twcheck4' ); ?>" /> 
<label for="<?php echo $this->get_field_id( 'twcheck4' ); ?>">Show Twitter Icon</label>
</p>
<p>
<input class="checkbox" type="checkbox" <?php checked( $instance[ 'lincheck4' ], 'on' ); ?> id="<?php echo $this->get_field_id( 'lincheck4' ); ?>" name="<?php echo $this->get_field_name( 'lincheck4' ); ?>" /> 
<label for="<?php echo $this->get_field_id( 'lincheck4' ); ?>">Show Linkedin Icon</label>
</p>

<p>
<label for="<?php echo $this->get_field_id( 'team_facebook_text4' ); ?>"><?php _e( 'Team Name4 Facebook Page URL Link :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'team_facebook_text4' ); ?>" name="<?php echo $this->get_field_name( 'team_facebook_text4' ); ?>" type="text" value="<?php echo esc_attr( $team_facebook_text4 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'team_googleplus_text4' ); ?>"><?php _e( 'Team Name4 Googleplus Page URL Link :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'team_googleplus_text4' ); ?>" name="<?php echo $this->get_field_name( 'team_googleplus_text4' ); ?>" type="text" value="<?php echo esc_attr( $team_googleplus_text4 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'team_twitter_text4' ); ?>"><?php _e( 'Team Name4 Twitter Page URL Link :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'team_twitter_text4' ); ?>" name="<?php echo $this->get_field_name( 'team_twitter_text4' ); ?>" type="text" value="<?php echo esc_attr( $team_twitter_text4 ); ?>" />
</p>
<p>
<label for="<?php echo $this->get_field_id( 'team_linkedin_text4' ); ?>"><?php _e( 'Team Name4 Linkedin Page URL Link :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'team_linkedin_text4' ); ?>" name="<?php echo $this->get_field_name( 'team_linkedin_text4' ); ?>" type="text" value="<?php echo esc_attr( $team_linkedin_text4 ); ?>" />
</p>


<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['team_title'] = ( ! empty( $new_instance['team_title'] ) ) ? strip_tags( $new_instance['team_title'] ) : '';
$instance['team_img1'] = ( ! empty( $new_instance['team_img1'] ) ) ? strip_tags( $new_instance['team_img1'] ) : '';
$instance['team_name1'] = ( ! empty( $new_instance['team_name1'] ) ) ? strip_tags( $new_instance['team_name1'] ) : '';
$instance['team_profession1'] = ( ! empty( $new_instance['team_profession1'] ) ) ? strip_tags( $new_instance['team_profession1'] ) : '';
$instance['team_cnt1'] = ( ! empty( $new_instance['team_cnt1'] ) ) ? strip_tags( $new_instance['team_cnt1'] ) : '';
$instance[ 'fbcheck1' ] = $new_instance[ 'fbcheck1' ];
$instance[ 'gpcheck1' ] = $new_instance[ 'gpcheck1' ];
$instance[ 'twcheck1' ] = $new_instance[ 'twcheck1' ];
$instance[ 'lincheck1' ] = $new_instance[ 'lincheck1' ]; 
$instance['team_facebook_text1'] = ( ! empty( $new_instance['team_facebook_text1'] ) ) ? strip_tags( $new_instance['team_facebook_text1'] ) : '';
$instance['team_googleplus_text1'] = ( ! empty( $new_instance['team_googleplus_text1'] ) ) ? strip_tags( $new_instance['team_googleplus_text1'] ) : '';
$instance['team_twitter_text1'] = ( ! empty( $new_instance['team_twitter_text1'] ) ) ? strip_tags( $new_instance['team_twitter_text1'] ) : '';
$instance['team_linkedin_text1'] = ( ! empty( $new_instance['team_linkedin_text1'] ) ) ? strip_tags( $new_instance['team_linkedin_text1'] ) : '';

$instance['team_img2'] = ( ! empty( $new_instance['team_img2'] ) ) ? strip_tags( $new_instance['team_img2'] ) : '';
$instance['team_name2'] = ( ! empty( $new_instance['team_name2'] ) ) ? strip_tags( $new_instance['team_name2'] ) : '';
$instance['team_profession2'] = ( ! empty( $new_instance['team_profession2'] ) ) ? strip_tags( $new_instance['team_profession2'] ) : '';
$instance['team_cnt2'] = ( ! empty( $new_instance['team_cnt2'] ) ) ? strip_tags( $new_instance['team_cnt2'] ) : '';
$instance[ 'fbcheck2' ] = $new_instance[ 'fbcheck2' ];
$instance[ 'gpcheck2' ] = $new_instance[ 'gpcheck2' ];
$instance[ 'twcheck2' ] = $new_instance[ 'twcheck2' ];
$instance[ 'lincheck2' ] = $new_instance[ 'lincheck2' ]; 
$instance['team_facebook_text2'] = ( ! empty( $new_instance['team_facebook_text2'] ) ) ? strip_tags( $new_instance['team_facebook_text2'] ) : '';
$instance['team_googleplus_text2'] = ( ! empty( $new_instance['team_googleplus_text2'] ) ) ? strip_tags( $new_instance['team_googleplus_text2'] ) : '';
$instance['team_twitter_text2'] = ( ! empty( $new_instance['team_twitter_text2'] ) ) ? strip_tags( $new_instance['team_twitter_text2'] ) : '';
$instance['team_linkedin_text2'] = ( ! empty( $new_instance['team_linkedin_text2'] ) ) ? strip_tags( $new_instance['team_linkedin_text2'] ) : '';

$instance['team_img3'] = ( ! empty( $new_instance['team_img3'] ) ) ? strip_tags( $new_instance['team_img3'] ) : '';
$instance['team_name3'] = ( ! empty( $new_instance['team_name3'] ) ) ? strip_tags( $new_instance['team_name3'] ) : '';
$instance['team_profession3'] = ( ! empty( $new_instance['team_profession3'] ) ) ? strip_tags( $new_instance['team_profession3'] ) : '';
$instance['team_cnt3'] = ( ! empty( $new_instance['team_cnt3'] ) ) ? strip_tags( $new_instance['team_cnt3'] ) : '';
$instance[ 'fbcheck3' ] = $new_instance[ 'fbcheck3' ];
$instance[ 'gpcheck3' ] = $new_instance[ 'gpcheck3' ];
$instance[ 'twcheck3' ] = $new_instance[ 'twcheck3' ];
$instance[ 'lincheck3' ] = $new_instance[ 'lincheck3' ]; 
$instance['team_facebook_text3'] = ( ! empty( $new_instance['team_facebook_text3'] ) ) ? strip_tags( $new_instance['team_facebook_text3'] ) : '';
$instance['team_googleplus_text3'] = ( ! empty( $new_instance['team_googleplus_text3'] ) ) ? strip_tags( $new_instance['team_googleplus_text3'] ) : '';
$instance['team_twitter_text3'] = ( ! empty( $new_instance['team_twitter_text3'] ) ) ? strip_tags( $new_instance['team_twitter_text3'] ) : '';
$instance['team_linkedin_text3'] = ( ! empty( $new_instance['team_linkedin_text3'] ) ) ? strip_tags( $new_instance['team_linkedin_text3'] ) : '';

$instance['team_img4'] = ( ! empty( $new_instance['team_img4'] ) ) ? strip_tags( $new_instance['team_img4'] ) : '';
$instance['team_name4'] = ( ! empty( $new_instance['team_name4'] ) ) ? strip_tags( $new_instance['team_name4'] ) : '';
$instance['team_profession4'] = ( ! empty( $new_instance['team_profession4'] ) ) ? strip_tags( $new_instance['team_profession4'] ) : '';
$instance['team_cnt4'] = ( ! empty( $new_instance['team_cnt4'] ) ) ? strip_tags( $new_instance['team_cnt4'] ) : '';
$instance[ 'fbcheck4' ] = $new_instance[ 'fbcheck4' ];
$instance[ 'gpcheck4' ] = $new_instance[ 'gpcheck4' ];
$instance[ 'twcheck4' ] = $new_instance[ 'twcheck4' ];
$instance[ 'lincheck4' ] = $new_instance[ 'lincheck4' ]; 
$instance['team_facebook_text4'] = ( ! empty( $new_instance['team_facebook_text4'] ) ) ? strip_tags( $new_instance['team_facebook_text4'] ) : '';
$instance['team_googleplus_text4'] = ( ! empty( $new_instance['team_googleplus_text4'] ) ) ? strip_tags( $new_instance['team_googleplus_text4'] ) : '';
$instance['team_twitter_text4'] = ( ! empty( $new_instance['team_twitter_text4'] ) ) ? strip_tags( $new_instance['team_twitter_text4'] ) : '';
$instance['team_linkedin_text4'] = ( ! empty( $new_instance['team_linkedin_text4'] ) ) ? strip_tags( $new_instance['team_linkedin_text4'] ) : '';

return $instance;
}
}

//Team section Widget Ends Here

// Latest News Section Widget Starts Here

class gl_latest_news_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_latest_news_widget', 

__('Link - Latest News Post', 'gl_latest_news_widget_domain'), 

array( 'description' => __( 'Displays Latest News Post Section', 'gl_latest_news_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$latest_title = apply_filters( 'latest_title', $instance['latest_title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
$width_size = apply_filters( 'width_size', $instance['width_size'] );
$height_size = apply_filters( 'height_size', $instance['height_size'] );
$read_more = apply_filters( 'read_more', $instance['read_more'] );

echo $args['before_widget'];
if ( ! empty( $title ) )
/*echo $args['before_title'] . $title . $args['after_title'];*/

?>
<div class="latest_news">
	<div class="latest_news_section wrap">
		<div class="line_title">
			<h3><?php echo $instance['latest_title']; ?></h3>
			<div class="line_under"><div class="line_center"></div></div>
			<div class="line_under below_line"><div class="line_center"></div></div>
		</div>
		<div class="latest_news_cnt">
			<?php $custom_query = new WP_Query('posts_per_page='. $post_count .''); 
			while($custom_query->have_posts()) : $custom_query->the_post(); 
			$i++;
			$class = ( $i % 3 ) ? 'latest_news_sec' : 'latest_news_sec last'; 
			?>
				<div class="<?php echo $class; ?>">
					<div class="latest_img" itemprop="image">
						<?php 
							// Defaults
							$f_img_width = $instance['width_size'];
							$f_img_height =$instance['height_size'];
							// Auto feature image defaults
							$thumb = get_post_thumbnail_id(); 
							$img_url = wp_get_attachment_url( $thumb,'full' ); 
							$image = aq_resize( $img_url, $f_img_width, $f_img_height, true );
							// Catch the Image defaults
							$catch_img_url = catch_that_image( $thumb,'full' );
							$catch_image = aq_resize( $catch_img_url, $f_img_width, $f_img_height, true );
							if(has_post_thumbnail())
							echo
							"<div class=\"featured_image\">\n".
							"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $image . "\" width=\"" . $f_img_width . "\" height=\"" . $f_img_height . "\" alt=\"" . get_the_title() . "\"><div class='image_overlay'></div></a>\n".
							"</div>\n";
							elseif (catch_that_image()){ 
							echo
							"<div class=\"featured_image\">\n".
							"<a class=\"featured_image_link\" href=\"" . get_permalink() . "\" title=\"" . get_the_title() . "\"><img src=\"" . $catch_image . "\" width=\"" . $f_img_width . "\" height=\"" . $f_img_height . "\" alt=\"" . get_the_title() . "\"><div class='image_overlay'></div></a>\n".
							"</div>\n"; 
							} 
							/*featured image ends here*/
						?>	
						<time  datetime="<?php the_time('c'); ?>" itemprop="datePublished"><?php the_time('j M') ?></time>		
					</div>
					<div class="latest_cnt">
						<?php echo "<h3 itemprop='headline'><a href='". get_permalink() ."'>".get_the_title()."";
						echo "</a></h3>";?>
						<div class="hme_byline">
							<?php
								$category = get_the_category(); 
							?>
							<span class='author' itemprop="author"><?php the_author() ?></span>
							<span class="cat"><a href='<?php echo get_category_link($category[0]->cat_ID) ?>'><?php echo $category[0]->cat_name; ?></a></span>
							
							<span class="info_comments"><a  href="<?php the_permalink(); ?>#comments" title="<?php comments_number(__('0','fb'),__('1','periodic'),__('%','fb')); ?>"><?php comments_number(__('0','periodic'),__('1','periodic'),__('%','fb')); ?> </a></span>	
							<span class="edit_link"><?php edit_post_link(); ?></span>
						</div>
						<?php 
						echo"<p>";
						$excerpt=get_the_excerpt();
						echo string_limit_words($excerpt,20);
						echo "</p>"; ?>
						<div class="read_more slider_readmore ">
						<a class="read_more_btn" href="<?php the_permalink(); ?>"><?php echo $instance['read_more']; ?></a>
						</div>
					</div>
				</div>
			<?php 
			endwhile;
			wp_reset_query(); 
			?>
		</div>
	</div>
</div>

<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {


 if ( isset( $instance[ 'latest_title' ] ) ) {
$latest_title = $instance[ 'latest_title' ];
}
else {
$latest_title = __( 'Latest News', 'gl_latest_news_widget_domain' );
}

 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '3', 'gl_latest_news_widget_domain' );
}


if ( isset( $instance[ 'width_size' ] ) ) {
$width_size = $instance[ 'width_size' ];
}
else {
$width_size = __( '285', 'gl_latest_news_widget_domain' );
}


 if ( isset( $instance[ 'height_size' ] ) ) {
$height_size = $instance[ 'height_size' ];
}
else {
$height_size = __( '250', 'gl_latest_news_widget_domain' );
}

 
if ( isset( $instance[ 'read_more' ] ) ) {
$read_more = $instance[ 'read_more' ];
}
else {
$read_more = __( 'Readmore', 'gl_latest_news_widget_domain' );
}


?>

<p>
<label for="<?php echo $this->get_field_id( 'latest_title' ); ?>"><?php _e( 'Latest News Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'latest_title' ); ?>" name="<?php echo $this->get_field_name( 'latest_title' ); ?>" type="text" value="<?php echo esc_attr( $latest_title ); ?>" />
</p>


<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>


<p>
<label for="<?php echo $this->get_field_id( 'width_size' ); ?>"><?php _e( 'Featured Image Width Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'width_size' ); ?>" name="<?php echo $this->get_field_name( 'width_size' ); ?>" type="text" value="<?php echo esc_attr( $width_size ); ?>" />
</p>


<p>
<label for="<?php echo $this->get_field_id( 'height_size' ); ?>"><?php _e( 'Featured Image Height Size:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'height_size' ); ?>" name="<?php echo $this->get_field_name( 'height_size' ); ?>" type="text" value="<?php echo esc_attr( $height_size ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'read_more' ); ?>"><?php _e( 'Read More Text :' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'read_more' ); ?>" name="<?php echo $this->get_field_name( 'read_more' ); ?>" type="text" value="<?php echo esc_attr( $read_more ); ?>" />
</p>


<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['latest_title'] = ( ! empty( $new_instance['latest_title'] ) ) ? strip_tags( $new_instance['latest_title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['width_size'] = ( ! empty( $new_instance['width_size'] ) ) ? strip_tags( $new_instance['width_size'] ) : '';
$instance['height_size'] = ( ! empty( $new_instance['height_size'] ) ) ? strip_tags( $new_instance['height_size'] ) : '';
$instance['read_more'] = ( ! empty( $new_instance['read_more'] ) ) ? strip_tags( $new_instance['read_more'] ) : '';



return $instance;
}
}

//Latest News section Widget Ends Here

// Testimonial Section Widget Starts Here

class gl_testimonial_widget extends WP_Widget {

function __construct() {
parent::__construct(
'gl_testimonial_widget', 

__('Link - Testimonial Section', 'gl_testimonial_widget_domain'), 

array( 'description' => __( 'Displays Testimonial Section', 'gl_testimonial_widget_domain' ), ) 
);
}

public function widget( $args, $instance ) {
$testimonial_title = apply_filters( 'testimonial_title', $instance['testimonial_title'] );
$post_count = apply_filters( 'post_count', $instance['post_count'] );
$testimonial_bgimg = apply_filters( 'testimonial_bgimg', $instance['testimonial_bgimg'] );


echo $args['before_widget'];
if ( ! empty( $title ) )
/*echo $args['before_title'] . $title . $args['after_title'];*/

?>
<div class="testimonal_section" style="background-image:url('<?php echo $instance['testimonial_bgimg']; ?>')" >
	<div class="testimonal_section_color">
	<div class="testimonal_box wrap">
		<div class="line_title">
			<h3><?php echo $instance['testimonial_title']; ?></h3>		
			<div class="line_under"><div class="line_center"></div></div>
			<div class="line_under below_line"><div class="line_center"></div></div>
		</div>
		<div class="testimonial_cnt">
			<div class="container">

		<div class="cd-testimonials-wrapper cd-container">
		<ul class="cd-testimonials">
	<?php
		global $post;
		$portfolio_category = get_post_meta($post->ID, 'testimonial_category', true);
		$paged = get_query_var('paged') ? get_query_var('paged') : 1;
		$args = array('post_type' => 'testimonial', 'showposts' => $instance['post_count'], 'paged' => $paged, 'testimonial-category' => $portfolio_category);
		$query_args = wp_parse_args($cf, $args);
		$wp_query = new WP_Query($query_args);
		$loop_counter = 0;
		if ( $wp_query->have_posts() ) : while ( $wp_query->have_posts() ) : $wp_query->the_post(); 
		$j++;
		?>
	
   <li>
      
      
          <div class="test_cnt">
		  <p><?php $excerpt=get_the_excerpt();
				echo string_limit_words($excerpt,55); 
				?></p>
		</div>
        <div class="testimonial_cnt_sec">
			<div class="test_img" itemprop="image">
				<a href=" <?php echo the_permalink(); ?>"><?php the_post_thumbnail(array(150,150)); ?></a>
		   </div>
		   <h2 itemprop="headline"><a href=" <?php echo the_permalink(); ?>"><?php echo the_title(); ?></a></h2>
	   </div>
       
   </li>
      
  <?php
		$loop_counter++;
		endwhile; else :  endif;
		wp_reset_query();
		?>
  
		</ul>
		</div>
  
  
</div>
		</div>
	</div>
	</div>
</div>
<?php


echo $args['after_widget'];
}
		
public function form( $instance ) {


 if ( isset( $instance[ 'testimonial_title' ] ) ) {
$testimonial_title = $instance[ 'testimonial_title' ];
}
else {
$testimonial_title = __( 'Testimonial', 'gl_testimonial_widget_domain' );
}

 if ( isset( $instance[ 'post_count' ] ) ) {
$post_count = $instance[ 'post_count' ];
}
else {
$post_count = __( '4', 'gl_testimonial_widget_domain' );
}


if ( isset( $instance[ 'testimonial_bgimg' ] ) ) {
$testimonial_bgimg = $instance[ 'testimonial_bgimg' ];
}
else {
$testimonial_bgimg = __( '', 'gl_testimonial_widget_domain' );
}

?>


<p>
<label for="<?php echo $this->get_field_id( 'testimonial_title' ); ?>"><?php _e( 'Testimonial Title:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'testimonial_title' ); ?>" name="<?php echo $this->get_field_name( 'testimonial_title' ); ?>" type="text" value="<?php echo esc_attr( $testimonial_title ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'testimonial_bgimg' ); ?>"><?php _e( 'Testimonial Background Image URL Link:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'testimonial_bgimg' ); ?>" name="<?php echo $this->get_field_name( 'testimonial_bgimg' ); ?>" type="text" value="<?php echo esc_attr( $testimonial_bgimg ); ?>" />
</p>

<p>
<label for="<?php echo $this->get_field_id( 'post_count' ); ?>"><?php _e( 'Post Count:' ); ?></label> 
<input class="widefat" id="<?php echo $this->get_field_id( 'post_count' ); ?>" name="<?php echo $this->get_field_name( 'post_count' ); ?>" type="text" value="<?php echo esc_attr( $post_count ); ?>" />
</p>





<?php 
}
	

public function update( $new_instance, $old_instance ) {
$instance = array();
$instance['testimonial_title'] = ( ! empty( $new_instance['testimonial_title'] ) ) ? strip_tags( $new_instance['testimonial_title'] ) : '';
$instance['post_count'] = ( ! empty( $new_instance['post_count'] ) ) ? strip_tags( $new_instance['post_count'] ) : '';
$instance['testimonial_bgimg'] = ( ! empty( $new_instance['testimonial_bgimg'] ) ) ? strip_tags( $new_instance['testimonial_bgimg'] ) : '';


return $instance;
}
}

//Testimonial section Widget Ends Here


// Register and load the widget
function gl_load_widget() {
	register_widget( 'gl_last_update_widget' );
	register_widget( 'gl_popular_widget' );
	register_widget( 'gl_aboutus_widget' );
	register_widget( 'gl_sidebar_search_widget' );
	register_widget( 'gl_related_post_widget' );
	register_widget( 'gl_slider_widget' );
	register_widget( 'gl_services_widget' );
	register_widget( 'gl_features_widget' );
	register_widget( 'gl_portfolio_widget' );
	register_widget( 'gl_team_widget' );
	register_widget( 'gl_testimonial_widget' );
	register_widget( 'gl_latest_news_widget' );
}
add_action( 'widgets_init', 'gl_load_widget' );