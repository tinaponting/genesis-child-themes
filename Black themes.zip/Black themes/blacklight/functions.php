<?php
//* Start the engine to load the core files
include_once( get_template_directory() . '/lib/init.php' );

//* Child theme (do not remove)
define( 'CHILD_THEME_NAME', 'Black Light' );
define( 'CHILD_THEME_VERSION', '1.0' );

//* Add HTML5 markup structure
add_theme_support( 'html5' );

//* Add HTML5 markup structure
add_theme_support( 'genesis-responsive-viewport' );

//* Add custom Viewport meta tag for mobile browsers
add_action( 'genesis_meta', 'lush_viewport_meta_tag' );
function lush_viewport_meta_tag() {echo '<meta name="viewport" content="width=device-width, initial-scale=1.0"/>';
}
/** Add custom Header Support */
add_theme_support( 'genesis-custom-header', array( 'width' => 960, 'height' => 200 ) );

//* Unregister content/sidebar/sidebar layout setting
genesis_unregister_layout( 'content-sidebar-sidebar' );
 
//* Unregister sidebar/sidebar/content layout setting
genesis_unregister_layout( 'sidebar-sidebar-content' );
 
//* Unregister sidebar/content/sidebar layout setting
genesis_unregister_layout( 'sidebar-content-sidebar' );

//* Unregister Sidebar
unregister_sidebar(  'header-right'  );

//* Unregister secondary sidebar
unregister_sidebar( 'sidebar-alt' );

//* Add support for custom background
add_theme_support( 'custom-background' );

//* Add support for 3-column footer widgets
add_theme_support( 'genesis-footer-widgets', 3 );

//* Set content/sidebar as the default layout
genesis_set_default_layout( 'content-sidebar' );

//* Enqueue scripts and styles
add_action( 'wp_enqueue_scripts', 'lush_enqueue_script' );
function lush_enqueue_script() {
wp_enqueue_script( 'sample-sticky-menu', get_bloginfo( 'stylesheet_directory' ) . '/js/sticky-menu.js', array( 'jquery' ), '1.0.0' );
wp_enqueue_style( 'dashicons' );
}
//* Reposition the secondary navigation menu
remove_action( 'genesis_after_header', 'genesis_do_subnav' );
add_action( 'genesis_before', 'genesis_do_subnav' );

//* Display author box on single posts
add_filter( 'get_the_author_genesis_author_box_single', '__return_true' );

//* Customize the author box title
add_filter( 'genesis_author_box_title', 'lush_author_box_title' );
function lush_author_box_title() {return '<strong>About the Author</strong>';
}
//* Modify the size of the Gravatar in the author box
add_filter( 'genesis_author_box_gravatar_size', 'lush_author_box_gravatar_size' );
function lush_author_box_gravatar_size( $size ) {return '200';
}
//* Modify the size of the Gravatar in comments
add_filter( 'genesis_comment_list_args', 'lush_comments_gravatar' );
function lush_comments_gravatar( $args ) {$args['avatar_size'] = 80;return $args;
}
//* Modify the size of the Gravatar in the User Profile Widget
add_filter( 'genesis_gravatar_sizes', 'lush_user_profile' );
function lush_user_profile( $sizes ) {
	$sizes['Small'] = 85;
	$sizes['Medium'] = 125;
	$sizes['Large'] = 240;
	$sizes['Extra Large'] = 280;
	$sizes['Extra Large Image'] = 340;return $sizes;
}
//* Remove HTML allowed tag in comment form
add_filter( 'comment_form_defaults', 'lush_comment_form_allowed_tags' );
function lush_comment_form_allowed_tags( $defaults ) {$defaults['comment_notes_after'] = '';return $defaults;
}
//* Customise Post Date
add_filter( 'genesis_post_date_shortcode', 'lush_post_date_shortcode', 10, 2 );
function lush_post_date_shortcode( $output, $atts ) {
	return sprintf(
		'<span class="my-date" title="%4$s">%1$s<span class="my-date-day">%2$s</span> <span class="my-date-month">%3$s</span> <span class="my-date-year">%5$s</span></span>',
		$atts['label'],
		get_the_time( 'j' ),
		get_the_time( 'M' ),
		get_the_time( 'Y-m-d\TH:i:sO' ),
		get_the_time( 'Y' )
	);}
//* Custom Tags and Categories text
add_filter( 'genesis_post_meta', 'lush_post_meta_filter' );
function lush_post_meta_filter($post_meta) {
if (!is_page()) {
$post_meta = '[post_categories sep="/" before="Categories: "] [post_tags sep="/" before="Tags: "]';return $post_meta;
}}
//* Change the footer text
add_filter('genesis_footer_creds_text', 'lush_footer_creds_filter');
function lush_footer_creds_filter( $creds ) {
echo'<p class=footer-credits>';
	$creds = '[footer_copyright] ' . get_bloginfo('name') .'. Made with pride! with <span class="dashicons dashicons-heart"></span> using a <a href="http://exempel.se/">MY OWN DESIGN</a>.';
	return $creds;
	echo'</p>';
}
//* Register After-Entry widget areas
genesis_register_sidebar( array(
    'id'=> 'after-entry',
    'name'=> __( 'After Entry', 'lush' ),
    'description'=> __( 'This is the bottom widget section.', 'lush' ),
));
//* Hooks after-entry widget area to single posts
add_action( 'genesis_entry_footer', 'lush_bottom_widget'  ); 
function lush_bottom_widget() {
    if ( ! is_singular( 'post' ) )return;
    genesis_widget_area( 'after-entry', array(
		'before'=> '<div class="after-entry"><div class="wrap">',
		'after'=> '</div></div>',
    ));}
//* Modify the length of post excerpts
add_filter( 'excerpt_length', 'lush_excerpt_length' );
function lush_excerpt_length( $length ) {return 50; 
}
//* Add Featured images above pages and posts
add_action( 'genesis_before_entry', 'lush_display_featured_image' );
function lush_display_featured_image() {
	if ( ! is_singular( array( 'post', 'page' ) ) ) {return;
	}
	if ( ! has_post_thumbnail() ) {return;
	}
//* Display featured image above content
	echo '<div class="singular-featured-image">';genesis_image( array( 'size' => 'singular-featured-thumb' ) );echo '</div>';
}
// Add Read More Link to Excerpts
add_filter('excerpt_more', 'get_read_more_link');
add_filter( 'the_content_more_link', 'get_read_more_link' );
function get_read_more_link() {return '...&nbsp;<a class="more-link" href="' . get_permalink() . '">Read&nbsp;More</a>';
}
//* Customize search form input box text
add_filter( 'genesis_search_text', 'lush_search_text' );
function lush_search_text( $text ) {
	return esc_attr( 'Search this website...' );
}
// ------------------ Woocommerce ------------------------ //
// Add WooCommerce support for Genesis layouts (sidebar, full-width, etc)
add_post_type_support( 'product', 'genesis-layouts' );

// Unhook WooCommerce Sidebar - use Genesis Sidebars instead
remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar', 10 );

 //* Unhook the WooCommerce wrappers
remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10);
remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10);

//* Hook in functions to display the wrappers
add_action('woocommerce_before_main_content', 'lush_wrapper_start', 10);
add_action('woocommerce_after_main_content', 'lush_wrapper_end', 10);

// Add opening wrapper before WooCommerce loop
function lush_wrapper_start() {
    do_action( 'genesis_before_content_sidebar_wrap' );
    genesis_markup( array(
        'html5'=> '<div %s>',
        'xhtml'=> '<div id="content-sidebar-wrap">',
        'context'=> 'content-sidebar-wrap',
    ));    
    do_action( 'genesis_before_content' );
    genesis_markup( array(
        'html5'=> '<main %s>',
        'xhtml'=> '<div id="content" class="hfeed">',
        'context'=> 'content',
    ));
    do_action( 'genesis_before_loop' );  
}   
/* Add closing wrapper after WooCommerce loop */
function lush_wrapper_end() {
  
    do_action( 'genesis_after_loop' );
    genesis_markup( array(
        'html5'=> '</main>', //* end .content
        'xhtml'=> '</div>', //* end #content
    ));
    do_action( 'genesis_after_content' );
    echo '</div>'; 
    do_action( 'genesis_after_content_sidebar_wrap' );
}
// Remove WooCommerce breadcrumbs, using Genesis crumbs instead.
add_action( 'get_header', 'lush_remove_wc_breadcrumbs' );
function lush_remove_wc_breadcrumbs() {remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20, 0 );
}
// Remove WooCommerce Theme Support admin message
add_theme_support( 'woocommerce' );

// Change number of products per row to 3
add_filter('loop_shop_columns', 'loop_columns');
if (!function_exists('loop_columns')) {function loop_columns() {return 3; 
}} 
add_filter ( 'woocommerce_product_thumbnails_columns', 'lush_thumb_cols' );
function lush_thumb_cols() {return 3;
}
add_filter( 'loop_shop_per_page', create_function( '$cols', 'return 6;' ), 20 );
add_action( 'genesis_before', 'lush_remove_store_sidebar' );
function lush_remove_store_sidebar() {
	if ( is_active_sidebar( 'store-sidebar' ) && (is_shop() || is_product() || is_cart() || is_checkout() ) ) {
		remove_action( 'genesis_sidebar', 'genesis_do_sidebar' );
		add_action( 'genesis_sidebar', 'lush_do_store_sidebar' );
		function lush_do_store_sidebar() {
			echo '<div id="sidebar" class="sidebar widget-area">';
				genesis_structural_wrap( 'sidebar' );
				do_action( 'genesis_before_sidebar_widget_area' );
				dynamic_sidebar( 'store-sidebar' );
				do_action( 'genesis_after_sidebar_widget_area' );
				genesis_structural_wrap( 'sidebar', 'close' );
			echo '</div>';
		}}}				
genesis_register_sidebar( array(
    'id'=> 'store-sidebar',
	'name'=> 'Store Sidebar',
	'description'=> 'This is the primary sidebar for the store.',
));