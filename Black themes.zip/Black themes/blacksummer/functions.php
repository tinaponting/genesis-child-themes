<?php
//* Start the engine to load the core files
include_once( get_template_directory() . '/lib/init.php' );
define( 'CHILD_THEME_NAME', 'Black Summer' );
define( 'CHILD_THEME_VERSION', '1.0' );
add_theme_support( 'html5' );
add_theme_support( 'genesis-responsive-viewport' );
add_action( 'genesis_meta', 'lush_viewport_meta_tag' );
function lush_viewport_meta_tag() {echo '<meta name="viewport" content="width=device-width, initial-scale=1.0"/>';
}
add_action( 'wp_enqueue_scripts', 'lush_enqueue_script' );
function lush_enqueue_script() {
wp_enqueue_style( 'dashicons' );
}
add_theme_support( 'genesis-custom-header', array( 'width' => 960, 'height' => 200 ) );
genesis_unregister_layout( 'content-sidebar-sidebar' );
genesis_unregister_layout( 'sidebar-sidebar-content' );
genesis_unregister_layout( 'sidebar-content-sidebar' );
unregister_sidebar(  'header-right'  );
unregister_sidebar( 'sidebar-alt' );
add_theme_support( 'genesis-menus', array( 'primary' => __( 'Primary Navigation Menu', 'genesis' ) ) );
add_theme_support( 'custom-background' );
add_theme_support( 'genesis-footer-widgets', 3 );
genesis_set_default_layout( 'content-sidebar' );

//* Add Color Style Options
add_theme_support( 'genesis-style-selector', array(
'lush-azure'=> __( 'Azure', 'lush' ),
'lush-coral'=> __( 'Coral', 'lush' ),
'lush-cyan'=> __( 'Cyan', 'lush' ),
'lush-fuchsia'=> __( 'Fuchsia', 'lush' ),
'lush-golden'=> __( 'Golden', 'lush' ),
'lush-hot-pink'=> __( 'Hot Pink', 'lush' ),
'lush-lavender'=> __( 'Lavender', 'lush' ),
'lush-lime'=> __( 'Lime', 'lush' ),
'lush-plum'=> __( 'Plum', 'lush' ),
'lush-salmon'=> __( 'Salmon', 'lush' ),
));
add_filter('body_class', 'string_body_class');
function string_body_class( $classes ) {
if ( isset( $_GET['color'] ) ) :$classes[] = 'lush-' . sanitize_html_class( $_GET['color'] );endif;return $classes;
}
add_filter( 'get_the_author_genesis_author_box_single', '__return_true' );
add_filter( 'genesis_author_box_title', 'lush_author_box_title' );
function lush_author_box_title() {return '<strong>About the Author</strong>';
}
add_filter( 'genesis_author_box_gravatar_size', 'lush_author_box_gravatar_size' );
function lush_author_box_gravatar_size( $size ) {return '200';
}
add_filter( 'genesis_comment_list_args', 'lush_comments_gravatar' );
function lush_comments_gravatar( $args ) {$args['avatar_size'] = 80;return $args;
}
add_filter( 'genesis_gravatar_sizes', 'lush_user_profile' );
function lush_user_profile( $sizes ) {
	$sizes['Small'] = 85;
	$sizes['Medium'] = 125;
	$sizes['Large'] = 240;
	$sizes['Extra Large'] = 280;
	$sizes['Extra Large Image'] = 340;return $sizes;
}
add_filter( 'comment_form_defaults', 'lush_comment_form_allowed_tags' );
function lush_comment_form_allowed_tags( $defaults ) {$defaults['comment_notes_after'] = '';return $defaults;
}
add_filter( 'genesis_post_date_shortcode', 'lush_post_date_shortcode', 10, 2 );
function lush_post_date_shortcode( $output, $atts ) {
	return sprintf(
		'<span class="my-date" title="%4$s">%1$s<span class="my-date-day">%2$s</span> <span class="my-date-month">%3$s</span> <span class="my-date-year">%5$s</span></span>',
		$atts['label'],
		get_the_time( 'j' ),
		get_the_time( 'M' ),
		get_the_time( 'Y-m-d\TH:i:sO' ),
		get_the_time( 'Y' )
	);}
add_filter( 'genesis_post_meta', 'lush_post_meta_filter' );
function lush_post_meta_filter($post_meta) {
if (!is_page()) {$post_meta = '[post_categories sep="/" before="Categories: "] [post_tags sep="/" before="Tags: "]';return $post_meta;
}}
//* Change the footer text
add_filter('genesis_footer_creds_text', 'lush_footer_creds_filter');
function lush_footer_creds_filter( $creds ) {
echo'<p class=footer-credits>';
	$creds = '[footer_copyright] ' . get_bloginfo('name') .'. Made by pride <span class="dashicons dashicons-heart"></span> using a <a href="http://exempel.se/"Made by me</a>.';
	return $creds;echo'</p>';
}
genesis_register_sidebar( array(
    'id'=> 'after-entry',
    'name'=> __( 'After Entry', 'lush' ),
    'description'=> __( 'This is the bottom widget section.', 'lush' ),
));
add_action( 'genesis_entry_footer', 'lush_bottom_widget'  ); 
function lush_bottom_widget() {
    if ( ! is_singular( 'post' ) )return;
    genesis_widget_area( 'after-entry', array(
		'before'=> '<div class="after-entry"><div class="wrap">',
		'after'=> '</div></div>',
    ));}
add_filter( 'excerpt_length', 'lush_excerpt_length' );
function lush_excerpt_length( $length ) {return 50; 
}
add_action( 'genesis_before_entry', 'lush_display_featured_image' );
function lush_display_featured_image() {if ( ! is_singular( array( 'post', 'page' ) ) ) {return;
	}
	if ( ! has_post_thumbnail() ) {return;
	}
echo '<div class="singular-featured-image">';genesis_image( array( 'size' => 'singular-featured-thumb' ) );echo '</div>';
}
add_filter('excerpt_more', 'get_read_more_link');
add_filter( 'the_content_more_link', 'get_read_more_link' );
function get_read_more_link() {return '...&nbsp;<a class="more-link" href="' . get_permalink() . '">Read&nbsp;More</a>';
}
add_filter( 'genesis_search_text', 'lush_search_text' );
function lush_search_text( $text ) {return esc_attr( 'Search this website...' );
}
// ------------------ Woocommerce ------------------------ //
add_post_type_support( 'product', 'genesis-layouts' );
remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar', 10 );
remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10);
remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10);
add_action('woocommerce_before_main_content', 'lush_wrapper_start', 10);
add_action('woocommerce_after_main_content', 'lush_wrapper_end', 10);

// Add opening wrapper before WooCommerce loop
function lush_wrapper_start() {
    do_action( 'genesis_before_content_sidebar_wrap' );
    genesis_markup( array(
        'html5'=> '<div %s>',
        'xhtml'=> '<div id="content-sidebar-wrap">',
        'context'=> 'content-sidebar-wrap',
    ));
    do_action( 'genesis_before_content' );
    genesis_markup( array(
        'html5'=> '<main %s>',
        'xhtml'=> '<div id="content" class="hfeed">',
        'context'=> 'content',
    ));
    do_action( 'genesis_before_loop' );
}
function lush_wrapper_end() {
    do_action( 'genesis_after_loop' );
    genesis_markup( array(
        'html5'=> '</main>', 
        'xhtml'=> '</div>', 
    ));
    do_action( 'genesis_after_content' );
    echo '</div>'; 
    do_action( 'genesis_after_content_sidebar_wrap' );
}
add_action( 'get_header', 'lush_remove_wc_breadcrumbs' );
function lush_remove_wc_breadcrumbs() {remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20, 0 );
}
add_theme_support( 'woocommerce' );
add_filter('loop_shop_columns', 'loop_columns');
if (!function_exists('loop_columns')) {function loop_columns() {return 3;
}} 
add_filter ( 'woocommerce_product_thumbnails_columns', 'lush_thumb_cols' );
function lush_thumb_cols() {return 3;
}
add_filter( 'loop_shop_per_page', create_function( '$cols', 'return 6;' ), 20 );
add_action( 'genesis_before', 'lush_remove_store_sidebar' );
function lush_remove_store_sidebar() {
	if ( is_active_sidebar( 'store-sidebar' ) && (is_shop() || is_product() || is_cart() || is_checkout() ) ) {
		remove_action( 'genesis_sidebar', 'genesis_do_sidebar' );
		add_action( 'genesis_sidebar', 'lush_do_store_sidebar' );
		function lush_do_store_sidebar() {
			echo '<div id="sidebar" class="sidebar widget-area">';
				genesis_structural_wrap( 'sidebar' );
				do_action( 'genesis_before_sidebar_widget_area' );
				dynamic_sidebar( 'store-sidebar' );
				do_action( 'genesis_after_sidebar_widget_area' );
				genesis_structural_wrap( 'sidebar', 'close' );
			echo '</div>';
		}}}
genesis_register_sidebar( array(
    'id'=> 'store-sidebar',
	'name'=> 'Store Sidebar',
	'description'=> 'This is the primary sidebar for the store.',
));