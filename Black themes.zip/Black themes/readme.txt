Black summer and Blacklight are the most commontheme amongst female bloggers.

: Blacksummer - square corners.
Change row 82, to your own domain.

: Blacknight - with light rounded corners.
Change row 105 to your owm domain.

* WooCommerce