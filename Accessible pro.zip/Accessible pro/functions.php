<?php
//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );

//* Set Localization (do not remove)
load_child_theme_textdomain( 'accpro', apply_filters( 'child_theme_textdomain', get_stylesheet_directory() . '/languages', 'accpro' ) );

//* Child theme (do not remove)
define( 'CHILD_THEME_NAME', 'Accessible Pro Theme', 'accpro' );

//* Enqueue Google Fonts
add_action( 'wp_enqueue_scripts', 'genesis_accpro_fonts' );
function genesis_accpro_fonts() {
    wp_enqueue_style( 'accpro-font-awesome', '//netdna.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css', array(), '4.1.0' );
    wp_enqueue_style( 'dashicons' );
}

add_action( 'wp_enqueue_scripts', 'accpro_enqueue_home_scripts' );
/**
 * Enqueue Scripts
 */
wp_enqueue_script( 'accpro-responsive-menu', get_bloginfo( 'stylesheet_directory' ) . '/js/responsive-menu.js', array( 'jquery' ), '1.0.0' );
function accpro_enqueue_home_scripts() {
    add_action( 'wp_enqueue_scripts', 'accpro_front_page_enqueue_scripts' );
        if ( ! get_background_image() )return;

        //* Enqueue Backstretch scripts
        wp_enqueue_script( 'accpro-backstretch', get_bloginfo( 'stylesheet_directory' ) . '/js/backstretch.js', array( 'jquery' ), '1.0.0' );
        wp_enqueue_script( 'accpro-backstretch-set', get_bloginfo('stylesheet_directory').'/js/backstretch-set.js' , array( 'jquery', 'accpro-backstretch' ), '1.0.0' );
        wp_localize_script( 'accpro-backstretch-set', 'BackStretchImg', array( 'src' => str_replace( 'http:', '', get_background_image() ) ) );
	wp_enqueue_script( 'accpro-home', get_bloginfo( 'stylesheet_directory' ) . '/js/home.js', array( 'jquery' ), '1.0.0', true );
	wp_enqueue_script( 'localScroll', get_stylesheet_directory_uri() . '/js/jquery.localScroll.min.js', array( 'scrollTo' ), '1.2.8b', true );
	wp_enqueue_script( 'scrollTo', get_stylesheet_directory_uri() . '/js/jquery.scrollTo.min.js', array( 'jquery' ), '1.4.5-beta', true );

}
//* Add HTML5 markup structure
add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list' ) );

//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Add support for custom background
add_theme_support( 'custom-background' );

//* Add support for 1-column footer widgets
add_theme_support( 'genesis-footer-widgets', 1 );

// Remove the default Genesis footer widget areas
remove_action( 'genesis_before_footer', 'genesis_footer_widget_areas' );

//* Add new image sizes
add_image_size( 'portfolio', 340, 230, TRUE );

//* Register widget areas
genesis_register_sidebar( array(
	'id'          => 'home-hero',
	'name'        => __( 'Home Hero', 'accpro' ),
	'description' => __( 'This is the home hero widget area.', 'accpro' ),
) );

genesis_register_sidebar( array(
	'id'          => 'home-portfolio',
	'name'        => __( 'Home Portfolio', 'accpro' ),
	'description' => __( 'This is the home portfolio widget area.', 'accpro' ),
) );

genesis_register_sidebar( array(
	'id'          => 'home-team',
	'name'        => __( 'Home Team', 'accpro' ),
	'description' => __( 'This is the home team widget area.', 'accpro' ),
) );


//* Customize the entire footer
remove_action( 'genesis_footer', 'genesis_do_footer' );
add_action( 'genesis_footer', 'sr_custom_footer' );
function sr_custom_footer() {
    ?>
    <p>&copy; <?php echo date('Y'); ?> <a href="<?php echo get_site_url(); ?>"><?php echo get_bloginfo ( 'name' );  ?></a> &middot; All Rights Reserved &middot; Made by Pride! <a href="http://exempel.se" title="MY OWN DESIGN</a></p>
<?php
}