<?php
/**
 * Controls the homepage output.
 */

// Force content-sidebar layout setting
add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );

//* Add home featured widget
add_action( 'genesis_after_header', 'accpro_hero_widget', 1 );

// Remove the default Genesis loop
remove_action( 'genesis_loop', 'genesis_do_loop' );

// Add homepage widgets
add_action( 'genesis_loop', 'accpro_homepage_widgets' );

function accpro_hero_widget() {

	genesis_widget_area( 'home-hero', array(
		'before' => '<div id="home-hero"><div class="wrap">',
		'after'  => '</div></div>',
	) );
}

function accpro_homepage_widgets() {
    genesis_widget_area('home-portfolio', array(
        'before' => '<div id="home-portfolio"><div class="wrap">',
        'after' => '</div></div>',
    ));

    genesis_widget_area('home-team', array(
        'before' => '<div id="home-team"><div class="wrap">',
        'after' => '</div></div>',
    ));

}

add_action( 'genesis_before_footer', 'genesis_footer_widget_areas' );

//* Run the Genesis loop
genesis();