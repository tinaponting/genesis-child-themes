jQuery(function( $ ){
	
    $('.home-hero .wrap') .css({'height': (($(window).height()))+'px'});
    $(window).resize(function(){
        $('.home-hero .wrap') .css({'height': (($(window).height()))+'px'});
    });
    
    $(".home-hero .home-hero .widget:last-child").after('<p class="arrow"><a href="#home-portfolio"></a></p>');
    
    $.localScroll({
    	duration: 750
    });
	
});